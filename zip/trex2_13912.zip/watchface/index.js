﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_uvi_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'pozadi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 33,
              font_array: ["kroky_0.png","kroky_1.png","kroky_2.png","kroky_3.png","kroky_4.png","kroky_5.png","kroky_6.png","kroky_7.png","kroky_8.png","kroky_9.png"],
              padding: false,
              h_space: -10,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 163,
              y: 403,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 404,
              font_array: ["kroky_0.png","kroky_1.png","kroky_2.png","kroky_3.png","kroky_4.png","kroky_5.png","kroky_6.png","kroky_7.png","kroky_8.png","kroky_9.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'procenta.png',
              unit_tc: 'procenta.png',
              unit_en: 'procenta.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 61,
              font_array: ["kroky_0.png","kroky_1.png","kroky_2.png","kroky_3.png","kroky_4.png","kroky_5.png","kroky_6.png","kroky_7.png","kroky_8.png","kroky_9.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'mala_stupne.png',
              unit_tc: 'mala_stupne.png',
              unit_en: 'mala_stupne.png',
              negative_image: 'mala_zapor.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 98,
              y: 54,
              image_array: ["0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 102,
              font_array: ["kroky_0.png","kroky_1.png","kroky_2.png","kroky_3.png","kroky_4.png","kroky_5.png","kroky_6.png","kroky_7.png","kroky_8.png","kroky_9.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'mala_km.png',
              unit_tc: 'mala_km.png',
              unit_en: 'mala_km.png',
              dot_image: 'mala_carka.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 315,
              font_array: ["kroky_0.png","kroky_1.png","kroky_2.png","kroky_3.png","kroky_4.png","kroky_5.png","kroky_6.png","kroky_7.png","kroky_8.png","kroky_9.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 315,
              font_array: ["kroky_0.png","kroky_1.png","kroky_2.png","kroky_3.png","kroky_4.png","kroky_5.png","kroky_6.png","kroky_7.png","kroky_8.png","kroky_9.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 315,
              font_array: ["kroky_0.png","kroky_1.png","kroky_2.png","kroky_3.png","kroky_4.png","kroky_5.png","kroky_6.png","kroky_7.png","kroky_8.png","kroky_9.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 335,
              year_startY: 279,
              year_sc_array: ["mala_0.png","mala_1.png","mala_2.png","mala_3.png","mala_4.png","mala_5.png","mala_6.png","mala_7.png","mala_8.png","mala_9.png"],
              year_tc_array: ["mala_0.png","mala_1.png","mala_2.png","mala_3.png","mala_4.png","mala_5.png","mala_6.png","mala_7.png","mala_8.png","mala_9.png"],
              year_en_array: ["mala_0.png","mala_1.png","mala_2.png","mala_3.png","mala_4.png","mala_5.png","mala_6.png","mala_7.png","mala_8.png","mala_9.png"],
              year_zero: 1,
              year_space: -4,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 65,
              day_startY: 279,
              day_sc_array: ["mala_0.png","mala_1.png","mala_2.png","mala_3.png","mala_4.png","mala_5.png","mala_6.png","mala_7.png","mala_8.png","mala_9.png"],
              day_tc_array: ["mala_0.png","mala_1.png","mala_2.png","mala_3.png","mala_4.png","mala_5.png","mala_6.png","mala_7.png","mala_8.png","mala_9.png"],
              day_en_array: ["mala_0.png","mala_1.png","mala_2.png","mala_3.png","mala_4.png","mala_5.png","mala_6.png","mala_7.png","mala_8.png","mala_9.png"],
              day_zero: 1,
              day_space: -4,
              day_unit_sc: 'mala_tecka.png',
              day_unit_tc: 'mala_tecka.png',
              day_unit_en: 'mala_tecka.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 89,
              month_startY: 273,
              month_sc_array: ["mesic_1.png","mesic_2.png","mesic_3.png","mesic_4.png","mesic_5.png","mesic_6.png","mesic_7.png","mesic_8.png","mesic_9.png","mesic_10.png","mesic_11.png","mesic_12.png"],
              month_tc_array: ["mesic_1.png","mesic_2.png","mesic_3.png","mesic_4.png","mesic_5.png","mesic_6.png","mesic_7.png","mesic_8.png","mesic_9.png","mesic_10.png","mesic_11.png","mesic_12.png"],
              month_en_array: ["mesic_1.png","mesic_2.png","mesic_3.png","mesic_4.png","mesic_5.png","mesic_6.png","mesic_7.png","mesic_8.png","mesic_9.png","mesic_10.png","mesic_11.png","mesic_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 88,
              y: 157,
              week_en: ["den_1.png","den_2.png","den_3.png","den_4.png","den_5.png","den_6.png","den_7.png"],
              week_tc: ["den_1.png","den_2.png","den_3.png","den_4.png","den_5.png","den_6.png","den_7.png"],
              week_sc: ["den_1.png","den_2.png","den_3.png","den_4.png","den_5.png","den_6.png","den_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 2,
              hour_startY: 181,
              hour_array: ["hodiny_0.png","hodiny_1.png","hodiny_2.png","hodiny_3.png","hodiny_4.png","hodiny_5.png","hodiny_6.png","hodiny_7.png","hodiny_8.png","hodiny_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'oddelovac.png',
              hour_unit_tc: 'oddelovac.png',
              hour_unit_en: 'oddelovac.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 160,
              minute_startY: 181,
              minute_array: ["hodiny_0.png","hodiny_1.png","hodiny_2.png","hodiny_3.png","hodiny_4.png","hodiny_5.png","hodiny_6.png","hodiny_7.png","hodiny_8.png","hodiny_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'oddelovac.png',
              minute_unit_tc: 'oddelovac.png',
              minute_unit_en: 'oddelovac.png',
              minute_align: hmUI.align.CENTER_H,

              second_startX: 316,
              second_startY: 181,
              second_array: ["hodiny_0.png","hodiny_1.png","hodiny_2.png","hodiny_3.png","hodiny_4.png","hodiny_5.png","hodiny_6.png","hodiny_7.png","hodiny_8.png","hodiny_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_unit_sc: 'oddelovac.png',
              second_unit_tc: 'oddelovac.png',
              second_unit_en: 'oddelovac.png',
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}