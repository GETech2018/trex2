/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_background_bg_img1 = '';
		let normal_background_bg_img2 = '';
		let normal_background_bg_img3 = '';
		let normal_background_bg_img4 = '';
		let normal_background_bg_img5 = '';
		let normal_digital_clock_img_hour7 = '';
		let normal_digital_clock_img_minute8 = '';
		let normal_date_img_date_week_img10 = '';
		let normal_date_current_date_monthday11 = '';
		let normal_date_current_date_month12 = '';
		let normal_background_bg_img13 = '';
		let normal_date_current_date_year14 = '';
		let normal_background_bg_img15 = '';
		let normal_background_bg_img16 = '';
		let normal_background_bg_img17 = '';
		let normal_alarm_status19 = '';
		let normal_step_current_text_img21 = '';
		let normal_background_bg_img22 = '';
		let normal_distance_current_text_img24 = '';
		let normal_background_bg_img25 = '';
		let normal_background_bg_img27 = '';
		let normal_battery_current_text_img28 = '';
		let normal_calories_current_text_img30 = '';
		let normal_background_bg_img31 = '';
		let normal_heart_current_text_img33 = '';
		let normal_background_bg_img34 = '';
		let normal_weather_image_progress_img_level36 = '';
		let normal_temperature_current_text_img37 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 144,
					y: 234,
					w: 166,
					h: 161,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -6,
					y: 226,
					w: 468,
					h: 3,
					src: '0003.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 12,
					y: 145,
					w: 111,
					h: 3,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 333,
					y: 145,
					w: 111,
					h: 3,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 12,
					y: 306,
					w: 111,
					h: 3,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 333,
					y: 306,
					w: 111,
					h: 3,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_hour7 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 153,
					hour_startY: 70,
					hour_array: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
					hour_zero: true,
					hour_space: 5,
					hour_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_minute8 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 153,
					minute_startY: 240,
					minute_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
					minute_zero: true,
					minute_space: 5,
					minute_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img10 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 103,
					y: 28,
					week_en: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					week_tc: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					week_sc: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday11 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 336,
					day_startY: 175,
					day_sc_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					day_tc_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					day_en_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					day_zero: true,
					day_space: -6,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_month12 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 396,
					month_startY: 175,
					month_sc_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					month_tc_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					month_en_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					month_zero: true,
					month_space: -6,
					month_align: hmUI.align.CENTER_H,
					month_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 385,
					y: 175,
					w: 19,
					h: 58,
					src: '0042.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_year14 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					year_startX: 342,
					year_startY: 231,
					year_sc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					year_tc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					year_en_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					year_zero: true,
					year_space: -5,
					year_align: hmUI.align.CENTER_H,
					year_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 356,
					y: 152,
					w: 23,
					h: 29,
					src: '0053.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 410,
					y: 152,
					w: 29,
					h: 29,
					src: '0054.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img17 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 385,
					y: 277,
					w: 23,
					h: 29,
					src: '0055.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status19 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 213,
					y: -2,
					w: 28,
					h: 29,
					type: hmUI.system_status.CLOCK,
					src: '0056.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_current_text_img21 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 3,
					y: 178,
					font_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
					padding: false,
					h_space: -5,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 51,
					y: 152,
					w: 30,
					h: 29,
					src: '0067.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_current_text_img24 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: -3,
					y: 231,
					font_array: ["0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png"],
					padding: false,
					h_space: -5,
					dot_image: '0078.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 47,
					y: 277,
					w: 36,
					h: 29,
					src: '0079.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 166,
					y: 396,
					w: 125,
					h: 64,
					src: '0080.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_current_text_img28 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 187,
					y: 411,
					font_array: ["0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png"],
					padding: false,
					h_space: -5,
					unit_sc: '0091.png',
					unit_tc: '0091.png',
					unit_en: '0091.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_current_text_img30 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 38,
					y: 103,
					font_array: ["0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png"],
					padding: false,
					h_space: -4,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 60,
					y: 80,
					w: 38,
					h: 24,
					src: '0102.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_text_img33 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 48,
					y: 315,
					font_array: ["0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png"],
					padding: false,
					h_space: -4,
					invalid_image: '0113.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img34 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 60,
					y: 353,
					w: 38,
					h: 24,
					src: '0114.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_image_progress_img_level36 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 357,
					y: 85,
					image_array: ["0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0126.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_text_img37 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 353,
					y: 315,
					font_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
					padding: false,
					h_space: -4,
					unit_sc: ["0154.png"],
					unit_tc: ["0154.png"],
					unit_en: ["0154.png"],
					negative_image: ["0153.png"],
					invalid_image: ["0155.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}