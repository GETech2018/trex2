﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 390;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 390;
        let normal_digital_clock_img_time = ''
        let normal_humidity_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'FondJ.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -511,
              // y: 93,
              // font_array: ["a0.png","a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png","a8.png","a9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'a0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'a1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'a2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'a3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'a4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'a5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'a6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'a7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'a8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'a9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: -511,
                center_y: 93,
                pos_x: -511,
                pos_y: 93,
                angle: 0,
                src: 'a0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -511,
              // y: 363,
              // font_array: ["a0.png","a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png","a8.png","a9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'a0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'a1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'a2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'a3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'a4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'a5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'a6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'a7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'a8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'a9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: -511,
                center_y: 363,
                pos_x: -511,
                pos_y: 363,
                angle: 0,
                src: 'a0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 186,
              hour_startY: 1,
              hour_array: ["a0.png","a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png","a8.png","a9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 186,
              minute_startY: 274,
              minute_array: ["a0.png","a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png","a8.png","a9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 40,
              y: 103,
              src: 'Mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 321,
              y: 103,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 40,
              y: 103,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function text_update() {

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -511 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, -511 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}