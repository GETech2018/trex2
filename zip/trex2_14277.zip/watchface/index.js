﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

		let cc = 0
		
		let time24 = hmSensor.createSensor(hmSensor.id.TIME);
		let normal_24Hcheck =''

		function check24h(){
			if (time24.is24Hour){
				normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, true);
			}
			if (!time24.is24Hour){
				normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);
			}
		}
		
		let element_index = 0; 
        let element_count = 5;
		
		function click_PLUS() {
			element_index = (element_index + 1) % element_count;
			apply_content_switch();
		}
		
		function click_MINUS() {
			if (element_index == 0) {
			element_index = element_count - 1;
				} else {
			element_index = (element_index - 1) % element_count;
				}	
			apply_content_switch();
		}

		function apply_content_switch() {

			  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  Button_10.setProperty(hmUI.prop.VISIBLE, element_index == 0);

              normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_11.setProperty(hmUI.prop.VISIBLE, element_index == 1);

              normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  Button_12.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  
			  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  Button_13.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
			  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  Button_14.setProperty(hmUI.prop.VISIBLE, element_index == 4);

               if (element_index == 0) {
                 hmUI.showToast({text: 'STEPS'});
               };
               if (element_index == 1) {
                 hmUI.showToast({text: 'PULSE'});
               };
               if (element_index == 2) {
                 hmUI.showToast({text: 'CALORIES'});
               };
			   if (element_index == 3) {
                 hmUI.showToast({text: 'SUNRISE/SET'});
               };
			   if (element_index == 4) {
                 hmUI.showToast({text: 'WEATHER'});
               };
        };
		
		let menunumber_1 = 1
        let total_menu = 2

        function click_MENU() {
            if(menunumber_1==total_menu) {
            menunumber_1=1;
                UpdateMenuOne();
                }
            else {
                menunumber_1=menunumber_1+1;
                if(menunumber_1==2) {
                  UpdateMenuTwo();
                }
            }
        }

        function UpdateMenuOne(){
				normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_2.setProperty(hmUI.prop.VISIBLE, false);
				Button_3.setProperty(hmUI.prop.VISIBLE, false);
	
				Button_4.setProperty(hmUI.prop.VISIBLE, true);
				Button_5.setProperty(hmUI.prop.VISIBLE, true);
				Button_6.setProperty(hmUI.prop.VISIBLE, true);
				Button_7.setProperty(hmUI.prop.VISIBLE, true);
				Button_8.setProperty(hmUI.prop.VISIBLE, true);
				Button_9.setProperty(hmUI.prop.VISIBLE, true);
				Button_10.setProperty(hmUI.prop.VISIBLE, true);
				Button_11.setProperty(hmUI.prop.VISIBLE, true);
				Button_12.setProperty(hmUI.prop.VISIBLE, true);
				Button_13.setProperty(hmUI.prop.VISIBLE, true);
				Button_14.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdateMenuTwo(){
				normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				Button_2.setProperty(hmUI.prop.VISIBLE, true);
				Button_3.setProperty(hmUI.prop.VISIBLE, true);
				
				Button_4.setProperty(hmUI.prop.VISIBLE, false);
				Button_5.setProperty(hmUI.prop.VISIBLE, false);
				Button_6.setProperty(hmUI.prop.VISIBLE, false);
				Button_7.setProperty(hmUI.prop.VISIBLE, false);
				Button_8.setProperty(hmUI.prop.VISIBLE, false);
				Button_9.setProperty(hmUI.prop.VISIBLE, false);
				Button_10.setProperty(hmUI.prop.VISIBLE, false);
				Button_11.setProperty(hmUI.prop.VISIBLE, false);
				Button_12.setProperty(hmUI.prop.VISIBLE, false);
				Button_13.setProperty(hmUI.prop.VISIBLE, false);
				Button_14.setProperty(hmUI.prop.VISIBLE, false);
        }
		
		let colornumber_main = 1
        let totalcolors_main = 16
		let namecolor_main = ''
		let colorstring = '0xFFFF8000'
		
		function click_COLOR() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }
			if ( colornumber_main == 1) { namecolor_main = "O R A N G E"
				colorstring = '0xFFFF8000'
			}
			if ( colornumber_main == 2) { namecolor_main = "T E A L"
				colorstring = '0xFF008080'
			}
			if ( colornumber_main == 3) { namecolor_main = "O L I V E"
				colorstring = '0xFF808000'
			}
			if ( colornumber_main == 4) { namecolor_main = "M A R O O N"
				colorstring = '0xFF800000'
			}
			if ( colornumber_main == 5) { namecolor_main = "A Q U A"
				colorstring = '0xFF00FFFF'
			}
			if ( colornumber_main == 6) { namecolor_main = "G R E E N"
				colorstring = '0xFF008000'
			}
			if ( colornumber_main == 7) { namecolor_main = "R E D"
				colorstring = '0xFFFF0000'
			}
			if ( colornumber_main == 8) { namecolor_main = "Y E L L O W"
				colorstring = '0xFFFFFF00'
			}
			if ( colornumber_main == 9) { namecolor_main = "L I M E"
				colorstring = '0xFFBFFF00'
			}
			if ( colornumber_main == 10) { namecolor_main = "P U R P L E"
				colorstring = '0xFFA020F0'
			}
			if ( colornumber_main == 11) { namecolor_main = "B L U E"
				colorstring = '0xFF0000FF'
			}
			if ( colornumber_main == 12) { namecolor_main = "F U C H S I A"
				colorstring = '0xFFFF00FF'
			}
			if ( colornumber_main == 13) { namecolor_main = "S E P I A"
				colorstring = '0xFFA5694F'
			}
			if ( colornumber_main == 14) { namecolor_main = "A M B E R"
				colorstring = '0xFFFFBF00'
			}
			if ( colornumber_main == 15) { namecolor_main = "S I L V E R"
				colorstring = '0xFF999999'
			}
			if ( colornumber_main == 16) { namecolor_main = "W H I T E"
				colorstring = '0xFFFFFFFF'
			}
			if ( colornumber_main <= 16) { 
			
            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: colorstring,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	
			}   
			hmUI.showToast({text: namecolor_main });
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "hand_sec" + parseInt(colornumber_main) + ".png");
		}
		
		let brightnumber_main = 1
        let totalbrights_main = 2
		let namebright_main = ''
		let monthstring = 'month1.png'
		
		function click_BRIGHT() {
            if(brightnumber_main>=totalbrights_main) {
            brightnumber_main=1;
                }
            else {
                brightnumber_main=brightnumber_main+1;
            }
			if ( brightnumber_main == 1) { namebright_main = "L I G H T"
				monthstring = 'month1.png'
			}
			if ( brightnumber_main == 2) { namebright_main = "D A R K"
				monthstring = 'month2.png'
			}
			if ( brightnumber_main <= 2) { 
			
            normal_month_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: monthstring,
              center_x: 227,
              center_y: 227,
              posX: 227,
              posY: 227,
              start_angle: -30,
              end_angle: 330,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	
			}   
			hmUI.showToast({text: namebright_main });
			normal_battery_icon_img.setProperty(hmUI.prop.SRC, "mask" + parseInt(brightnumber_main) + ".png");
			normal_system_disconnect_img.setProperty(hmUI.prop.SRC, "st_bt" + parseInt(brightnumber_main) + ".png");
			normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "hand_min" + parseInt(brightnumber_main) + ".png");
			normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "hand_hour" + parseInt(brightnumber_main) + ".png");
		}
        // end user_functions.js

        let normal_background_bg = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_stress_icon_img = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFFFF8000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'month1.png',
              center_x: 227,
              center_y: 227,
              posX: 227,
              posY: 227,
              start_angle: -30,
              end_angle: 330,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'batt.png',
              center_x: 228,
              center_y: 132,
              x: 40,
              y: 79,
              start_angle: 0,
              end_angle: 180,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 140,
              font_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'drk24_10.png',
              unit_tc: 'drk24_10.png',
              unit_en: 'drk24_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 112,
              y: 214,
              week_en: ["drkwd1.png","drkwd2.png","drkwd3.png","drkwd4.png","drkwd5.png","drkwd6.png","drkwd7.png"],
              week_tc: ["drkwd1.png","drkwd2.png","drkwd3.png","drkwd4.png","drkwd5.png","drkwd6.png","drkwd7.png"],
              week_sc: ["drkwd1.png","drkwd2.png","drkwd3.png","drkwd4.png","drkwd5.png","drkwd6.png","drkwd7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 74,
              day_startY: 214,
              day_sc_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
              day_tc_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
              day_en_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym5_wea.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 178,
              y: 319,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 321,
              font_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'drk24_13.png',
              unit_tc: 'drk24_13.png',
              unit_en: 'drk24_13.png',
              imperial_unit_sc: 'drk24_13.png',
              imperial_unit_tc: 'drk24_13.png',
              imperial_unit_en: 'drk24_13.png',
              negative_image: 'drk24_12.png',
              invalid_image: 'drk24_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 214,
                y: 321,
                font_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'drk24_13.png',
                unit_tc: 'drk24_13.png',
                unit_en: 'drk24_13.png',
                imperial_unit_sc: 'drk24_13.png',
                imperial_unit_tc: 'drk24_13.png',
                imperial_unit_en: 'drk24_13.png',
                negative_image: 'drk24_12.png',
                invalid_image: 'drk24_11.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym4_srss.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 321,
              font_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'drk24_11.png',
              dot_image: 'drk24_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym3_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 321,
              font_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym2_hr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 321,
              font_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym1_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 321,
              font_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
			const deviceInfo1 = hmSetting.getDeviceInfo();
            normal_24Hcheck = hmUI.createWidget(hmUI.widget.IMG, {
              x: deviceInfo1.width / 454 * 0,
              y: deviceInfo1.height / 454 * 0,
              src: 'time_tm.png',
            show_level: hmUI.show_level.ALL,

            });
			
			check24h()
            // end user_script.js

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 283,
              am_y: 214,
              am_sc_path: 'drk_am.png',
              am_en_path: 'drk_am.png',
              pm_x: 283,
              pm_y: 214,
              pm_sc_path: 'drk_pm.png',
              pm_en_path: 'drk_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 309,
              hour_startY: 214,
              hour_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'drk24_14.png',
              hour_unit_tc: 'drk24_14.png',
              hour_unit_en: 'drk24_14.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 347,
              minute_startY: 214,
              minute_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'st_bt1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_hour1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'hand_hour1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_min1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'hand_min1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_sec1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'hand_sec1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'menu.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 321,
              font_array: ["drk24_00.png","drk24_01.png","drk24_02.png","drk24_03.png","drk24_04.png","drk24_05.png","drk24_06.png","drk24_07.png","drk24_08.png","drk24_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'drk24_10.png',
              unit_tc: 'drk24_10.png',
              unit_en: 'drk24_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'st_bt2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_hour2.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'hand_hour2.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_min2.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'hand_min2.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 189,
              w: 76,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_MENU();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 133,
              y: 77,
              w: 76,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_BRIGHT();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 245,
              y: 77,
              w: 76,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 279,
              y: 307,
              w: 47,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_PLUS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 128,
              y: 307,
              w: 47,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_MINUS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 95,
              w: 76,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 71,
              y: 203,
              w: 85,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 298,
              y: 203,
              w: 85,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 355,
              w: 95,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 307,
              w: 95,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 307,
              w: 95,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 307,
              w: 95,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 307,
              w: 95,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 307,
              w: 95,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

			if (cc ==0 ){
			  normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_2.setProperty(hmUI.prop.VISIBLE, false);
			  Button_3.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_11.setProperty(hmUI.prop.VISIBLE, false);

              normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_12.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_13.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_14.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

			check24h()
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}