/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_date_current_date_monthday2 = '';
		let normal_analog_clock_time_pointer_hour4 = '';
		let normal_analog_clock_time_pointer_minute5 = '';
		let normal_analog_clock_time_pointer_second6 = '';
		let normal_battery_pointer_progress_img_pointer8 = '';
		let normal_step_pointer_progress_img_pointer10 = '';
		let normal_battery_jumpable_img_click13 = '';
		let normal_step_jumpable_img_click14 = '';
		let normal_weather_jumpable_img_click15 = '';
		let normal_alarm_jumpable_img_click16 = '';
		let normal_countdown_jumpable_img_click17 = '';
		let normal_sleep_jumpable_img_click18 = '';
		let normal_sunrise_jumpable_img_click19 = '';
		let normal_heart_jumpable_img_click20 = '';
		let idle_background_bg_img22 = '';
		let idle_analog_clock_time_pointer_hour24 = '';
		let idle_analog_clock_time_pointer_minute25 = '';
		let idle_analog_clock_time_pointer_second26 = '';
		let idle_date_current_date_monthday28 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday2 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 202,
					day_startY: 392,
					day_sc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					day_tc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					day_en_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_hour4 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0013.png',
					hour_centerX: 227,
					hour_centerY: 227,
					hour_posX: 9,
					hour_posY: 132,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_minute5 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0014.png',
					minute_centerX: 227,
					minute_centerY: 227,
					minute_posX: 9,
					minute_posY: 206,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_second6 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0015.png',
					second_centerX: 227,
					second_centerY: 227,
					second_posX: 10,
					second_posY: 227,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_pointer_progress_img_pointer8 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0016.png',
					center_x: 99,
					center_y: 227,
					x: 7,
					y: 51,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_pointer_progress_img_pointer10 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0016.png',
					center_x: 360,
					center_y: 227,
					x: 7,
					y: 51,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_jumpable_img_click13 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 46,
					y: 177,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_jumpable_img_click14 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 308,
					y: 177,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_jumpable_img_click15 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 177,
					y: 355,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_jumpable_img_click16 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 177,
					y: -2,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_jumpable_img_click17 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 304,
					y: 43,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sleep_jumpable_img_click18 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 46,
					y: 44,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunrise_jumpable_img_click19 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 309,
					y: 311,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.SUN_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_jumpable_img_click20 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 48,
					y: 316,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_background_bg_img22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0017.png',
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_hour24 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0013.png',
					hour_centerX: 227,
					hour_centerY: 227,
					hour_posX: 9,
					hour_posY: 132,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_minute25 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0014.png',
					minute_centerX: 227,
					minute_centerY: 227,
					minute_posX: 9,
					minute_posY: 206,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_second26 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0015.png',
					second_centerX: 227,
					second_centerY: 227,
					second_posX: 10,
					second_posY: 227,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_current_date_monthday28 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 202,
					day_startY: 392,
					day_sc_array: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
					day_tc_array: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
					day_en_array: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}