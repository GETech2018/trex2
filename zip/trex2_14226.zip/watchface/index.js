﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 70,
              font_array: ["Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png","Sist_10.png"],
              padding: false,
              h_space: 0,
              angle: -28,
              unit_sc: 'Sist_12.png',
              unit_tc: 'Sist_12.png',
              unit_en: 'Sist_12.png',
              negative_image: 'Sist_11.png',
              invalid_image: 'Sist_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 213,
              y: 16,
              image_array: ["Meteo_01.png","Meteo_02.png","Meteo_03.png","Meteo_04.png","Meteo_05.png","Meteo_06.png","Meteo_07.png","Meteo_08.png","Meteo_09.png","Meteo_10.png","Meteo_11.png","Meteo_12.png","Meteo_13.png","Meteo_14.png","Meteo_15.png","Meteo_16.png","Meteo_17.png","Meteo_18.png","Meteo_19.png","Meteo_20.png","Meteo_21.png","Meteo_22.png","Meteo_23.png","Meteo_24.png","Meteo_25.png","Meteo_26.png","Meteo_27.png","Meteo_28.png","Meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 199,
              day_startY: 356,
              day_sc_array: ["Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png","Sec_10.png"],
              day_tc_array: ["Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png","Sec_10.png"],
              day_en_array: ["Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png","Sec_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 227,
              y: 257,
              week_en: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_tc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_sc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Punt_01.png',
              center_x: 58,
              center_y: 221,
              x: 41,
              y: 71,
              start_angle: -135,
              end_angle: 72,
              invalid_visible: false,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 216,
              y: 199,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png"],
              image_length: 28,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 326,
              font_array: ["Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png","Sist_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 41,
              y: 239,
              image_array: ["Bat_01.png","Bat_02.png","Bat_03.png","Bat_04.png","Bat_05.png","Bat_06.png","Bat_07.png","Bat_08.png","Bat_09.png","Bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 172,
              font_array: ["Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png","Sist_10.png"],
              padding: false,
              h_space: 0,
              angle: -28,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 273,
              y: 81,
              image_array: ["Step_01.png","Step_02.png","Step_03.png","Step_04.png","Step_05.png","Step_06.png","Step_07.png","Step_08.png"],
              image_length: 8,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 111,
              font_array: ["Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png","Sist_10.png"],
              padding: false,
              h_space: 0,
              angle: -28,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 66,
              y: 43,
              image_array: ["Cal_01.png","Cal_02.png","Cal_03.png","Cal_04.png","Cal_05.png","Cal_06.png","Cal_07.png","Cal_08.png"],
              image_length: 8,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 225,
              hour_startY: 281,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 334,
              minute_startY: 281,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 0,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 291,
              second_startY: 356,
              second_array: ["Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png","Sec_10.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 318,
              y: 281,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}