/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_background_bg_img2 = '';
		let normal_battery_current_text_img3 = '';
		let normal_temperature_current_text_img5 = '';
		let normal_date_img_date_monthday_high7 = '';
		let normal_date_img_date_monthday_high7_array = ['0028.png','0029.png','0030.png','0031.png','0032.png','0033.png','0034.png','0035.png','0036.png','0037.png'];
		let normal_date_img_date_monthday_low8 = '';
		let normal_date_img_date_monthday_low8_array = ['0038.png','0039.png','0040.png','0041.png','0042.png','0043.png','0044.png','0045.png','0046.png','0047.png'];
		let normal_date_img_date_week_img9 = '';
		let normal_background_bg_img11 = '';
		let normal_heart_current_text_img12 = '';
		let normal_step_current_text_img14 = '';
		let normal_background_bg_img15 = '';
		let normal_alarm_status17 = '';
		let normal_bt_status18 = '';
		let normal_analog_clock_time_pointer_hour20 = '';
		let normal_analog_clock_time_pointer_minute21 = '';
		let normal_analog_clock_time_pointer_second22 = '';
		let normal_battery_jumpable_img_click25 = '';
		let normal_weather_jumpable_img_click26 = '';
		let normal_alarm_jumpable_img_click27 = '';
		let normal_countdown_jumpable_img_click28 = '';
		let normal_stopwatch_jumpable_img_click29 = '';
		let normal_sleep_jumpable_img_click30 = '';
		let normal_heart_jumpable_img_click31 = '';
		let normal_step_jumpable_img_click32 = '';
		let idle_date_img_date_week_img34 = '';
		let idle_date_img_date_monthday_high35 = '';
		let idle_date_img_date_monthday_high35_array = ['0090.png','0091.png','0092.png','0093.png','0094.png','0095.png','0096.png','0097.png','0098.png','0099.png'];
		let idle_date_img_date_monthday_low36 = '';
		let idle_date_img_date_monthday_low36_array = ['0090.png','0091.png','0092.png','0093.png','0094.png','0095.png','0096.png','0097.png','0098.png','0099.png'];
		let idle_background_bg_img38 = '';
		let idle_analog_clock_time_pointer_hour39 = '';
		let idle_analog_clock_time_pointer_minute40 = '';
		let idle_analog_clock_time_pointer_second41 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 174,
					y: 310,
					w: 21,
					h: 27,
					src: '0003.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_current_text_img3 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 196,
					y: 312,
					font_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0014.png',
					unit_tc: '0014.png',
					unit_en: '0014.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_text_img5 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 176,
					y: 121,
					font_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0026.png"],
					unit_tc: ["0026.png"],
					unit_en: ["0026.png"],
					negative_image: ["0025.png"],
					invalid_image: ["0027.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_monthday_high7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 308,
					y: 234,
					w: 308,
					h: 234,
					src: '0037.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_img_date_monthday_low8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 349,
					y: 234,
					w: 349,
					h: 234,
					src: '0047.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_img_date_week_img9 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 306,
					y: 182,
					week_en: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
					week_tc: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
					week_sc: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 93,
					y: 166,
					w: 28,
					h: 24,
					src: '0055.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_text_img12 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 73,
					y: 196,
					font_array: ["0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
					padding: true,
					h_space: 0,
					invalid_image: '0066.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_current_text_img14 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 54,
					y: 236,
					font_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 95,
					y: 265,
					w: 28,
					h: 22,
					src: '0077.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status17 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 232,
					y: 355,
					w: 39,
					h: 41,
					type: hmUI.system_status.CLOCK,
					src: '0078.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status18 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 189,
					y: 360,
					w: 21,
					h: 30,
					type: hmUI.system_status.DISCONNECT,
					src: '0079.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_hour20 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0080.png',
					hour_centerX: 228,
					hour_centerY: 227,
					hour_posX: 26,
					hour_posY: 227,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_minute21 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0081.png',
					minute_centerX: 228,
					minute_centerY: 227,
					minute_posX: 26,
					minute_posY: 227,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_second22 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0082.png',
					second_centerX: 227,
					second_centerY: 227,
					second_posX: 27,
					second_posY: 227,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_jumpable_img_click25 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 191,
					y: 314,
					w: 1,
					h: 1,
					src: '',
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_jumpable_img_click26 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 177,
					y: 76,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_jumpable_img_click27 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 171,
					y: 356,
					w: 111,
					h: 61,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_jumpable_img_click28 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 298,
					y: 234,
					w: 101,
					h: 77,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stopwatch_jumpable_img_click29 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 296,
					y: 155,
					w: 101,
					h: 66,
					src: '',
					type: hmUI.data_type.STOP_WATCH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sleep_jumpable_img_click30 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 177,
					y: 195,
					w: 100,
					h: 90,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_jumpable_img_click31 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 53,
					y: 144,
					w: 100,
					h: 77,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_jumpable_img_click32 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 53,
					y: 233,
					w: 100,
					h: 68,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_date_img_date_week_img34 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 306,
					y: 184,
					week_en: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png"],
					week_tc: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png"],
					week_sc: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png"],
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_img_date_monthday_high35 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 308,
					y: 234,
					w: 308,
					h: 234,
					src: '0099.png',
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_date_img_date_monthday_low36 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 349,
					y: 234,
					w: 349,
					h: 234,
					src: '0099.png',
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_background_bg_img38 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0100.png',
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_hour39 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0101.png',
					hour_centerX: 227,
					hour_centerY: 227,
					hour_posX: 25,
					hour_posY: 227,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_minute40 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0081.png',
					minute_centerX: 228,
					minute_centerY: 227,
					minute_posX: 26,
					minute_posY: 227,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_second41 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0082.png',
					second_centerX: 227,
					second_centerY: 227,
					second_posX: 27,
					second_posY: 227,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateImageCombos();
				});

				function updateImageCombos() {
					normal_date_img_date_monthday_high7.setProperty(hmUI.prop.MORE, {
						src: normal_date_img_date_monthday_high7_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					normal_date_img_date_monthday_low8.setProperty(hmUI.prop.MORE, {
						src: normal_date_img_date_monthday_low8_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
					idle_date_img_date_monthday_high35.setProperty(hmUI.prop.MORE, {
						src: idle_date_img_date_monthday_high35_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					idle_date_img_date_monthday_low36.setProperty(hmUI.prop.MORE, {
						src: idle_date_img_date_monthday_low36_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
				};

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateImageCombos();

					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}