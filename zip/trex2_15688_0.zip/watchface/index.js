﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0

	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	
		let colornumber_main = 1
        let totalcolors_main = 2
		let namecolor_main = ' '
		
		//	переход в ночной режим (подставлением полупрозрачной картинки поверх циферблата)
	
		function click_Night() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }
			if ( colornumber_main == 1) namecolor_main = "ДНЕВНОЙ РЕЖИМ"
			if ( colornumber_main == 2) namecolor_main = "НОЧНОЙ РЕЖИМ"
			hmUI.showToast({text: namecolor_main });
			normal_image_img.setProperty(hmUI.prop.SRC, "night_" + parseInt(colornumber_main) + ".png");
			vibro(28);
		}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_current_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_battery_icon_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_image_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: lcddisplaycapssskcyrillic.ttf; FontSize: 29; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 452,
              y: 452,
              w: 34,
              h: 34,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 389,
              y: 278,
              src: '0071.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 347,
              y: 276,
              src: '0072.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 66,
              y: 75,
              src: '0070.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 295,
              y: 280,
              src: '0073.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 56,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: -1,
              invalid_image: '0065.png',
              dot_image: '0050.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 244,
              y: 92,
              image_array: ["WD_1_N.png","WD_2_NE.png","WD_3_E.png","WD_4_SE.png","WD_5_S.png","WD_6_SW.png","WD_7_W.png","WD_8_NW.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 95,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 95,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0077.png',
              unit_tc: '0077.png',
              unit_en: '0077.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 56,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 169,
              y: 14,
              w: 123,
              h: 28,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 148,
              y: 70,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 40,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0063.png',
              unit_tc: '0063.png',
              unit_en: '0063.png',
              negative_image: '0064.png',
              invalid_image: '0065.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 367,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 367,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 323,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 323,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0074.png',
              unit_tc: '0074.png',
              unit_en: '0074.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 373,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 410,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0077.png',
              unit_tc: '0077.png',
              unit_en: '0077.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 161,
              y: 323,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 280,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: '0080.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 110,
              // center_y: 225,
              // start_angle: -180,
              // end_angle: 180,
              // radius: 69,
              // line_width: 19,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 155,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 110,
              center_y: 225,
              start_angle: 180,
              end_angle: -180,
              radius: 60,
              line_width: 19,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale.setAlpha(155);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 204,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 227,
              month_startY: 144,
              month_sc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              month_tc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              month_en_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 179,
              day_startY: 144,
              day_sc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              day_tc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              day_en_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: '0079.png',
              day_unit_tc: '0079.png',
              day_unit_en: '0079.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 273,
              y: 144,
              week_en: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_tc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_sc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 274,
              am_y: 179,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 274,
              pm_y: 179,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 188,
              hour_startY: 183,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 307,
              minute_startY: 183,
              minute_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 397,
              second_startY: 203,
              second_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 285,
              y: 189,
              src: '0011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 246,
              // end_angle: 292,
              // radius: 215,
              // line_width: 21,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 155,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 292,
              end_angle: 246,
              radius: 205,
              line_width: 21,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(155);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 53,
              y: 318,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0077.png',
              unit_tc: '0077.png',
              unit_en: '0077.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'night_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 227,
              month_startY: 144,
              month_sc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              month_tc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              month_en_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 179,
              day_startY: 144,
              day_sc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              day_tc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              day_en_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: '0079.png',
              day_unit_tc: '0079.png',
              day_unit_en: '0079.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 273,
              y: 145,
              week_en: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_tc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_sc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 246,
              // end_angle: 292,
              // radius: 215,
              // line_width: 21,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 155,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 292,
              end_angle: 246,
              radius: 205,
              line_width: 21,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_circle_scale.setAlpha(155);

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 318,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0077.png',
              unit_tc: '0077.png',
              unit_en: '0077.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOD1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 274,
              am_y: 179,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 274,
              pm_y: 179,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 188,
              hour_startY: 183,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 307,
              minute_startY: 183,
              minute_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 397,
              second_startY: 203,
              second_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 285,
              y: 189,
              src: '0011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'night_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 42,
              y: 166,
              w: 130,
              h: 119,
              src: '0012.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 68,
              y: 364,
              w: 103,
              h: 48,
              src: '0012.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 122,
              y: 313,
              w: 95,
              h: 46,
              src: '0012.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 227,
              y: 318,
              w: 178,
              h: 44,
              src: '0012.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 131,
              w: 39,
              h: 174,
              src: '0012.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 210,
              y: 47,
              w: 81,
              h: 40,
              src: '0012.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 22,
              w: 95,
              h: 51,
              src: '0012.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 285,
              y: 365,
              w: 95,
              h: 47,
              src: '0012.png',
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 410,
              w: 95,
              h: 40,
              src: '0012.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 297,
              y: 41,
              w: 95,
              h: 47,
              src: '0012.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 395,
              y: 198,
              w: 57,
              h: 61,
              src: '0012.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 289,
              y: 271,
              w: 52,
              h: 43,
              src: '0012.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 197,
              y: 363,
              w: 84,
              h: 44,
              src: '0012.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 184,
              w: 189,
              h: 84,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0012.png',
              normal_src: '0012.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 307,
              w: 85,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0012.png',
              normal_src: '0012.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 174,
              y: 134,
              w: 250,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0012.png',
              normal_src: '0012.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 75,
              w: 70,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0012.png',
              normal_src: '0012.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 110,
                      center_y: 225,
                      start_angle: 180,
                      end_angle: -180,
                      radius: 60,
                      line_width: 19,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 292,
                      end_angle: 246,
                      radius: 205,
                      line_width: 21,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 292,
                      end_angle: 246,
                      radius: 205,
                      line_width: 21,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}