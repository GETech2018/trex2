﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
 
// Buttons OFF / ON (SETTINGS)

    let bt_on_text = "Settings mode ON"
    let bt_off_text = "Settings mode OFF"

// Select background (SETTINGS)

    let total_backgrounds = 14
    let background_prefix = "01_bg_"
    
// Alternate screens (SETTINGS)

    let mask_prefix = "00_mask_"       
  
///////////////////////////// NOT EDIT BELOW ///////////////////////////

/////////////  Buttons OFF / ON (SCRIPT) ////////////// 

    let switch_pos_buttons = 1
    let total_pos_buttons = 2
    
    function switch_buttons() {
    
        if(switch_pos_buttons == total_pos_buttons) {
            switch_pos_buttons = 1; // Buttons OFF

            if(switch_pos_compass == 1) normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, true);               // Compass OFF
            if(switch_pos_compass == 2) normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, true);  // Compass ON
           
            image_top_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            
    		Button_2.setProperty(hmUI.prop.VISIBLE, false);
    		Button_3.setProperty(hmUI.prop.VISIBLE, false);
    		Button_4.setProperty(hmUI.prop.VISIBLE, false);
    		Button_5.setProperty(hmUI.prop.VISIBLE, false);
    		Button_6.setProperty(hmUI.prop.VISIBLE, false);
    		Button_7.setProperty(hmUI.prop.VISIBLE, false);
    		Button_8.setProperty(hmUI.prop.VISIBLE, false);
    		Button_9.setProperty(hmUI.prop.VISIBLE, false);
    		Button_10.setProperty(hmUI.prop.VISIBLE, false);
    		Button_11.setProperty(hmUI.prop.VISIBLE, false);
                        
            hmUI.showToast({text: bt_off_text});
            
        }
        else {
           switch_pos_buttons = switch_pos_buttons + 1; // Buttons ON

           if(switch_pos_buttons == 2) {

                normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);

                image_top_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                        
          		Button_2.setProperty(hmUI.prop.VISIBLE, true);
          		Button_3.setProperty(hmUI.prop.VISIBLE, true);
          		Button_4.setProperty(hmUI.prop.VISIBLE, true);
          		Button_5.setProperty(hmUI.prop.VISIBLE, true);
          		Button_6.setProperty(hmUI.prop.VISIBLE, true);
          		Button_7.setProperty(hmUI.prop.VISIBLE, true);
          		Button_8.setProperty(hmUI.prop.VISIBLE, true);
          		Button_9.setProperty(hmUI.prop.VISIBLE, true);
          		Button_10.setProperty(hmUI.prop.VISIBLE, true);
          		Button_11.setProperty(hmUI.prop.VISIBLE, true);
                                
                hmUI.showToast({text: bt_on_text});                           
                    
            }
        } 
            
     };

//////////////  Select background (SCRIPTS) //////////////

    let background_number = 1

    function up_background() {
    
        if(screen_number == 1) { // Time screen ON
    
            if(background_number >= total_backgrounds) {
                background_number = 1;
            }
            else {
                background_number = background_number + 1;
            }

            change_style_bg();
        
        }
        
    };
    
    function down_background() {
    
        if(screen_number == 1) { // Time screen ON
        
            if(background_number <= 1) {
                background_number = total_backgrounds;
            }
            else {
                background_number = background_number - 1;
            }
                          
            change_style_bg();   
        
        }
        
    };

    function change_style_bg() {
       
        normal_background_bg_img.setProperty(hmUI.prop.SRC, background_prefix + parseInt(background_number) + ".png");
        normal_stress_icon_img.setProperty(hmUI.prop.SRC, background_prefix + parseInt(background_number) + ".png");

    };
  
/////////////  Compass OFF / ON (SCRIPT) //////////////
  
    let switch_pos_compass = 1
    let total_pos_compass = 2

    function switch_compass() {
    
        if(screen_number == 1) { // Time screen ON
         
            if(switch_pos_compass == total_pos_compass) {
               switch_pos_compass = 1; // Compass OFF

               if (compass) {
               
                    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                    normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                    
                    normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
                    
                }        

            }
            else {
               switch_pos_compass = switch_pos_compass + 1; // Compass ON

               if(switch_pos_compass == 2) {
                   if (compass)  {
                        
                        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                        
                        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
                        
                    }        
                        
                }
            }
            
        }           
          
    };

//////////////  Alternate screens (SCRIPTS) //////////////

    let screen_number = 1    

    function button_time() {
    
        screen_number = 1

        FORECAST_OFF();
        WEATHER_OFF();
        DATE_OFF();
        MEASURES_OFF();
        HEALTH_OFF();
        TIME_ON();
        
        change_screen_mask();
          
    };
    
    function button_weather() {
    
        screen_number = 2

        FORECAST_OFF();
        WEATHER_ON();
        DATE_OFF();
        MEASURES_OFF();
        HEALTH_OFF();
        TIME_OFF();
        
        change_screen_mask();
          
    };
    
    function button_measures() {
    
        screen_number = 3

        FORECAST_OFF();
        WEATHER_OFF();
        DATE_OFF();
        MEASURES_ON();
        HEALTH_OFF();
        TIME_OFF();
        
        change_screen_mask();
          
    };

    function button_date() {
    
        screen_number = 4 

        FORECAST_OFF();
        WEATHER_OFF();
        DATE_ON();
        MEASURES_OFF();
        HEALTH_OFF();
        TIME_OFF();
        
        change_screen_mask();
          
    };
    
    function button_health() {
    
        screen_number = 5 

        FORECAST_OFF();
        WEATHER_OFF();
        DATE_OFF();
        MEASURES_OFF();
        HEALTH_ON();
        TIME_OFF();
        
        change_screen_mask();
          
    };
    
    function button_forecast() {
    
        screen_number = 6 

        FORECAST_ON();
        WEATHER_OFF();
        DATE_OFF();
        MEASURES_OFF();
        HEALTH_OFF();
        TIME_OFF();
        
        change_screen_mask();
               
    };
  
///////  AUX SCRIPTS  ///////
    
    function change_screen_mask() {
       
        normal_battery_icon_img.setProperty(hmUI.prop.SRC, mask_prefix + parseInt(screen_number) + ".png");
        
    };    
    
    function FORECAST_ON() {

        normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);

    };

    function WEATHER_ON() {

        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_city_name_text.setProperty(hmUI.prop.VISIBLE, true);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);

    };

    function DATE_ON() {

        normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
        normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, true);

    };

    function MEASURES_ON() {

        normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

    };

    function HEALTH_ON() {

        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

    };

    function TIME_ON() {

        normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, true);
        if(switch_pos_compass == 1) { // Compass OFF
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
            normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        };
        if(switch_pos_compass == 2) { // Compass ON
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        };
        normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);

    };

    function FORECAST_OFF() {

        normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);

    };

    function WEATHER_OFF() {

        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

    };

    function DATE_OFF() {

        normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
        normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);

    };

    function MEASURES_OFF() {

        normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

    };

    function HEALTH_OFF() {

        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

    };

    function TIME_OFF() {

        normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);

    };
              
////////////////////////////////////////////////////////////////////////////////////////////////

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_icon_img = ''
        let normal_forecast_date_week_img = new Array(3);
        let normal_forecast_date_week_img_array = ['08_wd_forecast_1.png', '08_wd_forecast_2.png', '08_wd_forecast_3.png', '08_wd_forecast_4.png', '08_wd_forecast_5.png', '08_wd_forecast_6.png', '08_wd_forecast_7.png'];
        let normal_forecast_average_text_img = new Array(3);
        let normal_forecast_image_progress_img_level = new Array(3);
        let normal_forecast_image_array = ['09_weather_01.png', '09_weather_02.png', '09_weather_03.png', '09_weather_04.png', '09_weather_05.png', '09_weather_06.png', '09_weather_07.png', '09_weather_08.png', '09_weather_09.png', '09_weather_10.png', '09_weather_11.png', '09_weather_12.png', '09_weather_13.png', '09_weather_14.png', '09_weather_15.png', '09_weather_16.png', '09_weather_17.png', '09_weather_18.png', '09_weather_19.png', '09_weather_20.png', '09_weather_21.png', '09_weather_22.png', '09_weather_23.png', '09_weather_24.png', '09_weather_25.png', '09_weather_26.png', '09_weather_27.png', '09_weather_28.png', '09_weather_29.png'];
        let normal_stress_icon_img = ''
        let normal_temperature_icon_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_uvi_text_text_img = ''
        let normal_uvi_text_separator_img = ''
        let normal_year_icon_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_moon_high_text_img = ''
        let normal_moon_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_altimeter_icon_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_fat_burning_current_separator_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_second = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_compass_icon_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_compass_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_img_time_second = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_stress_icon_img = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 83,
              // y: 188,
              // ColumnWidth: 104,
              // DaysCount: 3,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 83,
              y: 188,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            // normal_forecast_icon_img = hmUI.createWidget(hmUI.widget.IMG_Options, {
              // x: -83,
              // y: -188,
              // src: '00_fg_5.png',
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              normal_forecast_icon_img = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
              x: -83,
              y: -188,
              src: '00_fg_5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };

            // normal_forecast_date_week_img = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 3,
              // y: -60,
              // image_array: ["08_wd_forecast_1.png","08_wd_forecast_2.png","08_wd_forecast_3.png","08_wd_forecast_4.png","08_wd_forecast_5.png","08_wd_forecast_6.png","08_wd_forecast_7.png"],
              // image_length: 7,
              // type: hmUI.data_type.forecast_date_week_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_date_week_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 3 + i*104,
                  y: -60,
                  src: normal_forecast_date_week_img_array[0],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_average_text_img = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG_Options, {
              // x: -24,
              // y: 102,
              // font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              // padding: false,
              // h_space: 0,
              // unit_en: '10_degree_L.png',
              // imperial_unit_en: '10_degree_L.png',
              // negative_image: '10_dash_L.png',
              // invalid_image: '10_null_L.png',
              // dot_image: '10_dash_L.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.forecast_average_text_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_average_text_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG, {
                  x: -24 + i*104,
                  y: 102,
                  font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '10_degree_L.png',
                  unit_tc: '10_degree_L.png',
                  unit_en: '10_degree_L.png',
                  negative_image: '10_dash_L.png',
                  align_h: hmUI.align.CENTER_H,
                  // type: hmUI.data_type.FORECAST_NUMBER_MAX,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 0,
              // y: 0,
              // image_array: ["09_weather_01.png","09_weather_02.png","09_weather_03.png","09_weather_04.png","09_weather_05.png","09_weather_06.png","09_weather_07.png","09_weather_08.png","09_weather_09.png","09_weather_10.png","09_weather_11.png","09_weather_12.png","09_weather_13.png","09_weather_14.png","09_weather_15.png","09_weather_16.png","09_weather_17.png","09_weather_18.png","09_weather_19.png","09_weather_20.png","09_weather_21.png","09_weather_22.png","09_weather_23.png","09_weather_24.png","09_weather_25.png","09_weather_26.png","09_weather_27.png","09_weather_28.png","09_weather_29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 0 + i*104,
                  y: 0,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '01_bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_7.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 152,
              y: 208,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFE6E6E6,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 186,
              y: 126,
              image_array: ["09_weather_01.png","09_weather_02.png","09_weather_03.png","09_weather_04.png","09_weather_05.png","09_weather_06.png","09_weather_07.png","09_weather_08.png","09_weather_09.png","09_weather_10.png","09_weather_11.png","09_weather_12.png","09_weather_13.png","09_weather_14.png","09_weather_15.png","09_weather_16.png","09_weather_17.png","09_weather_18.png","09_weather_19.png","09_weather_20.png","09_weather_21.png","09_weather_22.png","09_weather_23.png","09_weather_24.png","09_weather_25.png","09_weather_26.png","09_weather_27.png","09_weather_28.png","09_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 145,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_L.png',
              unit_tc: '10_degree_L.png',
              unit_en: '10_degree_L.png',
              imperial_unit_sc: '10_degree_L.png',
              imperial_unit_tc: '10_degree_L.png',
              imperial_unit_en: '10_degree_L.png',
              negative_image: '10_dash_L.png',
              invalid_image: '10_null_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 294,
                y: 145,
                font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: '10_degree_L.png',
                unit_tc: '10_degree_L.png',
                unit_en: '10_degree_L.png',
                imperial_unit_sc: '10_degree_L.png',
                imperial_unit_tc: '10_degree_L.png',
                imperial_unit_en: '10_degree_L.png',
                negative_image: '10_dash_L.png',
                invalid_image: '10_null_L.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 145,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_L.png',
              unit_tc: '10_degree_L.png',
              unit_en: '10_degree_L.png',
              imperial_unit_sc: '10_degree_L.png',
              imperial_unit_tc: '10_degree_L.png',
              imperial_unit_en: '10_degree_L.png',
              negative_image: '10_dash_L.png',
              invalid_image: '10_null_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 77,
                y: 145,
                font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: '10_degree_L.png',
                unit_tc: '10_degree_L.png',
                unit_en: '10_degree_L.png',
                imperial_unit_sc: '10_degree_L.png',
                imperial_unit_tc: '10_degree_L.png',
                imperial_unit_en: '10_degree_L.png',
                negative_image: '10_dash_L.png',
                invalid_image: '10_null_L.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 67,
              font_array: ["02_XL_0.png","02_XL_1.png","02_XL_2.png","02_XL_3.png","02_XL_4.png","02_XL_5.png","02_XL_6.png","02_XL_7.png","02_XL_8.png","02_XL_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_XL.png',
              unit_tc: '10_degree_XL.png',
              unit_en: '10_degree_XL.png',
              imperial_unit_sc: '10_degree_XL.png',
              imperial_unit_tc: '10_degree_XL.png',
              imperial_unit_en: '10_degree_XL.png',
              negative_image: '10_dash_XL.png',
              invalid_image: '10_null_XL.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 178,
                y: 67,
                font_array: ["02_XL_0.png","02_XL_1.png","02_XL_2.png","02_XL_3.png","02_XL_4.png","02_XL_5.png","02_XL_6.png","02_XL_7.png","02_XL_8.png","02_XL_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: '10_degree_XL.png',
                unit_tc: '10_degree_XL.png',
                unit_en: '10_degree_XL.png',
                imperial_unit_sc: '10_degree_XL.png',
                imperial_unit_tc: '10_degree_XL.png',
                imperial_unit_en: '10_degree_XL.png',
                negative_image: '10_dash_XL.png',
                invalid_image: '10_null_XL.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 350,
              image_array: ["13_wind_1.png","13_wind_2.png","13_wind_3.png","13_wind_4.png","13_wind_5.png","13_wind_6.png","13_wind_7.png","13_wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 315,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 255,
              src: '10_wind_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 315,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_M.png',
              unit_tc: '10_percent_M.png',
              unit_en: '10_percent_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 108,
              y: 255,
              src: '10_hum.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 315,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 255,
              src: '10_uv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_year_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 257,
              year_startY: 237,
              year_sc_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              year_tc_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              year_en_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 98,
              y: 160,
              week_en: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              week_tc: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              week_sc: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 103,
              day_startY: 237,
              day_sc_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              day_tc_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              day_en_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '10_slash_L.png',
              day_unit_tc: '10_slash_L.png',
              day_unit_en: '10_slash_L.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 180,
              month_startY: 237,
              month_sc_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              month_tc_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              month_en_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '10_slash_L.png',
              month_unit_tc: '10_slash_L.png',
              month_unit_en: '10_slash_L.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 336,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_sep_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 336,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_sep_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 317,
              image_array: ["12_moon_01.png","12_moon_02.png","12_moon_03.png","12_moon_04.png","12_moon_05.png","12_moon_06.png","12_moon_07.png","12_moon_08.png","12_moon_09.png","12_moon_10.png","12_moon_11.png","12_moon_12.png","12_moon_13.png","12_moon_14.png","12_moon_15.png","12_moon_16.png","12_moon_17.png","12_moon_18.png","12_moon_19.png","12_moon_20.png","12_moon_21.png","12_moon_22.png","12_moon_23.png","12_moon_24.png","12_moon_25.png","12_moon_26.png","12_moon_27.png","12_moon_28.png","12_moon_29.png","12_moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 75,
              src: '10_sun5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 96,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_sep_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 96,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_sep_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 263,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              negative_image: '10_dash_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 278,
              y: 314,
              src: '10_alt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 263,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 128,
              y: 316,
              src: '10_baro.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 152,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '10_dot_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 277,
              y: 89,
              src: '10_dist_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 152,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 126,
              y: 89,
              src: '10_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 120,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 202,
              y: 65,
              src: '10_bpm2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 175,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 120,
              src: '10_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 350,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_L.png',
              unit_tc: '10_percent_L.png',
              unit_en: '10_percent_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 295,
              src: '10_spo2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 295,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 240,
              src: '10_PAI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 175,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 120,
              src: '10_fat_burn.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 295,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 240,
              src: '10_stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 337,
              am_y: 268,
              am_sc_path: '10_AM.png',
              am_en_path: '10_AM.png',
              pm_x: 337,
              pm_y: 268,
              pm_sc_path: '10_PM.png',
              pm_en_path: '10_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 152,
              minute_startY: 239,
              minute_array: ["02_mm_0.png","02_mm_1.png","02_mm_2.png","02_mm_3.png","02_mm_4.png","02_mm_5.png","02_mm_6.png","02_mm_7.png","02_mm_8.png","02_mm_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 152,
              hour_startY: 99,
              hour_array: ["02_hh_0.png","02_hh_1.png","02_hh_2.png","02_hh_3.png","02_hh_4.png","02_hh_5.png","02_hh_6.png","02_hh_7.png","02_hh_8.png","02_hh_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 316,
              second_startY: 198,
              second_array: ["02_ss_0.png","02_ss_1.png","02_ss_2.png","02_ss_3.png","02_ss_4.png","02_ss_5.png","02_ss_6.png","02_ss_7.png","02_ss_8.png","02_ss_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 234,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_L.png',
              unit_tc: '10_percent_L.png',
              unit_en: '10_percent_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 75,
              y: 180,
              image_array: ["11_bat_1.png","11_bat_2.png","11_bat_3.png","11_bat_4.png","11_bat_5.png","11_bat_6.png","11_bat_7.png","11_bat_8.png","11_bat_9.png","11_bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_aro_7.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: '00_compass_7.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: '00_compass_7.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 234,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: '10_degree_L.png',
              unit_tc: '10_degree_L.png',
              unit_en: '10_degree_L.png',
              negative_image: '10_null_L.png',
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 79,
              y: 184,
              src: '10_compass_5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 207,
              y: 362,
              src: '10_BT_OFF_2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 335,
              y: 156,
              src: '10_AL5.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 337,
              am_y: 268,
              am_sc_path: '10_AM.png',
              am_en_path: '10_AM.png',
              pm_x: 337,
              pm_y: 268,
              pm_sc_path: '10_PM.png',
              pm_en_path: '10_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 152,
              minute_startY: 239,
              minute_array: ["02_mm_0.png","02_mm_1.png","02_mm_2.png","02_mm_3.png","02_mm_4.png","02_mm_5.png","02_mm_6.png","02_mm_7.png","02_mm_8.png","02_mm_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 152,
              hour_startY: 99,
              hour_array: ["02_hh_0.png","02_hh_1.png","02_hh_2.png","02_hh_3.png","02_hh_4.png","02_hh_5.png","02_hh_6.png","02_hh_7.png","02_hh_8.png","02_hh_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 316,
              second_startY: 198,
              second_array: ["02_ss_0.png","02_ss_1.png","02_ss_2.png","02_ss_3.png","02_ss_4.png","02_ss_5.png","02_ss_6.png","02_ss_7.png","02_ss_8.png","02_ss_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 234,
              font_array: ["03_L_0.png","03_L_1.png","03_L_2.png","03_L_3.png","03_L_4.png","03_L_5.png","03_L_6.png","03_L_7.png","03_L_8.png","03_L_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_L.png',
              unit_tc: '10_percent_L.png',
              unit_en: '10_percent_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 75,
              y: 180,
              image_array: ["11_bat_1.png","11_bat_2.png","11_bat_3.png","11_bat_4.png","11_bat_5.png","11_bat_6.png","11_bat_7.png","11_bat_8.png","11_bat_9.png","11_bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 207,
              y: 362,
              src: '10_BT_OFF_2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 335,
              y: 156,
              src: '10_AL5.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_top_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_menu.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 197,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_settings.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                switch_buttons()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 177,
              y: 90,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                up_background()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 177,
              y: 264,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                down_background()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 62,
              y: 189,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                switch_compass()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 0,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                button_date()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 350,
              y: 90,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                button_health()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 350,
              y: 285,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                button_forecast()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 374,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                button_time()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 285,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                button_weather()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 90,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 26,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                button_measures()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 313,
              y: 189,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

////////////  Initial visibility of elements //////////// 

    let cc = 0

    if (cc == 0 ){

        // BUTTONS
       
          image_top_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          
          Button_2.setProperty(hmUI.prop.VISIBLE, false);
          Button_3.setProperty(hmUI.prop.VISIBLE, false);
          Button_4.setProperty(hmUI.prop.VISIBLE, false);
          Button_5.setProperty(hmUI.prop.VISIBLE, false);
          Button_6.setProperty(hmUI.prop.VISIBLE, false);
          Button_7.setProperty(hmUI.prop.VISIBLE, false);
          Button_8.setProperty(hmUI.prop.VISIBLE, false);
          Button_9.setProperty(hmUI.prop.VISIBLE, false);
          Button_10.setProperty(hmUI.prop.VISIBLE, false);
          Button_11.setProperty(hmUI.prop.VISIBLE, false);
    
        // COMPASS

          normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
          
        // DATE
        
          normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
          normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
          normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
          normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        
        // HEALTH
        
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       
        // WEATHER
        
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
          normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        
        // MEASURES
        
          normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
     
    cc = 1;

    };

/////////////////////////////////////////////////////////////////////////////////////////////////

            // end user_script_end.js

            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 3; i++) {
                // DOW images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_img[i].setProperty(hmUI.prop.SRC, normal_forecast_date_week_img_array[dowIndex]);
                };
              
                // Number_Average
                let averageTemperature = '-';
                if (i < forecastData.count) averageTemperature = parseInt((forecastData.data[i].high + forecastData.data[i].low)/2).toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_average_text_img[i].setProperty(hmUI.prop.TEXT, averageTemperature);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

                }

              }); // Listener end

            };
            //end of ignored block

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}