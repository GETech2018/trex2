﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0

		let alt_var = 1
        let alt_all = 2
		let alt_text = ' '
		let pressure_array = read_pressure();
        let value = getPressureValue(pressure_array);
		
		let night_var = 1
        let night_all = 2
		let name_text = ' '
		let night_dig = 1
		
		let menu = 1
        let total_menu = 2
		
		let color_r = 1
        let colors_r = 8
		let namecolor_r = ' '
		
		let color_digt = 1
        let all_digt = 13
		let color_text = '0xFFFFFFFF'
		let namecolor_digt = ' '
		
		let color_bg = 7
        let totalcolors_bg = 8
		let namecolor_main = ' '
		
		let visabl_main = 1
		let totalvisabl_main = 5
		
		let xxx_clock_h = 80       
		let yyy_clock_h = 187
		let xxx_clock_m = 227
		let yyy_clock_m = 187
		let xxx_clock_s = 343
		let yyy_clock_s = 187
		let xxx_clock = 179
		let yyy_clock = 187
		let xxx_day = 167
		let yyy_day = 123
		let xxx_month = 233
		let yyy_month = 123
		let xxx_day_w = 75
		let yyy_day_w = 123
		let xxx_batt = 317
		let yyy_batt = 123

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
//# барометр в мм рт. ст.


function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}



function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}
//# конец барометр в мм рт. ст.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// переключение едениц измерения давления

		

function click_ALT() {
            if(alt_var>=alt_all) {
            alt_var=1;
                }
            else {
                alt_var=alt_var+1;
            }
			if ( alt_var == 1) { 
			alt_text = "мм рт. ст."  
			value = hPa_To_mmHg(value);              // перевод в мм.рт.ст.
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
		    }			
			if ( alt_var == 2) { 
			alt_text = "гПа" 
			value = getPressureValue(pressure_array);              // перевод в гПа
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
			}
			
			hmUI.showToast({text: alt_text });
			vibro(28);
									
		}

// конец переключение едениц измерения давления

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function clicker() {
	
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: parseInt(xxx_clock_h),
              hour_startY: parseInt(yyy_clock_h),
              hour_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: parseInt(xxx_clock_m),
              minute_startY: parseInt(yyy_clock_m),
              minute_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: parseInt(xxx_clock_s),
              second_startY: parseInt(yyy_clock_s),
              second_array: [night_dig + "_013.png",night_dig + "_014.png",night_dig + "_015.png",night_dig + "_016.png",night_dig + "_017.png",night_dig + "_018.png",night_dig + "_019.png",night_dig + "_020.png",night_dig + "_021.png",night_dig + "_022.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: xxx_clock,
              y: yyy_clock,
              src: night_dig + '_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			


		normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: xxx_day_w,
              y: yyy_day_w,
              week_en: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              week_tc: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              week_sc: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_date_img_date_month.setProperty(hmUI.prop.MORE, {
              month_startX: xxx_month,
              month_startY: yyy_month,
              month_sc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_tc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_en_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: xxx_day,
              day_startY: yyy_day,
              day_sc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_tc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_en_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


		normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: xxx_batt,
              y: yyy_batt,
              font_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              padding: false,
              h_space: 2,
              unit_sc: night_dig + '_int.png',
              unit_tc: night_dig + '_int.png',
              unit_en: night_dig + '_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
}




//	возврат в дневной режим 

		function click_Day() {

		name_text = "ДНЕВНОЙ РЕЖИМ";  // "DAYTIME MODE"
		night_dig = 1		
		
		 xxx_clock_h = 76
		 yyy_clock_h = 177
		 xxx_clock_m = 215
		 yyy_clock_m = 177
		 xxx_clock_s = 324
		 yyy_clock_s = 177
		 xxx_clock = 169
		 yyy_clock = 177
		 xxx_day = 158
		 yyy_day = 116
		 xxx_month = 220
		 yyy_month = 116
		 xxx_day_w = 71
		 yyy_day_w = 116
		 xxx_batt = 300
		 yyy_batt = 116

	
        clicker();
		
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: color_digt + '_am.png',
              am_en_path: color_digt + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: color_digt + '_pm.png',
              pm_en_path: color_digt + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
		
		normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	
		normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		
		normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + color_digt + ".png");
		
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_city_name_text.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		
		
		
		
		
		Button_1.setProperty(hmUI.prop.VISIBLE, true);      //   кнопка календарь
		Button_2.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка давление   
		Button_3.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка погодная программа
		Button_4.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка переход в ночной режим
		Button_5.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка изменения цвета
		Button_6.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка возврат в дневной режим
		
		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык статистика активностей (калории)
		normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //  жиросжигание
		normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);          //   ярлык шаги 
		normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык пульса 
		normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык температуры
		normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык будильник
		normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);       //   ярлык секундомер
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык батарея		
		
		hmUI.showToast({text: name_text });
			
		vibro(28);		
				
			}
			
//	конец возврата в дневной режим 			

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
//	переход в ночной режим 			
			
		function click_Night() {		
				
		name_text = "НОЧНОЙ РЕЖИМ"   // "NIGHT MODE"
		night_dig = 'AOD'
		
		 xxx_clock_h = 59
		 yyy_clock_h = 189
		 xxx_clock_m = 217
		 yyy_clock_m = 189
		 xxx_clock_s = 343
		 yyy_clock_s = 189
		 xxx_clock = 168
		 yyy_clock = 189
		 xxx_day = 236
		 yyy_day = 101
		 xxx_month = 334
		 yyy_month = 101
		 xxx_day_w = 69
		 yyy_day_w = 99
		 xxx_batt = 205
		 yyy_batt = 361


		clicker()
		
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: night_dig + '_am.png',
              am_en_path: night_dig + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: night_dig + '_pm.png',
              pm_en_path: night_dig + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
		
		
		normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);	
		normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
			
		
 
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
		normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
		
		
		
		
		
		
		
		Button_1.setProperty(hmUI.prop.VISIBLE, false);      //   кнопка календарь
		Button_2.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка давление   
		Button_3.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка погодная программа
		Button_4.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка переход в ночной режим
		Button_5.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка изменения цвета
		Button_6.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка возврат в дневной режим
		
		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык статистика активностей (калории)
		normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //  жиросжигание
		normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);          //   ярлык шаги 
		normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык пульса 
		normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык температуры
		normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык будильник
		normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);       //   ярлык секундомер
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык батарея
		
		
		normal_background_bg_img.setProperty(hmUI.prop.SRC, night_dig + ".png");
		
		
		hmUI.showToast({text: name_text });
		vibro(28);
	
		}
		
//	конец перехода в ночной режим 		

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  изменение цвета фона

function click_BG() {
            if(color_digt>=all_digt) {
            color_digt=1;
                }
            else { 
			color_digt=color_digt+1;   
			}
			
			if ( color_digt == 1) namecolor_main = "АКВА"
			if ( color_digt == 2) namecolor_main = "ЗЕЛЁНО-СИНИЙ"
			if ( color_digt == 3) namecolor_main = "ЗЕЛЁНЫЙ"
			if ( color_digt == 4) namecolor_main = "ЖЁЛТЫЙ"
			if ( color_digt == 5) namecolor_main = "ОРАНЖЕВЫЙ"
			if ( color_digt == 6) namecolor_main = "КРАСНЫЙ"
			if ( color_digt == 7) namecolor_main = "СИНИЙ"
			if ( color_digt == 8) namecolor_main = "СЕРЫЙ"
			if ( color_digt == 9) namecolor_main = "СЕРО-ЗЕЛЁНЫЙ"
			if ( color_digt == 10) namecolor_main = "БЛЕДНЫЙ КРАСНЫЙ"
			if ( color_digt == 11) namecolor_main = "ЗЕЛЁНЫЙ ЦВЕТНОЙ"
			if ( color_digt == 12) namecolor_main = "СЕРЫЙ ЦВЕТНОЙ"
			if ( color_digt == 13) namecolor_main = "СИНИЙ ЦВЕТНОЙ"


		normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + parseInt(color_digt) + ".png");	
		normal_image_img.setProperty(hmUI.prop.SRC, "G_" + parseInt(color_digt) + ".png");
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: color_digt + '_am.png',
              am_en_path: color_digt + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: color_digt + '_pm.png',
              pm_en_path: color_digt + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
			hmUI.showToast({text: namecolor_main });	
				
			vibro(28);
					
			}
 //  конец  изменения цвета фона	







		
	
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_fat_burning_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: lcddisplaycapssskcyrillic.ttf; FontSize: 32; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 452,
              y: 452,
              w: 38,
              h: 38,
              text_size: 32,
              char_space: 2,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '1_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '1_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_battery_linear_scale.setAlpha(175);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 284,
              // start_y: 158,
              // color: 0xFF000000,
              // lenght: -39,
              // line_width: 17,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: True,
              // alpha: 175,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 116,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 2,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["AOD_batt_01.png","AOD_batt_02.png","AOD_batt_03.png","AOD_batt_04.png","AOD_batt_05.png","AOD_batt_06.png","AOD_batt_07.png","AOD_batt_08.png","AOD_batt_09.png","AOD_batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 326,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 326,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 23,
              y: 326,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 326,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 326,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 376,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 1,
              unit_sc: '1_km.png',
              unit_tc: '1_km.png',
              unit_en: '1_km.png',
              imperial_unit_sc: '1_ml.png',
              imperial_unit_tc: '1_ml.png',
              imperial_unit_en: '1_ml.png',
              dot_image: '1_point.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_step_linear_scale.setAlpha(175);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 145,
              // start_y: 417,
              // color: 0xFF000000,
              // lenght: 165,
              // line_width: 16,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 175,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 119,
              y: 376,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 220,
              month_startY: 116,
              month_sc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_tc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_en_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 158,
              day_startY: 116,
              day_sc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_tc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_en_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 71,
              y: 116,
              week_en: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_tc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_sc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 61,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 148,
              y: 26,
              w: 162,
              h: 28,
              text_size: 32,
              char_space: 2,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 308,
              y: 52,
              image_array: ["1_wth00.png","1_wth01.png","1_wth02.png","1_wth03.png","1_wth04.png","1_wth05.png","1_wth06.png","1_wth07.png","1_wth08.png","1_wth09.png","1_wth10.png","1_wth11.png","1_wth12.png","1_wth13.png","1_wth14.png","1_wth15.png","1_wth16.png","1_wth17.png","1_wth18.png","1_wth19.png","1_wth20.png","1_wth21.png","1_wth22.png","1_wth23.png","1_wth24.png","1_wth25.png","1_wth26.png","1_wth27.png","1_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 61,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              unit_sc: '1_dig.png',
              unit_tc: '1_dig.png',
              unit_en: '1_dig.png',
              imperial_unit_sc: '1_dig.png',
              imperial_unit_tc: '1_dig.png',
              imperial_unit_en: '1_dig.png',
              negative_image: '1_minus.png',
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 228,
                y: 61,
                font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
                padding: false,
                h_space: 2,
                unit_sc: '1_dig.png',
                unit_tc: '1_dig.png',
                unit_en: '1_dig.png',
                imperial_unit_sc: '1_dig.png',
                imperial_unit_tc: '1_dig.png',
                imperial_unit_en: '1_dig.png',
                negative_image: '1_minus.png',
                invalid_image: '1_eror.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'G_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '1_am.png',
              am_en_path: '1_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '1_pm.png',
              pm_en_path: '1_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 76,
              hour_startY: 177,
              hour_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 215,
              minute_startY: 177,
              minute_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 324,
              second_startY: 177,
              second_array: ["1_013.png","1_014.png","1_015.png","1_016.png","1_017.png","1_018.png","1_019.png","1_020.png","1_021.png","1_022.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 177,
              src: '1_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 361,
              font_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'AOD_int.png',
              unit_tc: 'AOD_int.png',
              unit_en: 'AOD_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["AOD_batt_01.png","AOD_batt_02.png","AOD_batt_03.png","AOD_batt_04.png","AOD_batt_05.png","AOD_batt_06.png","AOD_batt_07.png","AOD_batt_08.png","AOD_batt_09.png","AOD_batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 69,
              y: 99,
              week_en: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_tc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_sc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 334,
              month_startY: 101,
              month_sc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_tc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_en_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 236,
              day_startY: 101,
              day_sc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_tc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_en_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'AOD_am.png',
              am_en_path: 'AOD_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'AOD_pm.png',
              pm_en_path: 'AOD_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 59,
              hour_startY: 189,
              hour_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 217,
              minute_startY: 189,
              minute_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 343,
              second_startY: 189,
              second_array: ["AOD_013.png","AOD_014.png","AOD_015.png","AOD_016.png","AOD_017.png","AOD_018.png","AOD_019.png","AOD_020.png","AOD_021.png","AOD_022.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 168,
              y: 189,
              src: 'AOD_011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 132,
              y: 375,
              w: 189,
              h: 77,
              src: '00_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 300,
              w: 95,
              h: 70,
              src: '00_empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 341,
              y: 299,
              w: 82,
              h: 70,
              src: '00_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 300,
              w: 118,
              h: 70,
              src: '00_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 279,
              y: 107,
              w: 112,
              h: 52,
              src: '00_empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 217,
              y: 42,
              w: 81,
              h: 62,
              src: '00_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 324,
              y: 167,
              w: 65,
              h: 68,
              src: '00_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 324,
              y: 239,
              w: 63,
              h: 52,
              src: '00_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 300,
              w: 83,
              h: 70,
              src: '00_empty.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 64,
              y: 107,
              w: 207,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 67,
              y: 51,
              w: 142,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_ALT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 303,
              y: 45,
              w: 95,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index' });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 69,
              y: 170,
              w: 112,
              h: 113,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 170,
              w: 112,
              h: 113,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_BG()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 159,
              w: 337,
              h: 135,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Day()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let pressure_array = read_pressure();
let value = getPressureValue(pressure_array);
value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.
 
normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));

normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	
Button_6.setProperty(hmUI.prop.VISIBLE, false);	





            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 284;
                  let start_y_normal_battery = 119;
                  let lenght_ls_normal_battery = 39;
                  let line_width_ls_normal_battery = 17;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 310;
                  let start_y_normal_step = 417;
                  let lenght_ls_normal_step = -165;
                  let line_width_ls_normal_step = 16;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}