﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: '001.png', path: '001.png' },
                { id: 2, preview: '002.png', path: '002.png' },
                { id: 3, preview: '003.png', path: '003.png' },
                { id: 4, preview: '004.png', path: '004.png' },
                { id: 5, preview: '005.png', path: '005.png' },
                { id: 6, preview: '006.png', path: '006.png' },
              ],
              count: 6,
              default_id: 1,
              fg: '.png',
              tips_bg: 'tap.png',
              tips_x: 178,
              tips_y: 391,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 286,
              y: 230,
              src: 'lck.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 216,
              y: 4,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 145,
              y: 230,
              src: 'alrm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 217,
              font_array: ["set001.png","set002.png","set003.png","set004.png","set005.png","set006.png","set007.png","set008.png","set009.png","set010.png"],
              padding: false,
              h_space: -2,
              dot_image: 'set011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 217,
              font_array: ["set001.png","set002.png","set003.png","set004.png","set005.png","set006.png","set007.png","set008.png","set009.png","set010.png"],
              padding: false,
              h_space: -2,
              dot_image: 'set011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 399,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 300,
              font_array: ["bat001.png","bat002.png","bat003.png","bat004.png","bat005.png","bat006.png","bat007.png","bat008.png","bat009.png","bat010.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 379,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'min012.png',
              unit_tc: 'min012.png',
              unit_en: 'min012.png',
              negative_image: 'min011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 139,
              y: 379,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'min012.png',
              unit_tc: 'min012.png',
              unit_en: 'min012.png',
              negative_image: 'min011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 164,
              y: 278,
              font_array: ["wth01.png","wth02.png","wth03.png","wth04.png","wth05.png","wth06.png","wth07.png","wth08.png","wth09.png","wth10.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'wth12.png',
              unit_tc: 'wth12.png',
              unit_en: 'wth12.png',
              negative_image: 'wth11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 56,
              y: 289,
              image_array: ["w072.png","w073.png","w074.png","w075.png","w076.png","w077.png","w078.png","w079.png","w080.png","w081.png","w082.png","w083.png","w084.png","w085.png","w086.png","w087.png","w088.png","w089.png","w090.png","w091.png","w092.png","w093.png","w094.png","w095.png","w096.png","w097.png","w098.png","w099.png","w100.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 54,
              font_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 118,
              font_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 118,
              font_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 230,
              month_startY: 230,
              month_sc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              month_tc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              month_en_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              month_zero: 1,
              month_space: -5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 189,
              day_startY: 230,
              day_sc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              day_tc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              day_en_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 148,
              y: 191,
              week_en: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_tc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_sc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 211,
              am_y: 121,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 211,
              pm_y: 121,
              pm_sc_path: 'ampm.png',
              pm_en_path: 'ampm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 148,
              hour_startY: 144,
              hour_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 232,
              minute_startY: 144,
              minute_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 375,
              font_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 207,
              day_startY: 207,
              day_sc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              day_tc_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              day_en_array: ["osn001.png","osn002.png","osn003.png","osn004.png","osn005.png","osn006.png","osn007.png","osn008.png","osn009.png","osn010.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 148,
              y: 168,
              week_en: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_tc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_sc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 150,
              hour_startY: 119,
              hour_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 231,
              minute_startY: 119,
              minute_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 332,
              y: 226,
              w: 115,
              h: 160,
              src: 'y.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 150,
              y: 139,
              w: 157,
              h: 109,
              src: 'y.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 13,
              y: 226,
              w: 115,
              h: 157,
              src: 'y.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 149,
              y: 380,
              w: 154,
              h: 100,
              src: 'y.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 153,
              y: 271,
              w: 148,
              h: 100,
              src: 'y.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 322,
              y: 77,
              w: 124,
              h: 127,
              src: 'y.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 8,
              y: 77,
              w: 124,
              h: 127,
              src: 'y.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 146,
              y: 25,
              w: 160,
              h: 100,
              src: 'y.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
