﻿    /*
    ** Watch_Face_Editor tool v 17.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

		let R = 0.945833

		let alt_var = 1
        let alt_all = 2
		let alt_text = ' '
		let pressure_array = read_pressure();
        let value = getPressureValue(pressure_array);
		let pressere_changes = changesPressure(pressure_array);
		
		let night_var = 1
        let night_all = 2
		let name_text = ' '
		let night_dig = 1
		let night_dig1 = 1
		let night_dig2 = 1
		let night_dig3 = 1
		let night_dig4 = 1
		
		let menu = 1
        let total_menu = 2
		
		let color_r = 1
        let colors_r = 8
		let namecolor_r = ' '
		
		let color_digt = 1
        let all_digt = 8
		let color_text = '0xFFFFFFFF'
		let namecolor_digt = ' '
		
		let color_time = 1
		let color_date = 1
		let color_whether = 1
		let color_wth = 1
		let color_pres = 1
		let color_pai = 1
		let color_wind = 1

		
		let color_bg = 1
        let totalcolors_bg = 15
		let namecolor_main = ' '
		
		let visabl_main = 1
		let totalvisabl_main = 2
		
		let xxx_clock_h = 80       
		let yyy_clock_h = 187
		let xxx_clock_m = 227
		let yyy_clock_m = 187
		let xxx_clock_s = 343
		let yyy_clock_s = 187
		let xxx_clock = 179
		let yyy_clock = 187
		let xxx_day = 167
		let yyy_day = 123
		let xxx_month = 233
		let yyy_month = 123
		let xxx_day_w = 75
		let yyy_day_w = 123
		let xxx_batt = 317
		let yyy_batt = 123

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
//# барометр в мм рт. ст.


function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}


function changesPressure(pressure_array) {
 console.log("changesPressure()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 let value = pressure_array[start_index];
 let result = 0;
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  let element = pressure_array[index];
  if (element != 0) {
   if (Math.abs(value - element) > 50) { // учитываем только если разниза больше 0,5 hPa
    value = value - element;
    console.log(`element = ${element}`);
    console.log(`pressere_changes = ${value}`);
    return value;
   }
  }
 }
 return result;
}

function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}
//# конец барометр в мм рт. ст.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// переключение едениц измерения давления

		

function click_ALT() {
		let pressure_array = read_pressure();
		let value = getPressureValue(pressure_array);
	
            if(alt_var>=alt_all) {
            alt_var=1;
                }
            else {
                alt_var=alt_var+1;
            }
			if ( alt_var == 1) { 
			alt_text = "мм рт. ст."  // "m.m.Hg"
			value = hPa_To_mmHg(value);              // перевод в мм.рт.ст.
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
		    }			
			if ( alt_var == 2) { 
			alt_text = "гПа" //  "hPa"
			value = getPressureValue(pressure_array);              // перевод в гПа
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
			}
			
			hmUI.showToast({text: alt_text });
			vibro(28);
									
		}

// конец переключение едениц измерения давления

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//	видимость /невидимость	
		
		function click_visabl() {
			
            if(visabl_main>=totalvisabl_main) {
            visabl_main=1;
                }
            else {
                visabl_main=visabl_main+1;
            }

			
			if ( visabl_main == 1) { 
			
		namecolor_digt = "ОБЫЧНАЯ СЕКУНДНАЯ СТРЕЛКА"   // "NORMAL SECOND HAND"
		

		normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.VISIBLE, false);
		normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
			};
			
	        if ( visabl_main == 2) { 
		
		namecolor_digt = "ПЛАВНАЯ СЕКУНДНАЯ СТРЕЛКА"   //  "SMOOTH SECONDS HAND"
		
		normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.VISIBLE, true);
		normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

			};
	

	
			hmUI.showToast({text: namecolor_digt });
			
			vibro(28);
		}









////////////////////////////////



function clicker() {
	
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: parseInt(xxx_clock_h),
              hour_startY: parseInt(yyy_clock_h),
              hour_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: parseInt(xxx_clock_m),
              minute_startY: parseInt(yyy_clock_m),
              minute_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: parseInt(xxx_clock_s),
              second_startY: parseInt(yyy_clock_s),
              second_array: [night_dig + "_013.png",night_dig + "_014.png",night_dig + "_015.png",night_dig + "_016.png",night_dig + "_017.png",night_dig + "_018.png",night_dig + "_019.png",night_dig + "_020.png",night_dig + "_021.png",night_dig + "_022.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: xxx_clock,
              y: yyy_clock,
              src: night_dig + '_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: night_dig1 + '_am.png',
              am_en_path: night_dig1 + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: night_dig1 + '_pm.png',
              pm_en_path: night_dig1 + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	


		normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: xxx_day_w,
              y: yyy_day_w,
              week_en: [night_dig2 + "_023.png",night_dig2 + "_024.png",night_dig2 + "_025.png",night_dig2 + "_026.png",night_dig2 + "_027.png",night_dig2 + "_028.png",night_dig2 + "_029.png"],
              week_tc: [night_dig2 + "_023.png",night_dig2 + "_024.png",night_dig2 + "_025.png",night_dig2 + "_026.png",night_dig2 + "_027.png",night_dig2 + "_028.png",night_dig2 + "_029.png"],
              week_sc: [night_dig2 + "_023.png",night_dig2 + "_024.png",night_dig2 + "_025.png",night_dig2 + "_026.png",night_dig2 + "_027.png",night_dig2 + "_028.png",night_dig2 + "_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_date_img_date_month.setProperty(hmUI.prop.MORE, {
              month_startX: xxx_month,
              month_startY: yyy_month,
              month_sc_array: [night_dig2 + "_030.png",night_dig2 + "_031.png",night_dig2 + "_032.png",night_dig2 + "_033.png",night_dig2 + "_034.png",night_dig2 + "_035.png",night_dig2 + "_036.png",night_dig2 + "_037.png",night_dig2 + "_038.png",night_dig2 + "_039.png"],
              month_tc_array: [night_dig2 + "_030.png",night_dig2 + "_031.png",night_dig2 + "_032.png",night_dig2 + "_033.png",night_dig2 + "_034.png",night_dig2 + "_035.png",night_dig2 + "_036.png",night_dig2 + "_037.png",night_dig2 + "_038.png",night_dig2 + "_039.png"],
              month_en_array: [night_dig2 + "_030.png",night_dig2 + "_031.png",night_dig2 + "_032.png",night_dig2 + "_033.png",night_dig2 + "_034.png",night_dig2 + "_035.png",night_dig2 + "_036.png",night_dig2 + "_037.png",night_dig2 + "_038.png",night_dig2 + "_039.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: xxx_day,
              day_startY: yyy_day,
              day_sc_array: [night_dig2 + "_030.png",night_dig2 + "_031.png",night_dig2 + "_032.png",night_dig2 + "_033.png",night_dig2 + "_034.png",night_dig2 + "_035.png",night_dig2 + "_036.png",night_dig2 + "_037.png",night_dig2 + "_038.png",night_dig2 + "_039.png"],
              day_tc_array: [night_dig2 + "_030.png",night_dig2 + "_031.png",night_dig2 + "_032.png",night_dig2 + "_033.png",night_dig2 + "_034.png",night_dig2 + "_035.png",night_dig2 + "_036.png",night_dig2 + "_037.png",night_dig2 + "_038.png",night_dig2 + "_039.png"],
              day_en_array: [night_dig2 + "_030.png",night_dig2 + "_031.png",night_dig2 + "_032.png",night_dig2 + "_033.png",night_dig2 + "_034.png",night_dig2 + "_035.png",night_dig2 + "_036.png",night_dig2 + "_037.png",night_dig2 + "_038.png",night_dig2 + "_039.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


		normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: xxx_batt,
              y: yyy_batt,
              font_array: [night_dig3 + "_040.png",night_dig3 + "_041.png",night_dig3 + "_042.png",night_dig3 + "_043.png",night_dig3 + "_044.png",night_dig3 + "_045.png",night_dig3 + "_046.png",night_dig3 + "_047.png",night_dig3 + "_048.png",night_dig3 + "_049.png"],
              padding: false,
              h_space: 2,
              unit_sc: night_dig3 + '_int.png',
              unit_tc: night_dig3 + '_int.png',
              unit_en: night_dig3 + '_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
			const result = hmSetting.setScreenOff();			
	
}




//	возврат в дневной режим 

		function click_Day() {

		name_text = "ДНЕВНОЙ РЕЖИМ";  // "DAYTIME MODE"
		night_dig = color_time
		night_dig1 = color_bg
		night_dig2 = color_date
		night_dig3 = color_pres
		

		
		
		 xxx_clock_h = Math.round(65*R);
		 yyy_clock_h = Math.round(203*R);
		 xxx_clock = Math.round(183*R);
		 yyy_clock = Math.round(203*R);
		 xxx_clock_m = Math.round(216*R);
		 yyy_clock_m = Math.round(203*R);
		 xxx_clock_s = Math.round(349*R);
		 yyy_clock_s = Math.round(203*R);

		 xxx_day = Math.round(216*R);
		 yyy_day = Math.round(146*R);
		 xxx_month = Math.round(276*R);
		 yyy_month = Math.round(146*R);
		 xxx_day_w = Math.round(335*R);
		 yyy_day_w = Math.round(147*R);
		 xxx_batt = Math.round(94*R);
		 yyy_batt = Math.round(378*R);

	
        clicker();
		

		
		normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	
		normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
//	    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
              
			  
		normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + night_dig1 + ".png");
		normal_image_img.setProperty(hmUI.prop.SRC, "TOP_BG_" + night_dig1 + ".png");	

	
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
//		normal_city_name_text.setProperty(hmUI.prop.VISIBLE, true);


		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
//		normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		

		
		
		
		
		
		
		Button_1.setProperty(hmUI.prop.VISIBLE, true);      //   кнопка календарь
		Button_2.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка давление   
		Button_3.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка погодная программа
		Button_4.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка переход в ночной режим
		Button_5.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка изменения цвета
		Button_6.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка возврат в дневной режим
		Button_7.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка переключения стрелки
		
		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык статистика активностей (калории)
		normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //  жиросжигание
		normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);          //   ярлык шаги 
		normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык пульса 
		normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык температуры
		normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык будильник
		normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);       //   ярлык секундомер
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык батарея		
		
		visabl_main=visabl_main-1;
		click_visabl();
		
		hmUI.showToast({text: name_text });
			
		vibro(28);		
				
			}
			
//	конец возврата в дневной режим 			

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
//	переход в ночной режим 			
			
		function click_Night() {		
				
		name_text = "НОЧНОЙ РЕЖИМ"   // "NIGHT MODE"
		night_dig = 'AOD'
		night_dig1 = 'AOD'
		night_dig2 = 'AOD'
		night_dig3 = 'AOD'
		
		
		 xxx_clock_h = Math.round(60*R);
		 yyy_clock_h = Math.round(163*R);
		 xxx_clock = Math.round(184*R);
		 yyy_clock = Math.round(163*R);
		 xxx_clock_m = Math.round(240*R);
		 yyy_clock_m = Math.round(163*R);
		 xxx_clock_s = Math.round(388*R);
		 yyy_clock_s = Math.round(163*R);

		 xxx_day = Math.round(96*R);
		 yyy_day = Math.round(68*R);
		 xxx_month = Math.round(182*R);
		 yyy_month = Math.round(68*R);
		 xxx_day_w = Math.round(259*R);
		 yyy_day_w = Math.round(69*R);
		 xxx_batt = Math.round(100*R);
		 yyy_batt = Math.round(342*R);


		clicker()
		
		normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);	
		normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
		normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
	    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
		normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.VISIBLE, false);
              
		normal_background_bg_img.setProperty(hmUI.prop.SRC, night_dig1 + ".png");
		normal_image_img.setProperty(hmUI.prop.SRC, night_dig1 + "_TOP.png");	
		
		
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
//		normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);


		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
//		normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		
		
		
		
		
		
		
		Button_1.setProperty(hmUI.prop.VISIBLE, false);      //   кнопка календарь
		Button_2.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка давление   
		Button_3.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка погодная программа
		Button_4.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка переход в ночной режим
		Button_5.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка изменения цвета
		Button_6.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка возврат в дневной режим
		Button_7.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка переключения стрелки
		
		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык статистика активностей (калории)
		normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //  жиросжигание
		normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);          //   ярлык шаги 
		normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык пульса 
		normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык температуры
		normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык будильник
		normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);       //   ярлык секундомер
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык батарея
		

		
		hmUI.showToast({text: name_text });
		vibro(28);
	
		}
		
//	конец перехода в ночной режим 		

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  изменение цвета фона

function click_BG() {
	
		 xxx_clock_h = Math.round(65*R);
		 yyy_clock_h = Math.round(203*R);
		 xxx_clock = Math.round(183*R);
		 yyy_clock = Math.round(203*R);
		 xxx_clock_m = Math.round(216*R);
		 yyy_clock_m = Math.round(203*R);
		 xxx_clock_s = Math.round(349*R);
		 yyy_clock_s = Math.round(203*R);

		 xxx_day = Math.round(216*R);
		 yyy_day = Math.round(146*R);
		 xxx_month = Math.round(276*R);
		 yyy_month = Math.round(146*R);
		 xxx_day_w = Math.round(335*R);
		 yyy_day_w = Math.round(147*R);
		 xxx_batt = Math.round(94*R);
		 yyy_batt = Math.round(378*R);
	
	
	
        if(color_bg>=totalcolors_bg) {
            color_bg=1;
                }
        else { 
			color_bg=color_bg+1;   
			}
			

			
			if ( color_bg == 1) {
			namecolor_main = "БЕЛЫЙ";
			color_time = 1;
			color_date = 1;
			color_whether = 1;
			color_wth = 1;
			color_pres = 1;
			color_pai = 1;
			color_wind = 1;
			}
			
			if ( color_bg == 2)  {
			namecolor_main = "ЗЕЛЁНЫЙ";
			color_time = 2;
			color_date = 2;
			color_whether = 2;
			color_wth = 2;
			color_pres = 2;
			color_pai = 2;
			color_wind = 2;
			}
			
			if ( color_bg == 3)  {
			namecolor_main = "ПИП-БОЙ";
			color_time = 3;
			color_date = 3;
			color_whether = 3;
			color_wth = 3;
			color_pres = 3;
			color_pai = 3;
			color_wind = 3;
			}
			
			if ( color_bg == 4)  {
			namecolor_main = "ГОЛУБОЙ";
			color_time = 4;
			color_date = 4;
			color_whether = 4;
			color_wth = 4;
			color_pres = 4;
			color_pai = 4;
			color_wind = 4;
			}
			
			if ( color_bg == 5)  {
			namecolor_main = "ЖЁЛТЫЙ";
			color_time = 5;
			color_date = 5;
			color_whether = 5;
			color_wth = 5;
			color_pres = 5;
			color_pai = 5;
			color_wind = 5;
			}
			
			if ( color_bg == 6)   {
			namecolor_main = "СЕРО-ГОЛУБОЙ";
			color_time = 6;
			color_date = 6;
			color_whether = 6;
			color_wth = 6;
			color_pres = 6;
			color_pai = 6;
			color_wind = 6;
			}
			
			if ( color_bg == 7) {
			namecolor_main = "БЕЛО-КРАСНЫЙ";
			color_time = 1;
			color_date = 1;
			color_whether = 1;
			color_wth = 1;
			color_pres = 1;
			color_pai = 1;
			color_wind = 1;
			}
			
			if ( color_bg == 8) {
			namecolor_main = "БЕЛО-ЗЕЛЁНЫЙ";
			color_time = 1;
			color_date = 1;
			color_whether = 1;
			color_wth = 1;
			color_pres = 1;
			color_pai = 1;
			color_wind = 1;
			}
			
			if ( color_bg == 9) {
			namecolor_main = "БЕЛО-ГОЛУБОЙ";
			color_time = 1;
			color_date = 1;
			color_whether = 1;
			color_wth = 1;
			color_pres = 1;
			color_pai = 1;
			color_wind = 1;
			}
			
			if ( color_bg == 10) {
			namecolor_main = "ЦВЕТНОЙ 1";
			color_time = 1;
			color_date = 1;
			color_whether = 1;
			color_wth = 15;
			color_pres = 1;
			color_pai = 1;
			color_wind = 7;
			}
			
			if ( color_bg == 11) {
			namecolor_main = "ЦВЕТНОЙ 2";
			color_time = 5;
			color_date = 5;
			color_whether = 1;
			color_wth = 15;
			color_pres = 1;
			color_pai = 5;
			color_wind = 7;
			}
			
			if ( color_bg == 12) {
			namecolor_main = "ЦВЕТНОЙ 3";
			color_time = 2;
			color_date = 5;
			color_whether = 2;
			color_wth = 15;
			color_pres = 2;
			color_pai = 5;
			color_wind = 7;
			}
			
			if ( color_bg == 13) {
			namecolor_main = "ЦВЕТНОЙ 4";
			color_time = 3;
			color_date = 4;
			color_whether = 1;
			color_wth = 15;
			color_pres = 1;
			color_pai = 4;
			color_wind = 7;
			}
			
			if ( color_bg == 14) {
			namecolor_main = "ЦВЕТНОЙ 5";
			color_time = 4;
			color_date = 1;
			color_whether = 1;
			color_wth = 15;
			color_pres = 4;
			color_pai = 1;
			color_wind = 7;
           	}
			
			if ( color_bg == 15) {
			namecolor_main = "ЦВЕТНОЙ 6";
			color_time = 2;
			color_date = 3;
			color_whether = 1;
			color_wth = 15;
			color_pres = 4;
			color_pai = 3;
			color_wind = 7;
        	}


		normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + parseInt(color_bg) + ".png");
		normal_image_img.setProperty(hmUI.prop.SRC, "TOP_BG_" + parseInt(color_bg) + ".png");		

		normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: parseInt(color_bg) + '_str_h.png',
              hour_centerX: Math.round(137*R),
              hour_centerY: Math.round(133*R),
              hour_posX: Math.round(8*R),
              hour_posY: Math.round(37*R),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: parseInt(color_bg) + '_str_m.png',
              minute_centerX: Math.round(137*R),
              minute_centerY: Math.round(133*R),
              minute_posX: Math.round(8*R),
              minute_posY: Math.round(54*R),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: parseInt(color_bg) + '_str_s.png',
              second_centerX: Math.round(137*R),
              second_centerY: Math.round(133*R),
              second_posX: Math.round(9*R),
              second_posY: Math.round(73*R),
              second_cover_path: parseInt(color_bg) + '_s.png',
              second_cover_x: Math.round(130*R),
              second_cover_y: Math.round(128*R),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
///////////////		


        normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.MORE, {
              second_path: parseInt(color_bg) + '_str_s.png',
              second_centerX: Math.round(137*R),
              second_centerY: Math.round(133*R),
              second_posX: Math.round(9*R),
              second_posY: Math.round(73*R),
              fresh_frequency: 17,
              fresh_freqency: 17,
              second_cover_path: parseInt(color_bg) + '_s.png',
              second_cover_x: Math.round(130*R),
              second_cover_y: Math.round(125*R),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			

		
/////////		
		
		normal_fat_burning_current_text_img.setProperty(hmUI.prop.MORE, {
              x: Math.round(367*R),
              y: Math.round(330*R),
              font_array: [parseInt(color_pai) + "_040.png",parseInt(color_pai) + "_041.png",parseInt(color_pai) + "_042.png",parseInt(color_pai) + "_043.png",parseInt(color_pai) + "_044.png",parseInt(color_pai) + "_045.png",parseInt(color_pai) + "_046.png",parseInt(color_pai) + "_047.png",parseInt(color_pai) + "_048.png",parseInt(color_pai) + "_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

		normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: Math.round(240*R),
              y: Math.round(330*R),
              font_array: [parseInt(color_pai) + "_040.png",parseInt(color_pai) + "_041.png",parseInt(color_pai) + "_042.png",parseInt(color_pai) + "_043.png",parseInt(color_pai) + "_044.png",parseInt(color_pai) + "_045.png",parseInt(color_pai) + "_046.png",parseInt(color_pai) + "_047.png",parseInt(color_pai) + "_048.png",parseInt(color_pai) + "_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	
        normal_pai_weekly_text_img.setProperty(hmUI.prop.MORE, {
              x: Math.round(147*R),
              y: Math.round(330*R),
              font_array: [parseInt(color_pai) + "_040.png",parseInt(color_pai) + "_041.png",parseInt(color_pai) + "_042.png",parseInt(color_pai) + "_043.png",parseInt(color_pai) + "_044.png",parseInt(color_pai) + "_045.png",parseInt(color_pai) + "_046.png",parseInt(color_pai) + "_047.png",parseInt(color_pai) + "_048.png",parseInt(color_pai) + "_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_pai_day_text_img.setProperty(hmUI.prop.MORE, {
              x: Math.round(75*R),
              y: Math.round(330*R),
              font_array: [parseInt(color_pai) + "_040.png",parseInt(color_pai) + "_041.png",parseInt(color_pai) + "_042.png",parseInt(color_pai) + "_043.png",parseInt(color_pai) + "_044.png",parseInt(color_pai) + "_045.png",parseInt(color_pai) + "_046.png",parseInt(color_pai) + "_047.png",parseInt(color_pai) + "_048.png",parseInt(color_pai) + "_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
////////
	
	
	
		normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: xxx_batt,
              y: yyy_batt,
              font_array: [parseInt(color_pres) + "_040.png",parseInt(color_pres) + "_041.png",parseInt(color_pres) + "_042.png",parseInt(color_pres) + "_043.png",parseInt(color_pres) + "_044.png",parseInt(color_pres) + "_045.png",parseInt(color_pres) + "_046.png",parseInt(color_pres) + "_047.png",parseInt(color_pres) + "_048.png",parseInt(color_pres) + "_049.png"],
              padding: false,
              h_space: 2,
              unit_sc: parseInt(color_pres) + '_int.png',
              unit_tc: parseInt(color_pres) + '_int.png',
              unit_en: parseInt(color_pres) + '_int.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


		normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: Math.round(214*R),
              y: Math.round(377*R),
              font_array: [parseInt(color_pres) + "_040.png",parseInt(color_pres) + "_041.png",parseInt(color_pres) + "_042.png",parseInt(color_pres) + "_043.png",parseInt(color_pres) + "_044.png",parseInt(color_pres) + "_045.png",parseInt(color_pres) + "_046.png",parseInt(color_pres) + "_047.png",parseInt(color_pres) + "_048.png",parseInt(color_pres) + "_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: Math.round(280*R),
              y: Math.round(377*R),
              font_array: [parseInt(color_pres) + "_040.png",parseInt(color_pres) + "_041.png",parseInt(color_pres) + "_042.png",parseInt(color_pres) + "_043.png",parseInt(color_pres) + "_044.png",parseInt(color_pres) + "_045.png",parseInt(color_pres) + "_046.png",parseInt(color_pres) + "_047.png",parseInt(color_pres) + "_048.png",parseInt(color_pres) + "_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
			
			
		

		normal_humidity_text_text_img.setProperty(hmUI.prop.MORE, {
              x: Math.round(327*R),
              y: Math.round(86*R),
              font_array: [parseInt(color_pres) + "_040.png",parseInt(color_pres) + "_041.png",parseInt(color_pres) + "_042.png",parseInt(color_pres) + "_043.png",parseInt(color_pres) + "_044.png",parseInt(color_pres) + "_045.png",parseInt(color_pres) + "_046.png",parseInt(color_pres) + "_047.png",parseInt(color_pres) + "_048.png",parseInt(color_pres) + "_049.png"],
              padding: false,
              h_space: 1,
              unit_sc: parseInt(color_pres) + '_int.png',
              unit_tc: parseInt(color_pres) + '_int.png',
              unit_en: parseInt(color_pres) + '_int.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

 

        normal_altimeter_text_text_img.setProperty(hmUI.prop.MORE, {
              x: Math.round(208*R),
              y: Math.round(86*R),
              font_array: [parseInt(color_pres) + "_040.png",parseInt(color_pres) + "_041.png",parseInt(color_pres) + "_042.png",parseInt(color_pres) + "_043.png",parseInt(color_pres) + "_044.png",parseInt(color_pres) + "_045.png",parseInt(color_pres) + "_046.png",parseInt(color_pres) + "_047.png",parseInt(color_pres) + "_048.png",parseInt(color_pres) + "_049.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
			
				
				
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: Math.round(293*R),
              y: Math.round(82*R),
              image_array: [parseInt(color_wind) + "_WD_1_N.png",parseInt(color_wind) + "_WD_2_NE.png",parseInt(color_wind) + "_WD_3_E.png",parseInt(color_wind) + "_WD_4_SE.png",parseInt(color_wind) + "_WD_5_S.png",parseInt(color_wind) + "_WD_6_SW.png",parseInt(color_wind) + "_WD_7_W.png",parseInt(color_wind) + "_WD_8_NW.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
////////


        normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: Math.round(166*R),
              y: Math.round(7*R),
              font_array: [parseInt(color_whether) + "_040.png",parseInt(color_whether) + "_041.png",parseInt(color_whether) + "_042.png",parseInt(color_whether) + "_043.png",parseInt(color_whether) + "_044.png",parseInt(color_whether) + "_045.png",parseInt(color_whether) + "_046.png",parseInt(color_whether) + "_047.png",parseInt(color_whether) + "_048.png",parseInt(color_whether) + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_whether) + '_dig.png',
              unit_tc: parseInt(color_whether) + '_dig.png',
              unit_en: parseInt(color_whether) + '_dig.png',
              imperial_unit_sc: parseInt(color_whether) + '_dig.png',
              imperial_unit_tc: parseInt(color_whether) + '_dig.png',
              imperial_unit_en: parseInt(color_whether) + '_dig.png',
              negative_image: parseInt(color_whether) + '_minus.png',
              invalid_image: parseInt(color_whether) + '_eror.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
		
		
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: Math.round(238*R),
              y: 0,
              image_array: [parseInt(color_wth) + "_wth00.png",parseInt(color_wth) + "_wth01.png",parseInt(color_wth) + "_wth02.png",parseInt(color_wth) + "_wth03.png",parseInt(color_wth) + "_wth04.png",parseInt(color_wth) + "_wth05.png",parseInt(color_wth) + "_wth06.png",parseInt(color_wth) + "_wth07.png",parseInt(color_wth) + "_wth08.png",parseInt(color_wth) + "_wth09.png",parseInt(color_wth) + "_wth10.png",parseInt(color_wth) + "_wth11.png",parseInt(color_wth) + "_wth12.png",parseInt(color_wth) + "_wth13.png",parseInt(color_wth) + "_wth14.png",parseInt(color_wth) + "_wth15.png",parseInt(color_wth) + "_wth16.png",parseInt(color_wth) + "_wth17.png",parseInt(color_wth) + "_wth18.png",parseInt(color_wth) + "_wth19.png",parseInt(color_wth) + "_wth20.png",parseInt(color_wth) + "_wth21.png",parseInt(color_wth) + "_wth22.png",parseInt(color_wth) + "_wth23.png",parseInt(color_wth) + "_wth24.png",parseInt(color_wth) + "_wth25.png",parseInt(color_wth) + "_wth26.png",parseInt(color_wth) + "_wth27.png",parseInt(color_wth) + "_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		


			
/////////			
			
			
		normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: xxx_day_w,
              y: yyy_day_w,
              week_en: [parseInt(color_date) + "_023.png",parseInt(color_date) + "_024.png",parseInt(color_date) + "_025.png",parseInt(color_date) + "_026.png",parseInt(color_date) + "_027.png",parseInt(color_date) + "_028.png",parseInt(color_date) + "_029.png"],
              week_tc: [parseInt(color_date) + "_023.png",parseInt(color_date) + "_024.png",parseInt(color_date) + "_025.png",parseInt(color_date) + "_026.png",parseInt(color_date) + "_027.png",parseInt(color_date) + "_028.png",parseInt(color_date) + "_029.png"],
              week_sc: [parseInt(color_date) + "_023.png",parseInt(color_date) + "_024.png",parseInt(color_date) + "_025.png",parseInt(color_date) + "_026.png",parseInt(color_date) + "_027.png",parseInt(color_date) + "_028.png",parseInt(color_date) + "_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		normal_date_img_date_month.setProperty(hmUI.prop.MORE, {
              month_startX: xxx_month,
              month_startY: yyy_month,
              month_sc_array: [parseInt(color_date) + "_030.png",parseInt(color_date) + "_031.png",parseInt(color_date) + "_032.png",parseInt(color_date) + "_033.png",parseInt(color_date) + "_034.png",parseInt(color_date) + "_035.png",parseInt(color_date) + "_036.png",parseInt(color_date) + "_037.png",parseInt(color_date) + "_038.png",parseInt(color_date) + "_039.png"],
              month_tc_array: [parseInt(color_date) + "_030.png",parseInt(color_date) + "_031.png",parseInt(color_date) + "_032.png",parseInt(color_date) + "_033.png",parseInt(color_date) + "_034.png",parseInt(color_date) + "_035.png",parseInt(color_date) + "_036.png",parseInt(color_date) + "_037.png",parseInt(color_date) + "_038.png",parseInt(color_date) + "_039.png"],
              month_en_array: [parseInt(color_date) + "_030.png",parseInt(color_date) + "_031.png",parseInt(color_date) + "_032.png",parseInt(color_date) + "_033.png",parseInt(color_date) + "_034.png",parseInt(color_date) + "_035.png",parseInt(color_date) + "_036.png",parseInt(color_date) + "_037.png",parseInt(color_date) + "_038.png",parseInt(color_date) + "_039.png"],
			  month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: xxx_day,
              day_startY: yyy_day,
              day_sc_array: [parseInt(color_date) + "_030.png",parseInt(color_date) + "_031.png",parseInt(color_date) + "_032.png",parseInt(color_date) + "_033.png",parseInt(color_date) + "_034.png",parseInt(color_date) + "_035.png",parseInt(color_date) + "_036.png",parseInt(color_date) + "_037.png",parseInt(color_date) + "_038.png",parseInt(color_date) + "_039.png"],
              day_tc_array: [parseInt(color_date) + "_030.png",parseInt(color_date) + "_031.png",parseInt(color_date) + "_032.png",parseInt(color_date) + "_033.png",parseInt(color_date) + "_034.png",parseInt(color_date) + "_035.png",parseInt(color_date) + "_036.png",parseInt(color_date) + "_037.png",parseInt(color_date) + "_038.png",parseInt(color_date) + "_039.png"],
              day_en_array: [parseInt(color_date) + "_030.png",parseInt(color_date) + "_031.png",parseInt(color_date) + "_032.png",parseInt(color_date) + "_033.png",parseInt(color_date) + "_034.png",parseInt(color_date) + "_035.png",parseInt(color_date) + "_036.png",parseInt(color_date) + "_037.png",parseInt(color_date) + "_038.png",parseInt(color_date) + "_039.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			
			

//////////			
			
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: xxx_clock_h,
              hour_startY: yyy_clock_h,
              hour_array: [parseInt(color_time) + "_001.png",parseInt(color_time) + "_002.png",parseInt(color_time) + "_003.png",parseInt(color_time) + "_004.png",parseInt(color_time) + "_005.png",parseInt(color_time) + "_006.png",parseInt(color_time) + "_007.png",parseInt(color_time) + "_008.png",parseInt(color_time) + "_009.png",parseInt(color_time) + "_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: xxx_clock_m,
              minute_startY: yyy_clock_m,
              minute_array: [parseInt(color_time) + "_001.png",parseInt(color_time) + "_002.png",parseInt(color_time) + "_003.png",parseInt(color_time) + "_004.png",parseInt(color_time) + "_005.png",parseInt(color_time) + "_006.png",parseInt(color_time) + "_007.png",parseInt(color_time) + "_008.png",parseInt(color_time) + "_009.png",parseInt(color_time) + "_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: xxx_clock_s,
              second_startY: yyy_clock_s,
              second_array: [parseInt(color_time) + "_013.png",parseInt(color_time) + "_014.png",parseInt(color_time) + "_015.png",parseInt(color_time) + "_016.png",parseInt(color_time) + "_017.png",parseInt(color_time) + "_018.png",parseInt(color_time) + "_019.png",parseInt(color_time) + "_020.png",parseInt(color_time) + "_021.png",parseInt(color_time) + "_022.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	
    normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, parseInt(color_time) + "_011.png");			
			
	
			
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: parseInt(color_bg) + '_am.png',
              am_en_path: parseInt(color_bg) + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: parseInt(color_bg) + '_pm.png',
              pm_en_path: parseInt(color_bg) + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
			
		normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: parseInt(color_bg) + '_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });				
			
			
			hmUI.showToast({text: namecolor_main });	
				
			vibro(28);
					
			}
 //  конец  изменения цвета фона	
 













		
	
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_image_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '1_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '1_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 277,
              y: 78,
              image_array: ["1_WD_1_N.png","1_WD_2_NE.png","1_WD_3_E.png","1_WD_4_SE.png","1_WD_5_S.png","1_WD_6_SW.png","1_WD_7_W.png","1_WD_8_NW.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 81,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 1,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 81,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1_pres_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 347,
              y: 312,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 312,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 139,
              y: 312,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 312,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 179,
              // start_y: 413,
              // color: 0xFF000000,
              // lenght: 93,
              // line_width: 14,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 358,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 34,
              // start_y: 273,
              // color: 0xFF000000,
              // lenght: -94,
              // line_width: 14,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 358,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["AOD_batt_01.png","AOD_batt_02.png","AOD_batt_03.png","AOD_batt_04.png","AOD_batt_05.png","AOD_batt_06.png","AOD_batt_07.png","AOD_batt_08.png","AOD_batt_09.png","AOD_batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 405,
              // start_y: 272,
              // color: 0xFF000000,
              // lenght: -94,
              // line_width: 14,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 358,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 225,
              y: 0,
              image_array: ["1_wth00.png","1_wth01.png","1_wth02.png","1_wth03.png","1_wth04.png","1_wth05.png","1_wth06.png","1_wth07.png","1_wth08.png","1_wth09.png","1_wth10.png","1_wth11.png","1_wth12.png","1_wth13.png","1_wth14.png","1_wth15.png","1_wth16.png","1_wth17.png","1_wth18.png","1_wth19.png","1_wth20.png","1_wth21.png","1_wth22.png","1_wth23.png","1_wth24.png","1_wth25.png","1_wth26.png","1_wth27.png","1_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 7,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 1,
              unit_sc: '1_dig.png',
              unit_tc: '1_dig.png',
              unit_en: '1_dig.png',
              imperial_unit_sc: '1_dig.png',
              imperial_unit_tc: '1_dig.png',
              imperial_unit_en: '1_dig.png',
              negative_image: '1_minus.png',
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 157,
                y: 7,
                font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
                padding: false,
                h_space: 1,
                unit_sc: '1_dig.png',
                unit_tc: '1_dig.png',
                unit_en: '1_dig.png',
                imperial_unit_sc: '1_dig.png',
                imperial_unit_tc: '1_dig.png',
                imperial_unit_en: '1_dig.png',
                negative_image: '1_minus.png',
                invalid_image: '1_eror.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 261,
              month_startY: 138,
              month_sc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_tc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_en_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 204,
              day_startY: 138,
              day_sc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_tc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_en_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 317,
              y: 139,
              week_en: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_tc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_sc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '1_am.png',
              am_en_path: '1_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '1_pm.png',
              pm_en_path: '1_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 61,
              hour_startY: 192,
              hour_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 204,
              minute_startY: 192,
              minute_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 330,
              second_startY: 192,
              second_array: ["1_013.png","1_014.png","1_015.png","1_016.png","1_017.png","1_018.png","1_019.png","1_020.png","1_021.png","1_022.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 173,
              y: 192,
              src: '1_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'TOP_BG_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '1_str_h.png',
              hour_centerX: 130,
              hour_centerY: 126,
              hour_posX: 8,
              hour_posY: 35,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '1_str_m.png',
              minute_centerX: 130,
              minute_centerY: 126,
              minute_posX: 8,
              minute_posY: 51,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '1_str_s.png',
              second_centerX: 130,
              second_centerY: 126,
              second_posX: 9,
              second_posY: 69,
              second_cover_path: '1_s.png',
              second_cover_x: 123,
              second_cover_y: 118,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '1_str_s.png',
              // center_x: 130,
              // center_y: 126,
              // x: 9,
              // y: 69,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: '1_s.png',
              // cover_x: 123,
              // cover_y: 118,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '1_str_s.png',
              second_centerX: 130,
              second_centerY: 126,
              second_posX: 9,
              second_posY: 69,
              fresh_frequency: 17,
              fresh_freqency: 17,
              second_cover_path: '1_s.png',
              second_cover_x: 123,
              second_cover_y: 118,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 17,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 323,
              font_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'AOD_int.png',
              unit_tc: 'AOD_int.png',
              unit_en: 'AOD_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["AOD_batt_01.png","AOD_batt_02.png","AOD_batt_03.png","AOD_batt_04.png","AOD_batt_05.png","AOD_batt_06.png","AOD_batt_07.png","AOD_batt_08.png","AOD_batt_09.png","AOD_batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 172,
              month_startY: 64,
              month_sc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_tc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_en_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 91,
              day_startY: 64,
              day_sc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_tc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_en_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 245,
              y: 65,
              week_en: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_tc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_sc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'AOD_am.png',
              am_en_path: 'AOD_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'AOD_pm.png',
              pm_en_path: 'AOD_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 154,
              hour_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 227,
              minute_startY: 154,
              minute_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 367,
              second_startY: 156,
              second_array: ["AOD_013.png","AOD_014.png","AOD_015.png","AOD_016.png","AOD_017.png","AOD_018.png","AOD_019.png","AOD_020.png","AOD_021.png","AOD_022.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 154,
              src: 'AOD_011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOD_TOP.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 264,
              y: 353,
              w: 129,
              h: 64,
              src: '00_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 307,
              w: 95,
              h: 44,
              src: '00_empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 174,
              y: 353,
              w: 87,
              h: 95,
              src: '00_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 77,
              y: 307,
              w: 115,
              h: 43,
              src: '00_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 76,
              y: 353,
              w: 95,
              h: 95,
              src: '00_empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 136,
              y: 0,
              w: 95,
              h: 61,
              src: '00_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 323,
              y: 196,
              w: 76,
              h: 66,
              src: '00_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 323,
              y: 265,
              w: 76,
              h: 38,
              src: '00_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 302,
              y: 307,
              w: 95,
              h: 43,
              src: '00_empty.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 130,
              w: 189,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 202,
              y: 66,
              w: 70,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_ALT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 234,
              y: 0,
              w: 95,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index' });
vibro(28);		
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 61,
              y: 194,
              w: 124,
              h: 112,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 194,
              w: 115,
              h: 112,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_BG()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 61,
              y: 183,
              w: 340,
              h: 142,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Day()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 61,
              y: 70,
              w: 137,
              h: 109,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_visabl()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

//let pressure_array = read_pressure();
//let value = getPressureValue(pressure_array);
//value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.
 
//normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));

normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	
normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.VISIBLE, false);
Button_6.setProperty(hmUI.prop.VISIBLE, false);	





            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 272;
                  let start_y_normal_heart_rate = 413;
                  let lenght_ls_normal_heart_rate = -93;
                  let line_width_ls_normal_heart_rate = 14;
                  let color_ls_normal_heart_rate = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 34;
                  let start_y_normal_battery = 179;
                  let lenght_ls_normal_battery = 94;
                  let line_width_ls_normal_battery = 14;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 405;
                  let start_y_normal_step = 178;
                  let lenght_ls_normal_step = 94;
                  let line_width_ls_normal_step = 14;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = line_width_ls_normal_step;
                  let line_width_ls_normal_step_draw = lenght_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    line_width_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_y_normal_step_draw = start_y_normal_step_draw - line_width_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                stopVibro();

                console.log('resume_call.js');
                // start resume_call.js

let pressure_array = read_pressure();
let value = getPressureValue(pressure_array);

if ( alt_var == 1) {value = hPa_To_mmHg(value);}	// перевод в мм.рт.ст. 		
if ( alt_var == 2) {value = getPressureValue(pressure_array);}   // перевод в гПа

normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));

normal_altimeter_text_separator_img.setProperty(hmUI.prop.SRC, color_bg + "_pres_0.png");

let pressere_changes = changesPressure(pressure_array);

if(pressere_changes < 0) {normal_altimeter_text_separator_img.setProperty(hmUI.prop.SRC, color_bg + "_pres_down.png");}
if(pressere_changes > 0) {normal_altimeter_text_separator_img.setProperty(hmUI.prop.SRC, color_bg + "_pres_up.png");}




                  

                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}