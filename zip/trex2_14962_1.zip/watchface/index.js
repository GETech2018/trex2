﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_year = ''
        let idle_date_year_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_distance_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_humidity_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Sfondo_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 108,
              day_startY: 232,
              day_sc_array: ["Nr. Giorni_01.png","Nr. Giorni_02.png","Nr. Giorni_03.png","Nr. Giorni_04.png","Nr. Giorni_05.png","Nr. Giorni_06.png","Nr. Giorni_07.png","Nr. Giorni_08.png","Nr. Giorni_09.png","Nr. Giorni_10.png"],
              day_tc_array: ["Nr. Giorni_01.png","Nr. Giorni_02.png","Nr. Giorni_03.png","Nr. Giorni_04.png","Nr. Giorni_05.png","Nr. Giorni_06.png","Nr. Giorni_07.png","Nr. Giorni_08.png","Nr. Giorni_09.png","Nr. Giorni_10.png"],
              day_en_array: ["Nr. Giorni_01.png","Nr. Giorni_02.png","Nr. Giorni_03.png","Nr. Giorni_04.png","Nr. Giorni_05.png","Nr. Giorni_06.png","Nr. Giorni_07.png","Nr. Giorni_08.png","Nr. Giorni_09.png","Nr. Giorni_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 7,
              y: 232,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 118,
              month_startY: 190,
              month_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              month_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              month_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 7,
              year_startY: 190,
              year_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              year_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              year_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              year_zero: 1,
              year_space: 3,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 190,
              src: 'Nr.Att_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 231,
              y: 98,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 192,
              y: 100,
              src: 'Sveglia_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 22,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Nr.Att_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 158,
              y: 390,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 236,
              y: 403,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Nr.Att_12.png',
              unit_tc: 'Nr.Att_12.png',
              unit_en: 'Nr.Att_12.png',
              negative_image: 'Nr.Att_11.png',
              invalid_image: 'Nr.Att_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 336,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 92,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 55,
              y: 135,
              image_array: ["Ind.3_01.png","Ind.3_02.png","Ind.3_03.png","Ind.3_04.png","Ind.3_05.png","Ind.3_06.png","Ind.3_07.png","Ind.3_08.png","Ind.3_09.png","Ind.3_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 336,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Nr.Att_15.png',
              unit_tc: 'Nr.Att_15.png',
              unit_en: 'Nr.Att_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 238,
              y: 294,
              image_array: ["Ind.3_01.png","Ind.3_02.png","Ind.3_03.png","Ind.3_04.png","Ind.3_05.png","Ind.3_06.png","Ind.3_07.png","Ind.3_08.png","Ind.3_09.png","Ind.3_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 336,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Nr.Att_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 57,
              y: 294,
              image_array: ["Ind.2_01.png","Ind.2_02.png","Ind.2_03.png","Ind.2_04.png","Ind.2_05.png","Ind.2_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 92,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 238,
              y: 135,
              image_array: ["Ind.1_01.png","Ind.1_02.png","Ind.1_03.png","Ind.1_04.png","Ind.1_05.png","Ind.1_06.png","Ind.1_07.png","Ind.1_08.png","Ind.1_09.png","Ind.1_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 173,
              hour_startY: 190,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 293,
              minute_startY: 190,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 389,
              second_startY: 221,
              second_array: ["Nr.Sec_01.png","Nr.Sec_02.png","Nr.Sec_03.png","Nr.Sec_04.png","Nr.Sec_05.png","Nr.Sec_06.png","Nr.Sec_07.png","Nr.Sec_08.png","Nr.Sec_09.png","Nr.Sec_10.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 270,
              y: 190,
              src: 'Nr.Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Sfondo_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 108,
              day_startY: 232,
              day_sc_array: ["Nr. Giorni_01.png","Nr. Giorni_02.png","Nr. Giorni_03.png","Nr. Giorni_04.png","Nr. Giorni_05.png","Nr. Giorni_06.png","Nr. Giorni_07.png","Nr. Giorni_08.png","Nr. Giorni_09.png","Nr. Giorni_10.png"],
              day_tc_array: ["Nr. Giorni_01.png","Nr. Giorni_02.png","Nr. Giorni_03.png","Nr. Giorni_04.png","Nr. Giorni_05.png","Nr. Giorni_06.png","Nr. Giorni_07.png","Nr. Giorni_08.png","Nr. Giorni_09.png","Nr. Giorni_10.png"],
              day_en_array: ["Nr. Giorni_01.png","Nr. Giorni_02.png","Nr. Giorni_03.png","Nr. Giorni_04.png","Nr. Giorni_05.png","Nr. Giorni_06.png","Nr. Giorni_07.png","Nr. Giorni_08.png","Nr. Giorni_09.png","Nr. Giorni_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 7,
              y: 232,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 118,
              month_startY: 190,
              month_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              month_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              month_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 7,
              year_startY: 190,
              year_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              year_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              year_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              year_zero: 1,
              year_space: 3,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 190,
              src: 'Nr.Att_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 231,
              y: 98,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 192,
              y: 100,
              src: 'Sveglia_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 22,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Nr.Att_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 158,
              y: 390,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 236,
              y: 403,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Nr.Att_12.png',
              unit_tc: 'Nr.Att_12.png',
              unit_en: 'Nr.Att_12.png',
              negative_image: 'Nr.Att_11.png',
              invalid_image: 'Nr.Att_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 336,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 92,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 55,
              y: 135,
              image_array: ["Ind.3_01.png","Ind.3_02.png","Ind.3_03.png","Ind.3_04.png","Ind.3_05.png","Ind.3_06.png","Ind.3_07.png","Ind.3_08.png","Ind.3_09.png","Ind.3_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 336,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Nr.Att_15.png',
              unit_tc: 'Nr.Att_15.png',
              unit_en: 'Nr.Att_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 238,
              y: 294,
              image_array: ["Ind.3_01.png","Ind.3_02.png","Ind.3_03.png","Ind.3_04.png","Ind.3_05.png","Ind.3_06.png","Ind.3_07.png","Ind.3_08.png","Ind.3_09.png","Ind.3_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 336,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Nr.Att_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 57,
              y: 294,
              image_array: ["Ind.2_01.png","Ind.2_02.png","Ind.2_03.png","Ind.2_04.png","Ind.2_05.png","Ind.2_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 92,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 238,
              y: 135,
              image_array: ["Ind.1_01.png","Ind.1_02.png","Ind.1_03.png","Ind.1_04.png","Ind.1_05.png","Ind.1_06.png","Ind.1_07.png","Ind.1_08.png","Ind.1_09.png","Ind.1_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 173,
              hour_startY: 190,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 293,
              minute_startY: 190,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 270,
              y: 190,
              src: 'Nr.Ore_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}