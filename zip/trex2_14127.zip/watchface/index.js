﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Start background change
         // Start background change
        let btn_element_5 = ''
        let elementnumber_5 = 1
        let total_elemente5 = 7

        function click_elemente5() {
            if(elementnumber_5 >=total_elemente5) {
           elementnumber_5=1;
            }
else { 
elementnumber_5 =elementnumber_5 +1;
}
            if(elementnumber_5 ==1) hmUI.showToast({text: 'Rojo'});
            if(elementnumber_5 ==2) hmUI.showToast({text: 'Verde'});
            if(elementnumber_5 ==3) hmUI.showToast({text: 'Violeta'});
            if(elementnumber_5 ==4) hmUI.showToast({text: 'Azul'});
            if(elementnumber_5 ==5) hmUI.showToast({text: 'Naranja'});
            if(elementnumber_5 ==6) hmUI.showToast({text: 'Amarillo'});
            if(elementnumber_5 ==7) hmUI.showToast({text: 'Gris'});



normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(elementnumber_5) + ".png");
        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_hour" + parseInt(elementnumber_5) + ".png");
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_min" + parseInt(elementnumber_5) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Hand_sec" + parseInt(elementnumber_5) + ".png");
        }



//////////////////////////////////////////////////////////////////////


      // hands clock style
        let btncolor2 = ''
        let colornumber2 = 1
        let totalcolors2 = 7
        let namecolor2 = ''

        function click_Color() {

if (elementnumber_3==1) {

            if(colornumber2>=totalcolors2) {
            colornumber2=1;
                }
            else {
                colornumber2=colornumber2+1;
            }

if ( colornumber2 == 1) { namecolor2 = "Analog Hand Rojo"}
if ( colornumber2 == 2) { namecolor2 = "Analog Hand Verde"}
if ( colornumber2 == 3) { namecolor2 = "Analog Hand Violeta"}
if ( colornumber2 == 4) { namecolor2 = "Analog Hand Azul"}
if ( colornumber2 == 5) { namecolor2 = "Analog Hand Naranja"}
if ( colornumber2 == 6) { namecolor2 = "Analog Hand Amarillo"}
if ( colornumber2 == 7) { namecolor2 = "Analog Hand Gris"}

hmUI.showToast({text: namecolor2 });

             //hmUI.showToast({text: "color " + parseInt(colornumber2) });
                      

        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_hour" + parseInt(colornumber2) + ".png");
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_min" + parseInt(colornumber2) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Hand_sec" + parseInt(colornumber2) + ".png");
        }
}

/////////////////////////////////////////////////////////////////////////////////////////////////


        // Start background change
        let btn_element_3= ''
        let elementnumber_3= 1
        let total_elemente3 = 2

        function click_elemente3() {
            if(elementnumber_3==total_elemente3) {
            elementnumber_3=1;
                UpdateElemente3One();
                }
            else {
                elementnumber_3=elementnumber_3+1;
                if(elementnumber_3==2) {
                  UpdateElemente3Two();
                }

            }
            if(elementnumber_3==1) hmUI.showToast({text: 'Hand clock ON'});
            if(elementnumber_3==2) hmUI.showToast({text: 'Handclock OFF'});
        }

        //Hand clock on
        function UpdateElemente3One(){
        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);

        }

        //hand clock off
        function UpdateElemente3Two(){
        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);

        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 26;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 26;
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: -1,
              y: 110,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 296,
              y: 354,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 265,
              // y: 277,
              // font_array: ["mdig_00.png","mdig_01.png","mdig_02.png","mdig_03.png","mdig_04.png","mdig_05.png","mdig_06.png","mdig_07.png","mdig_08.png","mdig_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 58,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'mdig_00.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'mdig_01.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'mdig_02.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'mdig_03.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'mdig_04.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'mdig_05.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'mdig_06.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'mdig_07.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'mdig_08.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'mdig_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 265,
                center_y: 277,
                pos_x: 265,
                pos_y: 277,
                angle: 58,
                src: 'mdig_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 277,
              // y: 125,
              // font_array: ["mdig_00.png","mdig_01.png","mdig_02.png","mdig_03.png","mdig_04.png","mdig_05.png","mdig_06.png","mdig_07.png","mdig_08.png","mdig_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -58,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'mdig_00.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'mdig_01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'mdig_02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'mdig_03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'mdig_04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'mdig_05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'mdig_06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'mdig_07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'mdig_08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'mdig_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 277,
                center_y: 125,
                pos_x: 277,
                pos_y: 125,
                angle: -58,
                src: 'mdig_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 320,
              font_array: ["wnb_00.png","wnb_01.png","wnb_02.png","wnb_03.png","wnb_04.png","wnb_05.png","wnb_06.png","wnb_07.png","wnb_08.png","wnb_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 98,
              y: 261,
              image_array: ["battery_01.png","battery_02.png","battery_03.png","battery_04.png","battery_05.png","battery_06.png","battery_07.png","battery_08.png","battery_09.png","battery_10.png","battery_11.png","battery_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 150,
              font_array: ["wnb_00.png","wnb_01.png","wnb_02.png","wnb_03.png","wnb_04.png","wnb_05.png","wnb_06.png","wnb_07.png","wnb_08.png","wnb_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'wnb_C.png',
              unit_tc: 'wnb_C.png',
              unit_en: 'wnb_C.png',
              negative_image: 'wnb_min.png',
              invalid_image: 'wnb_min.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 139,
              y: 84,
              image_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 97,
              y: 213,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 29,
              day_startY: 216,
              day_sc_array: ["mdig_00.png","mdig_01.png","mdig_02.png","mdig_03.png","mdig_04.png","mdig_05.png","mdig_06.png","mdig_07.png","mdig_08.png","mdig_09.png"],
              day_tc_array: ["mdig_00.png","mdig_01.png","mdig_02.png","mdig_03.png","mdig_04.png","mdig_05.png","mdig_06.png","mdig_07.png","mdig_08.png","mdig_09.png"],
              day_en_array: ["mdig_00.png","mdig_01.png","mdig_02.png","mdig_03.png","mdig_04.png","mdig_05.png","mdig_06.png","mdig_07.png","mdig_08.png","mdig_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 299,
              hour_startY: 188,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 301,
              minute_startY: 235,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(UpdateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_hour1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 45,
              // y: 176,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 45,
              pos_y: 227 - 176,
              center_x: 227,
              center_y: 227,
              src: 'Hand_hour1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_min1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 45,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 45,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'Hand_min1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_sec1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 23,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 23,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'Hand_sec1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 64,
              hour_startY: 222,
              hour_array: ["timeaod_00.png","timeaod_01.png","timeaod_02.png","timeaod_03.png","timeaod_04.png","timeaod_05.png","timeaod_06.png","timeaod_07.png","timeaod_08.png","timeaod_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 187,
              minute_startY: 222,
              minute_array: ["timeaod_00.png","timeaod_01.png","timeaod_02.png","timeaod_03.png","timeaod_04.png","timeaod_05.png","timeaod_06.png","timeaod_07.png","timeaod_08.png","timeaod_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 320,
              second_startY: 222,
              second_array: ["timeaod_00.png","timeaod_01.png","timeaod_02.png","timeaod_03.png","timeaod_04.png","timeaod_05.png","timeaod_06.png","timeaod_07.png","timeaod_08.png","timeaod_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: Bluetooth desconectado,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth conectado,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth desconectado"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth conectado"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 5,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Change color main
click_elemente5()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 198,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                /// hands analog color change
click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 389,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // on/off  analog hands 
click_elemente3()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 265 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 277 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}