﻿/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start

    class ImgWidget {
      constructor(data) {
        this._widget = hmUI.createWidget(hmUI.widget.IMG, data);

        this._angle = data.angle;
        this._visible = true;
      }

      get angle() {
        return this._angle;
      }
      set angle(value) {
        if (this._widget) {
          this._angle = value;
          this._widget.setProperty(hmUI.prop.ANGLE, this._angle);
        }
      }

      get visible() {
        return this._visible;
      }
      set visible(value) {
        if (this._widget) {
          this._visible = value;
          this._widget.setProperty(hmUI.prop.VISIBLE, this._visible);
        }
      }
    }

    function valuesAreClose(firstValue, secondValue, tolerance = 10) {
      return Math.abs(Math.abs(firstValue) - Math.abs(secondValue)) <= tolerance;
    }

    const CHRONO_RESET = 0;
    const CHRONO_START = 1;
    const CHRONO_STOP = 2;

    const NORMAL_SEC = 0;
    const SEMI_SMOOTH_SEC = 1;
    const SMOOTH_SEC = 2;

    // Analog Clock class
    class AnalonClock {
      constructor(timeSensor, secMode = SEMI_SMOOTH_SEC) {
        this.timeSensor = timeSensor;

        this.hourPointer = "";
        this.minutePointer = "";
        this.secondsPointer = "";

        this.normal_angle_hour = 0;
        this.normal_angle_minute = 0;
        this.normal_angle_second = 0;

        this.normal_timerUpdate = undefined;
        this.normal_timerUpdateSec = undefined;

        this.secondsMode = secMode;
      }
      addHourPointer(pointer) {
        this.hourPointer = pointer;
      }
      addMinutePointer(pointer) {
        this.minutePointer = pointer;
      }
      addSecondsPointer(pointer) {
        this.secondsPointer = pointer;
      }

      update(updateHour = false, updateMinute = false) {
        let hour = this.timeSensor.hour;
        let minute = this.timeSensor.minute;
        let second = this.timeSensor.second;

        if (updateHour) {
          let normal_hour = hour;
          let normal_fullAngle_hour = 360;
          if (normal_hour > 11) normal_hour -= 12;
          this.normal_angle_hour = 0 + (normal_fullAngle_hour * normal_hour) / 12 + ((normal_fullAngle_hour / 12) * minute) / 60;
          if (this.hourPointer) this.hourPointer.angle = this.normal_angle_hour;
        }

        if (updateMinute) {
          let normal_fullAngle_minute = 360;
          this.normal_angle_minute = 0 + (normal_fullAngle_minute * (minute + second / 60)) / 60;
          if (this.minutePointer) this.minutePointer.angle = this.normal_angle_minute;
        }

        let normal_fullAngle_second = 360;
        this.normal_angle_second = 0 + (normal_fullAngle_second * (second + (this.timeSensor.utc % 1000) / 1000)) / 60;
        if (this.secondsPointer) this.secondsPointer.angle = this.normal_angle_second;
      }

      start_update() {
        let screenType = hmSetting.getScreenType();

        if (screenType == hmSetting.screen_type.WATCHFACE) {
          if (!this.normal_timerUpdate) {
            let animDelay = timeSensor.utc % 1000;
            let animRepeat = 1000;
            this.normal_timerUpdate = timer.createTimer(animDelay, animRepeat, (option) => {
              this.update(false, true);
            }); // end timer
          } // end timer check
        } // end screenType

        if (screenType == hmSetting.screen_type.WATCHFACE) {
          if (!this.normal_timerUpdateSec) {
            let animDelay = 0;
            let animRepeat = 1000 / 6;
            this.normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (option) => {
              this.update(false, false);
            }); // end timer
          } // end timer check
        } // end screenType
      }

      stop_update() {
        if (this.normal_timerUpdate) {
          timer.stopTimer(this.normal_timerUpdate);
          this.normal_timerUpdate = undefined;
        }
        if (this.normal_timerUpdateSec) {
          timer.stopTimer(this.normal_timerUpdateSec);
          this.normal_timerUpdateSec = undefined;
        }
      }
    }

    // Chrono class
    class Chronograph {
      constructor(timeSensor, updateInterval = 1000 / 6) {
        this.timeSensor = timeSensor;
        this.chrono_update_interval = updateInterval;

        this.chrono_start_time = 0;
        this.chrono_current_time = 0;
        this.chrono_mem = 0;

        this.chrono_mode = CHRONO_RESET;

        this.normal_timerUpdateChrono = undefined;
        this.normal_timerArrowsToZero = undefined;

        this.normal_chrono_angle_second = 0;
        this.normal_chrono_angle_minute = 0;
        this.normal_chrono_angle_hour = 0;

        this.arrow_animation_delta = 6;
        this.arrows_animation_is_running = false;

        this.hourPointer = undefined;
        this.minutePointer = undefined;
        this.secondsPointer = undefined;
      }

      addHourPointer(pointer) {
        this.hourPointer = pointer;
      }
      addMinutePointer(pointer) {
        this.minutePointer = pointer;
      }
      addSecondsPointer(pointer) {
        this.secondsPointer = pointer;
      }

      start_stop() {
        switch (this.chrono_mode) {
          case CHRONO_RESET:
            this.chrono_mode = CHRONO_START;

            this.chrono_start_time = this.timeSensor.utc;
            // start timer
            if (!this.normal_timerUpdateChrono) {
              this.normal_timerUpdateChrono = timer.createTimer(0, this.chrono_update_interval, (option) => {
                this.update();
              });
            }
            break;
          case CHRONO_START:
            this.chrono_mode = CHRONO_STOP;
            // remember last measured time
            this.chrono_mem = this.chrono_mem + (this.chrono_current_time - this.chrono_start_time);
            // stop timer
            if (this.normal_timerUpdateChrono) {
              timer.stopTimer(this.normal_timerUpdateChrono);
              this.normal_timerUpdateChrono = undefined;
            }
            break;
          case CHRONO_STOP:
            this.chrono_mode = CHRONO_START;
            this.chrono_start_time = this.timeSensor.utc;
            // start timer
            if (!this.normal_timerUpdateChrono) {
              this.normal_timerUpdateChrono = timer.createTimer(0, this.chrono_update_interval, (option) => {
                this.update();
              });
            }
            break;
          default:
            break;
        }
      }

      reset() {
        if (this.chrono_mode == CHRONO_START) return;

        this.chrono_mode = CHRONO_RESET;

        this.chrono_mem = 0;
        this.chrono_start_time = 0;
        this.chrono_current_time = 0;

        // reset should smoothly move arrows to zero
        // start animation to zero timer
        if (!this.normal_timerArrowsToZero) {
          this.arrows_animation_is_running = true;
          this.normal_timerArrowsToZero = timer.createTimer(0, Math.floor(1000 / 30), (option) => {
            this.goToZero();
          });
        }
      }

      goToZero() {
        // decrement
        this.normal_chrono_angle_hour -= this.arrow_animation_delta;
        this.normal_chrono_angle_minute -= this.arrow_animation_delta;
        this.normal_chrono_angle_second -= this.arrow_animation_delta;

        // zero them out
        if (valuesAreClose(this.normal_chrono_angle_hour, 0)) this.normal_chrono_angle_hour = 0;
        if (valuesAreClose(this.normal_chrono_angle_minute, 0)) this.normal_chrono_angle_minute = 0;
        if (valuesAreClose(this.normal_chrono_angle_second, 0)) this.normal_chrono_angle_second = 0;

        // set elements angles
        if (this.hourPointer) this.hourPointer.angle = this.normal_chrono_angle_hour;
        if (this.minutePointer) this.minutePointer.angle = this.normal_chrono_angle_minute;
        if (this.secondsPointer) this.secondsPointer.angle = this.normal_chrono_angle_second;

        if (this.normal_chrono_angle_hour == 0 && this.normal_chrono_angle_minute == 0 && this.normal_chrono_angle_second == 0) {
          if (this.normal_timerArrowsToZero) {
            timer.stopTimer(this.normal_timerArrowsToZero);
            this.normal_timerArrowsToZero = undefined;
            this.arrows_animation_is_running = false;
          }
        }
      }

      update() {
        this.chrono_current_time = this.timeSensor.utc;
        let chrono_time_diff = this.chrono_current_time - this.chrono_start_time + this.chrono_mem;

        let msec_in_hour = 60 * 60 * 1000;
        let msec_in_min = 60 * 1000;
        let msec_in_sec = 1000;

        let hour = Math.floor(chrono_time_diff / msec_in_hour);
        let minute = Math.floor((chrono_time_diff - hour * msec_in_hour) / msec_in_min);
        let second = Math.floor((chrono_time_diff - hour * msec_in_hour - minute * msec_in_min) / msec_in_sec);
        let msec = chrono_time_diff - hour * msec_in_hour - minute * msec_in_min - second * msec_in_sec;

        // update arrows position
        // hour
        let normal_hour = hour;
        let normal_fullAngle_hour = 360;
        if (normal_hour > 11) normal_hour -= 12;
        this.normal_chrono_angle_hour = (normal_hour * 60 + minute) * (normal_fullAngle_hour / 12 / 60);
        if (this.hourPointer) this.hourPointer.angle = this.normal_chrono_angle_hour;

        // minutes
        let normal_fullAngle_minute = 360;
        this.normal_chrono_angle_minute = (minute * 60 + second) * (normal_fullAngle_minute / 30 / 60);
        if (this.minutePointer) this.minutePointer.angle = this.normal_chrono_angle_minute;

        // sec
        let normal_fullAngle_second = 360;
        this.normal_chrono_angle_second = (second * msec_in_sec + msec) * (normal_fullAngle_second / msec_in_min);
        if (this.secondsPointer) this.secondsPointer.angle = this.normal_chrono_angle_second;
      }
    }

    let date_pointer = "";
    let normal_bg = "";
    let chrono_half_minute = "";
    let chrono_second = "";
    let normal_week = "";
    let hour_pointer = "";
    let minute_pointer = "";
    let second_pointer = "";
    let idle_bg = "";
    let idle_hour = "";
    let idle_minute = "";

    let timeSensor = "";

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start
        const deviceInfo = hmSetting.getDeviceInfo();
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

        let analogClock = new AnalonClock(timeSensor, SMOOTH_SEC);
        let chrono = new Chronograph(timeSensor);

        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
          analogClock.update(true, true);
        });

        date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
          src: "date.png",
          center_x: 227,
          center_y: 227,
          posX: 227,
          posY: 227,
          start_angle: -11.6,
          end_angle: 348.4,
          type: hmUI.date.DAY,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        normal_bg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "normal_bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        chrono_half_minute = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 47,
          pos_y: 319 - 46,
          center_x: 227,
          center_y: 319,
          src: "normal_arrow_small.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        chrono.addMinutePointer(chrono_half_minute);

        normal_week = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
          src: "normal_arrow_small.png",
          center_x: 137,
          center_y: 203,
          posX: 46,
          posY: 47,
          start_angle: 0,
          end_angle: 360,
          type: hmUI.date.WEEK,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        second_pointer = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 318 - 47,
          pos_y: 203 - 46,
          center_x: 318,
          center_y: 203,
          src: "normal_arrow_small.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        analogClock.addSecondsPointer(second_pointer);

        hour_pointer = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 17,
          pos_y: 227 - 107,
          center_x: 227,
          center_y: 227,
          src: "normal_hour.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        analogClock.addHourPointer(hour_pointer);

        minute_pointer = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 15,
          pos_y: 227 - 160,
          center_x: 227,
          center_y: 227,
          src: "normal_minute.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        analogClock.addMinutePointer(minute_pointer);

        chrono_second = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 10,
          pos_y: 227 - 165,
          center_x: 227,
          center_y: 227,
          src: "normal_second.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        chrono.addSecondsPointer(chrono_second);

        // idle screen
        idle_bg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "idle_bg.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: "idle_hour.png",
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 17,
          hour_posY: 107,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: "idle_minute.png",
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 17,
          minute_posY: 160,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        // chrono buttons
        button_start_stop = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 327, // x coordinate of the button
          y: 70, // y coordinate of the button
          text: "",
          w: 60, // button width
          h: 60, // button height
          normal_src: "_empty.png", // transparent image
          press_src: "_empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            chrono.start_stop();
          },
        });

        button_reset = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 327, // x coordinate of the button
          y: 327, // y coordinate of the button
          text: "",
          w: 60, // button width
          h: 60, // button height
          normal_src: "_empty.png", // transparent image
          press_src: "_empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            chrono.reset();
          },
        });

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            analogClock.update(true, true);
            analogClock.start_update();
          },
          pause_call: function () {
            analogClock.stop_update();
          },
        });

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e && e.stack && e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
