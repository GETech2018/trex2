﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0

		let alt_var = 1
        let alt_all = 2
		let alt_text = ' '
		let pressure_array = read_pressure();
        let value = getPressureValue(pressure_array);
		
		let night_var = 1
        let night_all = 2
		let name_text = ' '
		
		let menu = 1
        let total_menu = 2
		
		let color_r = 1
        let colors_r = 8
		let namecolor_r = ' '
		
		let color_digt = 2
        let all_digt = 10
		let color_text = '0xFFFFFFFF'
		let namecolor_digt = ' '
		
		let color_bg = 1
        let totalcolors_bg = 7
		let namecolor_main = ' '
		
		let visabl_main = 1
		let totalvisabl_main = 4

	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	
//# барометр в мм рт. ст.


function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}



function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}
//# конец барометр в мм рт. ст.

// переключение едениц измерения давления

		

function click_ALT() {
            if(alt_var>=alt_all) {
            alt_var=1;
                }
            else {
                alt_var=alt_var+1;
            }
			if ( alt_var == 1) { 
			alt_text = "mmHg"  
			value = hPa_To_mmHg(value);              // перевод в мм.рт.ст.
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
		    }			
			if ( alt_var == 2) { 
			alt_text = "hPa" 
			value = getPressureValue(pressure_array);              // перевод в гПа
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
			}
			
			hmUI.showToast({text: alt_text });
			vibro(28);
									
		}

// конец переключение едениц измерения давления

//	переход в ночной режим (подставлением полупрозрачной картинки поверх циферблата)
		

			
		function click_Night() {
            if(night_var>=night_all) {
            night_var=1;
                }
            else {
                night_var=night_var+1;
            }
			if ( night_var == 1) name_text = "DAYTIME MODE"
			if ( night_var == 2) name_text = "NIGHT MODE"
			hmUI.showToast({text: name_text });
			image_top_img.setProperty(hmUI.prop.SRC, "night_" + parseInt(night_var) + ".png");
			vibro(28);
		}
		
//	конец перехода в ночной режим 


function click_BG() {
            if(color_digt>=all_digt) {
            color_digt=2;
                }
            else { 
			color_digt=color_digt+1;   
			}
			if ( color_digt == 2) namecolor_main = "GREEN"
			if ( color_digt == 3) namecolor_main = "EMERALD"
			if ( color_digt == 4) namecolor_main = "AQUA"
			if ( color_digt == 5) namecolor_main = "LILAC"
			if ( color_digt == 6) namecolor_main = "YELLOW"
			if ( color_digt == 7) namecolor_main = "ORANGE-1"
			if ( color_digt == 8) namecolor_main = "ORANGE-2"
			if ( color_digt == 9) namecolor_main = "GREY-1"
			if ( color_digt == 10) namecolor_main = "GREY-2"


		normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + parseInt(color_digt) + ".png");	
		
		normal_battery_icon_img.setProperty(hmUI.prop.SRC, "scale_" + parseInt(color_digt) + ".png");	
              
		normal_system_disconnect_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: parseInt(color_digt) + '_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 201,
              y: 32,
              image_array: [parseInt(color_digt) + "_wth00.png",parseInt(color_digt) + "_wth01.png",parseInt(color_digt) + "_wth02.png",parseInt(color_digt) + "_wth03.png",parseInt(color_digt) + "_wth04.png",parseInt(color_digt) + "_wth05.png",parseInt(color_digt) + "_wth06.png",parseInt(color_digt) + "_wth07.png",parseInt(color_digt) + "_wth08.png",parseInt(color_digt) + "_wth09.png",parseInt(color_digt) + "_wth10.png",parseInt(color_digt) + "_wth11.png",parseInt(color_digt) + "_wth12.png",parseInt(color_digt) + "_wth13.png",parseInt(color_digt) + "_wth14.png",parseInt(color_digt) + "_wth15.png",parseInt(color_digt) + "_wth16.png",parseInt(color_digt) + "_wth17.png",parseInt(color_digt) + "_wth18.png",parseInt(color_digt) + "_wth19.png",parseInt(color_digt) + "_wth20.png",parseInt(color_digt) + "_wth21.png",parseInt(color_digt) + "_wth22.png",parseInt(color_digt) + "_wth23.png",parseInt(color_digt) + "_wth24.png",parseInt(color_digt) + "_wth25.png",parseInt(color_digt) + "_wth26.png",parseInt(color_digt) + "_wth27.png",parseInt(color_digt) + "_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 194,
              y: 94,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_digt) + '_dig.png',
              unit_tc: parseInt(color_digt) + '_dig.png',
              unit_en: parseInt(color_digt) + '_dig.png',
              imperial_unit_sc: parseInt(color_digt) + '_dig.png',
              imperial_unit_tc: parseInt(color_digt) + '_dig.png',
              imperial_unit_en: parseInt(color_digt) + '_dig.png',
              negative_image: parseInt(color_digt) + '_minus.png',
              invalid_image: parseInt(color_digt) + '_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: parseInt(color_digt) + '_am.png',
              am_en_path: parseInt(color_digt) + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: parseInt(color_digt) + '_pm.png',
              pm_en_path: parseInt(color_digt) + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

        normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.MORE, {
              second_path: parseInt(color_digt) + '_sek.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 126,
              second_posY: 237,
              fresh_frequency: 17,
              fresh_freqency: 17,
              second_cover_path: 'TOP0.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		

			hmUI.showToast({text: namecolor_main });	
				
			vibro(28);
					
			}
 //  конец  изменения цвета фона	

 
 

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_alarm_clock_icon_img = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_icon_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 270,
              y: 97,
              image_array: ["5_WD_1_N.png","5_WD_2_NE.png","5_WD_3_E.png","5_WD_4_SE.png","5_WD_5_S.png","5_WD_6_SW.png","5_WD_7_W.png","5_WD_8_NW.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 97,
              font_array: ["1_073.png","1_074.png","1_075.png","1_076.png","1_077.png","1_078.png","1_079.png","1_080.png","1_081.png","1_082.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 141,
              month_startY: 91,
              month_sc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_tc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_en_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 70,
              day_startY: 91,
              day_sc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_tc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_en_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 111,
              y: 94,
              src: '1_slesh.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 382,
              y: 166,
              src: 'alarm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_icon_img.setAlpha(100);

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 201,
              font_array: ["1_056.png","1_057.png","1_058.png","1_059.png","1_060.png","1_061.png","1_062.png","1_063.png","1_064.png","1_065.png"],
              padding: true,
              h_space: -1,
              invalid_image: '1_eror_a.png',
              dot_image: '1_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '2_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 382,
              y: 166,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 54,
              y: 130,
              week_en: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_tc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_sc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 201,
              y: 32,
              image_array: ["2_wth00.png","2_wth01.png","2_wth02.png","2_wth03.png","2_wth04.png","2_wth05.png","2_wth06.png","2_wth07.png","2_wth08.png","2_wth09.png","2_wth10.png","2_wth11.png","2_wth12.png","2_wth13.png","2_wth14.png","2_wth15.png","2_wth16.png","2_wth17.png","2_wth18.png","2_wth19.png","2_wth20.png","2_wth21.png","2_wth22.png","2_wth23.png","2_wth24.png","2_wth25.png","2_wth26.png","2_wth27.png","2_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 183,
              y: 25,
              w: 87,
              h: 28,
              text_size: 17,
              char_space: -1,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 94,
              font_array: ["2_040.png","2_041.png","2_042.png","2_043.png","2_044.png","2_045.png","2_046.png","2_047.png","2_048.png","2_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '2_dig.png',
              unit_tc: '2_dig.png',
              unit_en: '2_dig.png',
              imperial_unit_sc: '2_dig.png',
              imperial_unit_tc: '2_dig.png',
              imperial_unit_en: '2_dig.png',
              negative_image: '2_minus.png',
              invalid_image: '2_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 194,
                y: 94,
                font_array: ["2_040.png","2_041.png","2_042.png","2_043.png","2_044.png","2_045.png","2_046.png","2_047.png","2_048.png","2_049.png"],
                padding: false,
                h_space: 0,
                unit_sc: '2_dig.png',
                unit_tc: '2_dig.png',
                unit_en: '2_dig.png',
                imperial_unit_sc: '2_dig.png',
                imperial_unit_tc: '2_dig.png',
                imperial_unit_en: '2_dig.png',
                negative_image: '2_minus.png',
                invalid_image: '2_eror.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 97,
              font_array: ["1_073.png","1_074.png","1_075.png","1_076.png","1_077.png","1_078.png","1_079.png","1_080.png","1_081.png","1_082.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 51,
              font_array: ["1_073.png","1_074.png","1_075.png","1_076.png","1_077.png","1_078.png","1_079.png","1_080.png","1_081.png","1_082.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 51,
              font_array: ["1_073.png","1_074.png","1_075.png","1_076.png","1_077.png","1_078.png","1_079.png","1_080.png","1_081.png","1_082.png"],
              padding: true,
              h_space: 0,
              unit_sc: '1_int_m.png',
              unit_tc: '1_int_m.png',
              unit_en: '1_int_m.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 72,
              y: 306,
              font_array: ["1_073.png","1_074.png","1_075.png","1_076.png","1_077.png","1_078.png","1_079.png","1_080.png","1_081.png","1_082.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 306,
              font_array: ["1_073.png","1_074.png","1_075.png","1_076.png","1_077.png","1_078.png","1_079.png","1_080.png","1_081.png","1_082.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_km.png',
              unit_tc: '1_km.png',
              unit_en: '1_km.png',
              dot_image: '1_point.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 348,
              font_array: ["1_073.png","1_074.png","1_075.png","1_076.png","1_077.png","1_078.png","1_079.png","1_080.png","1_081.png","1_082.png"],
              padding: false,
              h_space: 0,
              invalid_image: '86.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 348,
              font_array: ["1_073.png","1_074.png","1_075.png","1_076.png","1_077.png","1_078.png","1_079.png","1_080.png","1_081.png","1_082.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 394,
              font_array: ["1_073.png","1_074.png","1_075.png","1_076.png","1_077.png","1_078.png","1_079.png","1_080.png","1_081.png","1_082.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 394,
              font_array: ["1_073.png","1_074.png","1_075.png","1_076.png","1_077.png","1_078.png","1_079.png","1_080.png","1_081.png","1_082.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 332,
              // center_y: 319,
              // start_angle: -180,
              // end_angle: 180,
              // radius: 65,
              // line_width: 19,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 332,
              center_y: 319,
              start_angle: 180,
              end_angle: -180,
              radius: 56,
              line_width: 19,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(150);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'scale_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 301,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 271,
              font_array: ["1_056.png","1_057.png","1_058.png","1_059.png","1_060.png","1_061.png","1_062.png","1_063.png","1_064.png","1_065.png"],
              padding: true,
              h_space: 0,
              invalid_image: '1_eror_a.png',
              dot_image: '1_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 40,
              y: 269,
              src: 'S_R.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 271,
              font_array: ["1_056.png","1_057.png","1_058.png","1_059.png","1_060.png","1_061.png","1_062.png","1_063.png","1_064.png","1_065.png"],
              padding: true,
              h_space: 0,
              invalid_image: '1_eror_a.png',
              dot_image: '1_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 269,
              src: 'S_D.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: 168,
              hour_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 193,
              minute_startY: 168,
              minute_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 299,
              second_startY: 170,
              second_array: ["1_013.png","1_014.png","1_015.png","1_016.png","1_017.png","1_018.png","1_019.png","1_020.png","1_021.png","1_022.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 170,
              src: '1_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '2_am.png',
              am_en_path: '2_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '2_pm.png',
              pm_en_path: '2_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'TOP.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '2_sek.png',
              // center_x: 227,
              // center_y: 227,
              // x: 126,
              // y: 237,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'TOP0.png',
              // cover_x: 0,
              // cover_y: 0,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '2_sek.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 126,
              second_posY: 237,
              fresh_frequency: 17,
              fresh_freqency: 17,
              second_cover_path: 'TOP0.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 17,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 141,
              month_startY: 92,
              month_sc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_tc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_en_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 70,
              day_startY: 91,
              day_sc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_tc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_en_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 111,
              y: 94,
              src: 'AOD_slesh.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 54,
              y: 130,
              week_en: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_tc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_sc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 301,
              font_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD_int.png',
              unit_tc: 'AOD_int.png',
              unit_en: 'AOD_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 332,
              // center_y: 319,
              // start_angle: -180,
              // end_angle: 180,
              // radius: 64,
              // line_width: 18,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 332,
              center_y: 319,
              start_angle: 180,
              end_angle: -180,
              radius: 55,
              line_width: 18,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_circle_scale.setAlpha(150);

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'scale_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: 168,
              hour_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 193,
              minute_startY: 168,
              minute_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 303,
              second_startY: 170,
              second_array: ["1_013.png","1_014.png","1_015.png","1_016.png","1_017.png","1_018.png","1_019.png","1_020.png","1_021.png","1_022.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 170,
              src: '1_011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'AOD_am.png',
              am_en_path: 'AOD_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'AOD_pm.png',
              pm_en_path: 'AOD_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 52,
              y: 300,
              w: 201,
              h: 43,
              src: '00_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 162,
              y: 344,
              w: 95,
              h: 41,
              src: '00_empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 345,
              w: 99,
              h: 70,
              src: '00_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 163,
              y: 389,
              w: 142,
              h: 55,
              src: '00_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 271,
              y: 268,
              w: 121,
              h: 117,
              src: '00_empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 48,
              y: 266,
              w: 208,
              h: 32,
              src: '00_empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 89,
              w: 95,
              h: 71,
              src: '00_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 169,
              w: 60,
              h: 77,
              src: '00_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 367,
              y: 172,
              w: 73,
              h: 78,
              src: '00_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 52,
              y: 89,
              w: 131,
              h: 74,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 26,
              w: 131,
              h: 59,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 72,
              y: 27,
              w: 119,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_ALT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 68,
              y: 167,
              w: 98,
              h: 96,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 167,
              w: 98,
              h: 96,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_BG()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 332,
                      center_y: 319,
                      start_angle: 180,
                      end_angle: -180,
                      radius: 56,
                      line_width: 19,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 332,
                      center_y: 319,
                      start_angle: 180,
                      end_angle: -180,
                      radius: 55,
                      line_width: 18,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}