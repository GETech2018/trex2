﻿/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start

    let normal_background_bg_img = "";
    let normal_date_img_date_day = "";
    let normal_analog_clock_pro_hour_pointer_img = "";
    let normal_analog_clock_pro_minute_pointer_img = "";
    let normal_timerUpdateSec = undefined;
    let normal_analog_clock_pro_second_pointer_small_img = "";
    let normal_chronograph_second_pointer_img = "";
    let normal_chronograph_half_minute_pointer_img = "";
    let normal_chronograph_hour_pointer_img = "";
    let normal_timerUpdateSecSmooth = undefined;
    let normal_timerUpdateChrono = undefined;
    let normal_analog_clock_pro_second_cover_pointer_img = "";
    let idle_background_bg_img = "";
    let idle_analog_clock_time_pointer_hour = "";
    let idle_analog_clock_time_pointer_minute = "";

    let button_start_stop = "";
    let button_reset = "";

    let timeSensor = "";

    let backgrounds = [
      "normal_bg_black.png",
      "normal_bg_violet.png",
      "normal_bg_glue.png",
      "normal_bg_aqua.png",
      "normal_bg_green.png",
      "normal_bg_copper.png",
      "normal_bg_red.png",
    ];
    let current_bg = 0;

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start

        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "normal_bg_black.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 217,
          day_startY: 363,
          day_sc_array: [
            "digit_0.png",
            "digit_1.png",
            "digit_2.png",
            "digit_3.png",
            "digit_4.png",
            "digit_5.png",
            "digit_6.png",
            "digit_7.png",
            "digit_8.png",
            "digit_9.png",
          ],
          day_tc_array: [
            "digit_0.png",
            "digit_1.png",
            "digit_2.png",
            "digit_3.png",
            "digit_4.png",
            "digit_5.png",
            "digit_6.png",
            "digit_7.png",
            "digit_8.png",
            "digit_9.png",
          ],
          day_en_array: [
            "digit_0.png",
            "digit_1.png",
            "digit_2.png",
            "digit_3.png",
            "digit_4.png",
            "digit_5.png",
            "digit_6.png",
            "digit_7.png",
            "digit_8.png",
            "digit_9.png",
          ],
          day_zero: 0,
          day_space: 0,
          day_align: hmUI.align.CENTER_H,
          day_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const deviceInfo = hmSetting.getDeviceInfo();
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
          time_update(true, true);
        });

        hmUI.createWidget(hmUI.widget.IMG, {
          x: 327,
          y: 70,
          w: 60,
          h: 60,
          src: "button_start_stop.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          angle: 0,
        });

        hmUI.createWidget(hmUI.widget.IMG, {
          x: 327,
          y: 327,
          w: 60,
          h: 60,
          angle: 0,
          src: "button_reset.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_chronograph_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 127 - 127 / 2,
          y: 227 - 127 / 2,
          w: 127,
          h: 127,
          pos_x: 0,
          pos_y: 0,
          center_x: 127 / 2,
          center_y: 127 / 2,
          src: "normal_small_arrow.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_chronograph_half_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 327 - 127 / 2,
          y: 227 - 127 / 2,
          w: 127,
          h: 127,
          pos_x: 0,
          pos_y: 0,
          center_x: 127 / 2,
          center_y: 127 / 2,
          src: "normal_small_arrow.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_second_pointer_small_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 227 - 127 / 2,
          y: 327 - 127 / 2,
          w: 127,
          h: 127,
          pos_x: 0,
          pos_y: 0,
          center_x: 127 / 2,
          center_y: 127 / 2,
          src: "normal_small_arrow.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'normal_hr.png',
        // center_x: 227,
        // center_y: 227,
        // x: 227,
        // y: 227,
        // start_angle: 0,
        // end_angle: 360,
        // type: hmUI.data_type.hour,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 227,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_hr.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();
        // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'normal_min.png',
        // center_x: 227,
        // center_y: 227,
        // x: 227,
        // y: 227,
        // start_angle: 0,
        // end_angle: 360,
        // type: hmUI.data_type.minute,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 227,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_min.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'normal_sec.png',
        // center_x: 227,
        // center_y: 227,
        // x: 227,
        // y: 227,
        // start_angle: 0,
        // end_angle: 360,
        // cover_path: 'normal_center.png',
        // cover_x: 221,
        // cover_y: 222,
        // type: hmUI.data_type.second,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_chronograph_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 227,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_sec.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 221,
          y: 222,
          src: "normal_center.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
        // type: 2,
        // fps: 6,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "idle_bg.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: "idle_hr.png",
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 227,
          hour_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: "idle_min.png",
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 227,
          minute_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        let tag_button = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 201, // x coordinate of the button
          y: 126, // y coordinate of the button
          text: "",
          w: 50, // button width
          h: 44, // button height
          normal_src: "_empty.png", // transparent image
          press_src: "_empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            cycle_bg();
          },
        });

        button_start_stop = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 327, // x coordinate of the button
          y: 70, // y coordinate of the button
          text: "",
          w: 60, // button width
          h: 60, // button height
          normal_src: "_empty.png", // transparent image
          press_src: "_empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            chrono_start_stop();
          },
        });

        button_reset = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 327, // x coordinate of the button
          y: 327, // y coordinate of the button
          text: "",
          w: 60, // button width
          h: 60, // button height
          normal_src: "_empty.png", // transparent image
          press_src: "_empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            chrono_reset();
          },
        });

        function cycle_bg() {
          current_bg++;
          if (current_bg >= backgrounds.length) current_bg = 0;

          normal_background_bg_img.setProperty(hmUI.prop.SRC, backgrounds[current_bg]);
        }

        let chrono_start_time = 0;
        let chrono_current_time = 0;
        let chrono_mem = 0;

        const CHRONO_RESET = 0;
        const CHRONO_START = 1;
        const CHRONO_STOP = 2;

        let chrono_mode = CHRONO_RESET;

        function chrono_start_stop() {
          switch (chrono_mode) {
            case CHRONO_RESET:
              hmUI.showToast({ text: "Start" });
              chrono_mode = CHRONO_START;

              chrono_start_time = timeSensor.utc;
              // start timer
              if (!normal_timerUpdateChrono) {
                normal_timerUpdateChrono = timer.createTimer(0, 200, function (option) {
                  update_chrono();
                });
              }
              break;
            case CHRONO_START:
              hmUI.showToast({ text: "Stop" });
              chrono_mode = CHRONO_STOP;
              // remember last measured time
              chrono_mem = chrono_mem + (chrono_current_time - chrono_start_time);
              // stop timer
              if (normal_timerUpdateChrono) {
                timer.stopTimer(normal_timerUpdateChrono);
                normal_timerUpdateChrono = undefined;
              }
              break;
            case CHRONO_STOP:
              chrono_mode = CHRONO_START;
              chrono_start_time = timeSensor.utc;
              // start timer
              if (!normal_timerUpdateChrono) {
                normal_timerUpdateChrono = timer.createTimer(0, 200, function (option) {
                  update_chrono();
                });
              }
              break;
            default:
              break;
          }
        }

        function chrono_reset() {
          if (chrono_mode == CHRONO_START) return;

          hmUI.showToast({ text: "Reset" });
          chrono_mode = CHRONO_RESET;

          chrono_mem = 0;
          chrono_start_time = 0;
          chrono_current_time = 0;

          // align arrows to 0
          if (normal_chronograph_second_pointer_img) normal_chronograph_second_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
          if (normal_chronograph_half_minute_pointer_img) normal_chronograph_half_minute_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
          if (normal_chronograph_hour_pointer_img) normal_chronograph_hour_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
        }

        function update_chrono() {
          chrono_current_time = timeSensor.utc;
          let chrono_time_diff = chrono_current_time - chrono_start_time + chrono_mem;

          let msec_in_hour = 60 * 60 * 1000;
          let msec_in_min = 60 * 1000;
          let msec_in_sec = 1000;

          let hour = Math.floor(chrono_time_diff / msec_in_hour);
          let minute = Math.floor((chrono_time_diff - hour * msec_in_hour) / msec_in_min);
          let second = Math.floor((chrono_time_diff - hour * msec_in_hour - minute * msec_in_min) / msec_in_sec);
          let msec = chrono_time_diff - hour * msec_in_hour - minute * msec_in_min - second * msec_in_sec;

          // update arrows position
          // hour
          let normal_hour = hour;
          let normal_fullAngle_hour = 360;
          if (normal_hour > 11) normal_hour -= 12;
          let normal_angle_hour = (normal_hour * 60 + minute) * (normal_fullAngle_hour / 12 / 60);
          if (normal_chronograph_hour_pointer_img) normal_chronograph_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);

          // half-minutes
          let normal_fullAngle_minute = 360;
          let normal_angle_minute = (minute * 60 + second) * (normal_fullAngle_minute / 30 / 60);
          if (normal_chronograph_half_minute_pointer_img) normal_chronograph_half_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);

          // sec
          let normal_fullAngle_second = 360;
          let normal_angle_second = (second * msec_in_sec + msec) * (normal_fullAngle_second / msec_in_min);
          if (normal_chronograph_second_pointer_img) normal_chronograph_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);
        }

        function time_update(updateHour = false, updateMinute = false) {
          let hour = timeSensor.hour;
          let minute = timeSensor.minute;
          let second = timeSensor.second;

          if (updateHour) {
            let normal_hour = hour;
            let normal_fullAngle_hour = 360;
            if (normal_hour > 11) normal_hour -= 12;
            let normal_angle_hour = 0 + (normal_fullAngle_hour * normal_hour) / 12 + ((normal_fullAngle_hour / 12) * minute) / 60;
            if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
          }

          if (updateMinute) {
            let normal_fullAngle_minute = 360;
            let normal_angle_minute = 0 + (normal_fullAngle_minute * (minute + second / 60)) / 60;
            if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
          }

          let normal_fullAngle_second = 360;
          let normal_angle_second = 0 + (normal_fullAngle_second * (second + (timeSensor.utc % 1000) / 1000)) / 60;
          if (normal_analog_clock_pro_second_pointer_small_img)
            normal_analog_clock_pro_second_pointer_small_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);
        }

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            time_update(true, true);
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSec) {
                let animDelay = timeSensor.utc % 1000;
                let animRepeat = 1000;
                normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, function (option) {
                  time_update(false, true);
                }); // end timer
              } // end timer check
            } // end screenType

            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSecSmooth) {
                let animDelay = 0;
                let animRepeat = 1000 / 6;
                normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, function (option) {
                  time_update(false, false);
                }); // end timer
              } // end timer check
            } // end screenType
          },
          pause_call: function () {
            if (normal_timerUpdateSec) {
              timer.stopTimer(normal_timerUpdateSec);
              normal_timerUpdateSec = undefined;
            }
            if (normal_timerUpdateSecSmooth) {
              timer.stopTimer(normal_timerUpdateSecSmooth);
              normal_timerUpdateSecSmooth = undefined;
            }
          },
        });

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e && e.stack && e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
