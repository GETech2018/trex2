﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'pozadi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 351,
              font_array: ["baterie_0.png","baterie_1.png","baterie_2.png","baterie_3.png","baterie_4.png","baterie_5.png","baterie_6.png","baterie_7.png","baterie_8.png","baterie_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 153,
              month_startY: 41,
              month_sc_array: ["baterie_0.png","baterie_1.png","baterie_2.png","baterie_3.png","baterie_4.png","baterie_5.png","baterie_6.png","baterie_7.png","baterie_8.png","baterie_9.png"],
              month_tc_array: ["baterie_0.png","baterie_1.png","baterie_2.png","baterie_3.png","baterie_4.png","baterie_5.png","baterie_6.png","baterie_7.png","baterie_8.png","baterie_9.png"],
              month_en_array: ["baterie_0.png","baterie_1.png","baterie_2.png","baterie_3.png","baterie_4.png","baterie_5.png","baterie_6.png","baterie_7.png","baterie_8.png","baterie_9.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 41,
              src: 'tecka.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 92,
              day_startY: 41,
              day_sc_array: ["baterie_0.png","baterie_1.png","baterie_2.png","baterie_3.png","baterie_4.png","baterie_5.png","baterie_6.png","baterie_7.png","baterie_8.png","baterie_9.png"],
              day_tc_array: ["baterie_0.png","baterie_1.png","baterie_2.png","baterie_3.png","baterie_4.png","baterie_5.png","baterie_6.png","baterie_7.png","baterie_8.png","baterie_9.png"],
              day_en_array: ["baterie_0.png","baterie_1.png","baterie_2.png","baterie_3.png","baterie_4.png","baterie_5.png","baterie_6.png","baterie_7.png","baterie_8.png","baterie_9.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 134,
              y: 41,
              src: 'tecka.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 226,
              // start_angle: 155,
              // end_angle: 124,
              // radius: 217,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFE805FA,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 226,
              start_angle: 155,
              end_angle: 124,
              radius: 213,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFE805FA,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 414,
              font_array: ["baterie_0.png","baterie_1.png","baterie_2.png","baterie_3.png","baterie_4.png","baterie_5.png","baterie_6.png","baterie_7.png","baterie_8.png","baterie_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'procenta.png',
              unit_tc: 'procenta.png',
              unit_en: 'procenta.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 372,
              font_array: ["kroky_0.png","kroky_1.png","kroky_2.png","kroky_3.png","kroky_4.png","kroky_5.png","kroky_6.png","kroky_7.png","kroky_8.png","kroky_9.png"],
              padding: true,
              h_space: -3,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'desetina_carka.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 325,
              font_array: ["kroky_0.png","kroky_1.png","kroky_2.png","kroky_3.png","kroky_4.png","kroky_5.png","kroky_6.png","kroky_7.png","kroky_8.png","kroky_9.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 6,
              hour_startY: 202,
              hour_array: ["cas_0.png","cas_1.png","cas_2.png","cas_3.png","cas_4.png","cas_5.png","cas_6.png","cas_7.png","cas_8.png","cas_9.png"],
              hour_zero: 1,
              hour_space: -20,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 238,
              minute_startY: 202,
              minute_array: ["cas_0.png","cas_1.png","cas_2.png","cas_3.png","cas_4.png","cas_5.png","cas_6.png","cas_7.png","cas_8.png","cas_9.png"],
              minute_zero: 1,
              minute_space: -20,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 392,
              second_startY: 171,
              second_array: ["baterie_0.png","baterie_1.png","baterie_2.png","baterie_3.png","baterie_4.png","baterie_5.png","baterie_6.png","baterie_7.png","baterie_8.png","baterie_9.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 219,
              y: 234,
              src: 'dvojtecka.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 226,
                      start_angle: 155,
                      end_angle: 124,
                      radius: 213,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFE805FA,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}