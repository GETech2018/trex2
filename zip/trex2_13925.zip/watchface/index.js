﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 24;
        let normal_step_TextRotate_unit = null;
        let normal_step_TextRotate_unit_width = 96;
        let normal_step_TextRotate_error_img_width = 83;
        let normal_system_disconnect_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 100,
              // y: 389,
              // font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -27,
              // unit_en: 'Step_Unit.png',
              // invalid_image: 'Step_Error.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'Step_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'Step_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'Step_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'Step_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'Step_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'Step_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'Step_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'Step_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'Step_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'Step_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 100,
                center_y: 389,
                pos_x: 100,
                pos_y: 389,
                angle: -27,
                src: 'Step_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_step_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 100,
              center_y: 389,
              pos_x: 100,
              pos_y: 389,
              angle: -27,
              src: 'Step_Unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 338,
              y: 267,
              src: 'Bluetooth_Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 285,
              y: 74,
              image_array: ["Weather_1.png","Weather_2.png","Weather_3.png","Weather_4.png","Weather_5.png","Weather_6.png","Weather_7.png","Weather_8.png","Weather_9.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 300,
              y: 275,
              image_array: ["Battery_1.png","Battery_2.png","Battery_3.png","Battery_4.png","Battery_5.png","Battery_6.png","Battery_7.png","Battery_8.png","Battery_9.png","Battery_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 413,
              y: 225,
              image_array: ["Moon_0.png","Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 343,
              y: 203,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 32,
              year_startY: 117,
              year_sc_array: ["Year_0.png","Year_1.png","Year_2.png","Year_3.png","Year_4.png","Year_5.png","Year_6.png","Year_7.png","Year_8.png","Year_9.png"],
              year_tc_array: ["Year_0.png","Year_1.png","Year_2.png","Year_3.png","Year_4.png","Year_5.png","Year_6.png","Year_7.png","Year_8.png","Year_9.png"],
              year_en_array: ["Year_0.png","Year_1.png","Year_2.png","Year_3.png","Year_4.png","Year_5.png","Year_6.png","Year_7.png","Year_8.png","Year_9.png"],
              year_zero: 1,
              year_space: -13,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 283,
              day_startY: 189,
              day_sc_array: ["Date_0.png","Date_1.png","Date_2.png","Date_3.png","Date_4.png","Date_5.png","Date_6.png","Date_7.png","Date_8.png","Date_9.png"],
              day_tc_array: ["Date_0.png","Date_1.png","Date_2.png","Date_3.png","Date_4.png","Date_5.png","Date_6.png","Date_7.png","Date_8.png","Date_9.png"],
              day_en_array: ["Date_0.png","Date_1.png","Date_2.png","Date_3.png","Date_4.png","Date_5.png","Date_6.png","Date_7.png","Date_8.png","Date_9.png"],
              day_zero: 0,
              day_space: -15,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 36,
              month_startY: 112,
              month_sc_array: ["Month_1.png","Month_2.png","Month_3.png","Month_4.png","Month_5.png","Month_6.png","Month_7.png","Month_8.png","Month_9.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_1.png","Month_2.png","Month_3.png","Month_4.png","Month_5.png","Month_6.png","Month_7.png","Month_8.png","Month_9.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_1.png","Month_2.png","Month_3.png","Month_4.png","Month_5.png","Month_6.png","Month_7.png","Month_8.png","Month_9.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 215,
              am_y: 250,
              am_sc_path: 'AMPM_1.png',
              am_en_path: 'AMPM_1.png',
              pm_x: 215,
              pm_y: 250,
              pm_sc_path: 'AMPM_2.png',
              pm_en_path: 'AMPM_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 66,
              hour_startY: 332,
              hour_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 333,
              hour_align: hmUI.align.LEFT,

              minute_startX: 148,
              minute_startY: 290,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 333,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Pointer_Hr.png',
              hour_centerX: 80,
              hour_centerY: 250,
              hour_posX: 2,
              hour_posY: 40,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Pointer_Min.png',
              minute_centerX: 80,
              minute_centerY: 250,
              minute_posX: 2,
              minute_posY: 65,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            let screenType = hmSetting.getScreenType();
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_step_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 100 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_step_TextRotate_unit.setProperty(hmUI.prop.POS_X, 100 + img_offset);
                  normal_step_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_step_TextRotate[0].setProperty(hmUI.prop.POS_X, 100);
                  normal_step_TextRotate[0].setProperty(hmUI.prop.SRC, 'Step_Error.png');
                  normal_step_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}