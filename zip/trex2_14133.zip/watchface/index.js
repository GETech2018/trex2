﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

		const language = hmSetting.getLanguage()
		let deviceInfo = hmSetting.getDeviceInfo();
		let Rootpath = ''
		let ArrayWD = ''
		
		function set_dow() {
				if (language == 3) {Rootpath = "3-ESP/"}
				else if (language == 4) {Rootpath = "4-RUS/"}
				else if (language == 6) {Rootpath = "6-FRA/"}
				else if (language == 7) {Rootpath = "7-GER/"}
				else if (language == 9) {Rootpath = "9-POL/"}
				else if (language == 10) {Rootpath = "10-ITA/"}
				else if (language == 15) {Rootpath = "15-POR/"}
				else if (language == 18) {Rootpath = "18-UKR/"}
				else if (language == 23) {Rootpath = "23-GRE/"}
				else {Rootpath = ''}
				
				ArrayWD =  [Rootpath+"wd_01.png",Rootpath+"wd_02.png",Rootpath+"wd_03.png",Rootpath+"wd_04.png",Rootpath+"wd_05.png",Rootpath+"wd_06.png",Rootpath+"wd_07.png"]
				
				normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
					x: 67,
					y: 198,
					week_en: ArrayWD,
					week_tc: ArrayWD,
					week_sc: ArrayWD,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
		}
		
		let animnumber_1 = 1
        let total_anim = 2

        function click_MENU() {
            if(animnumber_1==total_anim) {
            animnumber_1=1;
                UpdateanimOne();
                }
            else {
                animnumber_1=animnumber_1+1;
                if(animnumber_1==2) {
                  UpdateanimTwo();
                }
            }
        }

        function UpdateanimOne(){
				normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_9.setProperty(hmUI.prop.VISIBLE, false);
				Button_11.setProperty(hmUI.prop.VISIBLE, false);
				normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				Button_1.setProperty(hmUI.prop.VISIBLE, true);
				Button_2.setProperty(hmUI.prop.VISIBLE, true);
				Button_3.setProperty(hmUI.prop.VISIBLE, true);
				Button_4.setProperty(hmUI.prop.VISIBLE, true);
				Button_5.setProperty(hmUI.prop.VISIBLE, true);
				Button_6.setProperty(hmUI.prop.VISIBLE, true);
				Button_7.setProperty(hmUI.prop.VISIBLE, true);
				Button_8.setProperty(hmUI.prop.VISIBLE, true);
				Button_12.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdateanimTwo(){
				normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				Button_9.setProperty(hmUI.prop.VISIBLE, true);
				Button_11.setProperty(hmUI.prop.VISIBLE, true);
				normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_sleep_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				Button_1.setProperty(hmUI.prop.VISIBLE, false);
				Button_2.setProperty(hmUI.prop.VISIBLE, false);
				Button_3.setProperty(hmUI.prop.VISIBLE, false);
				Button_4.setProperty(hmUI.prop.VISIBLE, false);
				Button_5.setProperty(hmUI.prop.VISIBLE, false);
				Button_6.setProperty(hmUI.prop.VISIBLE, false);
				Button_7.setProperty(hmUI.prop.VISIBLE, false);
				Button_8.setProperty(hmUI.prop.VISIBLE, false);
				Button_12.setProperty(hmUI.prop.VISIBLE, false);
        }
		
		let elementnumber_1 = 1
        let total_elemente = 3

        function click_HANDS() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
				if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
            }
            if(elementnumber_1==1) hmUI.showToast({text: 'NORMAL SEC'});
            if(elementnumber_1==2) hmUI.showToast({text: 'SMOOTH SEC'});
			if(elementnumber_1==3) hmUI.showToast({text: 'HANDS OFF'});
        }

        // Smooth OFF
        function UpdateElementeOne(){
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        }

        //Smooth ON
        function UpdateElementeTwo(){
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        }
		
		//Hands OFF
        function UpdateElementeThree(){
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        }
		
		let screenType = hmSetting.getScreenType();
		let kd33Color_AOD = ''
		let colornumber_main = 1
        let totalcolors_main = 16
        let namecolor_main = ''
		let secstring = 't_sec1.png'

        function click_COLOR() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

			if ( colornumber_main == 1) { namecolor_main = "O R A N G E"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 2) { namecolor_main = "T E A L"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 3) { namecolor_main = "O L I V E"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 4) { namecolor_main = "M A R O O N"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 5) { namecolor_main = "A Q U A"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 6) { namecolor_main = "G R E E N"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 7) { namecolor_main = "R E D"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 8) { namecolor_main = "Y E L L O W"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 9) { namecolor_main = "L I M E"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 10) { namecolor_main = "P U R P L E"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 11) { namecolor_main = "B L U E"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 12) { namecolor_main = "F U C H S I A"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 13) { namecolor_main = "S E P I A"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 14) { namecolor_main = "A M B E R"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 15) { namecolor_main = "S I L V E R"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 16) { namecolor_main = "W H I T E"
				secstring = "t_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main <= 16) { 
			
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 19,
              second_posY: 231,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			}
			
			hmFS.SysProSetInt('kd33Color', colornumber_main);
            console.log(kd33Color_AOD);   

			hmUI.showToast({text: namecolor_main });
            normal_image_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber_main) + ".png");
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "t_sec" + parseInt(colornumber_main) + ".png");
		}
        // end user_functions.js

        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_linear_scale = ''
        let normal_step_linear_scale_pointer_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_stand_icon_img = ''
        let normal_stress_icon_img = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_stress_icon_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_stand_icon_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 91,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middle_13.png',
              unit_tc: 'middle_13.png',
              unit_en: 'middle_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 36,
              image_array: ["batt_01.png","batt_02.png","batt_03.png","batt_04.png","batt_05.png","batt_06.png","batt_07.png","batt_08.png","batt_09.png","batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 132,
              year_startY: 230,
              year_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_zero: 1,
              year_space: 1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 89,
              month_startY: 230,
              month_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_zero: 1,
              month_space: 1,
              month_unit_sc: 'small_10.png',
              month_unit_tc: 'small_10.png',
              month_unit_en: 'small_10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 46,
              day_startY: 230,
              day_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: 'small_10.png',
              day_unit_tc: 'small_10.png',
              day_unit_en: 'small_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 67,
              y: 198,
              week_en: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_tc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_sc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 91,
              y: 93,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 146,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'middle_14.png',
              dot_image: 'middle_17.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 326,
              y: 91,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 146,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middle_16.png',
              unit_tc: 'middle_16.png',
              unit_en: 'middle_16.png',
              imperial_unit_sc: 'middle_18.png',
              imperial_unit_tc: 'middle_18.png',
              imperial_unit_en: 'middle_18.png',
              negative_image: 'middle_15.png',
              invalid_image: 'middle_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 314,
                y: 146,
                font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'middle_18.png',
                unit_tc: 'middle_18.png',
                unit_en: 'middle_18.png',
                imperial_unit_sc: 'middle_16.png',
                imperial_unit_tc: 'middle_16.png',
                imperial_unit_en: 'middle_16.png',
                negative_image: 'middle_15.png',
                invalid_image: 'middle_14.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 350,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 119,
              y: 350,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 391,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 360,
              image_array: ["hr_01.png","hr_02.png","hr_03.png","hr_04.png","hr_05.png","hr_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 102,
              // start_y: 327,
              // color: 0xFF000000,
              // pointer: 'pointer.png',
              // lenght: 254,
              // line_width: 7,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 285,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 285,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middle_11.png',
              unit_tc: 'middle_11.png',
              unit_en: 'middle_11.png',
              imperial_unit_sc: 'middle_12.png',
              imperial_unit_tc: 'middle_12.png',
              imperial_unit_en: 'middle_12.png',
              dot_image: 'middle_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 397,
              am_y: 203,
              am_sc_path: 't_am.png',
              am_en_path: 't_am.png',
              pm_x: 397,
              pm_y: 203,
              pm_sc_path: 't_pm.png',
              pm_en_path: 't_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 271,
              hour_startY: 203,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 340,
              minute_startY: 203,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: -19,
              second_startY: 203,
              second_array: ["big_10.png","big_11.png","big_12.png","big_13.png","big_14.png","big_15.png","big_16.png","big_17.png","big_18.png","big_19.png"],
              second_zero: 1,
              second_space: 326,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 11,
              hour_posY: 139,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 10,
              minute_posY: 183,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 't_sec1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 19,
              second_posY: 231,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 't_sec1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 19,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 19,
              pos_y: 227 - 231,
              center_x: 227,
              center_y: 227,
              src: 't_sec1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 1,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 210,
              src: 't_point.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'menu.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_mask.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 91,
              font_array: ["middle_00.png","middle_01.png","middle_02.png","middle_03.png","middle_04.png","middle_05.png","middle_06.png","middle_07.png","middle_08.png","middle_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middle_13.png',
              unit_tc: 'middle_13.png',
              unit_en: 'middle_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 51,
              image_array: ["aod_batt01.png","aod_batt02.png","aod_batt03.png","aod_batt04.png","aod_batt05.png","aod_batt06.png","aod_batt07.png","aod_batt08.png","aod_batt09.png","aod_batt10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 132,
              year_startY: 230,
              year_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              year_zero: 1,
              year_space: 1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 89,
              month_startY: 230,
              month_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              month_zero: 1,
              month_space: 1,
              month_unit_sc: 'small_10.png',
              month_unit_tc: 'small_10.png',
              month_unit_en: 'small_10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 46,
              day_startY: 230,
              day_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: 'small_10.png',
              day_unit_tc: 'small_10.png',
              day_unit_en: 'small_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 67,
              y: 198,
              src: 'logo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'status_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 397,
              am_y: 203,
              am_sc_path: 't_am.png',
              am_en_path: 't_am.png',
              pm_x: 397,
              pm_y: 203,
              pm_sc_path: 't_pm.png',
              pm_en_path: 't_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 271,
              hour_startY: 203,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'big_10.png',
              hour_unit_tc: 'big_10.png',
              hour_unit_en: 'big_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 340,
              minute_startY: 203,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 11,
              hour_posY: 139,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 10,
              minute_posY: 183,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 210,
              src: 't_point.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 332,
              y: 194,
              w: 66,
              h: 66,
              src: 'blank.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 194,
              w: 66,
              h: 66,
              src: 'blank.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 89,
              w: 47,
              h: 47,
              src: 'blank.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 57,
              y: 137,
              w: 96,
              h: 47,
              src: 'blank.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 325,
              y: 89,
              w: 47,
              h: 47,
              src: 'blank.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 298,
              y: 137,
              w: 95,
              h: 47,
              src: 'blank.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 279,
              y: 340,
              w: 71,
              h: 47,
              src: 'blank.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 359,
              w: 95,
              h: 66,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 61,
              y: 270,
              w: 161,
              h: 52,
              src: 'blank.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 232,
              y: 270,
              w: 161,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 52,
              y: 194,
              w: 140,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 76,
              w: 95,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 104,
              y: 340,
              w: 71,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 42,
              y: 350,
              w: 61,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'HmReStartScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 351,
              y: 350,
              w: 61,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 336,
              y: 45,
              w: 71,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_dndScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 47,
              y: 45,
              w: 71,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 137,
              y: 80,
              w: 66,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                				click_HANDS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 194,
              w: 66,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                				click_MENU();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 251,
              y: 80,
              w: 66,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                				click_COLOR();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 0,
              w: 95,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

			let cc = 0
			if (cc ==0 ){
			  normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_9.setProperty(hmUI.prop.VISIBLE, false);
			  Button_11.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
			
			set_dow();
            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 356;
                  let start_y_normal_step = 327;
                  let lenght_ls_normal_step = -254;
                  let line_width_ls_normal_step = 7;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_step = 15;
                  let pointer_offset_y_ls_normal_step = 15;
                  normal_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step + lenght_ls_normal_step - pointer_offset_x_ls_normal_step,
                    y: start_y_normal_step_draw + line_width_ls_normal_step / 2 - pointer_offset_y_ls_normal_step,
                    src: 'pointer.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

			idle_image_img.setProperty(hmUI.prop.SRC, "color" + hmFS.SysProGetInt('kd33Color') + ".png");
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}