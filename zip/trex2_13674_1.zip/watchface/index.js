﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
// Select background (SETTINGS)

  let total_backgrounds = 1
  let background_prefix = "01_bg_"

// Select hands (SETTINGS)

  let total_hands_types = 3
  let hands_hour_prefix = "02_hh_"
  let hands_minute_prefix = "02_mm_"
  let hands_second_prefix = "02_ss_"
  
// Select foreground (SETTINGS)  
  
  let total_foregrounds = 6 
  let foreground_prefix = "00_fg_"
  
// Select image (SETTINGS)

  let total_images = 5
  let image_prefix = "11_image_"
  
// Analog Watchface OFF / ON (SETTINGS)  

  let empty_file = "10_empty.png" 
  let aditional_image_1 = "00_fg_num.png"
  let aditional_image_2 = "01_bg_ana.png"
  
///////////////////////////// NOT EDIT BELOW /////////////////////////// 

//////////////  Select background (SCRIPTS) ////////////// 

    let background_number = 1

    function up_background() {
    
            if(switch_pos == 1) {
           
                if(background_number >= total_backgrounds) {
                    background_number = 1;
                }
                else {
                    background_number = background_number + 1;
                }
    
                normal_background_bg_img.setProperty(hmUI.prop.SRC, background_prefix + parseInt(background_number) + ".png");  
                
            }
        
    }
    
    function down_background() {
    
            if(switch_pos == 1) {
           
                if(background_number <= 1) {
                    background_number = total_backgrounds;
                }
                else {
                    background_number = background_number - 1;
                }
                              
                normal_background_bg_img.setProperty(hmUI.prop.SRC, background_prefix + parseInt(background_number) + ".png");
                
            }
        
    }

////////////// Select hands type (SCRIPT) ////////////// 

    let hands_types = 1

    function select_hands() {
    
            if(switch_pos == 1) {
    
                if(hands_types >= total_hands_types) {
                    hands_types = 1;
                }
                else {
                    hands_types = hands_types + 1;
                }
    
                normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, hands_hour_prefix + parseInt(hands_types) + ".png");
                normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, hands_minute_prefix + parseInt(hands_types) + ".png");
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, hands_second_prefix + parseInt(hands_types) + ".png");

            }
        
    }
        
////////////// Select foreground (SCRIPT) ////////////// 

    let foreground_number = 1

    function select_foreground() {
    
            if(switch_pos == 1) {
           
                if(foreground_number >= total_foregrounds) {
                    foreground_number = 1;
                }
                else {
                    foreground_number = foreground_number + 1;
                }
    
                normal_image_img.setProperty(hmUI.prop.SRC, foreground_prefix + parseInt(foreground_number) + ".png");
                
            }
        
    }  
        
  //////////////  Select image (SCRIPT) //////////////

    let image_number = 1
		
	function select_image() {
    
            if(switch_pos == 1) {
    
                if(image_number >= total_images) {
                    image_number = 1;
                }
                else {
                    image_number = image_number + 1;
                }
                
                //normal_battery_icon_img.setProperty(hmUI.prop.SRC, image_prefix + parseInt(image_number) + ".png");
                //normal_temperature_icon_img.setProperty(hmUI.prop.SRC, image_prefix + parseInt(image_number) + ".png");
                //normal_stress_icon_img.setProperty(hmUI.prop.SRC, image_prefix + parseInt(image_number) + ".png");
                //normal_stand_icon_img.setProperty(hmUI.prop.SRC, image_prefix + parseInt(image_number) + ".png");
                normal_pai_icon_img.setProperty(hmUI.prop.SRC, image_prefix + parseInt(image_number) + ".png");
                select_hands();
                
            }

    }       

////////////// Analog Watchface OFF / ON (SCRIPT) //////////////

    let switch_pos = 1
    let total_pos = 2

    function off_on_analog() {
            
            if(switch_pos == total_pos) {
                
                switch_pos = 1;
                
                normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                
                normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
                //normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
                
                normal_pai_icon_img.setProperty(hmUI.prop.SRC, image_prefix + parseInt(image_number) + ".png");
                normal_stress_icon_img.setProperty(hmUI.prop.SRC, aditional_image_1);
                normal_image_img.setProperty(hmUI.prop.SRC, foreground_prefix + parseInt(foreground_number) + ".png");
                normal_stand_icon_img.setProperty(hmUI.prop.SRC, aditional_image_2);
                            
            }
            else {

                switch_pos = switch_pos + 1;
                
                if(switch_pos == 2) {
                
                    normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                    
                    normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
                    //normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
                    
                    normal_pai_icon_img.setProperty(hmUI.prop.SRC, empty_file);
                    normal_stress_icon_img.setProperty(hmUI.prop.SRC, empty_file);
                    normal_image_img.setProperty(hmUI.prop.SRC, empty_file);
                    normal_stand_icon_img.setProperty(hmUI.prop.SRC, empty_file);
                    
                }

            }

    } 
        
/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_spo2_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_altimeter_icon_img = ''
        let normal_altitude_target_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_stand_icon_img = ''
        let normal_image_img = ''
        let normal_stress_icon_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_pai_icon_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_digi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 135,
              src: '10_wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 150,
              y: 135,
              image_array: ["12_compass_1.png","12_compass_2.png","12_compass_3.png","12_compass_4.png","12_compass_5.png","12_compass_6.png","12_compass_7.png","12_compass_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 143,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 84,
              src: '10_UV.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 90,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 149,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_S.png',
              unit_tc: '10_degree_S.png',
              unit_en: '10_degree_S.png',
              negative_image: '10_dash_M.png',
              invalid_image: '10_null_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 407,
              y: 154,
              src: '10_max.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 251,
              y: 149,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_S.png',
              unit_tc: '10_degree_S.png',
              unit_en: '10_degree_S.png',
              negative_image: '10_dash_M.png',
              invalid_image: '10_null_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 241,
              y: 154,
              src: '10_min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 90,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_M.png',
              unit_tc: '10_degree_M.png',
              unit_en: '10_degree_M.png',
              negative_image: '10_dash_L.png',
              invalid_image: '10_null_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 77,
              image_array: ["09_weather_01.png","09_weather_02.png","09_weather_03.png","09_weather_04.png","09_weather_05.png","09_weather_06.png","09_weather_07.png","09_weather_08.png","09_weather_09.png","09_weather_10.png","09_weather_11.png","09_weather_12.png","09_weather_13.png","09_weather_14.png","09_weather_15.png","09_weather_16.png","09_weather_17.png","09_weather_18.png","09_weather_19.png","09_weather_20.png","09_weather_21.png","09_weather_22.png","09_weather_23.png","09_weather_24.png","09_weather_25.png","09_weather_26.png","09_weather_27.png","09_weather_28.png","09_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 204,
              y: 49,
              src: '10_sun.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 52,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_sep_S.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 52,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_sep_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '10_STATUSES.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 159,
              y: 14,
              src: '10_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 270,
              y: 14,
              src: '10_AL_ON.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 13,
              src: '10_battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 202,
              // start_y: 19,
              // color: 0xFF00E100,
              // lenght: 46,
              // line_width: 14,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 143,
              y: 390,
              src: '10_alt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 393,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 243,
              y: 335,
              src: '10_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 337,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 23,
              y: 274,
              src: '10_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 281,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 62,
              y: 335,
              src: '10_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 337,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 274,
              src: '10_dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 281,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '10_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 196,
              hour_array: ["03_hhmmss_0.png","03_hhmmss_1.png","03_hhmmss_2.png","03_hhmmss_3.png","03_hhmmss_4.png","03_hhmmss_5.png","03_hhmmss_6.png","03_hhmmss_7.png","03_hhmmss_8.png","03_hhmmss_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '10_sep_hhmmss.png',
              hour_unit_tc: '10_sep_hhmmss.png',
              hour_unit_en: '10_sep_hhmmss.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["03_hhmmss_0.png","03_hhmmss_1.png","03_hhmmss_2.png","03_hhmmss_3.png","03_hhmmss_4.png","03_hhmmss_5.png","03_hhmmss_6.png","03_hhmmss_7.png","03_hhmmss_8.png","03_hhmmss_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: '10_sep_hhmmss.png',
              minute_unit_tc: '10_sep_hhmmss.png',
              minute_unit_en: '10_sep_hhmmss.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 319,
              second_startY: 196,
              second_array: ["03_hhmmss_0.png","03_hhmmss_1.png","03_hhmmss_2.png","03_hhmmss_3.png","03_hhmmss_4.png","03_hhmmss_5.png","03_hhmmss_6.png","03_hhmmss_7.png","03_hhmmss_8.png","03_hhmmss_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '01_bg_ana.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_num.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 288,
              y: 218,
              week_en: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              week_tc: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              week_sc: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 218,
              day_sc_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              day_tc_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              day_en_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '11_image_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_hh_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 14,
              // y: 150,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 14,
              pos_y: 227 - 150,
              center_x: 227,
              center_y: 227,
              src: '02_hh_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_mm_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 14,
              // y: 150,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 14,
              pos_y: 227 - 150,
              center_x: 227,
              center_y: 227,
              src: '02_mm_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_ss_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 13,
              // y: 194,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 13,
              pos_y: 227 - 194,
              center_x: 227,
              center_y: 227,
              src: '02_ss_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_hh_AOD.png',
              // center_x: 227,
              // center_y: 227,
              // x: 14,
              // y: 150,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 14,
              pos_y: 227 - 150,
              center_x: 227,
              center_y: 227,
              src: '02_hh_AOD.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_mm_AOD.png',
              // center_x: 227,
              // center_y: 227,
              // x: 14,
              // y: 150,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 14,
              pos_y: 227 - 150,
              center_x: 227,
              center_y: 227,
              src: '02_mm_AOD.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_ss_AOD.png',
              // center_x: 227,
              // center_y: 227,
              // x: 13,
              // y: 194,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 13,
              pos_y: 227 - 194,
              center_x: 227,
              center_y: 227,
              src: '02_ss_AOD.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 342,
              y: 177,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                select_image()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 12,
              y: 177,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                select_foreground()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 177,
              y: 177,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                off_on_analog()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 202;
                  let start_y_normal_battery = 19;
                  let lenght_ls_normal_battery = 46;
                  let line_width_ls_normal_battery = 14;
                  let color_ls_normal_battery = 0xFF00E100;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}