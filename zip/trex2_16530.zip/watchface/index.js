﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_sun_current_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_spo2_icon_img = ''
        let normal_spo2_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_uvi_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_heart_rate_circle_scale_2 = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_sun_icon_img = ''
        let idle_sun_current_text_img = ''
        let idle_sun_current_separator_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_spo2_icon_img = ''
        let idle_spo2_text_text_img = ''
        let idle_step_icon_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_uvi_text_text_img = ''
        let idle_humidity_text_text_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_wind_text_text_img = ''
        let idle_wind_text_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: yu-gothic-bold.ttf; FontSize: 20; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 452,
              y: 452,
              w: 24,
              h: 24,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/yu-gothic-bold.ttf',
              color: 0xFF00B9FF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG-1C.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 235,
              font_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: -67,
              end_angle: -1,
              radius: 101,
              line_width: 29,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFFF8C00,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 223,
              y: 105,
              font_array: ["RED0.png","RED1.png","RED2.png","RED3.png","RED4.png","RED5.png","RED6.png","RED7.png","RED8.png","RED9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 304,
              y: 119,
              src: '0104.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'TOP-LAYER6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 195,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 0,
              dot_image: '0104.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 312,
              y: 167,
              src: 'SUN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 383,
              y: 128,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 384,
              month_startY: 174,
              month_sc_array: ["M_01.png","M_02.png","M_03.png","M_04.png","M_05.png","M_06.png","M_07.png","M_08.png","M_09.png","M_10.png","M_11.png","M_12.png"],
              month_tc_array: ["M_01.png","M_02.png","M_03.png","M_04.png","M_05.png","M_06.png","M_07.png","M_08.png","M_09.png","M_10.png","M_11.png","M_12.png"],
              month_en_array: ["M_01.png","M_02.png","M_03.png","M_04.png","M_05.png","M_06.png","M_07.png","M_08.png","M_09.png","M_10.png","M_11.png","M_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 374,
              day_startY: 191,
              day_sc_array: ["DM0.png","DM1.png","DM2.png","DM3.png","DM4.png","DM5.png","DM6.png","DM7.png","DM8.png","DM9.png"],
              day_tc_array: ["DM0.png","DM1.png","DM2.png","DM3.png","DM4.png","DM5.png","DM6.png","DM7.png","DM8.png","DM9.png"],
              day_en_array: ["DM0.png","DM1.png","DM2.png","DM3.png","DM4.png","DM5.png","DM6.png","DM7.png","DM8.png","DM9.png"],
              day_zero: 0,
              day_space: -10,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 356,
              y: 92,
              src: 'OXY.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 112,
              font_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 321,
              y: 48,
              src: 'STEPS.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: -86,
              // end_angle: -2,
              // radius: 175,
              // line_width: 44,
              // line_cap: Rounded,
              // color: 0xFF009FFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: -86,
              end_angle: -2,
              radius: 153,
              line_width: 44,
              corner_flag: 0,
              color: 0xFF009FFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 62,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'TOP-LAYER6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: -89,
              // end_angle: -1,
              // radius: 218,
              // line_width: 39,
              // line_cap: Rounded,
              // color: 0xFF00FF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: -89,
              end_angle: -1,
              radius: 199,
              line_width: 39,
              corner_flag: 0,
              color: 0xFF00FF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 22,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 18,
              src: 'mini%00999.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 379,
              y: 251,
              week_en: ["DAY1.png","DAY2.png","DAY3.png","DAY4.png","DAY5.png","DAY6.png","DAY7.png"],
              week_tc: ["DAY1.png","DAY2.png","DAY3.png","DAY4.png","DAY5.png","DAY6.png","DAY7.png"],
              week_sc: ["DAY1.png","DAY2.png","DAY3.png","DAY4.png","DAY5.png","DAY6.png","DAY7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 250,
              hour_array: ["DSFONT-01.png","DSFONT-02.png","DSFONT-03.png","DSFONT-04.png","DSFONT-05.png","DSFONT-06.png","DSFONT-07.png","DSFONT-08.png","DSFONT-09.png","DSFONT-10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'DSFONT-11.png',
              hour_unit_tc: 'DSFONT-11.png',
              hour_unit_en: 'DSFONT-11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["DSFONT-01.png","DSFONT-02.png","DSFONT-03.png","DSFONT-04.png","DSFONT-05.png","DSFONT-06.png","DSFONT-07.png","DSFONT-08.png","DSFONT-09.png","DSFONT-10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 285,
              second_startY: 287,
              second_array: ["DSSFONT-01.png","DSSFONT-02.png","DSSFONT-03.png","DSSFONT-04.png","DSSFONT-05.png","DSSFONT-06.png","DSSFONT-07.png","DSSFONT-08.png","DSSFONT-09.png","DSSFONT-10.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'TOP-LAYER6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 280,
              y: 139,
              w: 97,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/yu-gothic-bold.ttf',
              color: 0xFF00B9FF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 235,
              font_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0105.png',
              unit_tc: '0105.png',
              unit_en: '0105.png',
              negative_image: '0104.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 127,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 235,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 211,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 267,
              y: 403,
              src: '0136.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 50,
              y: 355,
              src: '0135.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 396,
              y: 282,
              src: '0137.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 211,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'layer2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0074.png',
              hour_centerX: 0,
              hour_centerY: 0,
              hour_posX: 0,
              hour_posY: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0074.png',
              minute_centerX: 0,
              minute_centerY: 0,
              minute_posX: 0,
              minute_posY: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'POINTER.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 25,
              second_posY: 285,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG-1C.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 235,
              font_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: -67,
              end_angle: -1,
              radius: 101,
              line_width: 29,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFFF8C00,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 223,
              y: 105,
              font_array: ["RED0.png","RED1.png","RED2.png","RED3.png","RED4.png","RED5.png","RED6.png","RED7.png","RED8.png","RED9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 304,
              y: 119,
              src: '0104.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'TOP-LAYER6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 195,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 0,
              dot_image: '0104.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 312,
              y: 167,
              src: 'SUN.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 383,
              y: 128,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 384,
              month_startY: 174,
              month_sc_array: ["M_01.png","M_02.png","M_03.png","M_04.png","M_05.png","M_06.png","M_07.png","M_08.png","M_09.png","M_10.png","M_11.png","M_12.png"],
              month_tc_array: ["M_01.png","M_02.png","M_03.png","M_04.png","M_05.png","M_06.png","M_07.png","M_08.png","M_09.png","M_10.png","M_11.png","M_12.png"],
              month_en_array: ["M_01.png","M_02.png","M_03.png","M_04.png","M_05.png","M_06.png","M_07.png","M_08.png","M_09.png","M_10.png","M_11.png","M_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 374,
              day_startY: 191,
              day_sc_array: ["DM0.png","DM1.png","DM2.png","DM3.png","DM4.png","DM5.png","DM6.png","DM7.png","DM8.png","DM9.png"],
              day_tc_array: ["DM0.png","DM1.png","DM2.png","DM3.png","DM4.png","DM5.png","DM6.png","DM7.png","DM8.png","DM9.png"],
              day_en_array: ["DM0.png","DM1.png","DM2.png","DM3.png","DM4.png","DM5.png","DM6.png","DM7.png","DM8.png","DM9.png"],
              day_zero: 0,
              day_space: -10,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 356,
              y: 92,
              src: 'OXY.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 112,
              font_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 321,
              y: 48,
              src: 'STEPS.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: -86,
              // end_angle: -2,
              // radius: 175,
              // line_width: 44,
              // line_cap: Rounded,
              // color: 0xFF009FFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: -86,
              end_angle: -2,
              radius: 153,
              line_width: 44,
              corner_flag: 0,
              color: 0xFF009FFF,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 62,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'TOP-LAYER6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: -89,
              // end_angle: -1,
              // radius: 218,
              // line_width: 39,
              // line_cap: Rounded,
              // color: 0xFF00FF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: -89,
              end_angle: -1,
              radius: 199,
              line_width: 39,
              corner_flag: 0,
              color: 0xFF00FF00,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 22,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 18,
              src: 'mini%00999.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 379,
              y: 251,
              week_en: ["DAY1.png","DAY2.png","DAY3.png","DAY4.png","DAY5.png","DAY6.png","DAY7.png"],
              week_tc: ["DAY1.png","DAY2.png","DAY3.png","DAY4.png","DAY5.png","DAY6.png","DAY7.png"],
              week_sc: ["DAY1.png","DAY2.png","DAY3.png","DAY4.png","DAY5.png","DAY6.png","DAY7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 250,
              hour_array: ["DSFONT-01.png","DSFONT-02.png","DSFONT-03.png","DSFONT-04.png","DSFONT-05.png","DSFONT-06.png","DSFONT-07.png","DSFONT-08.png","DSFONT-09.png","DSFONT-10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'DSFONT-11.png',
              hour_unit_tc: 'DSFONT-11.png',
              hour_unit_en: 'DSFONT-11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["DSFONT-01.png","DSFONT-02.png","DSFONT-03.png","DSFONT-04.png","DSFONT-05.png","DSFONT-06.png","DSFONT-07.png","DSFONT-08.png","DSFONT-09.png","DSFONT-10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 285,
              second_startY: 287,
              second_array: ["DSSFONT-01.png","DSSFONT-02.png","DSSFONT-03.png","DSSFONT-04.png","DSSFONT-05.png","DSSFONT-06.png","DSSFONT-07.png","DSSFONT-08.png","DSSFONT-09.png","DSSFONT-10.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'TOP-LAYER6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 280,
              y: 139,
              w: 97,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/yu-gothic-bold.ttf',
              color: 0xFF00B9FF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 235,
              font_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0105.png',
              unit_tc: '0105.png',
              unit_en: '0105.png',
              negative_image: '0104.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 127,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 235,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 211,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 267,
              y: 403,
              src: '0136.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 50,
              y: 355,
              src: '0135.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 396,
              y: 282,
              src: '0137.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 211,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'layer2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0074.png',
              hour_centerX: 0,
              hour_centerY: 0,
              hour_posX: 0,
              hour_posY: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0074.png',
              minute_centerX: 0,
              minute_centerY: 0,
              minute_posX: 0,
              minute_posY: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'POINTER.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 25,
              second_posY: 285,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: -86,
                      end_angle: -2,
                      radius: 153,
                      line_width: 44,
                      corner_flag: 0,
                      color: 0xFF009FFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: -89,
                      end_angle: -1,
                      radius: 199,
                      line_width: 39,
                      corner_flag: 0,
                      color: 0xFF00FF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: -86,
                      end_angle: -2,
                      radius: 153,
                      line_width: 44,
                      corner_flag: 0,
                      color: 0xFF009FFF,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: -89,
                      end_angle: -1,
                      radius: 199,
                      line_width: 39,
                      corner_flag: 0,
                      color: 0xFF00FF00,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let idle_cityNameStr = weatherData.cityName;
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}