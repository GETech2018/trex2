﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_year_TextRotate = new Array(4);
        let normal_year_TextRotate_ASCIIARRAY = new Array(10);
        let normal_year_TextRotate_img_width = 24;
        let normal_timerTextUpdate = undefined;
        let normal_image_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_year_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 63,
              // y: 85,
              // font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -47,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextRotate_ASCIIARRAY[0] = '12.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[1] = '13.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[2] = '14.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[3] = '15.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[4] = '16.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[5] = '17.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[6] = '18.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[7] = '19.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[8] = '20.png';  // set of images with numbers
            normal_year_TextRotate_ASCIIARRAY[9] = '21.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_year_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 63,
                center_y: 85,
                pos_x: 63,
                pos_y: 85,
                angle: -47,
                src: '12.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0_Empty (2).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 11,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 401,
              y: 258,
              src: '67.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 119,
              y: 19,
              src: '24.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 303,
              y: 30,
              src: '26.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 370,
              font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              padding: true,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 338,
              y: 369,
              src: '81.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 8,
              y: 199,
              font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              padding: false,
              h_space: -2,
              negative_image: '68.png',
              invalid_image: '113.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 23,
              y: 148,
              image_array: ["117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 164,
              y: 47,
              week_en: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              week_tc: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              week_sc: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 125,
              month_startY: 366,
              month_sc_array: ["37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              month_tc_array: ["37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              month_en_array: ["37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 198,
              day_startY: 377,
              day_sc_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              day_tc_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              day_en_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              day_zero: 1,
              day_space: -7,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 307,
              font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 307,
              font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 399,
              am_y: 220,
              am_sc_path: '22.png',
              am_en_path: '22.png',
              pm_x: 399,
              pm_y: 220,
              pm_sc_path: '23.png',
              pm_en_path: '23.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 120,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 245,
              minute_startY: 120,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 386,
              second_startY: 162,
              second_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              second_zero: 1,
              second_space: -10,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: 172,
              src: '89.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 97,
              y: 76,
              src: '26.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 209,
              day_startY: 28,
              day_sc_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              day_tc_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              day_en_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 166,
              y: 84,
              week_en: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              week_tc: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              week_sc: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 63,
              hour_startY: 170,
              hour_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 253,
              minute_startY: 170,
              minute_array: ["T_0.png","T_1.png","T_2.png","T_3.png","T_4.png","T_5.png","T_6.png","T_7.png","T_8.png","T_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 174,
              src: 'dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 0,
              w: 95,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty_(1).png',
              normal_src: '0_Empty_(1).png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 58,
              w: 95,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty_(1).png',
              normal_src: '0_Empty_(1).png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 303,
              y: 29,
              w: 95,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty_(1).png',
              normal_src: '0_Empty_(1).png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 270,
              y: 307,
              w: 95,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty_(1).png',
              normal_src: '0_Empty_(1).png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 76,
              y: 307,
              w: 130,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty_(1).png',
              normal_src: '0_Empty_(1).png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 130,
              y: 386,
              w: 130,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty_(1).png',
              normal_src: '0_Empty_(1).png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 274,
              y: 369,
              w: 130,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty_(1).png',
              normal_src: '0_Empty_(1).png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 16,
              y: 205,
              w: 57,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty_(1).png',
              normal_src: '0_Empty_(1).png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 16,
              y: 133,
              w: 57,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty_(1).png',
              normal_src: '0_Empty_(1).png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate year_TIME');
              let valueYear = timeSensor.year;
              let normal_year_rotate_string = parseInt(valueYear).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_rotate_string.length > 0 && normal_year_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_year_TextRotate_posOffset = normal_year_TextRotate_img_width * normal_year_rotate_string.length;
                  img_offset -= normal_year_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_year_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_year_TextRotate[index].setProperty(hmUI.prop.POS_X, 63 + img_offset);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.SRC, normal_year_TextRotate_ASCIIARRAY[charCode]);
                      normal_year_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_year_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}