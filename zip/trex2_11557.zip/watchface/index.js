﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_stand_linear_scale = ''
        let normal_stand_linear_scale_pointer_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_linear_scale = ''
        let normal_pai_day_text_img = ''
        let normal_sun_current_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '00001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 126,
              font_array: ["0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0500.png',
              unit_tc: '0500.png',
              unit_en: '0500.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 357,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 370,
              y: 271,
              font_array: ["0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 304,
              y: 274,
              src: '0164.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_stand_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_stand_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_stand_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 214,
              // start_y: 285,
              // color: 0xFFFF8C00,
              // pointer: '0131.png',
              // lenght: 169,
              // line_width: 0,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 348,
              y: 95,
              image_array: ["moon2_1.png","moon2_2.png","moon2_3.png","moon2_4.png","moon2_5.png","moon2_6.png","moon2_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 386,
              font_array: ["0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0023.png',
              unit_tc: '0023.png',
              unit_en: '0023.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 107,
              y: 384,
              src: '0330.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 220,
              // center_y: 227,
              // start_angle: 101,
              // end_angle: 147,
              // radius: 222,
              // line_width: 6,
              // color: 0xFF8080C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 413,
              font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0023.png',
              unit_tc: '0023.png',
              unit_en: '0023.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 274,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0167.png',
              unit_tc: '0167.png',
              unit_en: '0167.png',
              negative_image: '0024.png',
              invalid_image: '0026.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 169,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0167.png',
              unit_tc: '0167.png',
              unit_en: '0167.png',
              negative_image: '0024.png',
              invalid_image: '0026.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 220,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0167.png',
              unit_tc: '0167.png',
              unit_en: '0167.png',
              negative_image: '0024.png',
              invalid_image: '0026.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 70,
              image_array: ["0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 249,
              y: 235,
              week_en: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png"],
              week_tc: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png"],
              week_sc: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 211,
              // start_y: 373,
              // color: 0xFF692F91,
              // lenght: 122,
              // line_width: 2,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 352,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 150,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 0,
              dot_image: '0149.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 105,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0501.png',
              unit_tc: '0501.png',
              unit_en: '0501.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 80,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0023.png',
              unit_tc: '0023.png',
              unit_en: '0023.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 56,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 211,
              // start_y: 313,
              // color: 0xFFF00F36,
              // lenght: 123,
              // line_width: 2,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 292,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 211,
              // start_y: 344,
              // color: 0xFFF2F200,
              // lenght: 123,
              // line_width: 2,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 325,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 322,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0320.png',
              unit_tc: '0320.png',
              unit_en: '0320.png',
              dot_image: 'point 1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 211,
              // start_y: 402,
              // color: 0xFFC6FFFF,
              // lenght: 122,
              // line_width: 2,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 382,
              font_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 245,
              year_startY: 267,
              year_sc_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              year_tc_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              year_en_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 243,
              month_startY: 252,
              month_sc_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              month_tc_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              month_en_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 209,
              day_startY: 257,
              day_sc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_tc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_en_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 207,
              hour_startY: 189,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 297,
              minute_startY: 189,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 364,
              second_startY: 214,
              second_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 284,
              y: 200,
              src: 'point.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second_red2.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 46,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 381,
              y: 305,
              src: '0058.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 355,
              y: 329,
              src: '0700.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 360,
              y: 304,
              src: '0701.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 362,
              y: 288,
              src: '0703.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod02.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 238,
              y: 235,
              week_en: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png"],
              week_tc: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png"],
              week_sc: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 245,
              year_startY: 267,
              year_sc_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              year_tc_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              year_en_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 243,
              month_startY: 252,
              month_sc_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              month_tc_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              month_en_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 209,
              day_startY: 257,
              day_sc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_tc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_en_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 207,
              hour_startY: 189,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 297,
              minute_startY: 189,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 364,
              second_startY: 214,
              second_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 284,
              y: 200,
              src: 'point.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second_red2.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 46,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 340,
              y: 146,
              src: '0058.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 302,
              y: 146,
              src: '0057.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 234,
              y: 149,
              src: '0145.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 268,
              y: 147,
              src: '0056.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 206,
              y: 149,
              w: 154,
              h: 20,
              src: '0600.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 37,
              y: 199,
              w: 140,
              h: 46,
              src: '0600.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 106,
              y: 380,
              w: 71,
              h: 41,
              src: '0600.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 293,
              w: 131,
              h: 28,
              src: '0600.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 206,
              y: 385,
              w: 134,
              h: 26,
              src: '0600.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 74,
              w: 42,
              h: 37,
              src: '0600.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 68,
              y: 351,
              w: 84,
              h: 23,
              src: '0600.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 206,
              y: 125,
              w: 154,
              h: 21,
              src: '0600.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 209,
              y: 347,
              w: 131,
              h: 32,
              src: '0600.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 190,
              w: 77,
              h: 60,
              src: '0600.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 190,
              w: 89,
              h: 59,
              src: '0600.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 354,
              y: 291,
              w: 100,
              h: 100,
              src: '0600.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_ls_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_linear_scale
                  // initial parameters
                  let start_x_normal_stand = 214;
                  let start_y_normal_stand = 285;
                  let lenght_ls_normal_stand = 169;
                  let line_width_ls_normal_stand = 0;
                  let color_ls_normal_stand = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_normal_stand_draw = start_x_normal_stand;
                  let start_y_normal_stand_draw = start_y_normal_stand;
                  lenght_ls_normal_stand = lenght_ls_normal_stand * progress_ls_normal_stand;
                  let lenght_ls_normal_stand_draw = lenght_ls_normal_stand;
                  let line_width_ls_normal_stand_draw = line_width_ls_normal_stand;
                  if (lenght_ls_normal_stand < 0){
                    lenght_ls_normal_stand_draw = -lenght_ls_normal_stand;
                    start_x_normal_stand_draw = start_x_normal_stand - lenght_ls_normal_stand_draw;
                  };
                  
                  normal_stand_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_stand_draw,
                    y: start_y_normal_stand_draw,
                    w: lenght_ls_normal_stand_draw,
                    h: line_width_ls_normal_stand_draw,
                    color: color_ls_normal_stand,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_stand = 14;
                  let pointer_offset_y_ls_normal_stand = 1;
                  normal_stand_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_stand + lenght_ls_normal_stand - pointer_offset_x_ls_normal_stand,
                    y: start_y_normal_stand_draw + line_width_ls_normal_stand / 2 - pointer_offset_y_ls_normal_stand,
                    src: '0131.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = 11;
                  let end_angle_normal_battery = 57;
                  let center_x_normal_battery = 220;
                  let center_y_normal_battery = 227;
                  let radius_normal_battery = 222;
                  let line_width_cs_normal_battery = 6;
                  let color_cs_normal_battery = 0xFF8080C0;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_ls_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_linear_scale
                  // initial parameters
                  let start_x_normal_pai = 211;
                  let start_y_normal_pai = 373;
                  let lenght_ls_normal_pai = 122;
                  let line_width_ls_normal_pai = 2;
                  let color_ls_normal_pai = 0xFF692F91;
                  
                  // calculated parameters
                  let start_x_normal_pai_draw = start_x_normal_pai;
                  let start_y_normal_pai_draw = start_y_normal_pai;
                  lenght_ls_normal_pai = lenght_ls_normal_pai * progress_ls_normal_pai;
                  let lenght_ls_normal_pai_draw = lenght_ls_normal_pai;
                  let line_width_ls_normal_pai_draw = line_width_ls_normal_pai;
                  if (lenght_ls_normal_pai < 0){
                    lenght_ls_normal_pai_draw = -lenght_ls_normal_pai;
                    start_x_normal_pai_draw = start_x_normal_pai - lenght_ls_normal_pai_draw;
                  };
                  
                  normal_pai_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_pai_draw,
                    y: start_y_normal_pai_draw,
                    w: lenght_ls_normal_pai_draw,
                    h: line_width_ls_normal_pai_draw,
                    color: color_ls_normal_pai,
                  });
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 211;
                  let start_y_normal_heart_rate = 313;
                  let lenght_ls_normal_heart_rate = 123;
                  let line_width_ls_normal_heart_rate = 2;
                  let color_ls_normal_heart_rate = 0xFFF00F36;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 211;
                  let start_y_normal_calorie = 344;
                  let lenght_ls_normal_calorie = 123;
                  let line_width_ls_normal_calorie = 2;
                  let color_ls_normal_calorie = 0xFFF2F200;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 211;
                  let start_y_normal_step = 402;
                  let lenght_ls_normal_step = 122;
                  let line_width_ls_normal_step = 2;
                  let color_ls_normal_step = 0xFFC6FFFF;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
