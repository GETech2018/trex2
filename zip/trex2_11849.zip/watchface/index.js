/*
** Facemaker bundle tool v0.0.1
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img = '';
		let normal_analog_clock_time_pointer_hour = '';
		let normal_analog_clock_time_pointer_minute = '';
		let normal_analog_clock_time_pointer_second = '';
		let idle_digital_clock_img_hour = '';
		let idle_digital_clock_img_minute = '';
		let idle_digital_clock_img_second = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

			normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				src: '0002.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
				hour_path: '0003.png',
				hour_centerX: 227,
				hour_centerY: 227,
				hour_posX: 20,
				hour_posY: 129,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
				minute_path: '0004.png',
				minute_centerX: 227,
				minute_centerY: 227,
				minute_posX: 25,
				minute_posY: 198,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
				second_path: '0005.png',
				second_centerX: 227,
				second_centerY: 227,
				second_posX: 16,
				second_posY: 195,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			idle_digital_clock_img_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
				hour_startX: 31,
				hour_startY: 166,
				hour_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
				hour_zero: true,
				hour_space: 0,
				hour_align: hmUI.align.CENTER_H,
				show_level: hmUI.show_level.ONAL_AOD,
			});

			idle_digital_clock_img_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
				minute_startX: 199,
				minute_startY: 166,
				minute_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
				minute_zero: true,
				minute_space: 0,
				minute_align: hmUI.align.CENTER_H,
				show_level: hmUI.show_level.ONAL_AOD,
			});

			idle_digital_clock_img_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
				second_startX: 359,
				second_startY: 181,
				second_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
				second_zero: false,
				second_space: 0,
				second_align: hmUI.align.LEFT,
				show_level: hmUI.show_level.ONAL_AOD,
			});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},

		onReady() {
			console.log('index page.js on ready invoke')
		},

		onShow() {
			console.log('index page.js on show invoke')
		},

		onHide() {
			console.log('index page.js on hide invoke')
		},

		onDestory() {
			console.log('index page.js on destory invoke')
		},

	});	})()
} catch (e) {
	console.log(e)
}