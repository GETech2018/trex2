﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_digital_clock_img_time = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 106;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 76;
        let image_top_img = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 26,
              hour_startY: 128,
              hour_array: ["Pr0.png","Pr1.png","Pr2.png","Pr3.png","Pr4.png","Pr5.png","Pr6.png","Pr7.png","Pr8.png","Pr9.png"],
              hour_zero: 1,
              hour_space: 487,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 239,
              minute_startY: 81,
              minute_array: ["Gb0.png","Gb1.png","Gb2.png","Gb3.png","Gb4.png","Gb5.png","Gb6.png","Gb7.png","Gb8.png","Gb9.png"],
              minute_zero: 1,
              minute_space: 292,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 215,
              // y: 81,
              // font_array: ["Gr0.png","Gr1.png","Gr2.png","Gr3.png","Gr4.png","Gr5.png","Gr6.png","Gr7.png","Gr8.png","Gr9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 292,
              // angle: 0,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'Gr0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'Gr1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'Gr2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'Gr3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'Gr4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'Gr5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'Gr6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'Gr7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'Gr8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'Gr9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 215,
                center_y: 81,
                pos_x: 215,
                pos_y: 81,
                angle: 0,
                src: 'Gr0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 428,
              // y: 128,
              // font_array: ["Pb0.png","Pb1.png","Pb2.png","Pb3.png","Pb4.png","Pb5.png","Pb6.png","Pb7.png","Pb8.png","Pb9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 487,
              // angle: 0,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'Pb0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'Pb1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'Pb2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'Pb3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'Pb4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'Pb5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'Pb6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'Pb7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'Pb8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'Pb9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 428,
                center_y: 128,
                pos_x: 428,
                pos_y: 128,
                angle: 0,
                src: 'Pb0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block



            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function text_update() {

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  normal_hour_TextRotate_posOffset = normal_hour_TextRotate_posOffset + 292 * (normal_hour_rotate_string.length - 1);
                  img_offset -= normal_hour_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 215 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + 292;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_minute_TextRotate_posOffset = normal_minute_TextRotate_img_width * normal_minute_rotate_string.length;
                  normal_minute_TextRotate_posOffset = normal_minute_TextRotate_posOffset + 487 * (normal_minute_rotate_string.length - 1);
                  img_offset -= normal_minute_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 428 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + 487;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}