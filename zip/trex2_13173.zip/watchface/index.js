﻿/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start
    function valuesAreClose(firstValue, secondValue, tolerance = 10) {
      return Math.abs(Math.abs(firstValue) - Math.abs(secondValue)) <= tolerance;
    }

    const CHRONO_RESET = 0;
    const CHRONO_START = 1;
    const CHRONO_STOP = 2;

    const NORMAL_SEC = 0;
    const SEMI_SMOOTH_SEC = 1;
    const SMOOTH_SEC = 2;

    // img pointer class
    class ImgPointer {      
      constructor(element) {
        this._element = element;

        this._angle = 0;
        this._visible = true;
      }

      get element() {
        return _element;
      }
      set element(el) {
        this._element = el;
      }

      get angle() {
        return this._angle;
      }
      set angle(a) {
        this._angle = a;
        this._element.setProperty(hmUI.prop.ANGLE, this._angle);
      }

      show() {
        this._visible = true;
        this._element.setProperty(hmUI.prop.VISIBLE, this._visible);
      }
      hide () {
        this._visible = false;
        this._element.setProperty(hmUI.prop.VISIBLE, this._visible);
      }
      get visible() {
        return this._visible;
      }
    }
    
    // Analog Clock class
    class AnalonClock {
      constructor(timeSensor, secMode = SEMI_SMOOTH_SEC) {
        this.timeSensor = timeSensor;

        this.hourPointers = [];
        this.minutePointers = [];
        this.secondsPointers = [];

        this.normal_angle_hour = 0;
        this.normal_angle_minute = 0;
        this.normal_angle_second = 0;

        this.normal_timerUpdate = undefined;
        this.normal_timerUpdateSec = undefined;

        this.secondsMode = secMode;
      }
      addHourPointer(pointer) {
        this.hourPointers.push(pointer);
      }
      addMinutePointer(pointer) {
        this.minutePointers.push(pointer);
      }
      addSecondsPointer(pointer) {
        this.secondsPointers.push(pointer);
      }

      update(updateHour = false, updateMinute = false) {
        let hour = this.timeSensor.hour;
        let minute = this.timeSensor.minute;
        let second = this.timeSensor.second;

        if (updateHour) {
          let normal_hour = hour;
          let normal_fullAngle_hour = 360;
          if (normal_hour > 11) normal_hour -= 12;
          this.normal_angle_hour = 0 + (normal_fullAngle_hour * normal_hour) / 12 + ((normal_fullAngle_hour / 12) * minute) / 60;
          this.hourPointers.forEach((e) => {
            if (e) e.angle = this.normal_angle_hour;
          });
        }

        if (updateMinute) {
          let normal_fullAngle_minute = 360;
          this.normal_angle_minute = 0 + (normal_fullAngle_minute * (minute + second / 60)) / 60;
          this.minutePointers.forEach((e) => {
            if (e) e.angle = this.normal_angle_minute;
          });
        }

        let normal_fullAngle_second = 360;
        this.normal_angle_second = 0 + (normal_fullAngle_second * (second + (this.timeSensor.utc % 1000) / 1000)) / 60;
        this.secondsPointers.forEach((e) => {
          if (e) e.angle = this.normal_angle_second;
        });
      }

      start_update() {
        let screenType = hmSetting.getScreenType();

        if (screenType == hmSetting.screen_type.WATCHFACE) {
          if (!this.normal_timerUpdate) {
            let animDelay = timeSensor.utc % 1000;
            let animRepeat = 1000;
            this.normal_timerUpdate = timer.createTimer(animDelay, animRepeat, (option) => {
              this.update(false, true);
            }); // end timer
          } // end timer check
        } // end screenType

        if (screenType == hmSetting.screen_type.WATCHFACE) {
          if (!this.normal_timerUpdateSec) {
            let animDelay = 0;
            let animRepeat = 1000 / 6;
            this.normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (option) => {
              this.update(false, false);
            }); // end timer
          } // end timer check
        } // end screenType
      }

      stop_update() {
        if (this.normal_timerUpdate) {
          timer.stopTimer(this.normal_timerUpdate);
          this.normal_timerUpdate = undefined;
        }
        if (this.normal_timerUpdateSec) {
          timer.stopTimer(this.normal_timerUpdateSec);
          this.normal_timerUpdateSec = undefined;
        }
      }
    }

    // Chrono class
    class Chronograph {
      constructor(timeSensor, updateInterval = 1000 / 6) {
        this.timeSensor = timeSensor;
        this.chrono_update_interval = updateInterval;

        this.chrono_start_time = 0;
        this.chrono_current_time = 0;
        this.chrono_mem = 0;

        this.chrono_mode = CHRONO_RESET;

        this.normal_timerUpdateChrono = undefined;
        this.normal_timerArrowsToZero = undefined;

        this.normal_chrono_angle_second = 0;
        this.normal_chrono_angle_minute = 0;
        this.normal_chrono_angle_hour = 0;

        this.arrow_animation_delta = 10;
        this.arrows_animation_is_running = false;

        this.hourPointers = [];
        this.minutePointers = [];
        this.secondsPointers = [];
        this.msec10Pointers = []; // 1/10 sec;
        this.msec100Pointers = []; // 1/100 sec;
      }

      addHourPointer(pointer) {
        this.hourPointers.push(pointer);
      }
      addMinutePointer(pointer) {
        this.minutePointers.push(pointer);
      }
      addSecondsPointer(pointer) {
        this.secondsPointers.push(pointer);
      }
      addMsec10Pointer(pointer) {
        this.msec10Pointers.push(pointer);
      }
      addMsec100Pointer(pointer) {
        this.msec100Pointers.push(pointer);
      }

      start_stop() {
        switch (this.chrono_mode) {
          case CHRONO_RESET:
            this.chrono_mode = CHRONO_START;

            this.chrono_start_time = this.timeSensor.utc;
            // start timer
            if (!this.normal_timerUpdateChrono) {
              this.normal_timerUpdateChrono = timer.createTimer(0, this.chrono_update_interval, (option) => {
                this.update();
              });
            }
            break;
          case CHRONO_START:
            this.chrono_mode = CHRONO_STOP;
            // remember last measured time
            this.chrono_mem = this.chrono_mem + (this.chrono_current_time - this.chrono_start_time);
            // stop timer
            if (this.normal_timerUpdateChrono) {
              timer.stopTimer(this.normal_timerUpdateChrono);
              this.normal_timerUpdateChrono = undefined;
            }
            break;
          case CHRONO_STOP:
            this.chrono_mode = CHRONO_START;
            this.chrono_start_time = this.timeSensor.utc;
            // start timer
            if (!this.normal_timerUpdateChrono) {
              this.normal_timerUpdateChrono = timer.createTimer(0, this.chrono_update_interval, (option) => {
                this.update();
              });
            }
            break;
          default:
            break;
        }
      }

      reset(after = undefined) {
        if (this.chrono_mode == CHRONO_START) return;

        this.chrono_mem = 0;
        this.chrono_start_time = 0;
        this.chrono_current_time = 0;

        // reset should smoothly move arrows to zero
        // start animation to zero timer
        if (!this.normal_timerArrowsToZero) {
          this.arrows_animation_is_running = true;
          this.normal_timerArrowsToZero = timer.createTimer(0, Math.floor(1000 / 100), (option) => {
            this.goToZero(after);
          });
        }
      }

      goToZero(after = undefined) {
        // decrement
        this.normal_chrono_angle_hour -= this.arrow_animation_delta;
        this.normal_chrono_angle_minute -= this.arrow_animation_delta;
        this.normal_chrono_angle_second -= this.arrow_animation_delta;

        // zero them out
        if (valuesAreClose(this.normal_chrono_angle_hour, 0, 12)) this.normal_chrono_angle_hour = 0;
        if (valuesAreClose(this.normal_chrono_angle_minute, 0, 12)) this.normal_chrono_angle_minute = 0;
        if (valuesAreClose(this.normal_chrono_angle_second, 0, 12)) this.normal_chrono_angle_second = 0;

        // set elements angles
        this.hourPointers.forEach((hr) => {
          if (hr) hr.angle = this.normal_chrono_angle_hour;
        });
        this.minutePointers.forEach((min) => {
          if (min) min.angle = this.normal_chrono_angle_minute;
        });
        this.secondsPointers.forEach((sec) => {
          if (sec) sec.angle = this.normal_chrono_angle_second;
        });

        if (this.normal_chrono_angle_hour == 0 && this.normal_chrono_angle_minute == 0 && this.normal_chrono_angle_second == 0) {
          if (this.normal_timerArrowsToZero) {
            timer.stopTimer(this.normal_timerArrowsToZero);
            this.normal_timerArrowsToZero = undefined;
            this.arrows_animation_is_running = false;
          }
          this.chrono_mode = CHRONO_RESET;
          if (after) after();
        }
      }

      update() {
        this.chrono_current_time = this.timeSensor.utc;
        let chrono_time_diff = this.chrono_current_time - this.chrono_start_time + this.chrono_mem;

        let msec_in_hour = 60 * 60 * 1000;
        let msec_in_min = 60 * 1000;
        let msec_in_sec = 1000;

        let hour = Math.floor(chrono_time_diff / msec_in_hour);
        let minute = Math.floor((chrono_time_diff - hour * msec_in_hour) / msec_in_min);
        let second = Math.floor((chrono_time_diff - hour * msec_in_hour - minute * msec_in_min) / msec_in_sec);
        let msec = chrono_time_diff - hour * msec_in_hour - minute * msec_in_min - second * msec_in_sec;

        // update arrows position
        // hour
        let normal_hour = hour;
        let normal_fullAngle_hour = 360;
        this.normal_chrono_angle_hour = (normal_hour * 60 + minute) * (normal_fullAngle_hour / 24 / 60);
        this.hourPointers.forEach((hr) => {
          if (hr) hr.angle = this.normal_chrono_angle_hour;
        });

        // minutes
        let normal_fullAngle_minute = 360;
        this.normal_chrono_angle_minute = (minute * 60 + second) * (normal_fullAngle_minute / 60 / 60);
        this.minutePointers.forEach((min) => {
          if (min) min.angle = this.normal_chrono_angle_minute;
        });

        // sec
        let normal_fullAngle_second = 360;
        this.normal_chrono_angle_second = (second * msec_in_sec + msec) * (normal_fullAngle_second / msec_in_min);
        this.secondsPointers.forEach((sec) => {
          if (sec) sec.angle = this.normal_chrono_angle_second;
        });
      }
    }

    let normal_background_bg_img = "";
    let normal_date_img_date_day = "";
    let normal_analog_clock_pro_hour_pointer_img = "";
    let normal_analog_clock_pro_minute_pointer_img = "";
    let normal_analog_clock_pro_second_pointer_small_img = "";
    let normal_chronograph_second_pointer_img = "";
    let normal_chronograph_minute_pointer_img = "";
    let normal_chronograph_hour_pointer_img = "";
    let normal_analog_clock_pro_second_cover_pointer_img = "";
    let idle_background_bg_img = "";
    let idle_analog_clock_time_pointer_hour = "";
    let idle_analog_clock_time_pointer_minute = "";

    let timeSensor = "";
    let batterySensor = "";

    let miscTimer = undefined;

    let world_clock = "";
    let wt_angle_delta = 360 / 24 / 60;
    let wt_current_angle = 0;
    let wt_target_angle = 0;
    let index = 0;
    let worldData = undefined;
    let displayCurrent = true;

    let timer_animate_wt = undefined;

    let wt_update_in_progress = false;

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start

        const deviceInfo = hmSetting.getDeviceInfo();

        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        if (!batterySensor) batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
        if (!world_clock) world_clock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
        world_clock.init();

        if (hmFS.SysProGetInt("SPEEDMASTER_wt_index")) index = hmFS.SysProGetInt("SPEEDMASTER_wt_index");

        let chrono = new Chronograph(timeSensor);
        let analonClock = new AnalonClock(timeSensor, SMOOTH_SEC);

        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
          analonClock.update(true, true);
          updateDate();
        });

        normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          center_x: 227,
          center_y: 227,
          src: "normal_date.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "normal_bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // bottom dial - is a chrono minutes
        normal_chronograph_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 168,
          y: 259,
          w: 116,
          h: 116,
          pos_x: 0,
          pos_y: 0,
          center_x: 116 / 2,
          center_y: 116 / 2,
          src: "normal_small_arrow_2.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // left dial - time second pointer
        normal_analog_clock_pro_second_pointer_small_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 77,
          y: 169,
          w: 116,
          h: 116,
          pos_x: 0,
          pos_y: 0,
          center_x: 116 / 2,
          center_y: 116 / 2,
          src: "normal_small_arrow_1.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
        // right dial - chrono hour pointer
        normal_chronograph_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 260,
          y: 169,
          w: 116,
          h: 116,
          pos_x: 0,
          pos_y: 0,
          center_x: 116 / 2,
          center_y: 116 / 2,
          src: "normal_small_arrow_1.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 30,
          pos_y: 0,
          center_x: 227,
          center_y: 227,
          src: "normal_hour.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 30,
          pos_y: 0,
          center_x: 227,
          center_y: 227,
          src: "normal_minute.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_chronograph_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 30,
          pos_y: 0,
          center_x: 227,
          center_y: 227,
          src: "normal_second.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // idle screen
        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "idle_bg.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: "idle_hour.png",
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 30,
          hour_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: "idle_minute.png",
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 30,
          minute_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        // chrono buttons
        let button_start_stop = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 327,
          y: 70,
          text: "",
          w: 60,
          h: 60,
          normal_src: "_empty.png",
          press_src: "_empty.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            if (chrono.chrono_mode == CHRONO_RESET) // init on start only
              init_chrono_dials();
            chrono.start_stop();
          },
        });

        let button_reset = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 327,
          y: 327,
          text: "",
          w: 60,
          h: 60,
          normal_src: "_empty.png",
          press_src: "_empty.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {  
            if (chrono.chrono_mode != CHRONO_RESET) {
              chrono.reset(() => {
                init_misc_dials();
              });            
            }
          },
        });

        let gmtButton = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 260,
          y: 169,
          text: "",
          w: 116,
          h: 116,
          normal_src: "_empty.png",
          press_src: "_empty.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            displayCurrent = gmtButtonClick(displayCurrent);
          },
        });
        
        let chronoSecondPointer = new ImgPointer(normal_chronograph_second_pointer_img); 

        let clockSecondPointer = new ImgPointer(normal_analog_clock_pro_second_pointer_small_img);
        let clockHourPointer = new ImgPointer(normal_analog_clock_pro_hour_pointer_img);
        let clockMinutePointer = new ImgPointer(normal_analog_clock_pro_minute_pointer_img);        

        let datePointer = new ImgPointer(normal_date_img_date_day);
        let powerReservePointer = new ImgPointer(normal_chronograph_minute_pointer_img);
        let worldTimePointer = new ImgPointer(normal_chronograph_hour_pointer_img);

        analonClock.addSecondsPointer(clockSecondPointer);
        analonClock.addMinutePointer(clockMinutePointer);
        analonClock.addHourPointer(clockHourPointer);

        chrono.addSecondsPointer(chronoSecondPointer);
        
        function init_chrono_dials() {
          if (miscTimer)   {
            // stop update dials 
            timer.stopTimer(miscTimer);
            miscTimer = undefined;

            // and run them to 0
            miscTimer = timer.createTimer(0, 1000/100, function() {
              arrowsToZero();
            });
          }
        }

        function init_misc_dials() {          
          // remove hours and minutes pointers of chrono, use them as power reserve and world time
          chrono.hourPointers = [];
          chrono.minutePointers = [];          

          worldTimePointer.angle = 0;
          powerReservePointer.angle = 0;          

          if (!miscTimer) {
            miscTimer = timer.createTimer(0, 1000/100, function(opt) {
              arrowsToActualValues(opt);
            }, {
              wt_angle: get_worldTime_angle(index),
              pr_angle: get_powerReserve_angle(),
            });
          }
        }

        function arrowsToZero() {
          powerReservePointer.angle -= 10;
          worldTimePointer.angle -= 10;

          if (valuesAreClose(powerReservePointer.angle, 0, 12)) powerReservePointer.angle = 0
          if (valuesAreClose(worldTimePointer.angle, 0, 12)) worldTimePointer.angle = 0 
          
          if (powerReservePointer.angle == 0 && worldTimePointer.angle == 0) {
            timer.stopTimer(miscTimer);
            miscTimer = undefined;

            chrono.addMinutePointer(powerReservePointer);
            chrono.addHourPointer(worldTimePointer);
          }
        }

        function arrowsToActualValues(opt) {
          let pr_angle = opt.pr_angle;
          let wt_angle = opt.wt_angle;

          powerReservePointer.angle += 10;
          worldTimePointer.angle += 10;

          if (valuesAreClose(powerReservePointer.angle, pr_angle, 12)) powerReservePointer.angle = pr_angle
          if (valuesAreClose(worldTimePointer.angle, wt_angle, 12)) worldTimePointer.angle = wt_angle 

          if (powerReservePointer.angle == pr_angle && worldTimePointer.angle == wt_angle) {
            timer.stopTimer(miscTimer);
            miscTimer = undefined;
            
            miscTimer = timer.createTimer(0, 1000, function() {                
              update_right_sub();
              update_bottom_sub();
            })
          }
        }

        let dateChangeTimer = undefined;
        let dateLastValue = undefined;
        let dateCurrentValue = 1;

        let dateLastAngle = 0;
        let dateCurrentAngle = 0;

        function getDateAngle(day) {
          return (day - 1) * (360 / 31);
        }

        function updateDate() {
          let day = timeSensor.day;

          // 1st call
          if (!dateLastValue) {
            // init some start values
            dateLastValue = day;
            dateLastAngle = getDateAngle(dateLastValue);
            // and set the current date
            if (datePointer) datePointer.angle = dateLastAngle;
            return;
          }

          // followup calls
          dateCurrentValue = day;
          if (dateLastValue == dateCurrentValue) return; // do nothing if it's the same day

          if (!dateChangeTimer) {
            // calculate target angle
            dateCurrentAngle = dateCurrentValue == 1 ? 360 : getDateAngle(dateCurrentValue);
            // start timer
            dateChangeTimer = timer.createTimer(0, 1000 / 30, function (option) {
              moveDate();
            });
          }

          if (datePointer) datePointer.angle = date_angle;
        }

        function moveDate() {
          let d = (360 / 31 / 12);
          dateLastAngle += d;
          if (valuesAreClose(dateCurrentAngle, dateLastAngle, 1)) dateLastAngle = dateCurrentAngle;

          if (datePointer) datePointer.angle = dateLastAngle;

          if (dateLastAngle == dateCurrentAngle) {
            dateLastValue = dateCurrentValue;
            if (dateLastValue == 1) dateLastAngle = 0; 
            if (dateChangeTimer) {
              timer.stopTimer(dateChangeTimer);
              dateChangeTimer = undefined;
            }
          }
        }

        function get_powerReserve_angle() {
          let power = batterySensor.current;
          return 202 + power * ((275 - 202) / 100);
        }

        function get_worldTime_angle(index) {
          let worldData = getWorldData(index);          
          return (worldData.hour * 60 + worldData.minute) * wt_angle_delta;            
        }

        function update_bottom_sub() {
          let power_angle = get_powerReserve_angle();
          if (powerReservePointer) powerReservePointer.angle = power_angle;                   
        }

        function update_right_sub() {
          if (wt_update_in_progress) return;
          worldData = getWorldData(index);
          update_world_clock(false);
        }

        // world clock
        function gmtButtonClick(displayCurrent) {
          // prevent click in chronoghraph mode
          if (chrono.chrono_mode != CHRONO_RESET) return;

          let count = world_clock.getWorldClockCount();

          if (displayCurrent) {
            worldData = getWorldData(index);
            hmUI.showToast({ text: worldData.city + " (" + (index + 1) + "/" + count + ")" });
            return false;
          }

          index++;
          if (index == count) index = 0;

          hmFS.SysProSetInt("SPEEDMASTER_wt_index", index);

          worldData = getWorldData(index);
          if (worldData) hmUI.showToast({ text: worldData.city + " (" + (index + 1) + "/" + count + ")" });
          update_world_clock();
        }

        function getWorldData(idx) {
          let count = world_clock.getWorldClockCount();
          let data = undefined;

          if (idx >= count) idx = 0;
          if (count > 0 && idx < count) data = world_clock.getWorldClockInfo(idx);

          return data;
        }

        function update_world_clock(animate = true) {
          if (worldData) {
            wt_target_angle = (worldData.hour * 60 + worldData.minute) * wt_angle_delta;

            if (animate) {
              if (!timer_animate_wt) {
                wt_update_in_progress = true;
                timer_animate_wt = timer.createTimer(0, 1000 / 100, function (option) {
                  animate_wt();
                });
              }
            } else {
              wt_current_angle = wt_target_angle;
              set_wt(wt_target_angle);
            }
          }
        }

        function animate_wt() {
          let da = wt_current_angle > wt_target_angle ? -6 : 6;
          wt_current_angle += da;
          if (wt_current_angle >= 360) wt_current_angle = wt_current_angle - 360;
          if (valuesAreClose(wt_current_angle, wt_target_angle, 8)) wt_current_angle = wt_target_angle;

          set_wt(wt_current_angle);

          if (timer_animate_wt && wt_current_angle == wt_target_angle) {
            timer.stopTimer(timer_animate_wt);
            timer_animate_wt = undefined;
            wt_update_in_progress = false;
          }
        }

        function set_wt(angle) {
          if (worldTimePointer) worldTimePointer.angle = angle;
        }

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {  
            displayCurrent = true;

            analonClock.update(true, true);
            analonClock.start_update();

            if (chrono && chrono.chrono_mode == CHRONO_RESET){
              update_bottom_sub();
              update_right_sub();

              if (!miscTimer) {
                miscTimer = timer.createTimer(0, 1000, function() {                
                  update_right_sub();
                  update_bottom_sub();
                })
              }
            }

            updateDate();
          },
          pause_call: function () {
            displayCurrent = true;

            analonClock.stop_update();
            
            if (miscTimer) {
              timer.stopTimer(miscTimer);
              miscTimer = undefined;
            }
          },
        });

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e && e.stack && e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
