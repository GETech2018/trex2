﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_icon_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let normal_cal_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_walking_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main_bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 270,
              y: 405,
              src: 'icon_graph=hpa.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 399,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 159,
              y: 405,
              src: 'icon_graph=bar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 354,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 239,
              y: 330,
              src: 'icon_graph=callor.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 354,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'digits_small=km.png',
              unit_tc: 'digits_small=km.png',
              unit_en: 'digits_small=km.png',
              imperial_unit_sc: 'digits_small=ml.png',
              imperial_unit_tc: 'digits_small=ml.png',
              imperial_unit_en: 'digits_small=ml.png',
              dot_image: 'digits_small=dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 137,
              y: 330,
              src: 'icon_graph=dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 284,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 298,
              y: 286,
              src: 'icon_graph=droplet.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 284,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 193,
              y: 286,
              src: 'icon_graph=heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 284,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 76,
              y: 284,
              src: 'icon_graph=PAI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 44,
              y: 183,
              src: 'icon_graph=bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 375,
              y: 183,
              src: 'icon_graph=alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 131,
              src: 'icon_graph=goal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 290,
              // start_y: 123,
              // color: 0xFFFFFFFF,
              // lenght: 92,
              // line_width: 28,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 79,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 240,
              y: 79,
              src: 'icon_graph=steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 128,
              week_en: ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"],
              week_tc: ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"],
              week_sc: ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 174,
              day_startY: 128,
              day_sc_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              day_tc_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              day_en_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 74,
              y: 128,
              src: 'icon_graph=cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 72,
              image_array: ["icon_weather=_0.png","icon_weather=_1.png","icon_weather=_2.png","icon_weather=_3.png","icon_weather=_4.png","icon_weather=_5.png","icon_weather=_6.png","icon_weather=_7.png","icon_weather=_8.png","icon_weather=_9.png","icon_weather=_10.png","icon_weather=_11.png","icon_weather=_12.png","icon_weather=_13.png","icon_weather=_14.png","icon_weather=_15.png","icon_weather=_16.png","icon_weather=_17.png","icon_weather=_18.png","icon_weather=_19.png","icon_weather=_20.png","icon_weather=_21.png","icon_weather=_22.png","icon_weather=_23.png","icon_weather=_24.png","icon_weather=_25.png","icon_weather=_26.png","icon_weather=_27.png","icon_weather=_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 80,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digits_small=celcium.png',
              unit_tc: 'digits_small=celcium.png',
              unit_en: 'digits_small=celcium.png',
              imperial_unit_sc: 'digits_small=faringate.png',
              imperial_unit_tc: 'digits_small=faringate.png',
              imperial_unit_en: 'digits_small=faringate.png',
              negative_image: 'digits_small=minus.png',
              invalid_image: 'digits_small=error.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 127,
                y: 80,
                font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'digits_small=faringate.png',
                unit_tc: 'digits_small=faringate.png',
                unit_en: 'digits_small=faringate.png',
                imperial_unit_sc: 'digits_small=celcium.png',
                imperial_unit_tc: 'digits_small=celcium.png',
                imperial_unit_en: 'digits_small=celcium.png',
                negative_image: 'digits_small=minus.png',
                invalid_image: 'digits_small=error.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 30,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digits_small=procent.png',
              unit_tc: 'digits_small=procent.png',
              unit_en: 'digits_small=procent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seconds.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 38,
              am_y: 236,
              am_sc_path: 'icon_graph=AM.png',
              am_en_path: 'icon_graph=AM.png',
              pm_x: 38,
              pm_y: 236,
              pm_sc_path: 'icon_graph=PM.png',
              pm_en_path: 'icon_graph=PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 178,
              hour_array: ["digits_big=0.png","digits_big=1.png","digits_big=2.png","digits_big=3.png","digits_big=4.png","digits_big=5.png","digits_big=6.png","digits_big=7.png","digits_big=8.png","digits_big=9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 241,
              minute_startY: 178,
              minute_array: ["digits_big=0.png","digits_big=1.png","digits_big=2.png","digits_big=3.png","digits_big=4.png","digits_big=5.png","digits_big=6.png","digits_big=7.png","digits_big=8.png","digits_big=9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 377,
              second_startY: 236,
              second_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 176,
              src: 'digits_big=separation.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod_main_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 354,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img.setAlpha(150);

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 239,
              y: 330,
              src: 'icon_graph=callor.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img.setAlpha(150);

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 354,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'digits_small=km.png',
              unit_tc: 'digits_small=km.png',
              unit_en: 'digits_small=km.png',
              imperial_unit_sc: 'digits_small=ml.png',
              imperial_unit_tc: 'digits_small=ml.png',
              imperial_unit_en: 'digits_small=ml.png',
              dot_image: 'digits_small=dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img.setAlpha(150);

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 137,
              y: 330,
              src: 'icon_graph=dist.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img.setAlpha(150);

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 128,
              week_en: ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"],
              week_tc: ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"],
              week_sc: ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img.setAlpha(150);

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 174,
              day_startY: 128,
              day_sc_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              day_tc_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              day_en_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day.setAlpha(150);

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 74,
              y: 128,
              src: 'icon_graph=cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img.setAlpha(150);

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'icon_graph=AM.png',
              am_en_path: 'icon_graph=AM.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'icon_graph=PM.png',
              pm_en_path: 'icon_graph=PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 178,
              hour_array: ["aod_digits_big=0.png","aod_digits_big=1.png","aod_digits_big=2.png","aod_digits_big=3.png","aod_digits_big=4.png","aod_digits_big=5.png","aod_digits_big=6.png","aod_digits_big=7.png","aod_digits_big=8.png","aod_digits_big=9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 241,
              minute_startY: 178,
              minute_array: ["aod_digits_big=0.png","aod_digits_big=1.png","aod_digits_big=2.png","aod_digits_big=3.png","aod_digits_big=4.png","aod_digits_big=5.png","aod_digits_big=6.png","aod_digits_big=7.png","aod_digits_big=8.png","aod_digits_big=9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time.setAlpha(150);

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 284,
              y: 116,
              src: 'indicator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 71,
              y: 326,
              w: 151,
              h: 61,
              src: 'trans.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 142,
              y: 393,
              w: 180,
              h: 38,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_walking_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 236,
              y: 118,
              w: 166,
              h: 38,
              src: 'trans.png',
              type: hmUI.data_type.WALKING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 289,
              y: 270,
              w: 126,
              h: 57,
              src: 'trans.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 133,
              y: 26,
              w: 187,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 71,
              w: 142,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 52,
              y: 118,
              w: 170,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 236,
              y: 71,
              w: 142,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 175,
              w: 128,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 246,
              y: 175,
              w: 128,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 39,
              y: 269,
              w: 136,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 177,
              y: 270,
              w: 111,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 232,
              y: 326,
              w: 118,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityWeekShowScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 290;
                  let start_y_normal_step = 123;
                  let lenght_ls_normal_step = 92;
                  let line_width_ls_normal_step = 28;
                  let color_ls_normal_step = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}