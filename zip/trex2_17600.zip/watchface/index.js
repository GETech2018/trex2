﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_pai_icon_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_circle_scale = ''
        let normal_fat_burning_current_text_img = ''
        let normal_fat_burning_current_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 91,
              src: 'icon-BellSimpleSlash.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 133,
              y: 91,
              src: 'icon-BluetoothSlash.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 77,
              y: 91,
              src: 'icon-Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 86,
              font_array: ["digit-temp=0.png","digit-temp=1.png","digit-temp=2.png","digit-temp=3.png","digit-temp=4.png","digit-temp=5.png","digit-temp=6.png","digit-temp=7.png","digit-temp=8.png","digit-temp=9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'label-temp-celc.png',
              unit_tc: 'label-temp-celc.png',
              unit_en: 'label-temp-celc.png',
              imperial_unit_sc: 'label-temp-far.png',
              imperial_unit_tc: 'label-temp-far.png',
              imperial_unit_en: 'label-temp-far.png',
              negative_image: 'digit-temp=minus.png',
              invalid_image: 'digit-temp=null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 295,
                y: 86,
                font_array: ["digit-temp=0.png","digit-temp=1.png","digit-temp=2.png","digit-temp=3.png","digit-temp=4.png","digit-temp=5.png","digit-temp=6.png","digit-temp=7.png","digit-temp=8.png","digit-temp=9.png"],
                padding: false,
                h_space: 3,
                unit_sc: 'label-temp-far.png',
                unit_tc: 'label-temp-far.png',
                unit_en: 'label-temp-far.png',
                imperial_unit_sc: 'label-temp-celc.png',
                imperial_unit_tc: 'label-temp-celc.png',
                imperial_unit_en: 'label-temp-celc.png',
                negative_image: 'digit-temp=minus.png',
                invalid_image: 'digit-temp=null.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 243,
              day_startY: 81,
              day_sc_array: ["digit-dat=0.png","digit-dat=1.png","digit-dat=2.png","digit-dat=3.png","digit-dat=4.png","digit-dat=5.png","digit-dat=6.png","digit-dat=7.png","digit-dat=8.png","digit-dat=9.png"],
              day_tc_array: ["digit-dat=0.png","digit-dat=1.png","digit-dat=2.png","digit-dat=3.png","digit-dat=4.png","digit-dat=5.png","digit-dat=6.png","digit-dat=7.png","digit-dat=8.png","digit-dat=9.png"],
              day_en_array: ["digit-dat=0.png","digit-dat=1.png","digit-dat=2.png","digit-dat=3.png","digit-dat=4.png","digit-dat=5.png","digit-dat=6.png","digit-dat=7.png","digit-dat=8.png","digit-dat=9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 81,
              src: 'digit-dat=separator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 166,
              y: 81,
              week_en: ["digit-day=1.png","digit-day=2.png","digit-day=3.png","digit-day=4.png","digit-day=5.png","digit-day=6.png","digit-day=7.png"],
              week_tc: ["digit-day=1.png","digit-day=2.png","digit-day=3.png","digit-day=4.png","digit-day=5.png","digit-day=6.png","digit-day=7.png"],
              week_sc: ["digit-day=1.png","digit-day=2.png","digit-day=3.png","digit-day=4.png","digit-day=5.png","digit-day=6.png","digit-day=7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setAlpha(150);

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 340,
              src: 'bat-0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img.setAlpha(100);

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 340,
              image_array: ["bat-1.png","bat-2.png","bat-3.png","bat-4.png","bat-5.png","bat-6.png","bat-7.png","bat-8.png","bat-9.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 272,
              y: 336,
              src: 'label-pai.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img.setAlpha(150);

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 323,
              y: 336,
              font_array: ["digit-pai=0.png","digit-pai=1.png","digit-pai=2.png","digit-pai=3.png","digit-pai=4.png","digit-pai=5.png","digit-pai=6.png","digit-pai=7.png","digit-pai=8.png","digit-pai=9.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 272,
              y: 336,
              src: 'pai-back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 98,
              y: 337,
              src: 'label-cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img.setAlpha(150);

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 148,
              y: 336,
              font_array: ["digit-cal=0.png","digit-cal=1.png","digit-cal=2.png","digit-cal=3.png","digit-cal=4.png","digit-cal=5.png","digit-cal=6.png","digit-cal=7.png","digit-cal=8.png","digit-cal=9.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 98,
              y: 337,
              src: 'cal-back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 37,
              src: 'label-bio.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img.setAlpha(150);

            // normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 0,
              // end_angle: 90,
              // radius: 227,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFF9E1C1C,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 0,
              end_angle: 90,
              radius: 223,
              line_width: 9,
              corner_flag: 3,
              color: 0xFF9E1C1C,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 37,
              font_array: ["digit-bio=0.png","digit-bio=1.png","digit-bio=2.png","digit-bio=3.png","digit-bio=4.png","digit-bio=5.png","digit-bio=6.png","digit-bio=7.png","digit-bio=8.png","digit-bio=9.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 39,
              src: 'bio-back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 380,
              src: 'label-stp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img.setAlpha(150);

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 180,
              // end_angle: 270,
              // radius: 227,
              // line_width: 8,
              // line_cap: Flat,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 200,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 180,
              end_angle: 270,
              radius: 223,
              line_width: 8,
              corner_flag: 3,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale.setAlpha(200);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 380,
              font_array: ["digit-stp=0.png","digit-stp=1.png","digit-stp=2.png","digit-stp=3.png","digit-stp=4.png","digit-stp=5.png","digit-stp=6.png","digit-stp=7.png","digit-stp=8.png","digit-stp=9.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 382,
              src: 'stp-back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'label.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 44,
              am_y: 212,
              am_sc_path: 'format-am.png',
              am_en_path: 'format-am.png',
              pm_x: 44,
              pm_y: 212,
              pm_sc_path: 'format-pm.png',
              pm_en_path: 'format-pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 96,
              hour_startY: 148,
              hour_array: ["digit-main=0.png","digit-main=1.png","digit-main=2.png","digit-main=3.png","digit-main=4.png","digit-main=5.png","digit-main=6.png","digit-main=7.png","digit-main=8.png","digit-main=9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 148,
              minute_array: ["digit-minute=0.png","digit-minute=1.png","digit-minute=2.png","digit-minute=3.png","digit-minute=4.png","digit-minute=5.png","digit-minute=6.png","digit-minute=7.png","digit-minute=8.png","digit-minute=9.png"],
              minute_zero: 1,
              minute_space: 19,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 372,
              second_startY: 201,
              second_array: ["digit-sec=0.png","digit-sec=1.png","digit-sec=2.png","digit-sec=3.png","digit-sec=4.png","digit-sec=5.png","digit-sec=6.png","digit-sec=7.png","digit-sec=8.png","digit-sec=9.png"],
              second_zero: 1,
              second_space: 8,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 372,
              y: 201,
              src: 'sec-back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 243,
              day_startY: 81,
              day_sc_array: ["digit-dat=0.png","digit-dat=1.png","digit-dat=2.png","digit-dat=3.png","digit-dat=4.png","digit-dat=5.png","digit-dat=6.png","digit-dat=7.png","digit-dat=8.png","digit-dat=9.png"],
              day_tc_array: ["digit-dat=0.png","digit-dat=1.png","digit-dat=2.png","digit-dat=3.png","digit-dat=4.png","digit-dat=5.png","digit-dat=6.png","digit-dat=7.png","digit-dat=8.png","digit-dat=9.png"],
              day_en_array: ["digit-dat=0.png","digit-dat=1.png","digit-dat=2.png","digit-dat=3.png","digit-dat=4.png","digit-dat=5.png","digit-dat=6.png","digit-dat=7.png","digit-dat=8.png","digit-dat=9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day.setAlpha(200);

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 81,
              src: 'digit-dat=separator.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img.setAlpha(200);

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 166,
              y: 81,
              week_en: ["digit-day=1.png","digit-day=2.png","digit-day=3.png","digit-day=4.png","digit-day=5.png","digit-day=6.png","digit-day=7.png"],
              week_tc: ["digit-day=1.png","digit-day=2.png","digit-day=3.png","digit-day=4.png","digit-day=5.png","digit-day=6.png","digit-day=7.png"],
              week_sc: ["digit-day=1.png","digit-day=2.png","digit-day=3.png","digit-day=4.png","digit-day=5.png","digit-day=6.png","digit-day=7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img.setAlpha(200);

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 44,
              am_y: 212,
              am_sc_path: 'format-am.png',
              am_en_path: 'format-am.png',
              pm_x: 44,
              pm_y: 212,
              pm_sc_path: 'format-pm.png',
              pm_en_path: 'format-pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 96,
              hour_startY: 148,
              hour_array: ["digit-main=0.png","digit-main=1.png","digit-main=2.png","digit-main=3.png","digit-main=4.png","digit-main=5.png","digit-main=6.png","digit-main=7.png","digit-main=8.png","digit-main=9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 148,
              minute_array: ["digit-main=0.png","digit-main=1.png","digit-main=2.png","digit-main=3.png","digit-main=4.png","digit-main=5.png","digit-main=6.png","digit-main=7.png","digit-main=8.png","digit-main=9.png"],
              minute_zero: 1,
              minute_space: 19,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'up-img-scale.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 166,
              y: 381,
              w: 142,
              h: 33,
              src: 'emp.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 269,
              y: 333,
              w: 95,
              h: 38,
              src: 'emp.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 333,
              w: 62,
              h: 38,
              src: 'emp.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 302,
              y: 87,
              w: 76,
              h: 38,
              src: 'emp.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 333,
              w: 104,
              h: 38,
              src: 'emp.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 169,
              y: 80,
              w: 115,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'emp.png',
              normal_src: 'emp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 169,
              y: 34,
              w: 115,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'emp.png',
              normal_src: 'emp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 237,
              y: 149,
              w: 119,
              h: 161,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'emp.png',
              normal_src: 'emp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 96,
              y: 148,
              w: 119,
              h: 161,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'emp.png',
              normal_src: 'emp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 373,
              y: 201,
              w: 47,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'emp.png',
              normal_src: 'emp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_cs_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_fat_burning * 100);
                  if (normal_fat_burning_circle_scale) {
                    normal_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 0,
                      end_angle: 90,
                      radius: 223,
                      line_width: 9,
                      corner_flag: 3,
                      color: 0xFF9E1C1C,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 180,
                      end_angle: 270,
                      radius: 223,
                      line_width: 8,
                      corner_flag: 3,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}