﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 315,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'deg.png',
              unit_tc: 'deg.png',
              unit_en: 'deg.png',
              negative_image: 'minus.png',
              invalid_image: 'empty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 351,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'empty.png',
              unit_tc: 'empty.png',
              unit_en: 'empty.png',
              imperial_unit_sc: 'empty.png',
              imperial_unit_tc: 'empty.png',
              imperial_unit_en: 'empty.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 366,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: -6,
              invalid_image: 'empty.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 100,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 5,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 259,
              y: 37,
              image_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 145,
              y: 140,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 170,
              month_startY: 275,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 223,
              day_startY: 134,
              day_sc_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              day_tc_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              day_en_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              day_zero: 1,
              day_space: -6,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 209,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 0,
              pm_y: 209,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 177,
              hour_array: ["dig_big_0.png","dig_big_1.png","dig_big_2.png","dig_big_3.png","dig_big_4.png","dig_big_5.png","dig_big_6.png","dig_big_7.png","dig_big_8.png","dig_big_9.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 245,
              minute_startY: 150,
              minute_array: ["dig_big_0.png","dig_big_1.png","dig_big_2.png","dig_big_3.png","dig_big_4.png","dig_big_5.png","dig_big_6.png","dig_big_7.png","dig_big_8.png","dig_big_9.png"],
              minute_zero: 1,
              minute_space: -18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 209,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 0,
              pm_y: 209,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 177,
              hour_array: ["dig_big_0.png","dig_big_1.png","dig_big_2.png","dig_big_3.png","dig_big_4.png","dig_big_5.png","dig_big_6.png","dig_big_7.png","dig_big_8.png","dig_big_9.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 245,
              minute_startY: 150,
              minute_array: ["dig_big_0.png","dig_big_1.png","dig_big_2.png","dig_big_3.png","dig_big_4.png","dig_big_5.png","dig_big_6.png","dig_big_7.png","dig_big_8.png","dig_big_9.png"],
              minute_zero: 1,
              minute_space: -18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}