﻿/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start

    class ImgWidget {
      constructor(data) {
        this._widget = hmUI.createWidget(hmUI.widget.IMG, data);

        this._angle = data.angle;
        this._visible = true;
      }

      get angle() {
        return this._angle;
      }
      set angle(value) {
        if (this._widget) {
          this._angle = value;
          this._widget.setProperty(hmUI.prop.ANGLE, this._angle);
        }
      }

      get visible() {
        return this._visible;
      }
      set visible(value) {
        if (this._widget) {
          this._visible = value;
          this._widget.setProperty(hmUI.prop.VISIBLE, this._visible);
        }
      }
    }

    function valuesAreClose(firstValue, secondValue, tolerance = 10) {
      return Math.abs(Math.abs(firstValue) - Math.abs(secondValue)) <= tolerance;
    }

    const CHRONO_RESET = 0;
    const CHRONO_START = 1;
    const CHRONO_STOP = 2;

    const NORMAL_SEC = 0;
    const SEMI_SMOOTH_SEC = 1;
    const SMOOTH_SEC = 2;

    // Analog Clock class
    class AnalonClock {
      constructor(timeSensor, secMode = SEMI_SMOOTH_SEC) {
        this.timeSensor = timeSensor;

        this.hourPointer = "";
        this.minutePointer = "";
        this.secondsPointer = "";

        this.weekPointer = "";
        this.datePointer = "";

        this.normal_angle_hour = 0;
        this.normal_angle_minute = 0;
        this.normal_angle_second = 0;

        this.normal_timerUpdate = undefined;
        this.normal_timerUpdateSec = undefined;

        this.secondsMode = secMode;
        this.lastDay = 0;
      }
      addHourPointer(pointer) {
        this.hourPointer = pointer;
      }
      addMinutePointer(pointer) {
        this.minutePointer = pointer;
      }
      addSecondsPointer(pointer) {
        this.secondsPointer = pointer;
      }
      addWeekPointer(pointer) {
        this.weekPointer = pointer;
      }
      addDatePointer(pointer) {
        this.datePointer = pointer;
      }

      update(updateHour = false, updateMinute = false) {
        let hour = this.timeSensor.hour;
        let minute = this.timeSensor.minute;
        let second = this.timeSensor.second;

        if (updateHour) {
          let normal_hour = hour;
          let normal_fullAngle_hour = 360;
          if (normal_hour > 11) normal_hour -= 12;
          this.normal_angle_hour = 0 + (normal_fullAngle_hour * normal_hour) / 12 + ((normal_fullAngle_hour / 12) * minute) / 60;
          if (this.hourPointer) this.hourPointer.angle = this.normal_angle_hour;
        }

        if (updateMinute) {
          let normal_fullAngle_minute = 360;
          this.normal_angle_minute = 0 + (normal_fullAngle_minute * (minute + second / 60)) / 60;
          if (this.minutePointer) this.minutePointer.angle = this.normal_angle_minute;
        }

        let normal_fullAngle_second = 360;
        this.normal_angle_second = 0 + (normal_fullAngle_second * (second + (this.timeSensor.utc % 1000) / 1000)) / 60;
        if (this.secondsPointer) this.secondsPointer.angle = this.normal_angle_second;

        if (updateHour && updateMinute && this.lastDay != this.timeSensor.day) {
          // check and update only when it's required
          let normal_fullAngle = 360;
          this.lastDay = this.timeSensor.day;
          const currentDayAngle = Math.round((normal_fullAngle / 31) * (this.timeSensor.day - 1));
          const currentWeekAngle = -Math.round((normal_fullAngle / 7) * (this.timeSensor.week - 1));

          this.datePointer.angle = currentDayAngle;
          this.weekPointer.angle = currentWeekAngle;
        }
      }

      start_update() {
        let screenType = hmSetting.getScreenType();

        if (screenType == hmSetting.screen_type.WATCHFACE) {
          if (!this.normal_timerUpdate) {
            let animDelay = timeSensor.utc % 1000;
            let animRepeat = 1000;
            this.normal_timerUpdate = timer.createTimer(animDelay, animRepeat, (option) => {
              this.update(false, true);
            }); // end timer
          } // end timer check
        } // end screenType

        if (screenType == hmSetting.screen_type.WATCHFACE) {
          if (!this.normal_timerUpdateSec) {
            let animDelay = 0;
            let animRepeat = 1000 / 6;
            this.normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (option) => {
              this.update(false, false);
            }); // end timer
          } // end timer check
        } // end screenType
      }

      stop_update() {
        if (this.normal_timerUpdate) {
          timer.stopTimer(this.normal_timerUpdate);
          this.normal_timerUpdate = undefined;
        }
        if (this.normal_timerUpdateSec) {
          timer.stopTimer(this.normal_timerUpdateSec);
          this.normal_timerUpdateSec = undefined;
        }
      }
    }

    // Chrono class
    class Chronograph {
      constructor(timeSensor, updateInterval = 1000 / 6) {
        this.timeSensor = timeSensor;
        this.chrono_update_interval = updateInterval;

        this.chrono_start_time = 0;
        this.chrono_current_time = 0;
        this.chrono_mem = 0;

        this.chrono_mode = CHRONO_RESET;

        this.normal_timerUpdateChrono = undefined;
        this.normal_timerArrowsToZero = undefined;

        this.normal_chrono_angle_second = 0;
        this.normal_chrono_angle_minute = 0;
        this.normal_chrono_angle_hour = 0;

        this.arrow_animation_delta = 6;
        this.arrows_animation_is_running = false;

        this.hourPointer = undefined;
        this.minutePointer = undefined;
        this.secondsPointer = undefined;
      }

      addHourPointer(pointer) {
        this.hourPointer = pointer;
      }
      addMinutePointer(pointer) {
        this.minutePointer = pointer;
      }
      addSecondsPointer(pointer) {
        this.secondsPointer = pointer;
      }

      start_stop() {
        switch (this.chrono_mode) {
          case CHRONO_RESET:
            this.chrono_mode = CHRONO_START;

            this.chrono_start_time = this.timeSensor.utc;
            // start timer
            if (!this.normal_timerUpdateChrono) {
              this.normal_timerUpdateChrono = timer.createTimer(0, this.chrono_update_interval, (option) => {
                this.update();
              });
            }
            break;
          case CHRONO_START:
            this.chrono_mode = CHRONO_STOP;
            // remember last measured time
            this.chrono_mem = this.chrono_mem + (this.chrono_current_time - this.chrono_start_time);
            // stop timer
            if (this.normal_timerUpdateChrono) {
              timer.stopTimer(this.normal_timerUpdateChrono);
              this.normal_timerUpdateChrono = undefined;
            }
            break;
          case CHRONO_STOP:
            this.chrono_mode = CHRONO_START;
            this.chrono_start_time = this.timeSensor.utc;
            // start timer
            if (!this.normal_timerUpdateChrono) {
              this.normal_timerUpdateChrono = timer.createTimer(0, this.chrono_update_interval, (option) => {
                this.update();
              });
            }
            break;
          default:
            break;
        }
      }

      reset() {
        if (this.chrono_mode == CHRONO_START) return;

        this.chrono_mode = CHRONO_RESET;

        this.chrono_mem = 0;
        this.chrono_start_time = 0;
        this.chrono_current_time = 0;

        // reset should smoothly move arrows to zero
        // start animation to zero timer
        if (!this.normal_timerArrowsToZero) {
          this.arrows_animation_is_running = true;
          this.normal_timerArrowsToZero = timer.createTimer(0, Math.floor(1000 / 30), (option) => {
            this.goToZero();
          });
        }
      }

      goToZero() {
        // decrement
        this.normal_chrono_angle_hour -= this.arrow_animation_delta;
        this.normal_chrono_angle_minute -= this.arrow_animation_delta;
        this.normal_chrono_angle_second -= this.arrow_animation_delta;

        // zero them out
        if (valuesAreClose(this.normal_chrono_angle_hour, 0)) this.normal_chrono_angle_hour = 0;
        if (valuesAreClose(this.normal_chrono_angle_minute, 0)) this.normal_chrono_angle_minute = 0;
        if (valuesAreClose(this.normal_chrono_angle_second, 0)) this.normal_chrono_angle_second = 0;

        // set elements angles
        if (this.hourPointer) this.hourPointer.angle = this.normal_chrono_angle_hour;
        if (this.minutePointer) this.minutePointer.angle = this.normal_chrono_angle_minute;
        if (this.secondsPointer) this.secondsPointer.angle = this.normal_chrono_angle_second;

        if (this.normal_chrono_angle_hour == 0 && this.normal_chrono_angle_minute == 0 && this.normal_chrono_angle_second == 0) {
          if (this.normal_timerArrowsToZero) {
            timer.stopTimer(this.normal_timerArrowsToZero);
            this.normal_timerArrowsToZero = undefined;
            this.arrows_animation_is_running = false;
          }
        }
      }

      update() {
        this.chrono_current_time = this.timeSensor.utc;
        let chrono_time_diff = this.chrono_current_time - this.chrono_start_time + this.chrono_mem;

        let msec_in_hour = 60 * 60 * 1000;
        let msec_in_min = 60 * 1000;
        let msec_in_sec = 1000;

        let hour = Math.floor(chrono_time_diff / msec_in_hour);
        let minute = Math.floor((chrono_time_diff - hour * msec_in_hour) / msec_in_min);
        let second = Math.floor((chrono_time_diff - hour * msec_in_hour - minute * msec_in_min) / msec_in_sec);
        let msec = chrono_time_diff - hour * msec_in_hour - minute * msec_in_min - second * msec_in_sec;

        // update arrows position
        // hour
        let normal_hour = hour;
        let normal_fullAngle_hour = 360;
        if (normal_hour > 11) normal_hour -= 12;
        this.normal_chrono_angle_hour = (normal_hour * 60 + minute) * (normal_fullAngle_hour / 12 / 60);
        if (this.hourPointer) this.hourPointer.angle = this.normal_chrono_angle_hour;

        // minutes
        let normal_fullAngle_minute = 360;
        this.normal_chrono_angle_minute = (minute * 60 + second) * (normal_fullAngle_minute / 30 / 60);
        if (this.minutePointer) this.minutePointer.angle = this.normal_chrono_angle_minute;

        // sec
        let normal_fullAngle_second = 360;
        this.normal_chrono_angle_second = (second * msec_in_sec + msec) * (normal_fullAngle_second / msec_in_min);
        if (this.secondsPointer) this.secondsPointer.angle = this.normal_chrono_angle_second;
      }
    }

    let normal_date = "";
    let normal_week = "";
    let normal_bg = "";
    let normal_hour_pt = "";
    let normal_minute_pt = "";
    let normal_second_pt = "";
    let naormal_chrono_second_pt = "";
    let normal_chrono_minute_pt = "";
    let normal_chrono_hour_pt = "";
    let idle_bg = "";
    let idle_hour_pt = "";
    let idle_minute_pt = "";
    let timeSensor = "";

    let normal_timerUpdateSecSmooth = undefined;
    let normal_timerUpdateSec = undefined;
    let lastTime = 0;

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start
        const deviceInfo = hmSetting.getDeviceInfo();
        let screenType = hmSetting.getScreenType();

        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

        let analogClock = new AnalonClock(timeSensor, SMOOTH_SEC);
        let chrono = new Chronograph(timeSensor);

        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
          analogClock.update(true, true);
        });

        normal_date = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 0,
          pos_y: 0,
          center_x: 227,
          center_y: 227,
          src: "normal_date.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });
        analogClock.addDatePointer(normal_date);

        normal_week = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 0,
          pos_y: 0,
          center_x: 227,
          center_y: 227,
          src: "normal_day.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });
        analogClock.addWeekPointer(normal_week);

        normal_bg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "normal_bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
        });

        // -------------------------------------------------------

        normal_second_pt = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 119 - 53,
          pos_y: 227 - 53,
          center_x: 119,
          center_y: 227,
          src: "normal_small_pointer.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        analogClock.addSecondsPointer(normal_second_pt);

        normal_chrono_minute_pt = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 53,
          pos_y: 121 - 53,
          center_x: 227,
          center_y: 121,
          src: "normal_small_pointer.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        chrono.addMinutePointer(normal_chrono_minute_pt);

        normal_chrono_hour_pt = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 53,
          pos_y: 330 - 53,
          center_x: 227,
          center_y: 330,
          src: "normal_small_pointer.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        chrono.addHourPointer(normal_chrono_hour_pt);

        normal_hour_pt = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 28,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_hour.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        analogClock.addHourPointer(normal_hour_pt);

        normal_minute_pt = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 28,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_minute.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        analogClock.addMinutePointer(normal_minute_pt);

        naormal_chrono_second_pt = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 28,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_second.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        chrono.addSecondsPointer(naormal_chrono_second_pt);

        idle_bg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "idle_bg_tp.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        let idle__second_pt = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 119 - 53,
          pos_y: 227 - 53,
          center_x: 119,
          center_y: 227,
          src: "idle_small_pointer.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        // let idle__second_pt = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        //   second_path: "idle_small_pointer.png",
        //   second_centerX: 119,
        //   second_centerY: 227,
        //   second_posX: 53,
        //   second_posY: 53,
        //   show_level: hmUI.show_level.ONLY_AOD,
        // });

        let idle_chrono_minute_pt = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 53,
          pos_y: 121 - 53,
          center_x: 227,
          center_y: 121,
          src: "idle_small_pointer.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        let idle_chrono_hour = new ImgWidget({
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 53,
          pos_y: 330 - 53,
          center_x: 227,
          center_y: 330,
          src: "idle_small_pointer.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_hour_pt = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: "idle_hour.png",
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 28,
          hour_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_minute_pt = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: "idle_minute.png",
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 28,
          minute_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        // chrono buttons
        button_start_stop = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 327, // x coordinate of the button
          y: 70, // y coordinate of the button
          text: "",
          w: 60, // button width
          h: 60, // button height
          normal_src: "_empty.png", // transparent image
          press_src: "_empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            chrono.start_stop();
          },
        });

        button_reset = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 327, // x coordinate of the button
          y: 327, // y coordinate of the button
          text: "",
          w: 60, // button width
          h: 60, // button height
          normal_src: "_empty.png", // transparent image
          press_src: "_empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            chrono.reset();
          },
        });

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            analogClock.update(true, true);
            analogClock.start_update();
          },
          pause_call: function () {
            analogClock.stop_update();
          },
        });

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e && e.stack && e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
