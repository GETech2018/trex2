﻿/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start

    let normal_background_bg_img = "";
    let normal_day_TextRotate = new Array(2);
    let normal_day_TextRotate_ASCIIARRAY = new Array(10);
    let normal_day_TextRotate_img_width = 12;
    let normal_timerTextUpdate = undefined;
    let normal_analog_clock_pro_hour_pointer_img = "";
    let normal_analog_clock_pro_minute_pointer_img = "";
    let normal_analog_clock_pro_second_pointer_img = "";
    let normal_world_clock_pointer_img = "";
    let normal_timerUpdate = undefined;
    let normal_timerUpdateSec = undefined;
    let normal_analog_clock_pro_second_cover_pointer_img = "";
    let idle_background_bg_img = "";
    let idle_analog_clock_time_pointer_hour = "";
    let idle_analog_clock_time_pointer_minute = "";
    let timeSensor = "";

    let wt_angle_delta = 360 / 24 / 60;
    let wt_current_angle = 0;
    let wt_target_angle = 0;
    let index = 0;
    let worldData = undefined;

    let timer_animate_seconds = undefined;
    let timer_animate_wt = undefined;

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start

        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "normal_bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
        // x: 328,
        // y: 313,
        // font_array: ["digi_0.png","digi_1.png","digi_2.png","digi_3.png","digi_4.png","digi_5.png","digi_6.png","digi_7.png","digi_8.png","digi_9.png"],
        // zero: false,
        // unit_in_alignment: false,
        // h_space: 0,
        // angle: 45,
        // align_h: hmUI.align.CENTER_H,
        // type: hmUI.data_type.DAY,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_day_TextRotate_ASCIIARRAY[0] = "digi_0.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[1] = "digi_1.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[2] = "digi_2.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[3] = "digi_3.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[4] = "digi_4.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[5] = "digi_5.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[6] = "digi_6.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[7] = "digi_7.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[8] = "digi_8.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[9] = "digi_9.png"; // set of images with numbers

        //start of ignored block
        for (let i = 0; i < 2; i++) {
          normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 454,
            h: 454,
            center_x: 328,
            center_y: 313,
            pos_x: 328,
            pos_y: 313,
            angle: 45,
            src: "digi_0.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
        }
        //end of ignored block

        const world_clock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
        // world_clock.init();

        const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);
        let screenType = hmSetting.getScreenType();
        const deviceInfo = hmSetting.getDeviceInfo();
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
          time_update(true, true);
        });

        normal_world_clock_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 40,
          pos_y: 227 - 226,
          center_x: 227,
          center_y: 227,
          src: "arrow_wt.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'arrow_normal_hr.png',
        // center_x: 227,
        // center_y: 227,
        // x: 40,
        // y: 226,
        // start_angle: 0,
        // end_angle: 360,
        // type: hmUI.data_type.hour,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 40,
          pos_y: 227 - 226,
          center_x: 227,
          center_y: 227,
          src: "arrow_normal_hr.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'arrow_normal_min.png',
        // center_x: 227,
        // center_y: 227,
        // x: 40,
        // y: 226,
        // start_angle: 0,
        // end_angle: 360,
        // type: hmUI.data_type.minute,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 40,
          pos_y: 227 - 226,
          center_x: 227,
          center_y: 227,
          src: "arrow_normal_min.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'arrow_normal_sec.png',
        // center_x: 227,
        // center_y: 227,
        // x: 40,
        // y: 226,
        // start_angle: 0,
        // end_angle: 360,
        // cover_path: 'center.png',
        // cover_x: 0,
        // cover_y: 0,
        // type: hmUI.data_type.second,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 40,
          pos_y: 227 - 226,
          center_x: 227,
          center_y: 227,
          src: "arrow_normal_sec.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: "center.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "idle_bg.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: "arrow_idle_hr.png",
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 40,
          hour_posY: 226,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: "arrow_idle_min.png",
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 40,
          minute_posY: 226,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        let centerButton = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 202, // x coordinate of the button
          y: 202, // y coordinate of the button
          text: "",
          w: 50, // button width
          h: 50, // button height
          normal_src: "_empty.png", // transparent image
          press_src: "_empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            centerButtonClick();
          },
        });

        function time_update(updateHour = false, updateMinute = false) {
          let hour = timeSensor.hour;
          let minute = timeSensor.minute;
          let second = timeSensor.second;

          if (updateHour) {
            let normal_hour = hour;
            let normal_fullAngle_hour = 360;
            if (normal_hour > 11) normal_hour -= 12;
            let normal_angle_hour = 0 + (normal_fullAngle_hour * normal_hour) / 12 + ((normal_fullAngle_hour / 12) * minute) / 60;
            if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
          }

          if (updateMinute) {
            let normal_fullAngle_minute = 360;
            let normal_angle_minute = 0 + (normal_fullAngle_minute * minute) / 60;
            if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);

            // also update world_clock
            worldData = getWorldData(index);
            update_world_clock();
          }
        }

        let lastAngleSeconds = 0;
        let second_current_angle = 0;

        function time_update_sec() {
          // start timer
          second_current_angle = getSecondsNormalAngle(timeSensor.second - 1);
          lastAngleSeconds = getSecondsNormalAngle(timeSensor.second);
          setSeconds(second_current_angle);

          if (!timer_animate_seconds) {
            timer_animate_seconds = timer.createTimer(30, 30, function (option) {
              animate_seconds();
            });
          }
        }

        function animate_seconds() {
          second_current_angle += 360 / 60 / 3;

          setSeconds(second_current_angle);

          if (timer_animate_seconds && second_current_angle == lastAngleSeconds) {
            timer.stopTimer(timer_animate_seconds);
            timer_animate_seconds = undefined;

            lastAngleSeconds = second_current_angle;
          }
        }

        function setSeconds(angle) {
          if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, angle);
        }

        function getSecondsNormalAngle(second) {
          let normal_fullAngle_second = 360;
          let normal_angle_second = 0 + (normal_fullAngle_second * second) / 60;

          return normal_angle_second;
        }

        function centerButtonClick() {
          let count = world_clock.getWorldClockCount();

          index++;
          if (index == count) index = 0;

          worldData = getWorldData(index);
          if (worldData) hmUI.showToast({ text: worldData.city + " (" + (index + 1) + "/" + count + ")" });
          update_world_clock();
        }

        function getWorldData(idx) {
          let count = world_clock.getWorldClockCount();
          let data = undefined;
          if (count > 0 && idx < count) data = world_clock.getWorldClockInfo(idx);

          return data;
        }

        function update_world_clock() {
          if (worldData) {
            if (normal_world_clock_pointer_img) normal_world_clock_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
            wt_target_angle = (worldData.hour * 60 + worldData.minute) * wt_angle_delta;

            if (!timer_animate_wt) {
              timer_animate_wt = timer.createTimer(0, 30, function (option) {
                animate_wt();
              });
            }
          } else {
            if (normal_world_clock_pointer_img) normal_world_clock_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
          }
        }

        function valuesAreClose(firstValue, secondValue, tolerance = 10) {
          return Math.abs(firstValue - secondValue) <= tolerance;
        }

        function animate_wt() {
          let da = wt_current_angle > wt_target_angle ? -3 : 3;
          wt_current_angle += da;
          if (wt_current_angle >= 360) wt_current_angle = wt_current_angle - 360;
          if (valuesAreClose(wt_current_angle, wt_target_angle, 4)) wt_current_angle = wt_target_angle;

          if (normal_world_clock_pointer_img) normal_world_clock_pointer_img.setProperty(hmUI.prop.ANGLE, wt_current_angle);

          if (timer_animate_wt && wt_current_angle == wt_target_angle) {
            timer.stopTimer(timer_animate_wt);
            timer_animate_wt = undefined;
          }
        }

        function text_update() {
          console.log("update text rotate day_TIME");
          let valueDay = timeNaw.day;
          let normal_day_rotate_string = parseInt(valueDay).toString();

          if (screenType != hmSetting.screen_type.AOD) {
            for (var i = 1; i < 2; i++) {
              // hide all symbols
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            }
            if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {
              // display data if it was possible to get it
              let img_offset = 0;
              // alignment = CENTER_H
              let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
              img_offset -= normal_day_TextRotate_posOffset / 2;
              // alignment end

              let index = 0;
              for (let char of normal_day_rotate_string) {
                let charCode = char.charCodeAt() - 48;
                if (index >= 2) break;
                if (charCode >= 0 && charCode < 10) {
                  normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 328 + img_offset);
                  normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                  normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                  img_offset += normal_day_TextRotate_img_width;
                  index++;
                } // end if digit
              } // end char of string
            } // end isFinite
          }
        }

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            world_clock.init();
            worldData = getWorldData(index);
            time_update(true, true);
            // init seconds arrow angle
            second_current_angle = getSecondsNormalAngle(timeSensor.second - 1);
            lastAngleSeconds = getSecondsNormalAngle(timeSensor.second);
            setSeconds(second_current_angle);

            text_update();

            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerTextUpdate) {
                normal_timerTextUpdate = timer.createTimer(0, 1000, function (option) {
                  text_update();
                }); // end timer
              } // end timer check
            } // end screenType

            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdate) {
                let animDelay = timeSensor.utc % 1000;
                let animRepeat = 1000;
                normal_timerUpdate = timer.createTimer(animDelay, animRepeat, function (option) {
                  time_update(false, false);
                }); // end timer
              } // end timer check
            } // end screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSec) {
                normal_timerUpdateSec = timer.createTimer(0, 1000, function (option) {
                  time_update_sec();
                }); // end timer
              } // end timer check
            } // end screenType
          },
          pause_call: function () {
            if (normal_timerTextUpdate) {
              timer.stopTimer(normal_timerTextUpdate);
              normal_timerTextUpdate = undefined;
            }
            if (normal_timerUpdate) {
              timer.stopTimer(normal_timerUpdate);
              normal_timerUpdate = undefined;
            }
            if (normal_timerUpdateSec) {
              timer.stopTimer(normal_timerUpdateSec);
              normal_timerUpdateSec = undefined;
            }
            world_clock.uninit();
          },
        });

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e && e.stack && e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
