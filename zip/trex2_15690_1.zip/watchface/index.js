﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0

	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	
		let colornumber_main = 1
        let totalcolors_main = 2
		let namecolor_main = ' '
		
		//	переход в ночной режим (подставлением полупрозрачной картинки поверх циферблата)
	
		function click_Night() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }
			if ( colornumber_main == 1) namecolor_main = "ДНЕВНОЙ РЕЖИМ"
			if ( colornumber_main == 2) namecolor_main = "НОЧНОЙ РЕЖИМ"
			hmUI.showToast({text: namecolor_main });
			normal_image_img.setProperty(hmUI.prop.SRC, "night_" + parseInt(colornumber_main) + ".png");
			vibro(28);
		}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_pai_linear_scale = ''
        let normal_pai_weekly_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_analog_clock_pro_second_cover_pointer_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_image_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_freeTraining_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: lcddisplaycapssskcyrillic.ttf; FontSize: 23; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 452,
              y: 452,
              w: 27,
              h: 27,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 60,
              y: 308,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 56,
              y: 166,
              week_en: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_tc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_sc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 44,
              month_startY: 255,
              month_sc_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
              month_tc_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
              month_en_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 65,
              day_startY: 203,
              day_sc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_tc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_en_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_pai_linear_scale.setAlpha(165);
            };

            // normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 108,
              // start_y: 101,
              // color: 0xFF000000,
              // lenght: 65,
              // line_width: 12,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 165,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 69,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 26,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0077.png',
              unit_tc: '0077.png',
              unit_en: '0077.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 120,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: '0080.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_calorie_linear_scale.setAlpha(165);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 283,
              // start_y: 102,
              // color: 0xFF000000,
              // lenght: 67,
              // line_width: 12,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 165,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 69,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_battery_linear_scale.setAlpha(165);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 177,
              // start_y: 279,
              // color: 0xFF000000,
              // lenght: 146,
              // line_width: 14,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 165,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 271,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0077.png',
              unit_tc: '0077.png',
              unit_en: '0077.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 68,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 251,
              y: 52,
              image_array: ["hr1.png","hr2.png","hr3.png","hr4.png","hr5.png","hr6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 370,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              invalid_image: '0070.png',
              dot_image: '0050.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 360,
              y: 306,
              image_array: ["WD_1_N.png","WD_2_NE.png","WD_3_E.png","WD_4_SE.png","WD_5_S.png","WD_6_SW.png","WD_7_W.png","WD_8_NW.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 180,
              y: 400,
              w: 101,
              h: 28,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 294,
              y: 331,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 302,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0065.png',
              unit_tc: '0065.png',
              unit_en: '0065.png',
              imperial_unit_sc: '0066.png',
              imperial_unit_tc: '0066.png',
              imperial_unit_en: '0066.png',
              negative_image: '0069.png',
              invalid_image: '0070.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 192,
                y: 302,
                font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
                padding: false,
                h_space: 1,
                unit_sc: '0066.png',
                unit_tc: '0066.png',
                unit_en: '0066.png',
                imperial_unit_sc: '0065.png',
                imperial_unit_tc: '0065.png',
                imperial_unit_en: '0065.png',
                negative_image: '0069.png',
                invalid_image: '0070.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 336,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0077.png',
              unit_tc: '0077.png',
              unit_en: '0077.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 335,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_step_linear_scale.setAlpha(165);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 173,
              // start_y: 162,
              // color: 0xFF000000,
              // lenght: 149,
              // line_width: 13,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 165,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 164,
              y: 118,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sek4.png',
              // center_x: 227,
              // center_y: 227,
              // x: 128,
              // y: 226,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'BG1.png',
              // cover_x: 0,
              // cover_y: 0,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 128,
              pos_y: 227 - 226,
              center_x: 227,
              center_y: 227,
              src: 'sek4.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 127,
              y: 296,
              src: '0071.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 119,
              y: 119,
              src: '0072.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 67,
              y: 102,
              src: '0074.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 5,
              y: 215,
              src: '0073.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 319,
              am_y: 148,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 319,
              pm_y: 148,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 173,
              hour_startY: 183,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 286,
              minute_startY: 183,
              minute_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 374,
              second_startY: 203,
              second_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 179,
              src: '0011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'night_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 56,
              y: 166,
              week_en: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_tc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_sc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 44,
              month_startY: 255,
              month_sc_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
              month_tc_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
              month_en_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 65,
              day_startY: 203,
              day_sc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_tc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_en_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            idle_battery_linear_scale.setAlpha(165);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 177,
              // start_y: 279,
              // color: 0xFF000000,
              // lenght: 146,
              // line_width: 14,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 165,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 271,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0077.png',
              unit_tc: '0077.png',
              unit_en: '0077.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 319,
              am_y: 148,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 319,
              pm_y: 148,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 173,
              hour_startY: 183,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 286,
              minute_startY: 183,
              minute_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 374,
              second_startY: 203,
              second_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 179,
              src: '0011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'night_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 0,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 162,
              y: 117,
              w: 208,
              h: 63,
              src: '0012.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 57,
              w: 95,
              h: 57,
              src: '0012.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 102,
              y: 64,
              w: 72,
              h: 49,
              src: '0012.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 174,
              y: 269,
              w: 236,
              h: 28,
              src: '0012.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 169,
              y: 370,
              w: 95,
              h: 32,
              src: '0012.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 54,
              y: 309,
              w: 62,
              h: 56,
              src: '0012.png',
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 167,
              y: 299,
              w: 107,
              h: 33,
              src: '0012.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 196,
              y: 16,
              w: 60,
              h: 37,
              src: '0012.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 208,
              y: 336,
              w: 57,
              h: 29,
              src: '0012.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 375,
              y: 195,
              w: 53,
              h: 65,
              src: '0012.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 201,
              w: 42,
              h: 50,
              src: '0012.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_freeTraining_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 281,
              y: 58,
              w: 85,
              h: 56,
              src: '0012.png',
              type: hmUI.data_type.FREE_TRAINING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 179,
              y: 188,
              w: 189,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0012.png',
              normal_src: '0012.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 46,
              y: 167,
              w: 91,
              h: 121,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0012.png',
              normal_src: '0012.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 284,
              y: 320,
              w: 91,
              h: 81,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0012.png',
              normal_src: '0012.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_ls_normal_pai = 1 - progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_linear_scale
                  // initial parameters
                  let start_x_normal_pai = 173;
                  let start_y_normal_pai = 101;
                  let lenght_ls_normal_pai = -65;
                  let line_width_ls_normal_pai = 12;
                  let color_ls_normal_pai = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_pai_draw = start_x_normal_pai;
                  let start_y_normal_pai_draw = start_y_normal_pai;
                  lenght_ls_normal_pai = lenght_ls_normal_pai * progress_ls_normal_pai;
                  let lenght_ls_normal_pai_draw = lenght_ls_normal_pai;
                  let line_width_ls_normal_pai_draw = line_width_ls_normal_pai;
                  if (lenght_ls_normal_pai < 0){
                    lenght_ls_normal_pai_draw = -lenght_ls_normal_pai;
                    start_x_normal_pai_draw = start_x_normal_pai - lenght_ls_normal_pai_draw;
                  };
                  
                  normal_pai_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_pai_draw,
                    y: start_y_normal_pai_draw,
                    w: lenght_ls_normal_pai_draw,
                    h: line_width_ls_normal_pai_draw,
                    color: color_ls_normal_pai,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = 1 - progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 350;
                  let start_y_normal_calorie = 102;
                  let lenght_ls_normal_calorie = -67;
                  let line_width_ls_normal_calorie = 12;
                  let color_ls_normal_calorie = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 323;
                  let start_y_normal_battery = 279;
                  let lenght_ls_normal_battery = -146;
                  let line_width_ls_normal_battery = 14;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 322;
                  let start_y_normal_step = 162;
                  let lenght_ls_normal_step = -149;
                  let line_width_ls_normal_step = 13;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 323;
                  let start_y_idle_battery = 279;
                  let lenght_ls_idle_battery = -146;
                  let line_width_ls_idle_battery = 14;
                  let color_ls_idle_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}