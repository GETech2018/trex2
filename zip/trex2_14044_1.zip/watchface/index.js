﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
// Select background (SETTINGS)

  let total_backgrounds = 10
  let background_prefix = "01_bg_"

// Select hands (SETTINGS)

  let total_hands_types = 6
  let hands_hour_prefix = "02_hh_"
  let hands_minute_prefix = "02_mm_"
  // let hands_second_prefix = "02_ss_"
  
// Alternate Elements (SETTINGS)
        
  let top_center_items_count = 2
  let top_left_items_count = 2
  let top_right_items_count = 2
  let middle_left_items_count = 2
  let middle_right_items_count = 2
  let bottom_left_items_count = 2
  let bottom_right_items_count = 2  
   
///////////////////////////// NOT EDIT BELOW /////////////////////////// 

//////////////  Select background (SCRIPTS) ////////////// 

    let background_number = 1

    function up_background() {
    
        if(background_number >= total_backgrounds) {
            background_number = 1;
        }
        else {
            background_number = background_number + 1;
        }

        change_style();
    };
    
    function down_background() {
        
        if(background_number <= 1) {
            background_number = total_backgrounds;
        }
        else {
            background_number = background_number - 1;
        }
                      
        change_style();   
        
    };

    function change_style() {
       
          normal_background_bg_img.setProperty(hmUI.prop.SRC, background_prefix + parseInt(background_number) + ".png");
          normal_stand_icon_img.setProperty(hmUI.prop.SRC, background_prefix + parseInt(background_number) + ".png");

    };

////////////// Select hands type (SCRIPT) ////////////// 

    let hands_types = 1

    function select_hands() {
    
        if(switch_pos == 2) {

            if(hands_types >= total_hands_types) {
                hands_types = 1;
            }
            else {
                hands_types = hands_types + 1;
            }

            normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, hands_hour_prefix + parseInt(hands_types) + ".png");
            normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, hands_minute_prefix + parseInt(hands_types) + ".png");
            // normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, hands_second_prefix + parseInt(hands_types) + ".png");

        }
        
    };
        
////////////// Analog Watchface OFF / ON (SCRIPT) //////////////

    let switch_pos = 1
    let total_pos = 2

    function off_on_analog() {
            
        if(switch_pos == total_pos) {
            
            switch_pos = 1; // Analog OFF
            
            normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
            
            normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);       
            normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                        
        }
        else {

            switch_pos = switch_pos + 1;
            
            if(switch_pos == 2) { // Analog ON
            
                normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                
                normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                
            }

        }

    };
    
    /////////////  Compass OFF / ON (SCRIPT) //////////////

    let switch_pos_compass = 1
    let total_pos_compass = 2

    function switch_compass() {
    
        if(switch_pos == 1) {
          
            if(switch_pos_compass == total_pos_compass) {
                switch_pos_compass = 1; // Compass OFF

                   if (compass) {
                   
                      if (top_center_items_index == 1) normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                      if (top_center_items_index == 2) normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                  
                      normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
                       
                      normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                      compass.stop();
                   }        
                                
            }
            else {
                switch_pos_compass = switch_pos_compass + 1; // Compass ON
                if(switch_pos_compass == 2) {
                         
                    if (compass) {
                
                      if (top_center_items_index == 1) normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false); 
                      if (top_center_items_index == 2) normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                   
                      normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
                    
                      compass.start();
                    
                    }

                }
            }
            
        }
          
    };
 
//////////////  Alternate Elements (SCRIPTS) //////////////

    let top_center_items_index = 1

  function click_top_center_dial() {
  
       if(switch_pos == 1) {
       
            top_center_items_index++;
            if(top_center_items_index > top_center_items_count) top_center_items_index = 1;
             
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 1);
            if (switch_pos_compass == 1) normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 1);
            normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 1);
            normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 1);
             
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 2);
            if (switch_pos_compass == 1) normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 2);
            normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 2);
            normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 2);
          
        }       
  
  };
 
    let top_left_items_index = 1
 
  function click_top_left_dial() {
  
        if(switch_pos == 1) {
  
            top_left_items_index++;
            if(top_left_items_index > top_left_items_count) top_left_items_index = 1;

            normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 1);
            normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 1);
            normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 1);

            normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 2);
            normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 2);
            normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 2); 

        }
    
  };
  
    let top_right_items_index = 1

  function click_top_right_dial() {
  
        if(switch_pos == 1) {
  
            top_right_items_index++;
            if(top_right_items_index > top_right_items_count) top_right_items_index = 1;

            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 1);
            normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 1);
            normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 1);

            normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 2);
            normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 2);
            normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 2);    

        }

  }; 
   
    let middle_left_items_index = 1

  function click_middle_left_dial() {
  
        if(switch_pos == 1) {
  
            middle_left_items_index++;
            if(middle_left_items_index > middle_left_items_count) middle_left_items_index = 1;
         
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, middle_left_items_index == 1);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, middle_left_items_index == 1);
            
            normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, middle_left_items_index == 2);
            normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, middle_left_items_index == 2);

        }

  };

    let middle_right_items_index = 1

  function click_middle_right_dial() {
  
        if(switch_pos == 1) {
  
            middle_right_items_index++;
            if(middle_right_items_index > middle_right_items_count) middle_right_items_index = 1;
            
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, middle_right_items_index == 1);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, middle_right_items_index == 1);
            
            normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, middle_right_items_index == 2);
            normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, middle_right_items_index == 2);

        }
           
  }; 
  
    let bottom_left_items_index = 1

  function click_bottom_left_dial() {
  
        if(switch_pos == 1) {
  
            bottom_left_items_index++;
            if(bottom_left_items_index > bottom_left_items_count) bottom_left_items_index = 1;
            
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 1);
            normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 1);    
                
            normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 2);
            normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 2);

        }

  };
  
    let bottom_right_items_index = 1

  function click_bottom_right_dial() {
  
        if(switch_pos == 1) {
  
            bottom_right_items_index++;
            if(bottom_right_items_index > bottom_right_items_count) bottom_right_items_index = 1;

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 1);
            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 1);
            
            normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 2);
            normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 2);

        }

  }; 
        
/////////////////////////////////////////////////////////////////////////////////////////////////

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_fat_burning_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_moon_icon_img = ''
        let normal_moon_high_text_img = ''
        let normal_moon_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_uvi_text_text_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_stand_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_sun_icon_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_pai_icon_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_aod_fg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 397,
              src: '10_battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 399,
              font_array: ["05_S_B_0.png","05_S_B_1.png","05_S_B_2.png","05_S_B_3.png","05_S_B_4.png","05_S_B_5.png","05_S_B_6.png","05_S_B_7.png","05_S_B_8.png","05_S_B_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent.png',
              unit_tc: '10_percent.png',
              unit_en: '10_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: '00_compass_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: '00_compass_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 34,
              font_array: ["05_S_B_0.png","05_S_B_1.png","05_S_B_2.png","05_S_B_3.png","05_S_B_4.png","05_S_B_5.png","05_S_B_6.png","05_S_B_7.png","05_S_B_8.png","05_S_B_9.png"],
              padding: true,
              h_space: 1,
              unit_sc: '10_degree_B.png',
              unit_tc: '10_degree_B.png',
              unit_en: '10_degree_B.png',
              negative_image: '10_null_B.png',
              align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 352,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 238,
              y: 345,
              src: '10_fat_burn.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 352,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 352,
              src: '10_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 352,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_L.png',
              unit_tc: '10_percent_L.png',
              unit_en: '10_percent_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 95,
              y: 352,
              src: '10_SPO2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 352,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 93,
              y: 352,
              src: '10_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 180,
              // end_angle: 541,
              // radius: 229,
              // line_width: 5,
              // line_cap: Flat,
              // color: 0xFFC9C9C9,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 180,
              end_angle: 541,
              radius: 227,
              line_width: 5,
              corner_flag: 3,
              color: 0xFFC9C9C9,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 300,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 64,
              y: 300,
              src: '10_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 300,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 300,
              src: '10_altitude.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 300,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 64,
              y: 300,
              src: '10_baro.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 300,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '10_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 300,
              src: '10_dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 343,
              am_y: 202,
              am_sc_path: '10_AM.png',
              am_en_path: '10_AM.png',
              pm_x: 343,
              pm_y: 202,
              pm_sc_path: '10_PM.png',
              pm_en_path: '10_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 42,
              hour_startY: 178,
              hour_array: ["03_hhmm_0.png","03_hhmm_1.png","03_hhmm_2.png","03_hhmm_3.png","03_hhmm_4.png","03_hhmm_5.png","03_hhmm_6.png","03_hhmm_7.png","03_hhmm_8.png","03_hhmm_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: '10_separator_hhmm.png',
              hour_unit_tc: '10_separator_hhmm.png',
              hour_unit_en: '10_separator_hhmm.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 127,
              minute_startY: 195,
              minute_array: ["03_hhmm_0.png","03_hhmm_1.png","03_hhmm_2.png","03_hhmm_3.png","03_hhmm_4.png","03_hhmm_5.png","03_hhmm_6.png","03_hhmm_7.png","03_hhmm_8.png","03_hhmm_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: '10_separator_ss.png',
              minute_unit_tc: '10_separator_ss.png',
              minute_unit_en: '10_separator_ss.png',
              minute_align: hmUI.align.CENTER_H,

              second_startX: 348,
              second_startY: 232,
              second_array: ["03_ss_0.png","03_ss_1.png","03_ss_2.png","03_ss_3.png","03_ss_4.png","03_ss_5.png","03_ss_6.png","03_ss_7.png","03_ss_8.png","03_ss_9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 394,
              y: 177,
              src: '10_LOCK_ON.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 367,
              y: 177,
              src: '10_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 341,
              y: 177,
              src: '10_AL_ON.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 134,
              y: 93,
              src: '10_wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 73,
              y: 104,
              image_array: ["11_wind_1.png","11_wind_2.png","11_wind_3.png","11_wind_4.png","11_wind_5.png","11_wind_6.png","11_wind_7.png","11_wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 126,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 66,
              y: 105,
              week_en: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              week_tc: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              week_sc: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 120,
              day_startY: 126,
              day_sc_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_tc_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_en_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 114,
              month_startY: 95,
              month_sc_array: ["07_month_01.png","07_month_02.png","07_month_03.png","07_month_04.png","07_month_05.png","07_month_06.png","07_month_07.png","07_month_08.png","07_month_09.png","07_month_10.png","07_month_11.png","07_month_12.png"],
              month_tc_array: ["07_month_01.png","07_month_02.png","07_month_03.png","07_month_04.png","07_month_05.png","07_month_06.png","07_month_07.png","07_month_08.png","07_month_09.png","07_month_10.png","07_month_11.png","07_month_12.png"],
              month_en_array: ["07_month_01.png","07_month_02.png","07_month_03.png","07_month_04.png","07_month_05.png","07_month_06.png","07_month_07.png","07_month_08.png","07_month_09.png","07_month_10.png","07_month_11.png","07_month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 204,
              y: 33,
              src: '10_moon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 60,
              font_array: ["06_XS_0.png","06_XS_1.png","06_XS_2.png","06_XS_3.png","06_XS_4.png","06_XS_5.png","06_XS_6.png","06_XS_7.png","06_XS_8.png","06_XS_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null.png',
              dot_image: '10_separator.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 60,
              font_array: ["06_XS_0.png","06_XS_1.png","06_XS_2.png","06_XS_3.png","06_XS_4.png","06_XS_5.png","06_XS_6.png","06_XS_7.png","06_XS_8.png","06_XS_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null.png',
              dot_image: '10_separator.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 80,
              image_array: ["12_moon_01.png","12_moon_02.png","12_moon_03.png","12_moon_04.png","12_moon_05.png","12_moon_06.png","12_moon_07.png","12_moon_08.png","12_moon_09.png","12_moon_10.png","12_moon_11.png","12_moon_12.png","12_moon_13.png","12_moon_14.png","12_moon_15.png","12_moon_16.png","12_moon_17.png","12_moon_18.png","12_moon_19.png","12_moon_20.png","12_moon_21.png","12_moon_22.png","12_moon_23.png","12_moon_24.png","12_moon_25.png","12_moon_26.png","12_moon_27.png","12_moon_28.png","12_moon_29.png","12_moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 134,
              font_array: ["05_S_B_0.png","05_S_B_1.png","05_S_B_2.png","05_S_B_3.png","05_S_B_4.png","05_S_B_5.png","05_S_B_6.png","05_S_B_7.png","05_S_B_8.png","05_S_B_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_B.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 277,
              y: 93,
              src: '10_hum_uv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 134,
              font_array: ["05_S_B_0.png","05_S_B_1.png","05_S_B_2.png","05_S_B_3.png","05_S_B_4.png","05_S_B_5.png","05_S_B_6.png","05_S_B_7.png","05_S_B_8.png","05_S_B_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent.png',
              unit_tc: '10_percent.png',
              unit_en: '10_percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 329,
              y: 134,
              font_array: ["05_S_B_0.png","05_S_B_1.png","05_S_B_2.png","05_S_B_3.png","05_S_B_4.png","05_S_B_5.png","05_S_B_6.png","05_S_B_7.png","05_S_B_8.png","05_S_B_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_B.png',
              unit_tc: '10_degree_B.png',
              unit_en: '10_degree_B.png',
              negative_image: '10_dash_small.png',
              invalid_image: '10_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 134,
              font_array: ["05_S_B_0.png","05_S_B_1.png","05_S_B_2.png","05_S_B_3.png","05_S_B_4.png","05_S_B_5.png","05_S_B_6.png","05_S_B_7.png","05_S_B_8.png","05_S_B_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_B.png',
              unit_tc: '10_degree_B.png',
              unit_en: '10_degree_B.png',
              negative_image: '10_dash_small.png',
              invalid_image: '10_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 95,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree.png',
              unit_tc: '10_degree.png',
              unit_en: '10_degree.png',
              negative_image: '10_dash.png',
              invalid_image: '10_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 80,
              image_array: ["09_weather_01.png","09_weather_02.png","09_weather_03.png","09_weather_04.png","09_weather_05.png","09_weather_06.png","09_weather_07.png","09_weather_08.png","09_weather_09.png","09_weather_10.png","09_weather_11.png","09_weather_12.png","09_weather_13.png","09_weather_14.png","09_weather_15.png","09_weather_16.png","09_weather_17.png","09_weather_18.png","09_weather_19.png","09_weather_20.png","09_weather_21.png","09_weather_22.png","09_weather_23.png","09_weather_24.png","09_weather_25.png","09_weather_26.png","09_weather_27.png","09_weather_28.png","09_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 204,
              y: 33,
              src: '10_sun.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 60,
              font_array: ["06_XS_0.png","06_XS_1.png","06_XS_2.png","06_XS_3.png","06_XS_4.png","06_XS_5.png","06_XS_6.png","06_XS_7.png","06_XS_8.png","06_XS_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null.png',
              dot_image: '10_separator.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 60,
              font_array: ["06_XS_0.png","06_XS_1.png","06_XS_2.png","06_XS_3.png","06_XS_4.png","06_XS_5.png","06_XS_6.png","06_XS_7.png","06_XS_8.png","06_XS_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null.png',
              dot_image: '10_separator.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '01_bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_analog_fg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(UpdateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_hh_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 15,
              // y: 133,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 15,
              pos_y: 227 - 133,
              center_x: 227,
              center_y: 227,
              src: '02_hh_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_mm_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 15,
              // y: 183,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 15,
              pos_y: 227 - 183,
              center_x: 227,
              center_y: 227,
              src: '02_mm_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_ss.png',
              // center_x: 227,
              // center_y: 227,
              // x: 6,
              // y: 203,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 6,
              pos_y: 227 - 203,
              center_x: 227,
              center_y: 227,
              src: '02_ss.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_aod_fg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 397,
              src: '10_battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 399,
              font_array: ["05_S_B_0.png","05_S_B_1.png","05_S_B_2.png","05_S_B_3.png","05_S_B_4.png","05_S_B_5.png","05_S_B_6.png","05_S_B_7.png","05_S_B_8.png","05_S_B_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent.png',
              unit_tc: '10_percent.png',
              unit_en: '10_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 352,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 352,
              src: '10_bpm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 352,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 93,
              y: 352,
              src: '10_cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 300,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 64,
              y: 300,
              src: '10_steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 300,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '10_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 300,
              src: '10_dist.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 343,
              am_y: 202,
              am_sc_path: '10_AM.png',
              am_en_path: '10_AM.png',
              pm_x: 343,
              pm_y: 202,
              pm_sc_path: '10_PM.png',
              pm_en_path: '10_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 42,
              hour_startY: 178,
              hour_array: ["03_hhmm_0.png","03_hhmm_1.png","03_hhmm_2.png","03_hhmm_3.png","03_hhmm_4.png","03_hhmm_5.png","03_hhmm_6.png","03_hhmm_7.png","03_hhmm_8.png","03_hhmm_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: '10_separator_hhmm.png',
              hour_unit_tc: '10_separator_hhmm.png',
              hour_unit_en: '10_separator_hhmm.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 127,
              minute_startY: 195,
              minute_array: ["03_hhmm_0.png","03_hhmm_1.png","03_hhmm_2.png","03_hhmm_3.png","03_hhmm_4.png","03_hhmm_5.png","03_hhmm_6.png","03_hhmm_7.png","03_hhmm_8.png","03_hhmm_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: '10_separator_ss.png',
              minute_unit_tc: '10_separator_ss.png',
              minute_unit_en: '10_separator_ss.png',
              minute_align: hmUI.align.CENTER_H,

              second_startX: 348,
              second_startY: 232,
              second_array: ["03_ss_0.png","03_ss_1.png","03_ss_2.png","03_ss_3.png","03_ss_4.png","03_ss_5.png","03_ss_6.png","03_ss_7.png","03_ss_8.png","03_ss_9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 394,
              y: 177,
              src: '10_LOCK_ON.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 367,
              y: 177,
              src: '10_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 341,
              y: 177,
              src: '10_AL_ON.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 66,
              y: 105,
              week_en: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              week_tc: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              week_sc: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 120,
              day_startY: 126,
              day_sc_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_tc_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_en_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 114,
              month_startY: 95,
              month_sc_array: ["07_month_01.png","07_month_02.png","07_month_03.png","07_month_04.png","07_month_05.png","07_month_06.png","07_month_07.png","07_month_08.png","07_month_09.png","07_month_10.png","07_month_11.png","07_month_12.png"],
              month_tc_array: ["07_month_01.png","07_month_02.png","07_month_03.png","07_month_04.png","07_month_05.png","07_month_06.png","07_month_07.png","07_month_08.png","07_month_09.png","07_month_10.png","07_month_11.png","07_month_12.png"],
              month_en_array: ["07_month_01.png","07_month_02.png","07_month_03.png","07_month_04.png","07_month_05.png","07_month_06.png","07_month_07.png","07_month_08.png","07_month_09.png","07_month_10.png","07_month_11.png","07_month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 329,
              y: 134,
              font_array: ["05_S_B_0.png","05_S_B_1.png","05_S_B_2.png","05_S_B_3.png","05_S_B_4.png","05_S_B_5.png","05_S_B_6.png","05_S_B_7.png","05_S_B_8.png","05_S_B_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_B.png',
              unit_tc: '10_degree_B.png',
              unit_en: '10_degree_B.png',
              negative_image: '10_dash_small.png',
              invalid_image: '10_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 134,
              font_array: ["05_S_B_0.png","05_S_B_1.png","05_S_B_2.png","05_S_B_3.png","05_S_B_4.png","05_S_B_5.png","05_S_B_6.png","05_S_B_7.png","05_S_B_8.png","05_S_B_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_B.png',
              unit_tc: '10_degree_B.png',
              unit_en: '10_degree_B.png',
              negative_image: '10_dash_small.png',
              invalid_image: '10_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 95,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree.png',
              unit_tc: '10_degree.png',
              unit_en: '10_degree.png',
              negative_image: '10_dash.png',
              invalid_image: '10_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 80,
              image_array: ["09_weather_01.png","09_weather_02.png","09_weather_03.png","09_weather_04.png","09_weather_05.png","09_weather_06.png","09_weather_07.png","09_weather_08.png","09_weather_09.png","09_weather_10.png","09_weather_11.png","09_weather_12.png","09_weather_13.png","09_weather_14.png","09_weather_15.png","09_weather_16.png","09_weather_17.png","09_weather_18.png","09_weather_19.png","09_weather_20.png","09_weather_21.png","09_weather_22.png","09_weather_23.png","09_weather_24.png","09_weather_25.png","09_weather_26.png","09_weather_27.png","09_weather_28.png","09_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 204,
              y: 33,
              src: '10_sun.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 60,
              font_array: ["06_XS_0.png","06_XS_1.png","06_XS_2.png","06_XS_3.png","06_XS_4.png","06_XS_5.png","06_XS_6.png","06_XS_7.png","06_XS_8.png","06_XS_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null.png',
              dot_image: '10_separator.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 60,
              font_array: ["06_XS_0.png","06_XS_1.png","06_XS_2.png","06_XS_3.png","06_XS_4.png","06_XS_5.png","06_XS_6.png","06_XS_7.png","06_XS_8.png","06_XS_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null.png',
              dot_image: '10_separator.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '01_aod_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 5,
              w: 80,
              h: 65,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                switch_compass()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 182,
              y: 182,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                off_on_analog()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 389,
              w: 80,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                select_hands()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 364,
              y: 187,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                up_background()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 281,
              y: 90,
              w: 100,
              h: 70,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_top_right_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 72,
              y: 90,
              w: 100,
              h: 70,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_top_left_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 80,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_top_center_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 240,
              y: 343,
              w: 120,
              h: 45,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_bottom_right_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 240,
              y: 293,
              w: 150,
              h: 45,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_middle_right_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 343,
              w: 120,
              h: 45,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_bottom_left_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 65,
              y: 293,
              w: 150,
              h: 45,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_middle_left_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 187,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                down_background()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

////////////  Initial visibility of elements //////////// 

    let cc = 0

    if (cc == 0 ){
   
// By default Analog OFF  
     
    normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);       
    normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    
// By default compass text OFF 
    
    normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
       
// Selectable TOP CENTER
       
    normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
    normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
      
    normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
    normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, false);

// Selectable TOP LEFT

    normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
    normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);

    normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false); 
        
// Selectable TOP RIGHT

    normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);

    normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false); 

// Selectable MIDDLE LEFT

    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
    
    normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

// Selectable MIDDLE RIGHT

    normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
    
    normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);

// Selectable BOTTOM LEFT

    normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);    
        
    normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

// Selectable BOTTOM RIGHT

    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
    
    normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

    cc = 1;

    };

/////////////////////////////////////////////////////////////////////////////////////////////////

            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

                }

              }); // Listener end              normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);              //normal_compass_text_img.setProperty(hmUI.prop.TEXT, '000');              compass.stop();

            };
            //end of ignored block

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 180,
                      end_angle: 541,
                      radius: 227,
                      line_width: 5,
                      corner_flag: 3,
                      color: 0xFFC9C9C9,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if(switch_pos_compass == 2) {if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start()};
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if(switch_pos_compass == 2) {if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start()};
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}