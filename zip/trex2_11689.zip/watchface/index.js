/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_battery_image_progress_img_level2 = '';
		let normal_background_bg_img3 = '';
		let normal_date_img_date_monthday_high5 = '';
		let normal_date_img_date_monthday_high5_array = ['0009.png','0010.png','0011.png','0012.png','0013.png','0014.png','0015.png','0016.png','0017.png','0018.png'];
		let normal_date_img_date_monthday_low6 = '';
		let normal_date_img_date_monthday_low6_array = ['0009.png','0010.png','0011.png','0012.png','0013.png','0014.png','0015.png','0016.png','0017.png','0018.png'];
		let normal_date_img_date_week_img7 = '';
		let normal_alarm_status9 = '';
		let normal_analog_clock_time_pointer_hour11 = '';
		let normal_analog_clock_time_pointer_minute12 = '';
		let normal_analog_clock_time_pointer_second13 = '';
		let normal_alarm_jumpable_img_click16 = '';
		let normal_weather_jumpable_img_click17 = '';
		let normal_heart_jumpable_img_click18 = '';
		let normal_countdown_jumpable_img_click19 = '';
		let idle_background_bg_img21 = '';
		let idle_analog_clock_time_pointer_hour23 = '';
		let idle_analog_clock_time_pointer_minute24 = '';
		let idle_analog_clock_time_pointer_second25 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_image_progress_img_level2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 193,
					y: 330,
					image_array: ["0003.png","0004.png","0005.png","0006.png","0007.png"],
					image_length: 5,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0008.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_monthday_high5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 231,
					y: 165,
					w: 231,
					h: 165,
					src: '0018.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_img_date_monthday_low6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 298,
					y: 165,
					w: 298,
					h: 165,
					src: '0018.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_img_date_week_img7 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 243,
					y: 235,
					week_en: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
					week_tc: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
					week_sc: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status9 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 134,
					y: 217,
					w: 67,
					h: 19,
					type: hmUI.system_status.CLOCK,
					src: '0026.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_hour11 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0027.png',
					hour_centerX: 227,
					hour_centerY: 227,
					hour_posX: 16,
					hour_posY: 146,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_minute12 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0028.png',
					minute_centerX: 227,
					minute_centerY: 228,
					minute_posX: 15,
					minute_posY: 188,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_second13 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0029.png',
					second_centerX: 227,
					second_centerY: 228,
					second_posX: 9,
					second_posY: 205,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_jumpable_img_click16 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 92,
					y: 177,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_jumpable_img_click17 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 177,
					y: 55,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_jumpable_img_click18 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 177,
					y: 310,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_jumpable_img_click19 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 263,
					y: 177,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_background_bg_img21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0030.png',
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_hour23 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0031.png',
					hour_centerX: 227,
					hour_centerY: 227,
					hour_posX: 16,
					hour_posY: 146,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_minute24 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0032.png',
					minute_centerX: 227,
					minute_centerY: 227,
					minute_posX: 15,
					minute_posY: 188,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_analog_clock_time_pointer_second25 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0033.png',
					second_centerX: 227,
					second_centerY: 227,
					second_posX: 9,
					second_posY: 205,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateImageCombos();
				});

				function updateImageCombos() {
					normal_date_img_date_monthday_high5.setProperty(hmUI.prop.MORE, {
						src: normal_date_img_date_monthday_high5_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					normal_date_img_date_monthday_low6.setProperty(hmUI.prop.MORE, {
						src: normal_date_img_date_monthday_low6_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
				};

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateImageCombos();

					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}