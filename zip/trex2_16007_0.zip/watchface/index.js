﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0

		
		let night_var = 1
        let night_all = 2
		let name_text = ' '
		
	
		let color_c = 1
		let color_digt = 1
        let all_digt = 7
		let namecolor_digt = ' '
		
		

	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	

		


//	переход в ночной режим (подставлением полупрозрачной картинки поверх циферблата)
		

			
		function click_Night() {
            if(night_var>=night_all) {
            night_var=1;
                }
            else {
                night_var=night_var+1;
            }
			if ( night_var == 1)    name_text = "DAYTIME MODE";  
			if ( night_var == 2) 	name_text = "NIGHT MODE" ;  
			
			hmUI.showToast({text: name_text });
			image_top_img.setProperty(hmUI.prop.SRC, "night_" + parseInt(night_var) + ".png");
			vibro(28);
		}
		
//	конец перехода в ночной режим 


//  изменение цвета
  

	function click_DIGT() {
            if(color_digt>=all_digt) {
            color_digt=1;
                }
            else { 
			color_digt=color_digt+1;   
			}
		
            if(color_digt  == 7) {
            color_c=color_digt;
                }	
			else { 
			color_c=1;   
			}				

		normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.MORE, {
              second_path: parseInt(color_digt) + '_sek.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 126,
              second_posY: 236,
              fresh_frequency: 17,
              fresh_freqency: 17,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
		normal_temperature_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_BG0.png");	
		normal_image_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_top.png");
		normal_background_bg_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_BG.png");	
		
    	normal_heart_rate_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_alarm_off.png");
		normal_system_lock_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_lock.png");	
        normal_calorie_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_lock_off.png");	
		normal_heart_rate_text_separator_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_hart.png");
		normal_system_disconnect_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_BT_off.png");	
        normal_step_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_BT.png");	
		


	normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 122,
              y: 228,
              src: parseInt(color_digt) + '_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
			
	normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 194,
              y: 326,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_digt) + '_int.png',
              unit_tc: parseInt(color_digt) + '_int.png',
              unit_en: parseInt(color_digt) + '_int.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			
	
/////////////////////////////////////////////////////
			
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: 58,
              hour_startY: 185,
              hour_array: [parseInt(color_digt) + "_001.png",parseInt(color_digt) + "_002.png",parseInt(color_digt) + "_003.png",parseInt(color_digt) + "_004.png",parseInt(color_digt) + "_005.png",parseInt(color_digt) + "_006.png",parseInt(color_digt) + "_007.png",parseInt(color_digt) + "_008.png",parseInt(color_digt) + "_009.png",parseInt(color_digt) + "_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 166,
              minute_startY: 185,
              minute_array: [parseInt(color_digt) + "_001.png",parseInt(color_digt) + "_002.png",parseInt(color_digt) + "_003.png",parseInt(color_digt) + "_004.png",parseInt(color_digt) + "_005.png",parseInt(color_digt) + "_006.png",parseInt(color_digt) + "_007.png",parseInt(color_digt) + "_008.png",parseInt(color_digt) + "_009.png",parseInt(color_digt) + "_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
	
	
    normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_011.png");	

	normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: parseInt(color_digt) + '_am.png',
              am_en_path: parseInt(color_digt) + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: parseInt(color_digt) + '_pm.png',
              pm_en_path: parseInt(color_digt) + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
			
			
	normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 224,
              y: 128,
              week_en: [parseInt(color_digt) + "_023.png",parseInt(color_digt) + "_024.png",parseInt(color_digt) + "_025.png",parseInt(color_digt) + "_026.png",parseInt(color_digt) + "_027.png",parseInt(color_digt) + "_028.png",parseInt(color_digt) + "_029.png"],
              week_tc: [parseInt(color_digt) + "_023.png",parseInt(color_digt) + "_024.png",parseInt(color_digt) + "_025.png",parseInt(color_digt) + "_026.png",parseInt(color_digt) + "_027.png",parseInt(color_digt) + "_028.png",parseInt(color_digt) + "_029.png"],
              week_sc: [parseInt(color_digt) + "_023.png",parseInt(color_digt) + "_024.png",parseInt(color_digt) + "_025.png",parseInt(color_digt) + "_026.png",parseInt(color_digt) + "_027.png",parseInt(color_digt) + "_028.png",parseInt(color_digt) + "_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

    normal_date_img_date_year.setProperty(hmUI.prop.MORE, {
              year_startX: 325,
              year_startY: 88,
              year_sc_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              year_tc_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              year_en_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

    normal_date_img_date_month.setProperty(hmUI.prop.MORE, {
              month_startX: 277,
              month_startY: 88,
              month_sc_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              month_tc_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              month_en_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 230,
              day_startY: 88,
              day_sc_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              day_tc_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              day_en_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
///////////////////////////////////////////////////////	
	


        normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 200,
              y: 373,
              font_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
			
		normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 298,
              y: 317,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 77,
              y: 317,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
					
			
/////////////////////////////////////////////////////////			
			
	
		normal_moon_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 208,
              y: 38,
              image_array: [parseInt(color_digt) + "_Moon_01.png",parseInt(color_digt) + "_Moon_02.png",parseInt(color_digt) + "_Moon_03.png",parseInt(color_digt) + "_Moon_04.png",parseInt(color_digt) + "_Moon_05.png",parseInt(color_digt) + "_Moon_06.png",parseInt(color_digt) + "_Moon_07.png",parseInt(color_digt) + "_Moon_08.png",parseInt(color_digt) + "_Moon_09.png",parseInt(color_digt) + "_Moon_10.png",parseInt(color_digt) + "_Moon_11.png",parseInt(color_digt) + "_Moon_12.png",parseInt(color_digt) + "_Moon_13.png",parseInt(color_digt) + "_Moon_14.png",parseInt(color_digt) + "_Moon_15.png",parseInt(color_digt) + "_Moon_16.png",parseInt(color_digt) + "_Moon_17.png",parseInt(color_digt) + "_Moon_18.png",parseInt(color_digt) + "_Moon_19.png",parseInt(color_digt) + "_Moon_20.png",parseInt(color_digt) + "_Moon_21.png",parseInt(color_digt) + "_Moon_22.png",parseInt(color_digt) + "_Moon_23.png",parseInt(color_digt) + "_Moon_24.png",parseInt(color_digt) + "_Moon_25.png",parseInt(color_digt) + "_Moon_26.png",parseInt(color_digt) + "_Moon_27.png",parseInt(color_digt) + "_Moon_28.png",parseInt(color_digt) + "_Moon_29.png",parseInt(color_digt) + "_Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


		
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 68,
              y: 79,
              image_array: [parseInt(color_c) + "_wth00.png",parseInt(color_c) + "_wth01.png",parseInt(color_c) + "_wth02.png",parseInt(color_c) + "_wth03.png",parseInt(color_c) + "_wth04.png",parseInt(color_c) + "_wth05.png",parseInt(color_c) + "_wth06.png",parseInt(color_c) + "_wth07.png",parseInt(color_c) + "_wth08.png",parseInt(color_c) + "_wth09.png",parseInt(color_c) + "_wth10.png",parseInt(color_c) + "_wth11.png",parseInt(color_c) + "_wth12.png",parseInt(color_c) + "_wth13.png",parseInt(color_c) + "_wth14.png",parseInt(color_c) + "_wth15.png",parseInt(color_c) + "_wth16.png",parseInt(color_c) + "_wth17.png",parseInt(color_c) + "_wth18.png",parseInt(color_c) + "_wth19.png",parseInt(color_c) + "_wth20.png",parseInt(color_c) + "_wth21.png",parseInt(color_c) + "_wth22.png",parseInt(color_c) + "_wth23.png",parseInt(color_c) + "_wth24.png",parseInt(color_c) + "_wth25.png",parseInt(color_c) + "_wth26.png",parseInt(color_c) + "_wth27.png",parseInt(color_c) + "_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
				
				
        normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 161,
              y: 97,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_digt) + '_dig.png',
              unit_tc: parseInt(color_digt) + '_dig.png',
              unit_en: parseInt(color_digt) + '_dig.png',
              imperial_unit_sc: parseInt(color_digt) + '_dig.png',
              imperial_unit_tc: parseInt(color_digt) + '_dig.png',
              imperial_unit_en: parseInt(color_digt) + '_dig.png',
              negative_image: parseInt(color_digt) + '_minus.png',
              invalid_image: parseInt(color_digt) + '_eror.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

	

			if ( color_digt == 1) {
			normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);
       	    normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, true);
			normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_8.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_9.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_10.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_11.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_12.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_13.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_14.setProperty(hmUI.prop.VISIBLE, false);	
						}
						
			if ( color_digt == 2) {
			normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
       	    normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, true);
			normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, true);
			normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_8.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_9.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_10.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_11.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_12.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_13.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_14.setProperty(hmUI.prop.VISIBLE, false);
						}
						
			if ( color_digt == 3) {
			normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
       	    normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, true);
			normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, true);
			normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_8.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_9.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_10.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_11.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_12.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_13.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_14.setProperty(hmUI.prop.VISIBLE, false);
						}
						
			if ( color_digt == 4) {
			normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
       	    normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, true);
			normal_frame_animation_8.setProperty(hmUI.prop.VISIBLE, true);
			normal_frame_animation_9.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_10.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_11.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_12.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_13.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_14.setProperty(hmUI.prop.VISIBLE, false);
						}
						
			if ( color_digt == 5) {
			normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
       	    normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_8.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_9.setProperty(hmUI.prop.VISIBLE, true);
			normal_frame_animation_10.setProperty(hmUI.prop.VISIBLE, true);
			normal_frame_animation_11.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_12.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_13.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_14.setProperty(hmUI.prop.VISIBLE, false);
						}
						
			if ( color_digt == 6) {
			normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
       	    normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_8.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_9.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_10.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_11.setProperty(hmUI.prop.VISIBLE, true);
			normal_frame_animation_12.setProperty(hmUI.prop.VISIBLE, true);
			normal_frame_animation_13.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_14.setProperty(hmUI.prop.VISIBLE, false);
						}
						
			if ( color_digt == 7) {
			normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
       	    normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_8.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_9.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_10.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_11.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_12.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_13.setProperty(hmUI.prop.VISIBLE, true);
			normal_frame_animation_14.setProperty(hmUI.prop.VISIBLE, true);
						}



				



			if ( color_digt == 1) 	namecolor_digt = "COLOR BLUE";
			if ( color_digt == 2) 	namecolor_digt = "COLOR EMERALD";
			if ( color_digt == 3)	namecolor_digt = "COLOR GREEN";
			if ( color_digt == 4) 	namecolor_digt = "COLOR YELLOW";
			if ( color_digt == 5)	namecolor_digt = "COLOR ORANGE";
			if ( color_digt == 6)	namecolor_digt = "COLOR RASPBERRY";
			if ( color_digt == 7) 	namecolor_digt = "STEEL COLOR";
			
			hmUI.showToast({text: namecolor_digt });	
				
			
        	vibro(28);

			} 
 
//  конец  изменения цвета цифр




 
 

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_frame_animation_3 = ''
        let normal_frame_animation_4 = ''
        let normal_frame_animation_5 = ''
        let normal_frame_animation_6 = ''
        let normal_frame_animation_7 = ''
        let normal_frame_animation_8 = ''
        let normal_frame_animation_9 = ''
        let normal_frame_animation_10 = ''
        let normal_frame_animation_11 = ''
        let normal_frame_animation_12 = ''
        let normal_frame_animation_13 = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_battery_icon_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1_BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 284,
              y: 163,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "1_a1",
              anim_fps: 15,
              anim_size: 36,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 17,
              y: 136,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "1_a2",
              anim_fps: 15,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_3 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 284,
              y: 163,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "2_a1",
              anim_fps: 15,
              anim_size: 36,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_4 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 17,
              y: 136,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "2_a2",
              anim_fps: 15,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_5 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 284,
              y: 163,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "3_a1",
              anim_fps: 15,
              anim_size: 36,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_6 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 17,
              y: 136,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "3_a2",
              anim_fps: 15,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_7 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 284,
              y: 163,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "4_a1",
              anim_fps: 15,
              anim_size: 36,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_8 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 17,
              y: 136,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "4_a2",
              anim_fps: 15,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_9 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 284,
              y: 163,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "5_a1",
              anim_fps: 15,
              anim_size: 36,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_10 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 17,
              y: 136,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "5_a2",
              anim_fps: 15,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_11 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 284,
              y: 163,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "6_a1",
              anim_fps: 15,
              anim_size: 36,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_12 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 17,
              y: 136,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "6_a2",
              anim_fps: 15,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_13 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 284,
              y: 163,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "7_a1",
              anim_fps: 15,
              anim_size: 36,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
						
            normal_frame_animation_14 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 17,
              y: 136,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "7_a2",
              anim_fps: 15,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 96,
              y: 285,
              src: '1_lock_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img.setAlpha(120);

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 317,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 288,
              src: '1_alarm_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img.setAlpha(120);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 373,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 371,
              src: '1_hart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 38,
              y: 137,
              src: '1_BT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 317,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 96,
              y: 285,
              src: '1_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 38,
              y: 137,
              src: '1_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 122,
              y: 288,
              src: '1_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 228,
              y: 127,
              week_en: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_tc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_sc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 325,
              year_startY: 88,
              year_sc_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              year_tc_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              year_en_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 277,
              month_startY: 88,
              month_sc_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              month_tc_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              month_en_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 230,
              day_startY: 88,
              day_sc_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              day_tc_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              day_en_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 38,
              image_array: ["1_Moon_01.png","1_Moon_02.png","1_Moon_03.png","1_Moon_04.png","1_Moon_05.png","1_Moon_06.png","1_Moon_07.png","1_Moon_08.png","1_Moon_09.png","1_Moon_10.png","1_Moon_11.png","1_Moon_12.png","1_Moon_13.png","1_Moon_14.png","1_Moon_15.png","1_Moon_16.png","1_Moon_17.png","1_Moon_18.png","1_Moon_19.png","1_Moon_20.png","1_Moon_21.png","1_Moon_22.png","1_Moon_23.png","1_Moon_24.png","1_Moon_25.png","1_Moon_26.png","1_Moon_27.png","1_Moon_28.png","1_Moon_29.png","1_Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_battery_linear_scale.setAlpha(150);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 170,
              // start_y: 307,
              // color: 0xFF000000,
              // lenght: 117,
              // line_width: 12,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 326,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'scale.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 68,
              y: 79,
              image_array: ["1_wth00.png","1_wth01.png","1_wth02.png","1_wth03.png","1_wth04.png","1_wth05.png","1_wth06.png","1_wth07.png","1_wth08.png","1_wth09.png","1_wth10.png","1_wth11.png","1_wth12.png","1_wth13.png","1_wth14.png","1_wth15.png","1_wth16.png","1_wth17.png","1_wth18.png","1_wth19.png","1_wth20.png","1_wth21.png","1_wth22.png","1_wth23.png","1_wth24.png","1_wth25.png","1_wth26.png","1_wth27.png","1_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 161,
              y: 97,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_dig.png',
              unit_tc: '1_dig.png',
              unit_en: '1_dig.png',
              imperial_unit_sc: '1_dig.png',
              imperial_unit_tc: '1_dig.png',
              imperial_unit_en: '1_dig.png',
              negative_image: '1_minus.png',
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 161,
                y: 97,
                font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
                padding: false,
                h_space: 0,
                unit_sc: '1_dig.png',
                unit_tc: '1_dig.png',
                unit_en: '1_dig.png',
                imperial_unit_sc: '1_dig.png',
                imperial_unit_tc: '1_dig.png',
                imperial_unit_en: '1_dig.png',
                negative_image: '1_minus.png',
                invalid_image: '1_eror.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1_BG0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '1_am.png',
              am_en_path: '1_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '1_pm.png',
              pm_en_path: '1_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 58,
              hour_startY: 185,
              hour_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 166,
              minute_startY: 185,
              minute_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 186,
              src: '1_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '1_sek.png',
              // center_x: 227,
              // center_y: 227,
              // x: 126,
              // y: 236,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '1_sek.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 126,
              second_posY: 236,
              fresh_frequency: 17,
              fresh_freqency: 17,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 17,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 324,
              year_startY: 86,
              year_sc_array: ["7_040.png","7_041.png","7_042.png","7_043.png","7_044.png","7_045.png","7_046.png","7_047.png","7_048.png","7_049.png"],
              year_tc_array: ["7_040.png","7_041.png","7_042.png","7_043.png","7_044.png","7_045.png","7_046.png","7_047.png","7_048.png","7_049.png"],
              year_en_array: ["7_040.png","7_041.png","7_042.png","7_043.png","7_044.png","7_045.png","7_046.png","7_047.png","7_048.png","7_049.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 226,
              y: 127,
              week_en: ["7_023.png","7_024.png","7_025.png","7_026.png","7_027.png","7_028.png","7_029.png"],
              week_tc: ["7_023.png","7_024.png","7_025.png","7_026.png","7_027.png","7_028.png","7_029.png"],
              week_sc: ["7_023.png","7_024.png","7_025.png","7_026.png","7_027.png","7_028.png","7_029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 277,
              month_startY: 86,
              month_sc_array: ["7_040.png","7_041.png","7_042.png","7_043.png","7_044.png","7_045.png","7_046.png","7_047.png","7_048.png","7_049.png"],
              month_tc_array: ["7_040.png","7_041.png","7_042.png","7_043.png","7_044.png","7_045.png","7_046.png","7_047.png","7_048.png","7_049.png"],
              month_en_array: ["7_040.png","7_041.png","7_042.png","7_043.png","7_044.png","7_045.png","7_046.png","7_047.png","7_048.png","7_049.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 230,
              day_startY: 86,
              day_sc_array: ["7_040.png","7_041.png","7_042.png","7_043.png","7_044.png","7_045.png","7_046.png","7_047.png","7_048.png","7_049.png"],
              day_tc_array: ["7_040.png","7_041.png","7_042.png","7_043.png","7_044.png","7_045.png","7_046.png","7_047.png","7_048.png","7_049.png"],
              day_en_array: ["7_040.png","7_041.png","7_042.png","7_043.png","7_044.png","7_045.png","7_046.png","7_047.png","7_048.png","7_049.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            idle_battery_linear_scale.setAlpha(150);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 170,
              // start_y: 307,
              // color: 0xFF000000,
              // lenght: 117,
              // line_width: 12,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 325,
              font_array: ["7_040.png","7_041.png","7_042.png","7_043.png","7_044.png","7_045.png","7_046.png","7_047.png","7_048.png","7_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '7_int.png',
              unit_tc: '7_int.png',
              unit_en: '7_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'scale.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '7_am.png',
              am_en_path: '7_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '7_pm.png',
              pm_en_path: '7_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 58,
              hour_startY: 185,
              hour_array: ["7_001.png","7_002.png","7_003.png","7_004.png","7_005.png","7_006.png","7_007.png","7_008.png","7_009.png","7_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 166,
              minute_startY: 185,
              minute_array: ["7_001.png","7_002.png","7_003.png","7_004.png","7_005.png","7_006.png","7_007.png","7_008.png","7_009.png","7_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 186,
              src: '7_011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 0,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'night_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 313,
              w: 95,
              h: 95,
              src: '00_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 290,
              y: 314,
              w: 95,
              h: 95,
              src: '00_empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 176,
              y: 366,
              w: 104,
              h: 85,
              src: '00_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 288,
              w: 98,
              h: 73,
              src: '00_empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 22,
              w: 95,
              h: 61,
              src: '00_empty.png',
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 163,
              y: 88,
              w: 62,
              h: 60,
              src: '00_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 288,
              y: 173,
              w: 107,
              h: 109,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_DIGT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 106,
              y: 182,
              w: 107,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 235,
              y: 87,
              w: 123,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 67,
              y: 79,
              w: 92,
              h: 92,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

			normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_8.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_9.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_10.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_11.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_12.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_13.setProperty(hmUI.prop.VISIBLE, false);
			normal_frame_animation_14.setProperty(hmUI.prop.VISIBLE, false);




            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 287;
                  let start_y_normal_battery = 307;
                  let lenght_ls_normal_battery = -117;
                  let line_width_ls_normal_battery = 12;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 287;
                  let start_y_idle_battery = 307;
                  let lenght_ls_idle_battery = -117;
                  let line_width_ls_idle_battery = 12;
                  let color_ls_idle_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_5.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_6.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_7.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_8.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_9.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_10.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_11.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_12.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_13.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_5.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_6.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_7.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_8.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_9.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_10.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_11.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_12.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_13.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}