﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_total_TextCircle = new Array(3);
        let normal_pai_total_TextCircle_ASCIIARRAY = new Array(10);
        let normal_pai_total_TextCircle_img_width = 20;
        let normal_pai_total_TextCircle_img_height = 29;
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_TextCircle = new Array(3);
        let normal_fat_burning_TextCircle_ASCIIARRAY = new Array(10);
        let normal_fat_burning_TextCircle_img_width = 20;
        let normal_fat_burning_TextCircle_img_height = 29;
        let normal_altimeter_icon_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 20;
        let normal_day_TextCircle_img_height = 29;
        let normal_day_TextCircle_unit = null;
        let normal_day_TextCircle_unit_width = 20;
        let normal_timerTextUpdate = undefined;
        let normal_calorie_icon_img = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 20;
        let normal_calorie_TextCircle_img_height = 29;
        let normal_calorie_circle_scale = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_month_TextCircle = new Array(2);
        let normal_month_TextCircle_ASCIIARRAY = new Array(10);
        let normal_month_TextCircle_img_width = 20;
        let normal_month_TextCircle_img_height = 29;
        let normal_high_TextCircle = new Array(4);
        let normal_high_TextCircle_ASCIIARRAY = new Array(10);
        let normal_high_TextCircle_img_width = 20;
        let normal_high_TextCircle_img_height = 29;
        let normal_high_TextCircle_unit = null;
        let normal_high_TextCircle_unit_width = 20;
        let normal_high_TextCircle_dot_width = 20;
        let normal_low_TextCircle = new Array(4);
        let normal_low_TextCircle_ASCIIARRAY = new Array(10);
        let normal_low_TextCircle_img_width = 20;
        let normal_low_TextCircle_img_height = 29;
        let normal_low_TextCircle_unit = null;
        let normal_low_TextCircle_unit_width = 20;
        let normal_low_TextCircle_dot_width = 20;
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 20;
        let normal_distance_TextCircle_img_height = 29;
        let normal_distance_TextCircle_dot_width = 20;
        let normal_distance_icon_img = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_pai_total_TextCircle = new Array(3);
        let idle_pai_total_TextCircle_ASCIIARRAY = new Array(10);
        let idle_pai_total_TextCircle_img_width = 20;
        let idle_pai_total_TextCircle_img_height = 29;
        let idle_fat_burning_icon_img = ''
        let idle_fat_burning_TextCircle = new Array(3);
        let idle_fat_burning_TextCircle_ASCIIARRAY = new Array(10);
        let idle_fat_burning_TextCircle_img_width = 20;
        let idle_fat_burning_TextCircle_img_height = 29;
        let idle_altimeter_icon_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_day_TextCircle = new Array(2);
        let idle_day_TextCircle_ASCIIARRAY = new Array(10);
        let idle_day_TextCircle_img_width = 20;
        let idle_day_TextCircle_img_height = 29;
        let idle_day_TextCircle_unit = null;
        let idle_day_TextCircle_unit_width = 20;
        let idle_timerTextUpdate = undefined;
        let idle_calorie_icon_img = ''
        let idle_calorie_TextCircle = new Array(4);
        let idle_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let idle_calorie_TextCircle_img_width = 20;
        let idle_calorie_TextCircle_img_height = 29;
        let idle_calorie_circle_scale = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_month_TextCircle = new Array(2);
        let idle_month_TextCircle_ASCIIARRAY = new Array(10);
        let idle_month_TextCircle_img_width = 20;
        let idle_month_TextCircle_img_height = 29;
        let idle_high_TextCircle = new Array(4);
        let idle_high_TextCircle_ASCIIARRAY = new Array(10);
        let idle_high_TextCircle_img_width = 20;
        let idle_high_TextCircle_img_height = 29;
        let idle_high_TextCircle_unit = null;
        let idle_high_TextCircle_unit_width = 20;
        let idle_high_TextCircle_dot_width = 20;
        let idle_low_TextCircle = new Array(4);
        let idle_low_TextCircle_ASCIIARRAY = new Array(10);
        let idle_low_TextCircle_img_width = 20;
        let idle_low_TextCircle_img_height = 29;
        let idle_low_TextCircle_unit = null;
        let idle_low_TextCircle_unit_width = 20;
        let idle_low_TextCircle_dot_width = 20;
        let idle_distance_TextCircle = new Array(5);
        let idle_distance_TextCircle_ASCIIARRAY = new Array(10);
        let idle_distance_TextCircle_img_width = 20;
        let idle_distance_TextCircle_img_height = 29;
        let idle_distance_TextCircle_dot_width = 20;
        let idle_distance_icon_img = ''
        let idle_step_icon_img = ''
        let idle_step_circle_scale = ''
        let idle_digital_clock_img_time = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'background-garmin.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_pai_total_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 222,
              // circle_center_Y: 196,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 157,
              // angle: -25,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_pai_total_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_pai_total_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 222,
                center_y: 196,
                pos_x: 222 - normal_pai_total_TextCircle_img_width / 2,
                pos_y: 196 - 186,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 53,
              y: 339,
              src: 'FB.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_fat_burning_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 203,
              // circle_center_Y: 339,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 109,
              // angle: 205,
              // char_space_angle: 3,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_fat_burning_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 203,
                center_y: 339,
                pos_x: 203 - normal_fat_burning_TextCircle_img_width / 2,
                pos_y: 339 + 80,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 315,
              src: 'baro_pressure.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 320,
              font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 12,
              src: '0080.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 328,
              // circle_center_Y: 232,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 91,
              // angle: 92,
              // char_space_angle: 0,
              // unit: 'point.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 328,
                center_y: 232,
                pos_x: 328 - normal_day_TextCircle_img_width / 2,
                pos_y: 232 - 120,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_day_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 328,
              center_y: 232,
              pos_x: 328 - normal_day_TextCircle_unit_width / 2,
              pos_y: 232 - 120,
              src: 'point.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 258,
              y: 410,
              src: 'CAL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 268,
              // circle_center_Y: 285,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 149,
              // angle: 151,
              // char_space_angle: 2,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 268,
                center_y: 285,
                pos_x: 268 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 285 + 120,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 232,
              // start_angle: 225,
              // end_angle: 134,
              // radius: 170,
              // line_width: 6,
              // line_cap: Rounded,
              // color: 0xFF039FB2,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 232,
              start_angle: 225,
              end_angle: 134,
              radius: 167,
              line_width: 6,
              corner_flag: 0,
              color: 0xFF039FB2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 97,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 101,
              font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_month_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 315,
              // circle_center_Y: 249,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 97,
              // angle: 112,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_month_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_month_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 315,
                center_y: 249,
                pos_x: 315 - normal_month_TextCircle_img_width / 2,
                pos_y: 249 - 126,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_high_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 173,
              // circle_center_Y: 200,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 131,
              // angle: 269,
              // char_space_angle: 1,
              // unit: 'deg_c.png',
              // dot_image: 'minus.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_high_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_high_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 173,
                center_y: 200,
                pos_x: 173 - normal_high_TextCircle_img_width / 2,
                pos_y: 200 - 160,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_high_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 173,
              center_y: 200,
              pos_x: 173 - normal_high_TextCircle_unit_width / 2,
              pos_y: 200 - 160,
              src: 'deg_c.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_low_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 173,
              // circle_center_Y: 225,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 138,
              // angle: 243,
              // char_space_angle: 0,
              // unit: 'deg_c.png',
              // dot_image: 'minus.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_low_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_low_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 173,
                center_y: 225,
                pos_x: 173 - normal_low_TextCircle_img_width / 2,
                pos_y: 225 - 167,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_low_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 173,
              center_y: 225,
              pos_x: 173 - normal_low_TextCircle_unit_width / 2,
              pos_y: 225 - 167,
              src: 'deg_c.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 253,
              // circle_center_Y: 192,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 148,
              // angle: 41,
              // char_space_angle: 0,
              // dot_image: 'point.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 253,
                center_y: 192,
                pos_x: 253 - normal_distance_TextCircle_img_width / 2,
                pos_y: 192 - 177,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 252,
              y: 15,
              src: 'DIST.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 62,
              y: 59,
              src: 'PAI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 225,
              // start_angle: -47,
              // end_angle: 46,
              // radius: 172,
              // line_width: 6,
              // line_cap: Rounded,
              // color: 0xFF039FB2,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 225,
              start_angle: -47,
              end_angle: 46,
              radius: 169,
              line_width: 6,
              corner_flag: 0,
              color: 0xFF039FB2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 67,
              hour_startY: 175,
              hour_array: ["grh0.png","grh1.png","grh2.png","grh3.png","grh4.png","grh5.png","grh6.png","grh7.png","grh8.png","grh9.png"],
              hour_zero: 0,
              hour_space: 9,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 230,
              minute_startY: 174,
              minute_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png","h6.png","h7.png","h8.png","h9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 320,
              second_startY: 122,
              second_array: ["s.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png","s_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'background-garmin.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_pai_total_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 222,
              // circle_center_Y: 196,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 157,
              // angle: -25,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_pai_total_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_pai_total_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 222,
                center_y: 196,
                pos_x: 222 - idle_pai_total_TextCircle_img_width / 2,
                pos_y: 196 - 186,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 53,
              y: 339,
              src: 'FB.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_fat_burning_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 203,
              // circle_center_Y: 339,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 109,
              // angle: 205,
              // char_space_angle: 3,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_fat_burning_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            idle_fat_burning_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_fat_burning_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 203,
                center_y: 339,
                pos_x: 203 - idle_fat_burning_TextCircle_img_width / 2,
                pos_y: 339 + 80,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 315,
              src: 'baro_pressure.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 320,
              font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 12,
              src: '0080.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 328,
              // circle_center_Y: 232,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 91,
              // angle: 92,
              // char_space_angle: 0,
              // unit: 'point.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 328,
                center_y: 232,
                pos_x: 328 - idle_day_TextCircle_img_width / 2,
                pos_y: 232 - 120,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_day_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 328,
              center_y: 232,
              pos_x: 328 - idle_day_TextCircle_unit_width / 2,
              pos_y: 232 - 120,
              src: 'point.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 258,
              y: 410,
              src: 'CAL.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 268,
              // circle_center_Y: 285,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 149,
              // angle: 151,
              // char_space_angle: 2,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 268,
                center_y: 285,
                pos_x: 268 - idle_calorie_TextCircle_img_width / 2,
                pos_y: 285 + 120,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 232,
              // start_angle: 225,
              // end_angle: 134,
              // radius: 170,
              // line_width: 6,
              // line_cap: Rounded,
              // color: 0xFF039FB2,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 232,
              start_angle: 225,
              end_angle: 134,
              radius: 167,
              line_width: 6,
              corner_flag: 0,
              color: 0xFF039FB2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 97,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 101,
              font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_month_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 315,
              // circle_center_Y: 249,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 97,
              // angle: 112,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_month_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            idle_month_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_month_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 315,
                center_y: 249,
                pos_x: 315 - idle_month_TextCircle_img_width / 2,
                pos_y: 249 - 126,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_high_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 173,
              // circle_center_Y: 200,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 131,
              // angle: 269,
              // char_space_angle: 1,
              // unit: 'deg_c.png',
              // dot_image: 'minus.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_high_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            idle_high_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            idle_high_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            idle_high_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            idle_high_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            idle_high_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            idle_high_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            idle_high_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            idle_high_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            idle_high_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_high_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 173,
                center_y: 200,
                pos_x: 173 - idle_high_TextCircle_img_width / 2,
                pos_y: 200 - 160,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_high_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 173,
              center_y: 200,
              pos_x: 173 - idle_high_TextCircle_unit_width / 2,
              pos_y: 200 - 160,
              src: 'deg_c.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_low_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 173,
              // circle_center_Y: 225,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 138,
              // angle: 243,
              // char_space_angle: 0,
              // unit: 'deg_c.png',
              // dot_image: 'minus.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_low_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            idle_low_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            idle_low_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            idle_low_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            idle_low_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            idle_low_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            idle_low_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            idle_low_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            idle_low_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            idle_low_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_low_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 173,
                center_y: 225,
                pos_x: 173 - idle_low_TextCircle_img_width / 2,
                pos_y: 225 - 167,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_low_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 173,
              center_y: 225,
              pos_x: 173 - idle_low_TextCircle_unit_width / 2,
              pos_y: 225 - 167,
              src: 'deg_c.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 253,
              // circle_center_Y: 192,
              // font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              // radius: 148,
              // angle: 41,
              // char_space_angle: 0,
              // dot_image: 'point.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextCircle_ASCIIARRAY[0] = 'c0.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[1] = 'c1.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[2] = 'c2.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[3] = 'c3.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[4] = 'c4.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[5] = 'c5.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[6] = 'c6.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[7] = 'c7.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[8] = 'c8.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[9] = 'c9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 253,
                center_y: 192,
                pos_x: 253 - idle_distance_TextCircle_img_width / 2,
                pos_y: 192 - 177,
                src: 'c0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 252,
              y: 15,
              src: 'DIST.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 62,
              y: 59,
              src: 'PAI.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 225,
              // start_angle: -47,
              // end_angle: 46,
              // radius: 172,
              // line_width: 6,
              // line_cap: Rounded,
              // color: 0xFF039FB2,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 225,
              start_angle: -47,
              end_angle: 46,
              radius: 169,
              line_width: 6,
              corner_flag: 0,
              color: 0xFF039FB2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 67,
              hour_startY: 175,
              hour_array: ["grh0.png","grh1.png","grh2.png","grh3.png","grh4.png","grh5.png","grh6.png","grh7.png","grh8.png","grh9.png"],
              hour_zero: 0,
              hour_space: 9,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 230,
              minute_startY: 174,
              minute_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png","h6.png","h7.png","h8.png","h9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 148,
              w: 70,
              h: 168,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 173,
              y: 84,
              w: 127,
              h: 67,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 248,
              y: 368,
              w: 148,
              h: 82,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 172,
              w: 292,
              h: 113,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 385,
              y: 144,
              w: 64,
              h: 169,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 303,
              w: 149,
              h: 62,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 68,
              y: 6,
              w: 123,
              h: 100,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function text_update() {
              console.log('text_update()');

              console.log('update text circle pai_total_PAI');
              let totalPAI = pai.totalpai;
              let normal_pai_total_circle_string = parseInt(totalPAI).toString();
              normal_pai_total_circle_string = normal_pai_total_circle_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -25;
                if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && normal_pai_total_circle_string.length > 0 && normal_pai_total_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_pai_total_TextCircle_img_angle = 0;
                  let normal_pai_total_TextCircle_dot_img_angle = 0;
                  normal_pai_total_TextCircle_img_angle = toDegree(Math.atan2(normal_pai_total_TextCircle_img_width/2, 157));
                  // alignment = CENTER_H
                  let normal_pai_total_TextCircle_angleOffset = normal_pai_total_TextCircle_img_angle * (normal_pai_total_circle_string.length - 1);
                  normal_pai_total_TextCircle_angleOffset = normal_pai_total_TextCircle_angleOffset + 1 * (normal_pai_total_circle_string.length - 1) / 2;
                  char_Angle -= normal_pai_total_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_pai_total_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_pai_total_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 222 - normal_pai_total_TextCircle_img_width / 2);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, normal_pai_total_TextCircle_ASCIIARRAY[charCode]);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_pai_total_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle fat_burning_FAT_BURRING');
              let valueFatBurning = fat_burning.current;
              let normal_fat_burning_circle_string = parseInt(valueFatBurning).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 385;
                if (valueFatBurning != null && valueFatBurning != undefined && isFinite(valueFatBurning) && normal_fat_burning_circle_string.length > 0 && normal_fat_burning_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_fat_burning_TextCircle_img_angle = 0;
                  let normal_fat_burning_TextCircle_dot_img_angle = 0;
                  normal_fat_burning_TextCircle_img_angle = toDegree(Math.atan2(normal_fat_burning_TextCircle_img_width/2, 109));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_fat_burning_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_fat_burning_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.POS_X, 203 - normal_fat_burning_TextCircle_img_width / 2);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.SRC, normal_fat_burning_TextCircle_ASCIIARRAY[charCode]);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_fat_burning_TextCircle_img_angle + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_circle_string = parseInt(valueDay).toString();
              normal_day_circle_string = normal_day_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 92;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  let normal_day_TextCircle_unit_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 91));
                  normal_day_TextCircle_unit_angle = toDegree(Math.atan2(normal_day_TextCircle_unit_width/2, 91));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 328 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_day_TextCircle_unit_angle;
                  normal_day_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 331;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 149));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 268 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle month_TIME');
              let valueMonth = timeNaw.month;
              let normal_month_circle_string = parseInt(valueMonth).toString();
              normal_month_circle_string = normal_month_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 112;
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && normal_month_circle_string.length > 0 && normal_month_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_month_TextCircle_img_angle = 0;
                  let normal_month_TextCircle_dot_img_angle = 0;
                  normal_month_TextCircle_img_angle = toDegree(Math.atan2(normal_month_TextCircle_img_width/2, 97));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_month_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_month_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_month_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.POS_X, 315 - normal_month_TextCircle_img_width / 2);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.SRC, normal_month_TextCircle_ASCIIARRAY[charCode]);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_month_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let high_temp = -100;
              if (forecastData.count > 0) {
                high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text circle high_forecastData');
              let temperatureHigh = undefined;
              let normal_high_circle_string = undefined;
              if (high_temp > -100) {
                temperatureHigh = 0;
                normal_high_circle_string = String(high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 269;
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_high_circle_string.length > 0 && normal_high_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_high_TextCircle_img_angle = 0;
                  let normal_high_TextCircle_dot_img_angle = 0;
                  let normal_high_TextCircle_unit_angle = 0;
                  normal_high_TextCircle_img_angle = toDegree(Math.atan2(normal_high_TextCircle_img_width/2, 131));
                  normal_high_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_high_TextCircle_dot_width/2, 131));
                  normal_high_TextCircle_unit_angle = toDegree(Math.atan2(normal_high_TextCircle_unit_width/2, 131));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_high_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_high_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 173 - normal_high_TextCircle_img_width / 2);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.SRC, normal_high_TextCircle_ASCIIARRAY[charCode]);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_high_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_high_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 173 - normal_high_TextCircle_dot_width / 2);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.SRC, 'minus.png');
                      normal_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_high_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_high_TextCircle_unit_angle;
                  normal_high_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let low_temp = -100;
              if (forecastData.count > 0) {
                low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text circle low_forecastData');
              let temperatureLow = undefined;
              let normal_low_circle_string = undefined;
              if (low_temp > -100) {
                temperatureLow = 0;
                normal_low_circle_string = String(low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 243;
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_low_circle_string.length > 0 && normal_low_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_low_TextCircle_img_angle = 0;
                  let normal_low_TextCircle_dot_img_angle = 0;
                  let normal_low_TextCircle_unit_angle = 0;
                  normal_low_TextCircle_img_angle = toDegree(Math.atan2(normal_low_TextCircle_img_width/2, 138));
                  normal_low_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_low_TextCircle_dot_width/2, 138));
                  normal_low_TextCircle_unit_angle = toDegree(Math.atan2(normal_low_TextCircle_unit_width/2, 138));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_low_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_low_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 173 - normal_low_TextCircle_img_width / 2);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.SRC, normal_low_TextCircle_ASCIIARRAY[charCode]);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_low_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_low_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 173 - normal_low_TextCircle_dot_width / 2);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.SRC, 'minus.png');
                      normal_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_low_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_low_TextCircle_unit_angle;
                  normal_low_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 41;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 148));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 148));
                  // alignment = CENTER_H
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  char_Angle -= normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 253 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 253 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'point.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle pai_total_PAI');
              let idle_pai_total_circle_string = parseInt(totalPAI).toString();
              idle_pai_total_circle_string = idle_pai_total_circle_string.padStart(3, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -25;
                if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && idle_pai_total_circle_string.length > 0 && idle_pai_total_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_pai_total_TextCircle_img_angle = 0;
                  let idle_pai_total_TextCircle_dot_img_angle = 0;
                  idle_pai_total_TextCircle_img_angle = toDegree(Math.atan2(idle_pai_total_TextCircle_img_width/2, 157));
                  // alignment = CENTER_H
                  let idle_pai_total_TextCircle_angleOffset = idle_pai_total_TextCircle_img_angle * (idle_pai_total_circle_string.length - 1);
                  idle_pai_total_TextCircle_angleOffset = idle_pai_total_TextCircle_angleOffset + 1 * (idle_pai_total_circle_string.length - 1) / 2;
                  char_Angle -= idle_pai_total_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_pai_total_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_pai_total_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 222 - idle_pai_total_TextCircle_img_width / 2);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, idle_pai_total_TextCircle_ASCIIARRAY[charCode]);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_pai_total_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle fat_burning_FAT_BURRING');
              let idle_fat_burning_circle_string = parseInt(valueFatBurning).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 385;
                if (valueFatBurning != null && valueFatBurning != undefined && isFinite(valueFatBurning) && idle_fat_burning_circle_string.length > 0 && idle_fat_burning_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_fat_burning_TextCircle_img_angle = 0;
                  let idle_fat_burning_TextCircle_dot_img_angle = 0;
                  idle_fat_burning_TextCircle_img_angle = toDegree(Math.atan2(idle_fat_burning_TextCircle_img_width/2, 109));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_fat_burning_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_fat_burning_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_fat_burning_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_fat_burning_TextCircle[index].setProperty(hmUI.prop.POS_X, 203 - idle_fat_burning_TextCircle_img_width / 2);
                      idle_fat_burning_TextCircle[index].setProperty(hmUI.prop.SRC, idle_fat_burning_TextCircle_ASCIIARRAY[charCode]);
                      idle_fat_burning_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_fat_burning_TextCircle_img_angle + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle day_TIME');
              let idle_day_circle_string = parseInt(valueDay).toString();
              idle_day_circle_string = idle_day_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 92;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_circle_string.length > 0 && idle_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_day_TextCircle_img_angle = 0;
                  let idle_day_TextCircle_dot_img_angle = 0;
                  let idle_day_TextCircle_unit_angle = 0;
                  idle_day_TextCircle_img_angle = toDegree(Math.atan2(idle_day_TextCircle_img_width/2, 91));
                  idle_day_TextCircle_unit_angle = toDegree(Math.atan2(idle_day_TextCircle_unit_width/2, 91));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_day_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 328 - idle_day_TextCircle_img_width / 2);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.SRC, idle_day_TextCircle_ASCIIARRAY[charCode]);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_day_TextCircle_unit_angle;
                  idle_day_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let idle_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 331;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_circle_string.length > 0 && idle_calorie_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_calorie_TextCircle_img_angle = 0;
                  let idle_calorie_TextCircle_dot_img_angle = 0;
                  idle_calorie_TextCircle_img_angle = toDegree(Math.atan2(idle_calorie_TextCircle_img_width/2, 149));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 268 - idle_calorie_TextCircle_img_width / 2);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, idle_calorie_TextCircle_ASCIIARRAY[charCode]);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_calorie_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle month_TIME');
              let idle_month_circle_string = parseInt(valueMonth).toString();
              idle_month_circle_string = idle_month_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 112;
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && idle_month_circle_string.length > 0 && idle_month_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_month_TextCircle_img_angle = 0;
                  let idle_month_TextCircle_dot_img_angle = 0;
                  idle_month_TextCircle_img_angle = toDegree(Math.atan2(idle_month_TextCircle_img_width/2, 97));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_month_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_month_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_month_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_month_TextCircle[index].setProperty(hmUI.prop.POS_X, 315 - idle_month_TextCircle_img_width / 2);
                      idle_month_TextCircle[index].setProperty(hmUI.prop.SRC, idle_month_TextCircle_ASCIIARRAY[charCode]);
                      idle_month_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_month_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle high_forecastData');
              let idle_high_circle_string = undefined;
              if (high_temp > -100) {
                temperatureHigh = 0;
                idle_high_circle_string = String(high_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 269;
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && idle_high_circle_string.length > 0 && idle_high_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_high_TextCircle_img_angle = 0;
                  let idle_high_TextCircle_dot_img_angle = 0;
                  let idle_high_TextCircle_unit_angle = 0;
                  idle_high_TextCircle_img_angle = toDegree(Math.atan2(idle_high_TextCircle_img_width/2, 131));
                  idle_high_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_high_TextCircle_dot_width/2, 131));
                  idle_high_TextCircle_unit_angle = toDegree(Math.atan2(idle_high_TextCircle_unit_width/2, 131));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_high_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_high_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 173 - idle_high_TextCircle_img_width / 2);
                      idle_high_TextCircle[index].setProperty(hmUI.prop.SRC, idle_high_TextCircle_ASCIIARRAY[charCode]);
                      idle_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_high_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_high_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 173 - idle_high_TextCircle_dot_width / 2);
                      idle_high_TextCircle[index].setProperty(hmUI.prop.SRC, 'minus.png');
                      idle_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_high_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += idle_high_TextCircle_unit_angle;
                  idle_high_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle low_forecastData');
              let idle_low_circle_string = undefined;
              if (low_temp > -100) {
                temperatureLow = 0;
                idle_low_circle_string = String(low_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 243;
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && idle_low_circle_string.length > 0 && idle_low_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_low_TextCircle_img_angle = 0;
                  let idle_low_TextCircle_dot_img_angle = 0;
                  let idle_low_TextCircle_unit_angle = 0;
                  idle_low_TextCircle_img_angle = toDegree(Math.atan2(idle_low_TextCircle_img_width/2, 138));
                  idle_low_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_low_TextCircle_dot_width/2, 138));
                  idle_low_TextCircle_unit_angle = toDegree(Math.atan2(idle_low_TextCircle_unit_width/2, 138));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_low_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_low_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 173 - idle_low_TextCircle_img_width / 2);
                      idle_low_TextCircle[index].setProperty(hmUI.prop.SRC, idle_low_TextCircle_ASCIIARRAY[charCode]);
                      idle_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_low_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_low_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 173 - idle_low_TextCircle_dot_width / 2);
                      idle_low_TextCircle[index].setProperty(hmUI.prop.SRC, 'minus.png');
                      idle_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_low_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += idle_low_TextCircle_unit_angle;
                  idle_low_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let idle_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 41;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_circle_string.length > 0 && idle_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_distance_TextCircle_img_angle = 0;
                  let idle_distance_TextCircle_dot_img_angle = 0;
                  idle_distance_TextCircle_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_img_width/2, 148));
                  idle_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_dot_width/2, 148));
                  // alignment = CENTER_H
                  let idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_img_angle * (idle_distance_circle_string.length - 1);
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset - idle_distance_TextCircle_img_angle + idle_distance_TextCircle_dot_img_angle;
                  char_Angle -= idle_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 253 - idle_distance_TextCircle_img_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, idle_distance_TextCircle_ASCIIARRAY[charCode]);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 253 - idle_distance_TextCircle_dot_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'point.png');
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 232,
                      start_angle: 225,
                      end_angle: 134,
                      radius: 167,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFF039FB2,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 225,
                      start_angle: -47,
                      end_angle: 46,
                      radius: 169,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFF039FB2,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 232,
                      start_angle: 225,
                      end_angle: 134,
                      radius: 167,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFF039FB2,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 225,
                      start_angle: -47,
                      end_angle: 46,
                      radius: 169,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFF039FB2,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}