﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
// Select background (SETTINGS)

    let total_backgrounds = 13
    let background_prefix = "01_bg_"
  
// Select compass (SETTINGS)
    
    let total_compass = 6
    let compass_prefix = "00_compass_"
  
// Alternate Elements (SETTINGS)

    let top_center_items_count = 4
    let top_left_items_count = 3
    let top_right_items_count = 3
    let bottom_left_items_count = 3
    let bottom_right_items_count = 3
     
///////////////////////////// NOT EDIT BELOW ///////////////////////////

//////////////  Select background (SCRIPTS) //////////////

    let background_number = 1

    function up_background() {
    
        if(background_number >= total_backgrounds) {
            background_number = 1;
        }
        else {
            background_number = background_number + 1;
        }

        change_style();
    };
    
    function down_background() {
        
        if(background_number <= 1) {
            background_number = total_backgrounds;
        }
        else {
            background_number = background_number - 1;
        }
                      
        change_style();   
        
    };

    function change_style() {
       
          normal_background_bg_img.setProperty(hmUI.prop.SRC, background_prefix + parseInt(background_number) + ".png");

    };

//////////////  Select compass (SCRIPT) //////////////     

    let compass_number = 1
		
    function up_compass() {
      
        if(compass_number >= total_compass) {
            compass_number = 1;
        }
        else {
            compass_number = compass_number + 1;
        }

        normal_compass_direction_pointer_img.setProperty(hmUI.prop.SRC, compass_prefix + parseInt(compass_number) + ".png");
  
    };

/////////////  Compass OFF / ON (SCRIPT) //////////////
  
    let switch_pos_compass = 1
    let total_pos_compass = 2

    function switch_compass() {
          
        if(switch_pos_compass == total_pos_compass) {
           switch_pos_compass = 1; // Compass OFF

           if (compass) {
           
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '000');
                normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
                compass.stop();
                
           }        

        }
        else {
           switch_pos_compass = switch_pos_compass + 1; // Compass ON

           if(switch_pos_compass == 2) {
               if (compass)  {
                          
                    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                    
                    normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                    normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
                    compass.start();
                    
               }        
                    
           }
        }
          
    };
 
//////////////  Alternate Elements (SCRIPTS) //////////////

    let top_center_items_index = 1

    function click_top_center_dial() {
    
      top_center_items_index++;
      if(top_center_items_index > top_center_items_count) top_center_items_index = 1;
       
      normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 1); 
      normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 1);
      normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 1);
      
      normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 2);
      normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 2);
      normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 2);
     
      normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 3);
      normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 3);
      normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 3);
    
      normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 4);
      normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 4);
      normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, top_center_items_index == 4);
        
    };

    let top_left_items_index = 1

    function click_top_left_dial() {
    
      top_left_items_index++;
      if(top_left_items_index > top_left_items_count) top_left_items_index = 1;
      
      normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 1);
      normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 1);
      
      normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 2);
      normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 2);
     
      normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 3);
      normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, top_left_items_index == 3);
 
    };
  
    let top_right_items_index = 1

    function click_top_right_dial() {
    
      top_right_items_index++;
      if(top_right_items_index > top_right_items_count) top_right_items_index = 1;
      
      normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 1);
      normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 1);
      
      normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 2);
      normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 2);

      normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 3);
      normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, top_right_items_index == 3);

    }; 
   
    let bottom_left_items_index = 1

    function click_bottom_left_dial() {
    
      bottom_left_items_index++;
      if(bottom_left_items_index > bottom_left_items_count) bottom_left_items_index = 1;

      normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 1);
      normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 1);
      
      normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 2);
      normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 2);
      
      normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 3);
      normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_left_items_index == 3);
  
    };
  
    let bottom_right_items_index = 1

    function click_bottom_right_dial() {
    
      bottom_right_items_index++;
      if(bottom_right_items_index > bottom_right_items_count) bottom_right_items_index = 1;

      normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 1);
      normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 1);
      
      normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 2);
      normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 2);

      normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 3);
      normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_right_items_index == 3);
           
    }; 
        
/////////////////////////////////////////////////////////////////////////////////////////////////

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_compass_icon_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_direction_cover_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_uvi_text_text_img = ''
        let normal_uvi_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_fat_burning_current_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_pai_day_text_img = ''
        let normal_pai_day_separator_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_moon_high_text_img = ''
        let normal_moon_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_compass_tap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: '00_compass_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: '10_ring2.png',
              // cover_x: 0,
              // cover_y: 0,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: '00_compass_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_direction_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '10_ring2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 48,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: '10_degree_S.png',
              unit_tc: '10_degree_S.png',
              unit_en: '10_degree_S.png',
              negative_image: '10_null_S.png',
              align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 335,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_M.png',
              unit_tc: '10_percent_M.png',
              unit_en: '10_percent_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 260,
              y: 373,
              src: '10_hum.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 248,
              y: 335,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 260,
              y: 373,
              src: '10_uv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 335,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '10_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 260,
              y: 373,
              src: '10_dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 335,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 161,
              y: 373,
              src: '10_fat_burn.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 335,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_M.png',
              unit_tc: '10_percent_M.png',
              unit_en: '10_percent_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 161,
              y: 373,
              src: '10_spo2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 335,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 161,
              y: 373,
              src: '10_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 64,
              hour_startY: 211,
              hour_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '10_sep_hhmm.png',
              hour_unit_tc: '10_sep_hhmm.png',
              hour_unit_en: '10_sep_hhmm.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 155,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 371,
              y: 151,
              src: '10_PAI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 155,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 371,
              y: 151,
              src: '10_stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 155,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 371,
              y: 151,
              src: '10_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 155,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              negative_image: '10_dash_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 49,
              y: 151,
              src: '10_alt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 155,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 49,
              y: 151,
              src: '10_baro.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 155,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 49,
              y: 151,
              src: '10_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 91,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_sep_S.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 91,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_sep_S.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 203,
              y: 77,
              image_array: ["12_moon_01.png","12_moon_02.png","12_moon_03.png","12_moon_04.png","12_moon_05.png","12_moon_06.png","12_moon_07.png","12_moon_08.png","12_moon_09.png","12_moon_10.png","12_moon_11.png","12_moon_12.png","12_moon_13.png","12_moon_14.png","12_moon_15.png","12_moon_16.png","12_moon_17.png","12_moon_18.png","12_moon_19.png","12_moon_20.png","12_moon_21.png","12_moon_22.png","12_moon_23.png","12_moon_24.png","12_moon_25.png","12_moon_26.png","12_moon_27.png","12_moon_28.png","12_moon_29.png","12_moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 91,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_sep_S.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 91,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_sep_S.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 91,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_S.png',
              unit_tc: '10_degree_S.png',
              unit_en: '10_degree_S.png',
              negative_image: '10_dash_S.png',
              invalid_image: '10_null_S.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 91,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_S.png',
              unit_tc: '10_degree_S.png',
              unit_en: '10_degree_S.png',
              negative_image: '10_dash_S.png',
              invalid_image: '10_null_S.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 87,
              font_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_M.png',
              unit_tc: '10_degree_M.png',
              unit_en: '10_degree_M.png',
              negative_image: '10_dash_M.png',
              invalid_image: '10_null_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 203,
              y: 77,
              image_array: ["09_weather_01.png","09_weather_02.png","09_weather_03.png","09_weather_04.png","09_weather_05.png","09_weather_06.png","09_weather_07.png","09_weather_08.png","09_weather_09.png","09_weather_10.png","09_weather_11.png","09_weather_12.png","09_weather_13.png","09_weather_14.png","09_weather_15.png","09_weather_16.png","09_weather_17.png","09_weather_18.png","09_weather_19.png","09_weather_20.png","09_weather_21.png","09_weather_22.png","09_weather_23.png","09_weather_24.png","09_weather_25.png","09_weather_26.png","09_weather_27.png","09_weather_28.png","09_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 270,
              month_startY: 88,
              month_sc_array: ["07_month_POL_01.png","07_month_POL_02.png","07_month_POL_03.png","07_month_POL_04.png","07_month_POL_05.png","07_month_POL_06.png","07_month_POL_07.png","07_month_POL_08.png","07_month_POL_09.png","07_month_POL_10.png","07_month_POL_11.png","07_month_POL_12.png"],
              month_tc_array: ["07_month_POL_01.png","07_month_POL_02.png","07_month_POL_03.png","07_month_POL_04.png","07_month_POL_05.png","07_month_POL_06.png","07_month_POL_07.png","07_month_POL_08.png","07_month_POL_09.png","07_month_POL_10.png","07_month_POL_11.png","07_month_POL_12.png"],
              month_en_array: ["07_month_POL_01.png","07_month_POL_02.png","07_month_POL_03.png","07_month_POL_04.png","07_month_POL_05.png","07_month_POL_06.png","07_month_POL_07.png","07_month_POL_08.png","07_month_POL_09.png","07_month_POL_10.png","07_month_POL_11.png","07_month_POL_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 200,
              day_startY: 87,
              day_sc_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              day_tc_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              day_en_array: ["04_M_0.png","04_M_1.png","04_M_2.png","04_M_3.png","04_M_4.png","04_M_5.png","04_M_6.png","04_M_7.png","04_M_8.png","04_M_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 105,
              y: 88,
              week_en: ["08_wd_POL_1.png","08_wd_POL_2.png","08_wd_POL_3.png","08_wd_POL_4.png","08_wd_POL_5.png","08_wd_POL_6.png","08_wd_POL_7.png"],
              week_tc: ["08_wd_POL_1.png","08_wd_POL_2.png","08_wd_POL_3.png","08_wd_POL_4.png","08_wd_POL_5.png","08_wd_POL_6.png","08_wd_POL_7.png"],
              week_sc: ["08_wd_POL_1.png","08_wd_POL_2.png","08_wd_POL_3.png","08_wd_POL_4.png","08_wd_POL_5.png","08_wd_POL_6.png","08_wd_POL_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 48,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_S.png',
              unit_tc: '10_percent_S.png',
              unit_en: '10_percent_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 48,
              image_array: ["11_bat_1.png","11_bat_2.png","11_bat_3.png","11_bat_4.png","11_bat_5.png","11_bat_6.png","11_bat_7.png","11_bat_8.png","11_bat_9.png","11_bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 239,
              y: 155,
              src: '10_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 64,
              hour_startY: 177,
              hour_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '10_sep_hhmm.png',
              hour_unit_tc: '10_sep_hhmm.png',
              hour_unit_en: '10_sep_hhmm.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_top_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 167,
              y: 10,
              w: 120,
              h: 55,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                switch_compass()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 167,
              y: 75,
              w: 120,
              h: 55,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_top_center_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 138,
              w: 110,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_top_right_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 65,
              y: 138,
              w: 140,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_top_left_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 216,
              w: 44,
              h: 90,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                up_compass()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 267,
              y: 216,
              w: 120,
              h: 90,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                up_background()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 68,
              y: 216,
              w: 120,
              h: 90,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                down_background()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 250,
              y: 320,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                 click_bottom_right_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 115,
              y: 320,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_bottom_left_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

////////////  Initial visibility of elements //////////// 

    let cc = 0

    if (cc == 0 ){

       normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
    
 // TOP CENTER
    
      normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true); 
      normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
      normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
      
      normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
     
      normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
      normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
    
      normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
      normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
 
 // TOP LEFT

      normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
      normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
      
      normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
     
      normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);   
   
 // TOP RIGHT
 
      normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
      normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
      
      normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

      normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);     
 
 // BOTTOM LEFT

      normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
      normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
      
      normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
      
      normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

 // BOTTOM RIGHT
    
      normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
      normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
      
      normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

      normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        
    cc = 1;

    };

/////////////////////////////////////////////////////////////////////////////////////////////////

            // end user_script_end.js

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

                }

              }); // Listener end              normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);              normal_compass_text_img.setProperty(hmUI.prop.TEXT, '000');              compass.stop();

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                if(switch_pos_compass == 2) {if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start()};

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if(switch_pos_compass == 2) {if (compass) compass.stop()};

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}