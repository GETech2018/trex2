﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 103,
              y: 140,
              week_en: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_tc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_sc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 353,
              y: 141,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 280,
              y: 141,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 317,
              y: 141,
              src: 'al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 108,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digsmall_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 108,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digsmall_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 239,
              y: 25,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 48,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digsmall_11.png',
              unit_tc: 'digsmall_11.png',
              unit_en: 'digsmall_11.png',
              negative_image: 'digsmall_min.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 173,
              y: 26,
              image_array: ["weat_01.png","weat_02.png","weat_03.png","weat_04.png","weat_05.png","weat_06.png","weat_07.png","weat_08.png","weat_09.png","weat_10.png","weat_11.png","weat_12.png","weat_13.png","weat_14.png","weat_15.png","weat_16.png","weat_17.png","weat_18.png","weat_19.png","weat_20.png","weat_21.png","weat_22.png","weat_23.png","weat_24.png","weat_25.png","weat_26.png","weat_27.png","weat_28.png","weat_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 384,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digsmall_per.png',
              unit_tc: 'digsmall_per.png',
              unit_en: 'digsmall_per.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 384,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 384,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digsmall_per.png',
              unit_tc: 'digsmall_per.png',
              unit_en: 'digsmall_per.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 321,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'digsmall_err.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 321,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 147,
              y: 321,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digsmall_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 321,
              font_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 160,
              month_startY: 98,
              month_sc_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              month_tc_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              month_en_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'digsmall_10.png',
              month_unit_tc: 'digsmall_10.png',
              month_unit_en: 'digsmall_10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 114,
              day_startY: 98,
              day_sc_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              day_tc_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              day_en_array: ["digsmall_00.png","digsmall_01.png","digsmall_02.png","digsmall_03.png","digsmall_04.png","digsmall_05.png","digsmall_06.png","digsmall_07.png","digsmall_08.png","digsmall_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'digsmall_10.png',
              day_unit_tc: 'digsmall_10.png',
              day_unit_en: 'digsmall_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'analogsec1.png',
              second_centerX: 226,
              second_centerY: 228,
              second_posX: 10,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 69,
              hour_startY: 182,
              hour_array: ["digbig1_00.png","digbig1_01.png","digbig1_02.png","digbig1_03.png","digbig1_04.png","digbig1_05.png","digbig1_06.png","digbig1_07.png","digbig1_08.png","digbig1_09.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 233,
              minute_startY: 182,
              minute_array: ["digbig2_00.png","digbig2_01.png","digbig2_02.png","digbig2_03.png","digbig2_04.png","digbig2_05.png","digbig2_06.png","digbig2_07.png","digbig2_08.png","digbig2_09.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            console.log('Watch_Face.Shortcuts');

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 231,
              y: 76,
              w: 170,
              h: 57,
              src: 'short.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 353,
              w: 82,
              h: 57,
              src: 'short.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 106,
              y: 27,
              w: 113,
              h: 59,
              src: 'short.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 321,
              y: 289,
              w: 80,
              h: 57,
              src: 'short.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 53,
              y: 289,
              w: 170,
              h: 57,
              src: 'short.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}