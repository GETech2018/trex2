﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 42,
              font_array: ["NR.5_01.png","NR.5_02.png","NR.5_03.png","NR.5_04.png","NR.5_05.png","NR.5_06.png","NR.5_07.png","NR.5_08.png","NR.5_09.png","NR.5_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'NR.5_13.png',
              unit_tc: 'NR.5_13.png',
              unit_en: 'NR.5_13.png',
              negative_image: 'NR.5_12.png',
              invalid_image: 'NR.5_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 9,
              image_array: ["Meteo_01.png","Meteo_02.png","Meteo_03.png","Meteo_04.png","Meteo_05.png","Meteo_06.png","Meteo_07.png","Meteo_08.png","Meteo_09.png","Meteo_10.png","Meteo_11.png","Meteo_12.png","Meteo_13.png","Meteo_14.png","Meteo_15.png","Meteo_16.png","Meteo_17.png","Meteo_18.png","Meteo_19.png","Meteo_20.png","Meteo_21.png","Meteo_22.png","Meteo_23.png","Meteo_24.png","Meteo_25.png","Meteo_26.png","Meteo_27.png","Meteo_28.png","Meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 400,
              font_array: ["NR4_01.png","NR4_02.png","NR4_03.png","NR4_04.png","NR4_05.png","NR4_06.png","NR4_07.png","NR4_08.png","NR4_09.png","NR4_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 359,
              font_array: ["NR.5_01.png","NR.5_02.png","NR.5_03.png","NR.5_04.png","NR.5_05.png","NR.5_06.png","NR.5_07.png","NR.5_08.png","NR.5_09.png","NR.5_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'NR.5_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 359,
              font_array: ["NR.5_01.png","NR.5_02.png","NR.5_03.png","NR.5_04.png","NR.5_05.png","NR.5_06.png","NR.5_07.png","NR.5_08.png","NR.5_09.png","NR.5_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 306,
              y: 392,
              src: 'LK_01.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 43,
              src: 'DND_01.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 121,
              y: 34,
              src: 'Bt_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 343,
              y: 58,
              src: 'AL_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 74,
              font_array: ["NR.3_01.png","NR.3_02.png","NR.3_03.png","NR.3_04.png","NR.3_05.png","NR.3_06.png","NR.3_07.png","NR.3_08.png","NR.3_09.png","NR.3_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 127,
              y: 77,
              image_array: ["Bat_01.png","Bat_02.png","Bat_03.png","Bat_04.png","Bat_05.png","Bat_06.png","Bat_07.png","Bat_08.png","Bat_09.png","Bat_10.png","Bat_11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 329,
              month_startY: 91,
              month_sc_array: ["NR.2_01.png","NR.2_02.png","NR.2_03.png","NR.2_04.png","NR.2_05.png","NR.2_06.png","NR.2_07.png","NR.2_08.png","NR.2_09.png","NR.2_10.png"],
              month_tc_array: ["NR.2_01.png","NR.2_02.png","NR.2_03.png","NR.2_04.png","NR.2_05.png","NR.2_06.png","NR.2_07.png","NR.2_08.png","NR.2_09.png","NR.2_10.png"],
              month_en_array: ["NR.2_01.png","NR.2_02.png","NR.2_03.png","NR.2_04.png","NR.2_05.png","NR.2_06.png","NR.2_07.png","NR.2_08.png","NR.2_09.png","NR.2_10.png"],
              month_zero: 1,
              month_space: 4,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 258,
              day_startY: 91,
              day_sc_array: ["NR.2_01.png","NR.2_02.png","NR.2_03.png","NR.2_04.png","NR.2_05.png","NR.2_06.png","NR.2_07.png","NR.2_08.png","NR.2_09.png","NR.2_10.png"],
              day_tc_array: ["NR.2_01.png","NR.2_02.png","NR.2_03.png","NR.2_04.png","NR.2_05.png","NR.2_06.png","NR.2_07.png","NR.2_08.png","NR.2_09.png","NR.2_10.png"],
              day_en_array: ["NR.2_01.png","NR.2_02.png","NR.2_03.png","NR.2_04.png","NR.2_05.png","NR.2_06.png","NR.2_07.png","NR.2_08.png","NR.2_09.png","NR.2_10.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 40,
              y: 110,
              week_en: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_tc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_sc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 146,
              hour_array: ["NR.1_01.png","NR.1_02.png","NR.1_03.png","NR.1_04.png","NR.1_05.png","NR.1_06.png","NR.1_07.png","NR.1_08.png","NR.1_09.png","NR.1_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 240,
              minute_startY: 146,
              minute_array: ["NR.1_01.png","NR.1_02.png","NR.1_03.png","NR.1_04.png","NR.1_05.png","NR.1_06.png","NR.1_07.png","NR.1_08.png","NR.1_09.png","NR.1_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'SEC_01.png',
              second_centerX: 226,
              second_centerY: 226,
              second_posX: 185,
              second_posY: 185,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}