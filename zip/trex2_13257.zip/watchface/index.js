﻿/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start
    function valuesAreClose(firstValue, secondValue, tolerance = 10) {
      return Math.abs(Math.abs(firstValue) - Math.abs(secondValue)) <= tolerance;
    }

    const CHRONO_RESET = 0;
    const CHRONO_START = 1;
    const CHRONO_STOP = 2;

    const NORMAL_SEC = 0;
    const SEMI_SMOOTH_SEC = 1;
    const SMOOTH_SEC = 2;

    // Analog Clock class
    class AnalonClock {
      constructor(timeSensor, secMode = SEMI_SMOOTH_SEC) {
        this.timeSensor = timeSensor;

        this.hourPointers = [];
        this.minutePointers = [];
        this.secondsPointers = [];

        this.normal_angle_hour = 0;
        this.normal_angle_minute = 0;
        this.normal_angle_second = 0;

        this.normal_timerUpdate = undefined;
        this.normal_timerUpdateSec = undefined;

        this.secondsMode = secMode;
      }
      addHourPointer(pointer) {
        this.hourPointers.push(pointer);
      }
      addMinutePointer(pointer) {
        this.minutePointers.push(pointer);
      }
      addSecondsPointer(pointer) {
        this.secondsPointers.push(pointer);
      }

      update(updateHour = false, updateMinute = false) {
        let hour = this.timeSensor.hour;
        let minute = this.timeSensor.minute;
        let second = this.timeSensor.second;

        if (updateHour) {
          let normal_hour = hour;
          let normal_fullAngle_hour = 360;
          if (normal_hour > 11) normal_hour -= 12;
          this.normal_angle_hour = 0 + (normal_fullAngle_hour * normal_hour) / 12 + ((normal_fullAngle_hour / 12) * minute) / 60;
          this.hourPointers.forEach((e) => {
            if (e) e.setProperty(hmUI.prop.ANGLE, this.normal_angle_hour);
          });
        }

        if (updateMinute) {
          let normal_fullAngle_minute = 360;
          this.normal_angle_minute = 0 + (normal_fullAngle_minute * (minute + second / 60)) / 60;
          this.minutePointers.forEach((e) => {
            if (e) e.setProperty(hmUI.prop.ANGLE, this.normal_angle_minute);
          });
        }

        let normal_fullAngle_second = 360;
        this.normal_angle_second = 0 + (normal_fullAngle_second * (second + (this.timeSensor.utc % 1000) / 1000)) / 60;
        this.secondsPointers.forEach((e) => {
          if (e) e.setProperty(hmUI.prop.ANGLE, this.normal_angle_second);
        });
      }

      start_update() {
        let screenType = hmSetting.getScreenType();

        if (screenType == hmSetting.screen_type.WATCHFACE) {
          if (!this.normal_timerUpdate) {
            let animDelay = timeSensor.utc % 1000;
            let animRepeat = 1000;
            this.normal_timerUpdate = timer.createTimer(animDelay, animRepeat, (option) => {
              this.update(false, true);
            }); // end timer
          } // end timer check
        } // end screenType

        if (screenType == hmSetting.screen_type.WATCHFACE) {
          if (!this.normal_timerUpdateSec) {
            let animDelay = 0;
            let animRepeat = 1000 / 6;
            this.normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (option) => {
              this.update(false, false);
            }); // end timer
          } // end timer check
        } // end screenType
      }

      stop_update() {
        if (this.normal_timerUpdate) {
          timer.stopTimer(this.normal_timerUpdate);
          this.normal_timerUpdate = undefined;
        }
        if (this.normal_timerUpdateSec) {
          timer.stopTimer(this.normal_timerUpdateSec);
          this.normal_timerUpdateSec = undefined;
        }
      }
    }

    // Chrono class
    class Chronograph {
      constructor(timeSensor, updateInterval = 1000 / 6) {
        this.timeSensor = timeSensor;
        this.chrono_update_interval = updateInterval;

        this.chrono_start_time = 0;
        this.chrono_current_time = 0;
        this.chrono_mem = 0;

        this.chrono_mode = CHRONO_RESET;

        this.normal_timerUpdateChrono = undefined;
        this.normal_timerArrowsToZero = undefined;

        this.normal_chrono_angle_second = 0;
        this.normal_chrono_angle_minute = 0;
        this.normal_chrono_angle_hour = 0;

        this.arrow_animation_delta = 6;
        this.arrows_animation_is_running = false;

        this.hourPointers = [];
        this.minutePointers = [];
        this.secondsPointers = [];
        this.msec10Pointers = []; // 1/10 sec;
        this.msec100Pointers = []; // 1/100 sec;
      }

      addHourPointer(pointer) {
        this.hourPointers.push(pointer);
      }
      addMinutePointer(pointer) {
        this.minutePointers.push(pointer);
      }
      addSecondsPointer(pointer) {
        this.secondsPointers.push(pointer);
      }
      addMsec10Pointer(pointer) {
        this.msec10Pointers.push(pointer);
      }
      addMsec100Pointer(pointer) {
        this.msec100Pointers.push(pointer);
      }

      start_stop() {
        switch (this.chrono_mode) {
          case CHRONO_RESET:
            this.chrono_mode = CHRONO_START;

            this.chrono_start_time = this.timeSensor.utc;
            // start timer
            if (!this.normal_timerUpdateChrono) {
              this.normal_timerUpdateChrono = timer.createTimer(0, this.chrono_update_interval, (option) => {
                this.update();
              });
            }
            break;
          case CHRONO_START:
            this.chrono_mode = CHRONO_STOP;
            // remember last measured time
            this.chrono_mem = this.chrono_mem + (this.chrono_current_time - this.chrono_start_time);
            // stop timer
            if (this.normal_timerUpdateChrono) {
              timer.stopTimer(this.normal_timerUpdateChrono);
              this.normal_timerUpdateChrono = undefined;
            }
            break;
          case CHRONO_STOP:
            this.chrono_mode = CHRONO_START;
            this.chrono_start_time = this.timeSensor.utc;
            // start timer
            if (!this.normal_timerUpdateChrono) {
              this.normal_timerUpdateChrono = timer.createTimer(0, this.chrono_update_interval, (option) => {
                this.update();
              });
            }
            break;
          default:
            break;
        }
      }

      reset() {
        if (this.chrono_mode == CHRONO_START) return;

        this.chrono_mode = CHRONO_RESET;

        this.chrono_mem = 0;
        this.chrono_start_time = 0;
        this.chrono_current_time = 0;

        // reset should smoothly move arrows to zero
        // start animation to zero timer
        if (!this.normal_timerArrowsToZero) {
          this.arrows_animation_is_running = true;
          this.normal_timerArrowsToZero = timer.createTimer(0, Math.floor(1000 / 30), (option) => {
            this.goToZero();
          });
        }
      }

      goToZero() {
        // decrement
        this.normal_chrono_angle_hour -= this.arrow_animation_delta;
        this.normal_chrono_angle_minute -= this.arrow_animation_delta;
        this.normal_chrono_angle_second -= this.arrow_animation_delta;

        // zero them out
        if (valuesAreClose(this.normal_chrono_angle_hour, 0)) this.normal_chrono_angle_hour = 0;
        if (valuesAreClose(this.normal_chrono_angle_minute, 0)) this.normal_chrono_angle_minute = 0;
        if (valuesAreClose(this.normal_chrono_angle_second, 0)) this.normal_chrono_angle_second = 0;

        // set elements angles
        this.hourPointers.forEach((hr) => {
          if (hr) hr.setProperty(hmUI.prop.ANGLE, this.normal_chrono_angle_hour);
        });
        this.minutePointers.forEach((min) => {
          if (min) min.setProperty(hmUI.prop.ANGLE, this.normal_chrono_angle_minute);
        });
        this.secondsPointers.forEach((sec) => {
          if (sec) sec.setProperty(hmUI.prop.ANGLE, this.normal_chrono_angle_second);
        });

        if (this.normal_chrono_angle_hour == 0 && this.normal_chrono_angle_minute == 0 && this.normal_chrono_angle_second == 0) {
          if (this.normal_timerArrowsToZero) {
            timer.stopTimer(this.normal_timerArrowsToZero);
            this.normal_timerArrowsToZero = undefined;
            this.arrows_animation_is_running = false;
          }
        }
      }

      update() {
        this.chrono_current_time = this.timeSensor.utc;
        let chrono_time_diff = this.chrono_current_time - this.chrono_start_time + this.chrono_mem;

        let msec_in_hour = 60 * 60 * 1000;
        let msec_in_min = 60 * 1000;
        let msec_in_sec = 1000;

        let hour = Math.floor(chrono_time_diff / msec_in_hour);
        let minute = Math.floor((chrono_time_diff - hour * msec_in_hour) / msec_in_min);
        let second = Math.floor((chrono_time_diff - hour * msec_in_hour - minute * msec_in_min) / msec_in_sec);
        let msec = chrono_time_diff - hour * msec_in_hour - minute * msec_in_min - second * msec_in_sec;

        // update arrows position
        // hour
        let normal_hour = hour;
        let normal_fullAngle_hour = 360;
        if (normal_hour > 11) normal_hour -= 12;
        this.normal_chrono_angle_hour = (normal_hour * 60 + minute) * (normal_fullAngle_hour / 12 / 60);
        this.hourPointers.forEach((hr) => {
          if (hr) hr.setProperty(hmUI.prop.ANGLE, this.normal_chrono_angle_hour);
        });

        // minutes
        let normal_fullAngle_minute = 360;
        this.normal_chrono_angle_minute = (minute * 60 + second) * (normal_fullAngle_minute / 30 / 60);
        this.minutePointers.forEach((min) => {
          if (min) min.setProperty(hmUI.prop.ANGLE, this.normal_chrono_angle_minute);
        });

        // sec
        let normal_fullAngle_second = 360;
        this.normal_chrono_angle_second = (second * msec_in_sec + msec) * (normal_fullAngle_second / msec_in_min);
        this.secondsPointers.forEach((sec) => {
          if (sec) sec.setProperty(hmUI.prop.ANGLE, this.normal_chrono_angle_second);
        });
      }
    }

    let normal_background_bg_img = "";
    let normal_date_img_date_day = "";
    let normal_analog_clock_pro_hour_pointer_img = "";
    let normal_analog_clock_pro_minute_pointer_img = "";
    let normal_analog_clock_pro_hour_pointer_img_shadow = "";
    let normal_analog_clock_pro_minute_pointer_img_shadow = "";
    let normal_analog_clock_pro_second_pointer_small_img = "";
    let normal_analog_clock_pro_second_pointer_small_img_shadow = "";
    let normal_chronograph_second_pointer_img = "";
    let normal_chronograph_second_pointer_img_shadow = "";
    let normal_chronograph_minute_pointer_img = "";
    let normal_chronograph_hour_pointer_img = "";
    let normal_analog_clock_pro_second_cover_pointer_img = "";
    let idle_background_bg_img = "";
    let idle_analog_clock_time_pointer_hour = "";
    let idle_analog_clock_time_pointer_minute = "";

    let button_start_stop = "";
    let button_reset = "";

    let timeSensor = "";

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start

        const deviceInfo = hmSetting.getDeviceInfo();

        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

        let chrono = new Chronograph(timeSensor);
        let analonClock = new AnalonClock(timeSensor, SMOOTH_SEC);

        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
          analonClock.update(true, true);
          updateDate();
        });

        normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          center_x: 227,
          center_y: 227,
          src: "normal_date.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "normal_bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_chronograph_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 264,
          y: 164,
          w: 124,
          h: 124,
          pos_x: 54,
          pos_y: 0,
          center_x: 62,
          center_y: 62,
          src: "normal_small_pointer.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        chrono.addMinutePointer(normal_chronograph_minute_pointer_img);

        normal_analog_clock_pro_second_pointer_small_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 64,
          y: 164,
          w: 124,
          h: 124,
          pos_x: 54,
          pos_y: 0,
          center_x: 62,
          center_y: 62,
          src: "normal_small_pointer.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        analonClock.addSecondsPointer(normal_analog_clock_pro_second_pointer_small_img);

        normal_analog_clock_pro_hour_pointer_img_shadow = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 5,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 20,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "shadow_hour.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 20,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_hour_black.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        analonClock.addHourPointer(normal_analog_clock_pro_hour_pointer_img_shadow);
        analonClock.addHourPointer(normal_analog_clock_pro_hour_pointer_img);

        normal_analog_clock_pro_minute_pointer_img_shadow = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 7,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 20,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "shadow_minute.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 20,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_minute_black.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        analonClock.addMinutePointer(normal_analog_clock_pro_minute_pointer_img_shadow);
        analonClock.addMinutePointer(normal_analog_clock_pro_minute_pointer_img);

        normal_chronograph_second_pointer_img_shadow = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 9,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 12,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "shadow_second.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_chronograph_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 12,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_second_black.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        chrono.addSecondsPointer(normal_chronograph_second_pointer_img_shadow);
        chrono.addSecondsPointer(normal_chronograph_second_pointer_img);

        // idle screen
        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "idle_bg.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: "idle_hour.png",
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 20,
          hour_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: "idle_minute.png",
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 20,
          minute_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        // chrono buttons
        button_start_stop = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 327, // x coordinate of the button
          y: 70, // y coordinate of the button
          text: "",
          w: 60, // button width
          h: 60, // button height
          normal_src: "_empty.png", // transparent image
          press_src: "_empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            chrono.start_stop();
          },
        });

        button_reset = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 327, // x coordinate of the button
          y: 327, // y coordinate of the button
          text: "",
          w: 60, // button width
          h: 60, // button height
          normal_src: "_empty.png", // transparent image
          press_src: "_empty.png", // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            chrono.reset();
          },
        });

        let dateChangeTimer = undefined;
        let dateLastValue = undefined;
        let dateCurrentValue = 1;

        let dateLastAngle = 0;
        let dateCurrentAngle = 0;

        function getDateAngle(day) {
          return (day - 1) * (360 / 31);
        }

        function updateDate() {
          let day = timeSensor.day;

          // 1st call
          if (!dateLastValue) {
            // init some start values
            dateLastValue = day;
            dateLastAngle = -getDateAngle(dateLastValue);
            // and set the current date
            if (normal_date_img_date_day) normal_date_img_date_day.setProperty(hmUI.prop.ANGLE, dateLastAngle);
            return;
          }

          // followup calls
          dateCurrentValue = day;
          if (dateLastValue == dateCurrentValue) return; // do nothing if it's the same day

          if (!dateChangeTimer) {
            // calculate target angle
            dateCurrentAngle = dateCurrentValue == 1 ? -360 : -getDateAngle(dateCurrentValue);
            // start timer
            dateChangeTimer = timer.createTimer(0, 1000 / 30, function (option) {
              moveDate();
            });
          }

          if (normal_date_img_date_day) normal_date_img_date_day.setProperty(hmUI.prop.ANGLE, date_angle);
        }

        function moveDate() {
          let d = -(360 / 31 / 12);
          dateLastAngle += d;
          if (valuesAreClose(dateCurrentAngle, dateLastAngle, 1)) dateLastAngle = dateCurrentAngle;

          if (normal_date_img_date_day) normal_date_img_date_day.setProperty(hmUI.prop.ANGLE, dateLastAngle);

          if (dateLastAngle == dateCurrentAngle) {
            dateLastValue = dateCurrentValue;
            if (dateLastValue == 1) dateLastAngle = 0; //
            if (dateChangeTimer) {
              timer.stopTimer(dateChangeTimer);
              dateChangeTimer = undefined;
            }
          }
        }

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            analonClock.update(true, true);
            analonClock.start_update();

            updateDate();
          },
          pause_call: function () {
            analonClock.stop_update();
          },
        });

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e && e.stack && e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
