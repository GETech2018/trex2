﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_humidity_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_humidity_text_text_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_uvi_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 158,
              month_startY: 147,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 69,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 349,
              y: 163,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'Nr.Sist.14.png',
              dot_image: 'Nr.Sist.11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 349,
              y: 189,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'Nr.Sist.14.png',
              dot_image: 'Nr.Sist.11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 196,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr.Sist.14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 368,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 284,
              image_array: ["Kcal_01.png","Kcal_02.png","Kcal_03.png","Kcal_04.png","Kcal_05.png","Kcal_06.png","Kcal_07.png"],
              image_length: 7,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 168,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 322,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: true,
              h_space: 0,
              dot_image: 'Nr.Sist.12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 322,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 0,
              image_array: ["Steps_01.png","Steps_02.png","Steps_03.png","Steps_04.png","Steps_05.png","Steps_06.png","Steps_07.png","Steps_08.png","Steps_09.png","Steps_10.png","Steps_11.png","Steps_12.png","Steps_13.png","Steps_14.png","Steps_15.png"],
              image_length: 15,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 223,
              y: 179,
              week_en: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_tc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_sc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 170,
              day_startY: 179,
              day_sc_array: ["Nr.Day_01.png","Nr.Day_02.png","Nr.Day_03.png","Nr.Day_04.png","Nr.Day_05.png","Nr.Day_06.png","Nr.Day_07.png","Nr.Day_08.png","Nr.Day_09.png","Nr.Day_10.png"],
              day_tc_array: ["Nr.Day_01.png","Nr.Day_02.png","Nr.Day_03.png","Nr.Day_04.png","Nr.Day_05.png","Nr.Day_06.png","Nr.Day_07.png","Nr.Day_08.png","Nr.Day_09.png","Nr.Day_10.png"],
              day_en_array: ["Nr.Day_01.png","Nr.Day_02.png","Nr.Day_03.png","Nr.Day_04.png","Nr.Day_05.png","Nr.Day_06.png","Nr.Day_07.png","Nr.Day_08.png","Nr.Day_09.png","Nr.Day_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 25,
              y: 261,
              src: 'Lk_01.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 58,
              y: 260,
              src: 'DND_01.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 55,
              y: 231,
              src: 'BtOff_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 18,
              y: 235,
              src: 'Alarm_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 368,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr.Sist.14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 285,
              y: 285,
              image_array: ["BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Punt_01.png',
              center_x: 227,
              center_y: 379,
              x: 12,
              y: -38,
              start_angle: 63,
              end_angle: 296,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 350,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 190,
              y: 14,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 115,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr.Sist.15.png',
              unit_tc: 'Nr.Sist.15.png',
              unit_en: 'Nr.Sist.15.png',
              negative_image: 'Nr.Sist.13.png',
              invalid_image: 'Nr.Sist.14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 65,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr.Sist.15.png',
              unit_tc: 'Nr.Sist.15.png',
              unit_en: 'Nr.Sist.15.png',
              negative_image: 'Nr.Sist.13.png',
              invalid_image: 'Nr.Sist.14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 94,
              font_array: ["Nr.Day_01.png","Nr.Day_02.png","Nr.Day_03.png","Nr.Day_04.png","Nr.Day_05.png","Nr.Day_06.png","Nr.Day_07.png","Nr.Day_08.png","Nr.Day_09.png","Nr.Day_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr.Day_13.png',
              unit_tc: 'Nr.Day_13.png',
              unit_en: 'Nr.Day_13.png',
              negative_image: 'Nr.Day_11.png',
              invalid_image: 'Nr.Day_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 30,
              am_y: 288,
              am_sc_path: 'AM_01.png',
              am_en_path: 'AM_01.png',
              pm_x: 31,
              pm_y: 288,
              pm_sc_path: 'PM_01.png',
              pm_en_path: 'PM_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 227,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 1,
              hour_space: -3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 210,
              minute_startY: 227,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 340,
              second_startY: 238,
              second_array: ["Nr.Min_01.png","Nr.Min_02.png","Nr.Min_03.png","Nr.Min_04.png","Nr.Min_05.png","Nr.Min_06.png","Nr.Min_07.png","Nr.Min_08.png","Nr.Min_09.png","Nr.Min_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 227,
              src: 'Nr.Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 320,
              y: 222,
              src: 'Nr.Ore_12.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 158,
              month_startY: 147,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 69,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 349,
              y: 163,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'Nr.Sist.14.png',
              dot_image: 'Nr.Sist.11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 349,
              y: 189,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'Nr.Sist.14.png',
              dot_image: 'Nr.Sist.11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 196,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr.Sist.14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 368,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 284,
              image_array: ["Kcal_01.png","Kcal_02.png","Kcal_03.png","Kcal_04.png","Kcal_05.png","Kcal_06.png","Kcal_07.png"],
              image_length: 7,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 168,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 322,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: true,
              h_space: 0,
              dot_image: 'Nr.Sist.12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 322,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 0,
              image_array: ["Steps_01.png","Steps_02.png","Steps_03.png","Steps_04.png","Steps_05.png","Steps_06.png","Steps_07.png","Steps_08.png","Steps_09.png","Steps_10.png","Steps_11.png","Steps_12.png","Steps_13.png","Steps_14.png","Steps_15.png"],
              image_length: 15,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 223,
              y: 179,
              week_en: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_tc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_sc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 170,
              day_startY: 179,
              day_sc_array: ["Nr.Day_01.png","Nr.Day_02.png","Nr.Day_03.png","Nr.Day_04.png","Nr.Day_05.png","Nr.Day_06.png","Nr.Day_07.png","Nr.Day_08.png","Nr.Day_09.png","Nr.Day_10.png"],
              day_tc_array: ["Nr.Day_01.png","Nr.Day_02.png","Nr.Day_03.png","Nr.Day_04.png","Nr.Day_05.png","Nr.Day_06.png","Nr.Day_07.png","Nr.Day_08.png","Nr.Day_09.png","Nr.Day_10.png"],
              day_en_array: ["Nr.Day_01.png","Nr.Day_02.png","Nr.Day_03.png","Nr.Day_04.png","Nr.Day_05.png","Nr.Day_06.png","Nr.Day_07.png","Nr.Day_08.png","Nr.Day_09.png","Nr.Day_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 25,
              y: 261,
              src: 'Lk_01.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 58,
              y: 260,
              src: 'DND_01.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 55,
              y: 231,
              src: 'BtOff_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 18,
              y: 235,
              src: 'Alarm_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 368,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr.Sist.14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 285,
              y: 285,
              image_array: ["BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Punt_01.png',
              center_x: 227,
              center_y: 379,
              x: 12,
              y: -38,
              start_angle: 63,
              end_angle: 296,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 350,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 190,
              y: 14,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 115,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr.Sist.15.png',
              unit_tc: 'Nr.Sist.15.png',
              unit_en: 'Nr.Sist.15.png',
              negative_image: 'Nr.Sist.13.png',
              invalid_image: 'Nr.Sist.14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 65,
              font_array: ["Nr.Sist.01.png","Nr.Sist.02.png","Nr.Sist.03.png","Nr.Sist.04.png","Nr.Sist.05.png","Nr.Sist.06.png","Nr.Sist.07.png","Nr.Sist.08.png","Nr.Sist.09.png","Nr.Sist.10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr.Sist.15.png',
              unit_tc: 'Nr.Sist.15.png',
              unit_en: 'Nr.Sist.15.png',
              negative_image: 'Nr.Sist.13.png',
              invalid_image: 'Nr.Sist.14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 94,
              font_array: ["Nr.Day_01.png","Nr.Day_02.png","Nr.Day_03.png","Nr.Day_04.png","Nr.Day_05.png","Nr.Day_06.png","Nr.Day_07.png","Nr.Day_08.png","Nr.Day_09.png","Nr.Day_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr.Day_13.png',
              unit_tc: 'Nr.Day_13.png',
              unit_en: 'Nr.Day_13.png',
              negative_image: 'Nr.Day_11.png',
              invalid_image: 'Nr.Day_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 30,
              am_y: 288,
              am_sc_path: 'AM_01.png',
              am_en_path: 'AM_01.png',
              pm_x: 31,
              pm_y: 288,
              pm_sc_path: 'PM_01.png',
              pm_en_path: 'PM_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 227,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 1,
              hour_space: -3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 210,
              minute_startY: 227,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 340,
              second_startY: 238,
              second_array: ["Nr.Min_01.png","Nr.Min_02.png","Nr.Min_03.png","Nr.Min_04.png","Nr.Min_05.png","Nr.Min_06.png","Nr.Min_07.png","Nr.Min_08.png","Nr.Min_09.png","Nr.Min_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 227,
              src: 'Nr.Ore_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 320,
              y: 222,
              src: 'Nr.Ore_12.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}