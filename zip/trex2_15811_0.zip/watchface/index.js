﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0
	
	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	
	
		let color_var = 1
        let totalcolors = 7
		let night_var = 1
        let night_all = 2
		let visabl_main = 1
		let totalvisabl_main = 3
		let new_dgt = 1
		let xxx_clock_h = 288
		let yyy_clock_h = 143
		let xxx_clock_m = 288
		let yyy_clock_m = 249
		let xxx_clock_s = 390
		let yyy_clock_s = 215
		let xxx_temp = 87
		let yyy_temp = 218
		let xxx_weather = 16
		let yyy_weather = 208
		let namecolor_main = ' '
		let name_text = ' '
		let name_dgt = ' '
	
//	переход в ночной режим (подставлением полупрозрачной картинки поверх циферблата)
	
		function click_Night() {
            if(night_var>=night_all) {
            night_var=1;
                }
            else {
                night_var=night_var+1;
            }
			if ( night_var == 1) name_text = "DAYTIME MODE"  
			if ( night_var == 2) name_text = "NIGHT MODE" 
			hmUI.showToast({text: name_text });
			normal_image_img.setProperty(hmUI.prop.SRC, "night_" + parseInt(night_var) + ".png");
			vibro(28);
		}
		
		
		
		function UpdateButtonOne(){

// активируем кнопки и ярлыки				

				Button_1.setProperty(hmUI.prop.VISIBLE, true);     // ночь/день 1
//				Button_2.setProperty(hmUI.prop.VISIBLE, true);		//  изменение параметров 
				Button_3.setProperty(hmUI.prop.VISIBLE, true);		//  изменение цвета 1
//				Button_4.setProperty(hmUI.prop.VISIBLE, true);    //  календарь
				Button_5.setProperty(hmUI.prop.VISIBLE, true);    //  погодный сервис
				normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      // ярлык секундомер
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык температуры
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.MORE, {
                 x: 83,
                 y: 212,
                 w: 91,
                 h: 61,
                 src: '00_empty.png',
                 type: hmUI.data_type.WEATHER_CURRENT,
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });
//				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык пульса 

//  убираем кнопки и ярлыки				
				Button_6.setProperty(hmUI.prop.VISIBLE, false);      //  ночь/день 2
				Button_7.setProperty(hmUI.prop.VISIBLE, false);      // изменение цвета 2
				Button_8.setProperty(hmUI.prop.VISIBLE, false);      // погодный сервис 2
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык атмосферного давления
				normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык P A I
				normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык статистика активностей (калории)
				normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык разминка 
				normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //  ярлык жиросжигание
       }

        function UpdateButtonTwo(){

// активируем кнопки и ярлыки

				Button_6.setProperty(hmUI.prop.VISIBLE, true);      //  ночь/день 2
				Button_7.setProperty(hmUI.prop.VISIBLE, true);      // изменение цвета 2
//              normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык пульса 
				normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык P A I
				normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык статистика активностей (калории)
				normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык разминка 
				normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //  ярлык жиросжигание
				
//  убираем кнопки и ярлыки	
			
				Button_1.setProperty(hmUI.prop.VISIBLE, false);    //  ночь/день 1
				Button_3.setProperty(hmUI.prop.VISIBLE, false);		//  изменение цвета 1
				Button_5.setProperty(hmUI.prop.VISIBLE, false);    //  погодный сервис
				Button_8.setProperty(hmUI.prop.VISIBLE, false);      // погодный сервис 2
				
				normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      // ярлык секундомер
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык температуры
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык атмосферного давления
								
        }
		
		function UpdateButtonThree(){

// активируем кнопки и ярлыки
				
			Button_6.setProperty(hmUI.prop.VISIBLE, true);      //  ночь/день 2
			Button_7.setProperty(hmUI.prop.VISIBLE, true);      // изменение цвета 2
			Button_8.setProperty(hmUI.prop.VISIBLE, true);    //  погодный сервис 2
			normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык температуры
			normal_temperature_jumpable_img_click.setProperty(hmUI.prop.MORE, {
              x: 270,
              y: 139,
              w: 65,
              h: 55,
              src: '00_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык атмосферного давления
			
//  убираем кнопки и ярлыки	
			
			Button_1.setProperty(hmUI.prop.VISIBLE, false);    //  ночь/день 1
			Button_3.setProperty(hmUI.prop.VISIBLE, false);		//  изменение цвета 1
			Button_5.setProperty(hmUI.prop.VISIBLE, false);    //  погодный сервис
			normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      // ярлык секундомер
//			normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык пульса 
			normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык P A I
			normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык статистика активностей (калории)
			normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык разминка 
			normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //  ярлык жиросжигание
       }
		
		
		
		
	//	видимость /невидимость	
		
		function click_visabl() {
            if(visabl_main>=totalvisabl_main) {
            visabl_main=1; 
                }
            else {
                visabl_main=visabl_main+1;
            }
			
	//  время - большие цифры		
			
			if ( visabl_main == 1) { 
		
		UpdateButtonOne()
		
		normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		new_dgt = 1;
		
		xxx_clock_h = 288;
		yyy_clock_h = 143;
		
		xxx_clock_m = 288;
		yyy_clock_m = 249;
		
		xxx_clock_s = 390;
		yyy_clock_s = 215;
		
		xxx_temp = 87;
		yyy_temp = 218;
		
		xxx_weather = 16;
		yyy_weather = 208;

		
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: parseInt(xxx_clock_h),
              hour_startY: parseInt(yyy_clock_h),
              hour_array: [parseInt(new_dgt) + "_" + parseInt(color_var) + "_01.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_02.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_03.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_04.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_05.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_06.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_07.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_08.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_09.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: parseInt(xxx_clock_m),
              minute_startY: parseInt(yyy_clock_m),
              minute_array: [parseInt(new_dgt) + "_" + parseInt(color_var) + "_01.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_02.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_03.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_04.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_05.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_06.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_07.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_08.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_09.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: parseInt(xxx_clock_s),
              second_startY: parseInt(yyy_clock_s),
              second_array: [parseInt(new_dgt) + "_" + parseInt(color_var) + "_13.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_14.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_15.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_16.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_17.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_18.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_19.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_20.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_21.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_22.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_am.png',
              am_en_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_pm.png',
              pm_en_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


		    normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: parseInt(xxx_weather),
              y: parseInt(yyy_weather),
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: parseInt(xxx_temp),
              y: parseInt(yyy_temp),
              font_array: ["1_" + parseInt(color_var) + "_13.png","1_" + parseInt(color_var) + "_14.png","1_" + parseInt(color_var) + "_15.png","1_" + parseInt(color_var) + "_16.png","1_" + parseInt(color_var) + "_17.png","1_" + parseInt(color_var) + "_18.png","1_" + parseInt(color_var) + "_19.png","1_" + parseInt(color_var) + "_20.png","1_" + parseInt(color_var) + "_21.png","1_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_var) + '_deg.png',
              unit_tc: parseInt(color_var) + '_deg.png',
              unit_en: parseInt(color_var) + '_deg.png',
              imperial_unit_sc: parseInt(color_var) + '_deg.png',
              imperial_unit_tc: parseInt(color_var) + '_deg.png',
              imperial_unit_en: parseInt(color_var) + '_deg.png',
              negative_image: parseInt(color_var) + '_minus.png',
              invalid_image: parseInt(color_var) + '_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
						
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			
		normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);		
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		
		namecolor_main = "TIME IN BIG NUMBERS"
		hmUI.showToast({text: namecolor_main });
		vibro(28);
				
			};

//     модуль активностей

			
			if ( visabl_main == 2) { 
			
		UpdateButtonTwo()
			
			new_dgt = 2;
			xxx_clock_h = 12;
			yyy_clock_h = 212;
			xxx_clock_m = 93;
			yyy_clock_m = 212;
			xxx_clock_s = 163;
			yyy_clock_s = 223;
			
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: parseInt(xxx_clock_h),
              hour_startY: parseInt(yyy_clock_h),
              hour_array: [parseInt(new_dgt) + "_" + parseInt(color_var) + "_01.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_02.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_03.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_04.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_05.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_06.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_07.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_08.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_09.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: parseInt(xxx_clock_m),
              minute_startY: parseInt(yyy_clock_m),
              minute_array: [parseInt(new_dgt) + "_" + parseInt(color_var) + "_01.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_02.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_03.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_04.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_05.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_06.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_07.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_08.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_09.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: parseInt(xxx_clock_s),
              second_startY: parseInt(yyy_clock_s),
              second_array: [parseInt(new_dgt) + "_" + parseInt(color_var) + "_13.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_14.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_15.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_16.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_17.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_18.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_19.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_20.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_21.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_22.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_am.png',
              am_en_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_pm.png',
              pm_en_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);   
			
			
     	normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		
		
		normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);		
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		
		namecolor_main = "ACTIVITIES IN DETAIL"
		hmUI.showToast({text: namecolor_main });
		vibro(28);
		
			};

//   погодный модуль
			
			if ( visabl_main == 3) { 

		UpdateButtonThree()

            new_dgt = 2;
			xxx_clock_h = 12;
			yyy_clock_h = 212;
			xxx_clock_m = 93;
			yyy_clock_m = 212;
			xxx_clock_s = 163;
			yyy_clock_s = 223;
			xxx_temp = 263;
			yyy_temp = 140;
			xxx_weather = 350;
			yyy_weather = 128;
			
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: parseInt(xxx_clock_h),
              hour_startY: parseInt(yyy_clock_h),
              hour_array: [parseInt(new_dgt) + "_" + parseInt(color_var) + "_01.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_02.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_03.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_04.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_05.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_06.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_07.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_08.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_09.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: parseInt(xxx_clock_m),
              minute_startY: parseInt(yyy_clock_m),
              minute_array: [parseInt(new_dgt) + "_" + parseInt(color_var) + "_01.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_02.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_03.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_04.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_05.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_06.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_07.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_08.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_09.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: parseInt(xxx_clock_s),
              second_startY: parseInt(yyy_clock_s),
              second_array: [parseInt(new_dgt) + "_" + parseInt(color_var) + "_13.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_14.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_15.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_16.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_17.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_18.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_19.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_20.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_21.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_22.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_am.png',
              am_en_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_pm.png',
              pm_en_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


		    normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: parseInt(xxx_weather),
              y: parseInt(yyy_weather),
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: parseInt(xxx_temp),
              y: parseInt(yyy_temp),
              font_array: ["1_" + parseInt(color_var) + "_13.png","1_" + parseInt(color_var) + "_14.png","1_" + parseInt(color_var) + "_15.png","1_" + parseInt(color_var) + "_16.png","1_" + parseInt(color_var) + "_17.png","1_" + parseInt(color_var) + "_18.png","1_" + parseInt(color_var) + "_19.png","1_" + parseInt(color_var) + "_20.png","1_" + parseInt(color_var) + "_21.png","1_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_var) + '_deg.png',
              unit_tc: parseInt(color_var) + '_deg.png',
              unit_en: parseInt(color_var) + '_deg.png',
              imperial_unit_sc: parseInt(color_var) + '_deg.png',
              imperial_unit_tc: parseInt(color_var) + '_deg.png',
              imperial_unit_en: parseInt(color_var) + '_deg.png',
              negative_image: parseInt(color_var) + '_minus.png',
              invalid_image: parseInt(color_var) + '_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			 


        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);	
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);	

        		
				
     	
		
		namecolor_main = "WEATHER IN DETAIL"
		hmUI.showToast({text: namecolor_main });
			
		vibro(28);
			
		};



       };
	   
	   
	   //  изменение цвета цифер	
		
		function colordig() {
            if(color_var>=totalcolors) {
            color_var=1;
                }
            else {
                color_var=color_var+1;
            }
			
			normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 232,
              y: 374,
              font_array: ["2_" + parseInt(color_var) + "_13.png","2_" + parseInt(color_var) + "_14.png","2_" + parseInt(color_var) + "_15.png","2_" + parseInt(color_var) + "_16.png","2_" + parseInt(color_var) + "_17.png","2_" + parseInt(color_var) + "_18.png","2_" + parseInt(color_var) + "_19.png","2_" + parseInt(color_var) + "_20.png","2_" + parseInt(color_var) + "_21.png","2_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			normal_stress_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_var) + "_sep.png");
	
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: parseInt(color_var) + '_steps.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -3,
              end_angle: 232,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			     
			normal_step_current_separator_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: parseInt(color_var) + '_stp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			
			
			normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 271,
              y: 301,
              font_array: ["2_" + parseInt(color_var) + "_13.png","2_" + parseInt(color_var) + "_14.png","2_" + parseInt(color_var) + "_15.png","2_" + parseInt(color_var) + "_16.png","2_" + parseInt(color_var) + "_17.png","2_" + parseInt(color_var) + "_18.png","2_" + parseInt(color_var) + "_19.png","2_" + parseInt(color_var) + "_20.png","2_" + parseInt(color_var) + "_21.png","2_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_var) + '_km.png',
              unit_tc: parseInt(color_var) + '_km.png',
              unit_en: parseInt(color_var) + '_km.png',
              imperial_unit_sc: parseInt(color_var) + '_ml.png',
              imperial_unit_tc: parseInt(color_var) + '_ml.png',
              imperial_unit_en: parseInt(color_var) + '_ml.png',
              dot_image: parseInt(color_var) + '_point.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_stand_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 350,
              y: 248,
              font_array: [parseInt(color_var) + "_030.png",parseInt(color_var) + "_031.png",parseInt(color_var) + "_032.png",parseInt(color_var) + "_033.png",parseInt(color_var) + "_034.png",parseInt(color_var) + "_035.png",parseInt(color_var) + "_036.png",parseInt(color_var) + "_037.png",parseInt(color_var) + "_038.png",parseInt(color_var) + "_039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 288,
              y: 248,
              font_array: [parseInt(color_var) + "_030.png",parseInt(color_var) + "_031.png",parseInt(color_var) + "_032.png",parseInt(color_var) + "_033.png",parseInt(color_var) + "_034.png",parseInt(color_var) + "_035.png",parseInt(color_var) + "_036.png",parseInt(color_var) + "_037.png",parseInt(color_var) + "_038.png",parseInt(color_var) + "_039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
			
			normal_pai_weekly_text_img.setProperty(hmUI.prop.MORE, {
              x: 359,
              y: 198,
              font_array: ["2_" + parseInt(color_var) + "_13.png","2_" + parseInt(color_var) + "_14.png","2_" + parseInt(color_var) + "_15.png","2_" + parseInt(color_var) + "_16.png","2_" + parseInt(color_var) + "_17.png","2_" + parseInt(color_var) + "_18.png","2_" + parseInt(color_var) + "_19.png","2_" + parseInt(color_var) + "_20.png","2_" + parseInt(color_var) + "_21.png","2_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img.setProperty(hmUI.prop.MORE, {
              x: 286,
              y: 198,
              font_array: ["2_" + parseInt(color_var) + "_13.png","2_" + parseInt(color_var) + "_14.png","2_" + parseInt(color_var) + "_15.png","2_" + parseInt(color_var) + "_16.png","2_" + parseInt(color_var) + "_17.png","2_" + parseInt(color_var) + "_18.png","2_" + parseInt(color_var) + "_19.png","2_" + parseInt(color_var) + "_20.png","2_" + parseInt(color_var) + "_21.png","2_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_var) + '_slesh.png',
              unit_tc: parseInt(color_var) + '_slesh.png',
              unit_en: parseInt(color_var) + '_slesh.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 313,
              y: 145,
              font_array: [parseInt(color_var) + "_030.png",parseInt(color_var) + "_031.png",parseInt(color_var) + "_032.png",parseInt(color_var) + "_033.png",parseInt(color_var) + "_034.png",parseInt(color_var) + "_035.png",parseInt(color_var) + "_036.png",parseInt(color_var) + "_037.png",parseInt(color_var) + "_038.png",parseInt(color_var) + "_039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
						
			
			normal_altimeter_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 330,
              y: 199,
              font_array: ["2_" + parseInt(color_var) + "_13.png","2_" + parseInt(color_var) + "_14.png","2_" + parseInt(color_var) + "_15.png","2_" + parseInt(color_var) + "_16.png","2_" + parseInt(color_var) + "_17.png","2_" + parseInt(color_var) + "_18.png","2_" + parseInt(color_var) + "_19.png","2_" + parseInt(color_var) + "_20.png","2_" + parseInt(color_var) + "_21.png","2_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 291,
              y: 250,
              font_array: ["2_" + parseInt(color_var) + "_13.png","2_" + parseInt(color_var) + "_14.png","2_" + parseInt(color_var) + "_15.png","2_" + parseInt(color_var) + "_16.png","2_" + parseInt(color_var) + "_17.png","2_" + parseInt(color_var) + "_18.png","2_" + parseInt(color_var) + "_19.png","2_" + parseInt(color_var) + "_20.png","2_" + parseInt(color_var) + "_21.png","2_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_wind_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 359,
              y: 303,
              font_array: ["2_" + parseInt(color_var) + "_13.png","2_" + parseInt(color_var) + "_14.png","2_" + parseInt(color_var) + "_15.png","2_" + parseInt(color_var) + "_16.png","2_" + parseInt(color_var) + "_17.png","2_" + parseInt(color_var) + "_18.png","2_" + parseInt(color_var) + "_19.png","2_" + parseInt(color_var) + "_20.png","2_" + parseInt(color_var) + "_21.png","2_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 344,
              y: 249,
              font_array: ["2_" + parseInt(color_var) + "_13.png","2_" + parseInt(color_var) + "_14.png","2_" + parseInt(color_var) + "_15.png","2_" + parseInt(color_var) + "_16.png","2_" + parseInt(color_var) + "_17.png","2_" + parseInt(color_var) + "_18.png","2_" + parseInt(color_var) + "_19.png","2_" + parseInt(color_var) + "_20.png","2_" + parseInt(color_var) + "_21.png","2_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: -2,
              unit_sc: parseInt(color_var) + '_int.png',
              unit_tc: parseInt(color_var) + '_int.png',
              unit_en: parseInt(color_var) + '_int.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: parseInt(xxx_temp),
              y: parseInt(yyy_temp),
              font_array: ["1_" + parseInt(color_var) + "_13.png","1_" + parseInt(color_var) + "_14.png","1_" + parseInt(color_var) + "_15.png","1_" + parseInt(color_var) + "_16.png","1_" + parseInt(color_var) + "_17.png","1_" + parseInt(color_var) + "_18.png","1_" + parseInt(color_var) + "_19.png","1_" + parseInt(color_var) + "_20.png","1_" + parseInt(color_var) + "_21.png","1_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_var) + '_deg.png',
              unit_tc: parseInt(color_var) + '_deg.png',
              unit_en: parseInt(color_var) + '_deg.png',
              imperial_unit_sc: parseInt(color_var) + '_deg.png',
              imperial_unit_tc: parseInt(color_var) + '_deg.png',
              imperial_unit_en: parseInt(color_var) + '_deg.png',
              negative_image: parseInt(color_var) + '_minus.png',
              invalid_image: parseInt(color_var) + '_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 99,
              y: 356,
              font_array: ["2_" + parseInt(color_var) + "_13.png","2_" + parseInt(color_var) + "_14.png","2_" + parseInt(color_var) + "_15.png","2_" + parseInt(color_var) + "_16.png","2_" + parseInt(color_var) + "_17.png","2_" + parseInt(color_var) + "_18.png","2_" + parseInt(color_var) + "_19.png","2_" + parseInt(color_var) + "_20.png","2_" + parseInt(color_var) + "_21.png","2_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			
			
			normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 98,
              y: 169,
              font_array: ["2_" + parseInt(color_var) + "_13.png","2_" + parseInt(color_var) + "_14.png","2_" + parseInt(color_var) + "_15.png","2_" + parseInt(color_var) + "_16.png","2_" + parseInt(color_var) + "_17.png","2_" + parseInt(color_var) + "_18.png","2_" + parseInt(color_var) + "_19.png","2_" + parseInt(color_var) + "_20.png","2_" + parseInt(color_var) + "_21.png","2_" + parseInt(color_var) + "_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 305,
              y: 83,
              week_en: [parseInt(color_var) + "_023.png",parseInt(color_var) + "_024.png",parseInt(color_var) + "_025.png",parseInt(color_var) + "_026.png",parseInt(color_var) + "_027.png",parseInt(color_var) + "_028.png",parseInt(color_var) + "_029.png"],
              week_tc: [parseInt(color_var) + "_023.png",parseInt(color_var) + "_024.png",parseInt(color_var) + "_025.png",parseInt(color_var) + "_026.png",parseInt(color_var) + "_027.png",parseInt(color_var) + "_028.png",parseInt(color_var) + "_029.png"],
              week_sc: [parseInt(color_var) + "_023.png",parseInt(color_var) + "_024.png",parseInt(color_var) + "_025.png",parseInt(color_var) + "_026.png",parseInt(color_var) + "_027.png",parseInt(color_var) + "_028.png",parseInt(color_var) + "_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 246,
              day_startY: 65,
              day_sc_array: ["1_" + parseInt(color_var) + "_13.png","1_" + parseInt(color_var) + "_14.png","1_" + parseInt(color_var) + "_15.png","1_" + parseInt(color_var) + "_16.png","1_" + parseInt(color_var) + "_17.png","1_" + parseInt(color_var) + "_18.png","1_" + parseInt(color_var) + "_19.png","1_" + parseInt(color_var) + "_20.png","1_" + parseInt(color_var) + "_21.png","1_" + parseInt(color_var) + "_22.png"],
              day_tc_array: ["1_" + parseInt(color_var) + "_13.png","1_" + parseInt(color_var) + "_14.png","1_" + parseInt(color_var) + "_15.png","1_" + parseInt(color_var) + "_16.png","1_" + parseInt(color_var) + "_17.png","1_" + parseInt(color_var) + "_18.png","1_" + parseInt(color_var) + "_19.png","1_" + parseInt(color_var) + "_20.png","1_" + parseInt(color_var) + "_21.png","1_" + parseInt(color_var) + "_22.png"],
              day_en_array: ["1_" + parseInt(color_var) + "_13.png","1_" + parseInt(color_var) + "_14.png","1_" + parseInt(color_var) + "_15.png","1_" + parseInt(color_var) + "_16.png","1_" + parseInt(color_var) + "_17.png","1_" + parseInt(color_var) + "_18.png","1_" + parseInt(color_var) + "_19.png","1_" + parseInt(color_var) + "_20.png","1_" + parseInt(color_var) + "_21.png","1_" + parseInt(color_var) + "_22.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_am.png',
              am_en_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_pm.png',
              pm_en_path: parseInt(new_dgt) + "_" + parseInt(color_var) + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: parseInt(xxx_clock_h),
              hour_startY: parseInt(yyy_clock_h),
              hour_array: [parseInt(new_dgt) + "_" + parseInt(color_var) + "_01.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_02.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_03.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_04.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_05.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_06.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_07.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_08.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_09.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: parseInt(xxx_clock_m),
              minute_startY: parseInt(yyy_clock_m),
              minute_array: [parseInt(new_dgt) + "_" + parseInt(color_var) + "_01.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_02.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_03.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_04.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_05.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_06.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_07.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_08.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_09.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: parseInt(xxx_clock_s),
              second_startY: parseInt(yyy_clock_s),
              second_array: [parseInt(new_dgt) + "_" + parseInt(color_var) + "_13.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_14.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_15.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_16.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_17.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_18.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_19.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_20.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_21.png",parseInt(new_dgt) + "_" + parseInt(color_var) + "_22.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

			
			
			
			if ( color_var == 1) name_dgt = "COLOR OF NUMBERS - WHITE"
			if ( color_var == 2) name_dgt = "COLOR OF NUMBERS - GREEN"
			if ( color_var == 3) name_dgt = "COLOR OF NUMBERS - AQUA"
			if ( color_var == 4) name_dgt = "COLOR OF NUMBERS - YELLOW"
			if ( color_var == 5) name_dgt = "COLOR OF NUMBERS - GREEN-BLUE"
			if ( color_var == 6) name_dgt = "COLOR OF NUMBERS - ORANGE"
			if ( color_var == 7) name_dgt = "COLOR OF NUMBERS - GRAY"
			
			hmUI.showToast({text: name_dgt });
				
			vibro(28);
		}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 354,
              font_array: ["2_1_13.png","2_1_14.png","2_1_15.png","2_1_16.png","2_1_17.png","2_1_18.png","2_1_19.png","2_1_20.png","2_1_21.png","2_1_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1_stp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '1_steps.png',
              center_x: 227,
              center_y: 227,
              x: 227,
              y: 227,
              start_angle: -3,
              end_angle: 232,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 65,
              y: 201,
              src: '1_sep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 285,
              font_array: ["2_1_13.png","2_1_14.png","2_1_15.png","2_1_16.png","2_1_17.png","2_1_18.png","2_1_19.png","2_1_20.png","2_1_21.png","2_1_22.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_km.png',
              unit_tc: '1_km.png',
              unit_en: '1_km.png',
              imperial_unit_sc: '1_ml.png',
              imperial_unit_tc: '1_ml.png',
              imperial_unit_en: '1_ml.png',
              dot_image: '1_point.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 331,
              y: 235,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 235,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 187,
              font_array: ["2_1_13.png","2_1_14.png","2_1_15.png","2_1_16.png","2_1_17.png","2_1_18.png","2_1_19.png","2_1_20.png","2_1_21.png","2_1_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 187,
              font_array: ["2_1_13.png","2_1_14.png","2_1_15.png","2_1_16.png","2_1_17.png","2_1_18.png","2_1_19.png","2_1_20.png","2_1_21.png","2_1_22.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_slesh.png',
              unit_tc: '1_slesh.png',
              unit_en: '1_slesh.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 137,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'pai_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 188,
              font_array: ["2_1_13.png","2_1_14.png","2_1_15.png","2_1_16.png","2_1_17.png","2_1_18.png","2_1_19.png","2_1_20.png","2_1_21.png","2_1_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 236,
              font_array: ["2_1_13.png","2_1_14.png","2_1_15.png","2_1_16.png","2_1_17.png","2_1_18.png","2_1_19.png","2_1_20.png","2_1_21.png","2_1_22.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 303,
              y: 289,
              image_array: ["WD_1_N.png","WD_2_NE.png","WD_3_E.png","WD_4_SE.png","WD_5_S.png","WD_6_SW.png","WD_7_W.png","WD_8_NW.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 287,
              font_array: ["2_1_13.png","2_1_14.png","2_1_15.png","2_1_16.png","2_1_17.png","2_1_18.png","2_1_19.png","2_1_20.png","2_1_21.png","2_1_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 236,
              font_array: ["2_1_13.png","2_1_14.png","2_1_15.png","2_1_16.png","2_1_17.png","2_1_18.png","2_1_19.png","2_1_20.png","2_1_21.png","2_1_22.png"],
              padding: false,
              h_space: -2,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'weth.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 15,
              y: 197,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 206,
              font_array: ["1_1_13.png","1_1_14.png","1_1_15.png","1_1_16.png","1_1_17.png","1_1_18.png","1_1_19.png","1_1_20.png","1_1_21.png","1_1_22.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_deg.png',
              unit_tc: '1_deg.png',
              unit_en: '1_deg.png',
              imperial_unit_sc: '1_deg.png',
              imperial_unit_tc: '1_deg.png',
              imperial_unit_en: '1_deg.png',
              negative_image: '1_minus.png',
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 82,
                y: 206,
                font_array: ["1_1_13.png","1_1_14.png","1_1_15.png","1_1_16.png","1_1_17.png","1_1_18.png","1_1_19.png","1_1_20.png","1_1_21.png","1_1_22.png"],
                padding: false,
                h_space: 0,
                unit_sc: '1_deg.png',
                unit_tc: '1_deg.png',
                unit_en: '1_deg.png',
                imperial_unit_sc: '1_deg.png',
                imperial_unit_tc: '1_deg.png',
                imperial_unit_en: '1_deg.png',
                negative_image: '1_minus.png',
                invalid_image: '1_eror.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 129,
              y: 22,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 43,
              y: 157,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 210,
              y: 8,
              src: 'BToff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG-1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str.png',
              center_x: 136,
              center_y: 317,
              x: 10,
              y: 55,
              start_angle: -125,
              end_angle: 161,
              invalid_visible: false,
              cover_path: 'BG2.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 337,
              font_array: ["2_1_13.png","2_1_14.png","2_1_15.png","2_1_16.png","2_1_17.png","2_1_18.png","2_1_19.png","2_1_20.png","2_1_21.png","2_1_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str.png',
              center_x: 135,
              center_y: 139,
              x: 11,
              y: 55,
              start_angle: -111,
              end_angle: 160,
              invalid_visible: false,
              cover_path: 'BG1.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sek.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 160,
              font_array: ["2_1_13.png","2_1_14.png","2_1_15.png","2_1_16.png","2_1_17.png","2_1_18.png","2_1_19.png","2_1_20.png","2_1_21.png","2_1_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 288,
              y: 79,
              week_en: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_tc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_sc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 233,
              day_startY: 61,
              day_sc_array: ["1_1_13.png","1_1_14.png","1_1_15.png","1_1_16.png","1_1_17.png","1_1_18.png","1_1_19.png","1_1_20.png","1_1_21.png","1_1_22.png"],
              day_tc_array: ["1_1_13.png","1_1_14.png","1_1_15.png","1_1_16.png","1_1_17.png","1_1_18.png","1_1_19.png","1_1_20.png","1_1_21.png","1_1_22.png"],
              day_en_array: ["1_1_13.png","1_1_14.png","1_1_15.png","1_1_16.png","1_1_17.png","1_1_18.png","1_1_19.png","1_1_20.png","1_1_21.png","1_1_22.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '1_1_am.png',
              am_en_path: '1_1_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '1_1_pm.png',
              pm_en_path: '1_1_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 272,
              hour_startY: 135,
              hour_array: ["1_1_01.png","1_1_02.png","1_1_03.png","1_1_04.png","1_1_05.png","1_1_06.png","1_1_07.png","1_1_08.png","1_1_09.png","1_1_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 272,
              minute_startY: 236,
              minute_array: ["1_1_01.png","1_1_02.png","1_1_03.png","1_1_04.png","1_1_05.png","1_1_06.png","1_1_07.png","1_1_08.png","1_1_09.png","1_1_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 369,
              second_startY: 203,
              second_array: ["1_1_13.png","1_1_14.png","1_1_15.png","1_1_16.png","1_1_17.png","1_1_18.png","1_1_19.png","1_1_20.png","1_1_21.png","1_1_22.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'night_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sek.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'straod.png',
              center_x: 135,
              center_y: 139,
              x: 11,
              y: 55,
              start_angle: -111,
              end_angle: 160,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 160,
              font_array: ["2_7_13.png","2_7_14.png","2_7_15.png","2_7_16.png","2_7_17.png","2_7_18.png","2_7_19.png","2_7_20.png","2_7_21.png","2_7_22.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 288,
              y: 79,
              week_en: ["7_023.png","7_024.png","7_025.png","7_026.png","7_027.png","7_028.png","7_029.png"],
              week_tc: ["7_023.png","7_024.png","7_025.png","7_026.png","7_027.png","7_028.png","7_029.png"],
              week_sc: ["7_023.png","7_024.png","7_025.png","7_026.png","7_027.png","7_028.png","7_029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 233,
              day_startY: 61,
              day_sc_array: ["1_7_13.png","1_7_14.png","1_7_15.png","1_7_16.png","1_7_17.png","1_7_18.png","1_7_19.png","1_7_20.png","1_7_21.png","1_7_22.png"],
              day_tc_array: ["1_7_13.png","1_7_14.png","1_7_15.png","1_7_16.png","1_7_17.png","1_7_18.png","1_7_19.png","1_7_20.png","1_7_21.png","1_7_22.png"],
              day_en_array: ["1_7_13.png","1_7_14.png","1_7_15.png","1_7_16.png","1_7_17.png","1_7_18.png","1_7_19.png","1_7_20.png","1_7_21.png","1_7_22.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '1_7_am.png',
              am_en_path: '1_7_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '1_7_pm.png',
              pm_en_path: '1_7_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 272,
              hour_startY: 135,
              hour_array: ["1_7_01.png","1_7_02.png","1_7_03.png","1_7_04.png","1_7_05.png","1_7_06.png","1_7_07.png","1_7_08.png","1_7_09.png","1_7_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 272,
              minute_startY: 236,
              minute_array: ["1_7_01.png","1_7_02.png","1_7_03.png","1_7_04.png","1_7_05.png","1_7_06.png","1_7_07.png","1_7_08.png","1_7_09.png","1_7_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 369,
              second_startY: 203,
              second_array: ["1_7_13.png","1_7_14.png","1_7_15.png","1_7_16.png","1_7_17.png","1_7_18.png","1_7_19.png","1_7_20.png","1_7_21.png","1_7_22.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 0,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 201,
              y: 343,
              w: 163,
              h: 103,
              src: '00_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 131,
              w: 130,
              h: 52,
              src: '00_empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 96,
              y: 273,
              w: 95,
              h: 95,
              src: '00_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 268,
              y: 185,
              w: 117,
              h: 44,
              src: '00_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 89,
              y: 89,
              w: 95,
              h: 95,
              src: '00_empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 79,
              y: 201,
              w: 86,
              h: 58,
              src: '00_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 328,
              y: 232,
              w: 54,
              h: 45,
              src: '00_empty.png',
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 267,
              y: 184,
              w: 95,
              h: 44,
              src: '00_empty.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 374,
              y: 192,
              w: 77,
              h: 69,
              src: '00_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 17,
              y: 260,
              w: 64,
              h: 69,
              src: '00_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 268,
              y: 232,
              w: 55,
              h: 45,
              src: '00_empty.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 267,
              y: 237,
              w: 95,
              h: 85,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 168,
              y: 185,
              w: 95,
              h: 85,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_visabl()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 272,
              y: 132,
              w: 95,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                colordig()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 222,
              y: 60,
              w: 146,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 5,
              y: 199,
              w: 67,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
vibro(28)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 86,
              y: 199,
              w: 74,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 3,
              y: 199,
              w: 74,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                colordig()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 322,
              y: 131,
              w: 68,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
vibro(28)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

        normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		
     	normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			
		normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);		
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		
		Button_6.setProperty(hmUI.prop.VISIBLE, false);      //  ночь/день 2
		Button_7.setProperty(hmUI.prop.VISIBLE, false);      // изменение цвета 2
		Button_8.setProperty(hmUI.prop.VISIBLE, false);      // погодный сервис 2
		
		normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык атмосферного давления
		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык статистика активностей (калории)
		normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык разминка 
		normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //  ярлык жиросжигание
   

		
   
            // end user_script_end.js

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}