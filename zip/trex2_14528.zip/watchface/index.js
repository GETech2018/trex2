﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_uvi_text_text_img = ''
        let idle_humidity_text_text_img = ''
        let idle_wind_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 221,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr. Piccoli_14.png',
              dot_image: 'Nr. Piccoli_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 365,
              y: 221,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr. Piccoli_14.png',
              dot_image: 'Nr. Piccoli_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 377,
              y: 164,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr. Piccoli_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 273,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 164,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 177,
              font_array: ["Nr.Sistema_01.png","Nr.Sistema_02.png","Nr.Sistema_03.png","Nr.Sistema_04.png","Nr.Sistema_05.png","Nr.Sistema_06.png","Nr.Sistema_07.png","Nr.Sistema_08.png","Nr.Sistema_09.png","Nr.Sistema_10.png"],
              padding: true,
              h_space: 0,
              dot_image: 'Nr.Sistema_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 184,
              month_startY: 378,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 20,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 70,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr. Piccoli_13.png',
              unit_tc: 'Nr. Piccoli_13.png',
              unit_en: 'Nr. Piccoli_13.png',
              negative_image: 'Nr. Piccoli_12.png',
              invalid_image: 'Nr. Piccoli_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 38,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr. Piccoli_13.png',
              unit_tc: 'Nr. Piccoli_13.png',
              unit_en: 'Nr. Piccoli_13.png',
              negative_image: 'Nr. Piccoli_12.png',
              invalid_image: 'Nr. Piccoli_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 50,
              font_array: ["Nr. Meteo_01.png","Nr. Meteo_02.png","Nr. Meteo_03.png","Nr. Meteo_04.png","Nr. Meteo_05.png","Nr. Meteo_06.png","Nr. Meteo_07.png","Nr. Meteo_08.png","Nr. Meteo_09.png","Nr. Meteo_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr. Meteo_14.png',
              unit_tc: 'Nr. Meteo_14.png',
              unit_en: 'Nr. Meteo_14.png',
              negative_image: 'Nr. Meteo_12.png',
              invalid_image: 'Nr. Meteo_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 125,
              day_startY: 370,
              day_sc_array: ["Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png","Secondi_10.png"],
              day_tc_array: ["Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png","Secondi_10.png"],
              day_en_array: ["Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png","Secondi_10.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 350,
              y: 350,
              src: 'BtOff_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 74,
              y: 350,
              src: 'AlOn_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 105,
              y: 332,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 213,
              font_array: ["Nr.Sistema_01.png","Nr.Sistema_02.png","Nr.Sistema_03.png","Nr.Sistema_04.png","Nr.Sistema_05.png","Nr.Sistema_06.png","Nr.Sistema_07.png","Nr.Sistema_08.png","Nr.Sistema_09.png","Nr.Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 108,
              y: 214,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png"],
              image_length: 4,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 177,
              font_array: ["Nr.Sistema_01.png","Nr.Sistema_02.png","Nr.Sistema_03.png","Nr.Sistema_04.png","Nr.Sistema_05.png","Nr.Sistema_06.png","Nr.Sistema_07.png","Nr.Sistema_08.png","Nr.Sistema_09.png","Nr.Sistema_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr.Sistema_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 245,
              y: 209,
              image_array: ["BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 110,
              font_array: ["Nr.Sistema_01.png","Nr.Sistema_02.png","Nr.Sistema_03.png","Nr.Sistema_04.png","Nr.Sistema_05.png","Nr.Sistema_06.png","Nr.Sistema_07.png","Nr.Sistema_08.png","Nr.Sistema_09.png","Nr.Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 242,
              y: 133,
              image_array: ["Cal_01.png","Cal_02.png","Cal_03.png","Cal_04.png","Cal_05.png","Cal_06.png"],
              image_length: 6,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 110,
              font_array: ["Nr.Sistema_01.png","Nr.Sistema_02.png","Nr.Sistema_03.png","Nr.Sistema_04.png","Nr.Sistema_05.png","Nr.Sistema_06.png","Nr.Sistema_07.png","Nr.Sistema_08.png","Nr.Sistema_09.png","Nr.Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 114,
              y: 132,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 251,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 244,
              minute_startY: 251,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 364,
              second_startY: 273,
              second_array: ["Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png","Secondi_10.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 219,
              y: 251,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 221,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr. Piccoli_14.png',
              dot_image: 'Nr. Piccoli_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 365,
              y: 221,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr. Piccoli_14.png',
              dot_image: 'Nr. Piccoli_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 377,
              y: 164,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr. Piccoli_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 273,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 164,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 177,
              font_array: ["Nr.Sistema_01.png","Nr.Sistema_02.png","Nr.Sistema_03.png","Nr.Sistema_04.png","Nr.Sistema_05.png","Nr.Sistema_06.png","Nr.Sistema_07.png","Nr.Sistema_08.png","Nr.Sistema_09.png","Nr.Sistema_10.png"],
              padding: true,
              h_space: 0,
              dot_image: 'Nr.Sistema_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 184,
              month_startY: 378,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 20,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 70,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr. Piccoli_13.png',
              unit_tc: 'Nr. Piccoli_13.png',
              unit_en: 'Nr. Piccoli_13.png',
              negative_image: 'Nr. Piccoli_12.png',
              invalid_image: 'Nr. Piccoli_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 38,
              font_array: ["Nr. Piccoli_01.png","Nr. Piccoli_02.png","Nr. Piccoli_03.png","Nr. Piccoli_04.png","Nr. Piccoli_05.png","Nr. Piccoli_06.png","Nr. Piccoli_07.png","Nr. Piccoli_08.png","Nr. Piccoli_09.png","Nr. Piccoli_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr. Piccoli_13.png',
              unit_tc: 'Nr. Piccoli_13.png',
              unit_en: 'Nr. Piccoli_13.png',
              negative_image: 'Nr. Piccoli_12.png',
              invalid_image: 'Nr. Piccoli_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 50,
              font_array: ["Nr. Meteo_01.png","Nr. Meteo_02.png","Nr. Meteo_03.png","Nr. Meteo_04.png","Nr. Meteo_05.png","Nr. Meteo_06.png","Nr. Meteo_07.png","Nr. Meteo_08.png","Nr. Meteo_09.png","Nr. Meteo_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr. Meteo_14.png',
              unit_tc: 'Nr. Meteo_14.png',
              unit_en: 'Nr. Meteo_14.png',
              negative_image: 'Nr. Meteo_12.png',
              invalid_image: 'Nr. Meteo_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 125,
              day_startY: 370,
              day_sc_array: ["Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png","Secondi_10.png"],
              day_tc_array: ["Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png","Secondi_10.png"],
              day_en_array: ["Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png","Secondi_10.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 350,
              y: 350,
              src: 'BtOff_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 74,
              y: 350,
              src: 'AlOn_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 105,
              y: 332,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 213,
              font_array: ["Nr.Sistema_01.png","Nr.Sistema_02.png","Nr.Sistema_03.png","Nr.Sistema_04.png","Nr.Sistema_05.png","Nr.Sistema_06.png","Nr.Sistema_07.png","Nr.Sistema_08.png","Nr.Sistema_09.png","Nr.Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 108,
              y: 214,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png"],
              image_length: 4,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 177,
              font_array: ["Nr.Sistema_01.png","Nr.Sistema_02.png","Nr.Sistema_03.png","Nr.Sistema_04.png","Nr.Sistema_05.png","Nr.Sistema_06.png","Nr.Sistema_07.png","Nr.Sistema_08.png","Nr.Sistema_09.png","Nr.Sistema_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr.Sistema_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 245,
              y: 209,
              image_array: ["BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 110,
              font_array: ["Nr.Sistema_01.png","Nr.Sistema_02.png","Nr.Sistema_03.png","Nr.Sistema_04.png","Nr.Sistema_05.png","Nr.Sistema_06.png","Nr.Sistema_07.png","Nr.Sistema_08.png","Nr.Sistema_09.png","Nr.Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 242,
              y: 133,
              image_array: ["Cal_01.png","Cal_02.png","Cal_03.png","Cal_04.png","Cal_05.png","Cal_06.png"],
              image_length: 6,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 110,
              font_array: ["Nr.Sistema_01.png","Nr.Sistema_02.png","Nr.Sistema_03.png","Nr.Sistema_04.png","Nr.Sistema_05.png","Nr.Sistema_06.png","Nr.Sistema_07.png","Nr.Sistema_08.png","Nr.Sistema_09.png","Nr.Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 114,
              y: 132,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 251,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 244,
              minute_startY: 251,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 364,
              second_startY: 273,
              second_array: ["Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png","Secondi_10.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 219,
              y: 251,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}