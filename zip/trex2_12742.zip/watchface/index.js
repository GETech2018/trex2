﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 18;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 18;
        let normal_battery_TextRotate_error_img_width = 1;
        let normal_battery_image_progress_img_level = ''
        let normal_spo2_text_text_img = ''
        let normal_pai_total_TextRotate = new Array(3);
        let normal_pai_total_TextRotate_ASCIIARRAY = new Array(10);
        let normal_pai_total_TextRotate_img_width = 11;
        let normal_pai_total_TextRotate_error_img_width = 1;
        let normal_wind_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 18;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 37;
        let normal_distance_TextRotate_dot_width = 8;
        let normal_distance_TextRotate_error_img_width = 1;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 18;
        let normal_step_TextRotate_error_img_width = 1;
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 18;
        let idle_battery_TextRotate_unit = null;
        let idle_battery_TextRotate_unit_width = 18;
        let idle_battery_TextRotate_error_img_width = 1;
        let idle_battery_image_progress_img_level = ''
        let idle_spo2_text_text_img = ''
        let idle_pai_total_TextRotate = new Array(3);
        let idle_pai_total_TextRotate_ASCIIARRAY = new Array(10);
        let idle_pai_total_TextRotate_img_width = 11;
        let idle_pai_total_TextRotate_error_img_width = 1;
        let idle_wind_text_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_TextRotate = new Array(5);
        let idle_distance_TextRotate_ASCIIARRAY = new Array(10);
        let idle_distance_TextRotate_img_width = 18;
        let idle_distance_TextRotate_unit = null;
        let idle_distance_TextRotate_unit_width = 37;
        let idle_distance_TextRotate_dot_width = 8;
        let idle_distance_TextRotate_error_img_width = 1;
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 18;
        let idle_step_TextRotate_error_img_width = 1;
        let idle_step_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 99,
              // y: 337,
              // font_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: 43,
              // unit_en: 'percent.png',
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'font_day_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'font_day_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'font_day_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'font_day_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'font_day_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'font_day_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'font_day_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'font_day_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'font_day_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'font_day_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 99,
                center_y: 337,
                pos_x: 99,
                pos_y: 337,
                angle: 43,
                src: 'font_day_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 99,
              center_y: 337,
              pos_x: 99,
              pos_y: 337,
              angle: 43,
              src: 'percent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 247,
              image_array: ["img_bat_1.png","img_bat_2.png","img_bat_3.png","img_bat_4.png","img_bat_5.png","img_bat_6.png","img_bat_7.png","img_bat_8.png","img_bat_9.png","img_bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 333,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_pai_total_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 232,
              // y: 383,
              // font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 52,
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_pai_total_TextRotate_ASCIIARRAY[0] = 'font_small_0.png';  // set of images with numbers
            normal_pai_total_TextRotate_ASCIIARRAY[1] = 'font_small_1.png';  // set of images with numbers
            normal_pai_total_TextRotate_ASCIIARRAY[2] = 'font_small_2.png';  // set of images with numbers
            normal_pai_total_TextRotate_ASCIIARRAY[3] = 'font_small_3.png';  // set of images with numbers
            normal_pai_total_TextRotate_ASCIIARRAY[4] = 'font_small_4.png';  // set of images with numbers
            normal_pai_total_TextRotate_ASCIIARRAY[5] = 'font_small_5.png';  // set of images with numbers
            normal_pai_total_TextRotate_ASCIIARRAY[6] = 'font_small_6.png';  // set of images with numbers
            normal_pai_total_TextRotate_ASCIIARRAY[7] = 'font_small_7.png';  // set of images with numbers
            normal_pai_total_TextRotate_ASCIIARRAY[8] = 'font_small_8.png';  // set of images with numbers
            normal_pai_total_TextRotate_ASCIIARRAY[9] = 'font_small_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_pai_total_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 232,
                center_y: 383,
                pos_x: 232,
                pos_y: 383,
                angle: 52,
                src: 'font_small_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_pai_total_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 395,
              y: 188,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 383,
              y: 221,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_3.png',
              unit_tc: 'pointer_3.png',
              unit_en: 'pointer_3.png',
              negative_image: 'pointer_2.png',
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 380,
              y: 250,
              image_array: ["weaher_1.png","weaher_2.png","weaher_3.png","weaher_4.png","weaher_5.png","weaher_6.png","weaher_7.png","weaher_8.png","weaher_9.png","weaher_10.png","weaher_11.png","weaher_12.png","weaher_13.png","weaher_14.png","weaher_15.png","weaher_16.png","weaher_17.png","weaher_18.png","weaher_19.png","weaher_20.png","weaher_21.png","weaher_22.png","weaher_23.png","weaher_24.png","weaher_25.png","weaher_26.png","weaher_27.png","weaher_28.png","weaher_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 281,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 224,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 361,
              // y: 118,
              // font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 31,
              // unit_en: 'km.png',
              // imperial_unit_en: 'ml.png',
              // invalid_image: 'dot.png',
              // dot_image: 'pointer_1.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'font_act_0.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'font_act_1.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'font_act_2.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'font_act_3.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'font_act_4.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'font_act_5.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'font_act_6.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'font_act_7.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'font_act_8.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'font_act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 361,
                center_y: 118,
                pos_x: 361,
                pos_y: 118,
                angle: 31,
                src: 'font_act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 361,
              center_y: 118,
              pos_x: 361,
              pos_y: 118,
              angle: 31,
              src: 'km.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'ml.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 294,
              // y: 46,
              // font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: 25,
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'font_act_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'font_act_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'font_act_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'font_act_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'font_act_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'font_act_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'font_act_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'font_act_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'font_act_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'font_act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 294,
                center_y: 46,
                pos_x: 294,
                pos_y: 46,
                angle: 25,
                src: 'font_act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 212,
              y: 7,
              image_array: ["img_step_1.png","img_step_2.png","img_step_3.png","img_step_4.png","img_step_5.png","img_step_6.png","img_step_7.png","img_step_8.png","img_step_9.png","img_step_10.png","img_step_11.png","img_step_12.png","img_step_13.png","img_step_14.png","img_step_15.png","img_step_16.png","img_step_17.png"],
              image_length: 17,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 16,
              y: 179,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 4,
              month_startY: 212,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 147,
              day_startY: 223,
              day_sc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_tc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_en_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 84,
              am_y: 62,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 84,
              pm_y: 62,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 97,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_unit_sc: 'pointer_0.png',
              hour_unit_tc: 'pointer_0.png',
              hour_unit_en: 'pointer_0.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 161,
              minute_startY: 97,
              minute_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 299,
              hour_centerY: 333,
              hour_posX: 6,
              hour_posY: 46,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 299,
              minute_centerY: 333,
              minute_posX: 6,
              minute_posY: 67,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 299,
              second_centerY: 333,
              second_posX: 2,
              second_posY: 75,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 99,
              // y: 337,
              // font_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: 43,
              // unit_en: 'percent.png',
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'font_day_0.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'font_day_1.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'font_day_2.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'font_day_3.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'font_day_4.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'font_day_5.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'font_day_6.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'font_day_7.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'font_day_8.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'font_day_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 99,
                center_y: 337,
                pos_x: 99,
                pos_y: 337,
                angle: 43,
                src: 'font_day_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 99,
              center_y: 337,
              pos_x: 99,
              pos_y: 337,
              angle: 43,
              src: 'percent.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 247,
              image_array: ["img_bat_1.png","img_bat_2.png","img_bat_3.png","img_bat_4.png","img_bat_5.png","img_bat_6.png","img_bat_7.png","img_bat_8.png","img_bat_9.png","img_bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 333,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_pai_total_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 232,
              // y: 383,
              // font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 52,
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_pai_total_TextRotate_ASCIIARRAY[0] = 'font_small_0.png';  // set of images with numbers
            idle_pai_total_TextRotate_ASCIIARRAY[1] = 'font_small_1.png';  // set of images with numbers
            idle_pai_total_TextRotate_ASCIIARRAY[2] = 'font_small_2.png';  // set of images with numbers
            idle_pai_total_TextRotate_ASCIIARRAY[3] = 'font_small_3.png';  // set of images with numbers
            idle_pai_total_TextRotate_ASCIIARRAY[4] = 'font_small_4.png';  // set of images with numbers
            idle_pai_total_TextRotate_ASCIIARRAY[5] = 'font_small_5.png';  // set of images with numbers
            idle_pai_total_TextRotate_ASCIIARRAY[6] = 'font_small_6.png';  // set of images with numbers
            idle_pai_total_TextRotate_ASCIIARRAY[7] = 'font_small_7.png';  // set of images with numbers
            idle_pai_total_TextRotate_ASCIIARRAY[8] = 'font_small_8.png';  // set of images with numbers
            idle_pai_total_TextRotate_ASCIIARRAY[9] = 'font_small_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_pai_total_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 232,
                center_y: 383,
                pos_x: 232,
                pos_y: 383,
                angle: 52,
                src: 'font_small_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_pai_total_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 395,
              y: 188,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 383,
              y: 221,
              font_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_3.png',
              unit_tc: 'pointer_3.png',
              unit_en: 'pointer_3.png',
              negative_image: 'pointer_2.png',
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 380,
              y: 250,
              image_array: ["weaher_1.png","weaher_2.png","weaher_3.png","weaher_4.png","weaher_5.png","weaher_6.png","weaher_7.png","weaher_8.png","weaher_9.png","weaher_10.png","weaher_11.png","weaher_12.png","weaher_13.png","weaher_14.png","weaher_15.png","weaher_16.png","weaher_17.png","weaher_18.png","weaher_19.png","weaher_20.png","weaher_21.png","weaher_22.png","weaher_23.png","weaher_24.png","weaher_25.png","weaher_26.png","weaher_27.png","weaher_28.png","weaher_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 281,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 224,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 361,
              // y: 118,
              // font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 31,
              // unit_en: 'km.png',
              // imperial_unit_en: 'ml.png',
              // invalid_image: 'dot.png',
              // dot_image: 'pointer_1.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextRotate_ASCIIARRAY[0] = 'font_act_0.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[1] = 'font_act_1.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[2] = 'font_act_2.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[3] = 'font_act_3.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[4] = 'font_act_4.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[5] = 'font_act_5.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[6] = 'font_act_6.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[7] = 'font_act_7.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[8] = 'font_act_8.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[9] = 'font_act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 361,
                center_y: 118,
                pos_x: 361,
                pos_y: 118,
                angle: 31,
                src: 'font_act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 361,
              center_y: 118,
              pos_x: 361,
              pos_y: 118,
              angle: 31,
              src: 'km.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (mileageUnit == 1) {
              idle_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'ml.png');
            };
            //end of ignored block

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 294,
              // y: 46,
              // font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: 25,
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'font_act_0.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'font_act_1.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'font_act_2.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'font_act_3.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'font_act_4.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'font_act_5.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'font_act_6.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'font_act_7.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'font_act_8.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'font_act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 294,
                center_y: 46,
                pos_x: 294,
                pos_y: 46,
                angle: 25,
                src: 'font_act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 212,
              y: 7,
              image_array: ["img_step_1.png","img_step_2.png","img_step_3.png","img_step_4.png","img_step_5.png","img_step_6.png","img_step_7.png","img_step_8.png","img_step_9.png","img_step_10.png","img_step_11.png","img_step_12.png","img_step_13.png","img_step_14.png","img_step_15.png","img_step_16.png","img_step_17.png"],
              image_length: 17,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 16,
              y: 179,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 4,
              month_startY: 212,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 147,
              day_startY: 223,
              day_sc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_tc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_en_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 84,
              am_y: 62,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 84,
              pm_y: 62,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 97,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_unit_sc: 'pointer_0.png',
              hour_unit_tc: 'pointer_0.png',
              hour_unit_en: 'pointer_0.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 161,
              minute_startY: 97,
              minute_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 299,
              hour_centerY: 333,
              hour_posX: 6,
              hour_posY: 46,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 299,
              minute_centerY: 333,
              minute_posX: 6,
              minute_posY: 67,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 299,
              second_centerY: 333,
              second_posX: 2,
              second_posY: 75,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 262,
              y: 135,
              w: 47,
              h: 47,
              src: 'dot.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 87,
              w: 99,
              h: 95,
              src: 'dot.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 374,
              y: 251,
              w: 69,
              h: 56,
              src: 'dot.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 367,
              y: 170,
              w: 77,
              h: 35,
              src: 'dot.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 368,
              y: 208,
              w: 76,
              h: 38,
              src: 'dot.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 201,
              y: 372,
              w: 56,
              h: 57,
              src: 'dot.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 166,
              y: 312,
              w: 57,
              h: 57,
              src: 'dot.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 263,
              w: 124,
              h: 47,
              src: 'dot.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 25,
              w: 106,
              h: 62,
              src: 'dot.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            function text_update() {

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + 1 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 99 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 99 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.POS_X, 99 - normal_battery_TextRotate_error_img_width / 2);
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate pai_total_PAI');
              let totalPAI = pai.totalpai;
              let normal_pai_total_rotate_string = parseInt(totalPAI).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_pai_total_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && normal_pai_total_rotate_string.length > 0 && normal_pai_total_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_pai_total_TextRotate_posOffset = normal_pai_total_TextRotate_img_width * normal_pai_total_rotate_string.length;
                  img_offset -= normal_pai_total_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_pai_total_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_pai_total_TextRotate[index].setProperty(hmUI.prop.POS_X, 232 + img_offset);
                      normal_pai_total_TextRotate[index].setProperty(hmUI.prop.SRC, normal_pai_total_TextRotate_ASCIIARRAY[charCode]);
                      normal_pai_total_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_pai_total_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_pai_total_TextRotate[0].setProperty(hmUI.prop.POS_X, 232 - normal_pai_total_TextRotate_error_img_width / 2);
                  normal_pai_total_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_pai_total_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  img_offset -= normal_distance_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 361 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 361 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'pointer_1.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 361 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 361 - normal_distance_TextRotate_error_img_width / 2);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + 1 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 294 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_step_TextRotate[0].setProperty(hmUI.prop.POS_X, 294 - normal_step_TextRotate_error_img_width / 2);
                  normal_step_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_step_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + 1 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 99 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 99 + img_offset);
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.POS_X, 99 - idle_battery_TextRotate_error_img_width / 2);
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate pai_total_PAI');
              let idle_pai_total_rotate_string = parseInt(totalPAI).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_pai_total_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && idle_pai_total_rotate_string.length > 0 && idle_pai_total_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_pai_total_TextRotate_posOffset = idle_pai_total_TextRotate_img_width * idle_pai_total_rotate_string.length;
                  img_offset -= idle_pai_total_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_pai_total_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_pai_total_TextRotate[index].setProperty(hmUI.prop.POS_X, 232 + img_offset);
                      idle_pai_total_TextRotate[index].setProperty(hmUI.prop.SRC, idle_pai_total_TextRotate_ASCIIARRAY[charCode]);
                      idle_pai_total_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_pai_total_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_pai_total_TextRotate[0].setProperty(hmUI.prop.POS_X, 232 - idle_pai_total_TextRotate_error_img_width / 2);
                  idle_pai_total_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_pai_total_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate DISTANCE');
              let idle_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_rotate_string.length > 0 && idle_distance_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_distance_TextRotate_posOffset = idle_distance_TextRotate_img_width * idle_distance_rotate_string.length;
                  idle_distance_TextRotate_posOffset = idle_distance_TextRotate_posOffset - idle_distance_TextRotate_img_width + idle_distance_TextRotate_dot_width;
                  img_offset -= idle_distance_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 361 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, idle_distance_TextRotate_ASCIIARRAY[charCode]);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 361 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'pointer_1.png');
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 361 + img_offset);
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 361 - idle_distance_TextRotate_error_img_width / 2);
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  idle_step_TextRotate_posOffset = idle_step_TextRotate_posOffset + 1 * (idle_step_rotate_string.length - 1);
                  img_offset -= idle_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 294 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_step_TextRotate[0].setProperty(hmUI.prop.POS_X, 294 - idle_step_TextRotate_error_img_width / 2);
                  idle_step_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_step_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}