/*
** Facemaker bundle tool v0.0.1
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img = '';
		let normal_digital_clock_img_hour = '';
		let normal_digital_clock_img_minute = '';
		let normal_digital_clock_img_second = '';
		let normal_date_current_date_month = '';
		let normal_date_current_date_monthday = '';
		let normal_battery_current_text_img = '';
		let normal_step_current_text_img = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

			normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 458,
				h: 458,
				src: '0002.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_digital_clock_img_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
				hour_startX: 71,
				hour_startY: 179,
				hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
				hour_zero: true,
				hour_space: 0,
				hour_align: hmUI.align.CENTER_H,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_digital_clock_img_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
				minute_startX: 205,
				minute_startY: 179,
				minute_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
				minute_zero: true,
				minute_space: 0,
				minute_align: hmUI.align.CENTER_H,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_digital_clock_img_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
				second_startX: 327,
				second_startY: 219,
				second_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
				second_zero: true,
				second_space: 0,
				second_align: hmUI.align.LEFT,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_date_current_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
				month_startX: 151,
				month_startY: 325,
				month_sc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
				month_tc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
				month_en_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
				month_zero: true,
				month_space: 1,
				month_align: hmUI.align.LEFT,
				month_is_character: false,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_date_current_date_monthday = hmUI.createWidget(hmUI.widget.IMG_DATE, {
				day_startX: 247,
				day_startY: 325,
				day_sc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
				day_tc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
				day_en_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
				day_zero: true,
				day_space: 1,
				day_align: hmUI.align.CENTER_H,
				day_is_character: false,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_battery_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
				x: 137,
				y: 109,
				font_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png"],
				padding: false,
				h_space: 0,
				align_h: hmUI.align.CENTER_H,
				type: hmUI.data_type.BATTERY,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
				x: 242,
				y: 109,
				font_array: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png"],
				padding: false,
				h_space: 0,
				align_h: hmUI.align.LEFT,
				type: hmUI.data_type.STEP,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},

		onReady() {
			console.log('index page.js on ready invoke')
		},

		onShow() {
			console.log('index page.js on show invoke')
		},

		onHide() {
			console.log('index page.js on hide invoke')
		},

		onDestory() {
			console.log('index page.js on destory invoke')
		},

	});	})()
} catch (e) {
	console.log(e)
}