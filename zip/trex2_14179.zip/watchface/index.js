﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_wind_text_text_img = ''
        let idle_humidity_text_text_img = ''
        let idle_uvi_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_week_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 396,
              font_array: ["NRP_01.png","NRP_02.png","NRP_03.png","NRP_04.png","NRP_05.png","NRP_06.png","NRP_07.png","NRP_08.png","NRP_09.png","NRP_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'NRP_12.png',
              dot_image: 'NRP_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 416,
              font_array: ["NRP_01.png","NRP_02.png","NRP_03.png","NRP_04.png","NRP_05.png","NRP_06.png","NRP_07.png","NRP_08.png","NRP_09.png","NRP_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'NRP_12.png',
              dot_image: 'NRP_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 13,
              font_array: ["NRP_01.png","NRP_02.png","NRP_03.png","NRP_04.png","NRP_05.png","NRP_06.png","NRP_07.png","NRP_08.png","NRP_09.png","NRP_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 38,
              font_array: ["NRP_01.png","NRP_02.png","NRP_03.png","NRP_04.png","NRP_05.png","NRP_06.png","NRP_07.png","NRP_08.png","NRP_09.png","NRP_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 38,
              font_array: ["NRP_01.png","NRP_02.png","NRP_03.png","NRP_04.png","NRP_05.png","NRP_06.png","NRP_07.png","NRP_08.png","NRP_09.png","NRP_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'NRP_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 213,
              font_array: ["NRA_01.png","NRA_02.png","NRA_03.png","NRA_04.png","NRA_05.png","NRA_06.png","NRA_07.png","NRA_08.png","NRA_09.png","NRA_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 233,
              image_array: ["Hrt_01.png","Hrt_02.png","Hrt_03.png","Hrt_04.png","Hrt_05.png","Hrt_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 357,
              font_array: ["NRA_01.png","NRA_02.png","NRA_03.png","NRA_04.png","NRA_05.png","NRA_06.png","NRA_07.png","NRA_08.png","NRA_09.png","NRA_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 308,
              font_array: ["NRA_01.png","NRA_02.png","NRA_03.png","NRA_04.png","NRA_05.png","NRA_06.png","NRA_07.png","NRA_08.png","NRA_09.png","NRA_10.png"],
              padding: false,
              h_space: 3,
              dot_image: 'NRA_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 260,
              font_array: ["NRA_01.png","NRA_02.png","NRA_03.png","NRA_04.png","NRA_05.png","NRA_06.png","NRA_07.png","NRA_08.png","NRA_09.png","NRA_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 231,
              y: 260,
              image_array: ["Steps_01.png","Steps_02.png","Steps_03.png","Steps_04.png","Steps_05.png","Steps_06.png","Steps_07.png","Steps_08.png","Steps_09.png"],
              image_length: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 292,
              y: 182,
              src: 'Lk_01.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 38,
              y: 117,
              src: 'Bt_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 377,
              y: 93,
              src: 'Al_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 95,
              month_startY: 182,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 33,
              month_startY: 182,
              month_sc_array: ["NRG_01.png","NRG_02.png","NRG_03.png","NRG_04.png","NRG_05.png","NRG_06.png","NRG_07.png","NRG_08.png","NRG_09.png","NRG_10.png"],
              month_tc_array: ["NRG_01.png","NRG_02.png","NRG_03.png","NRG_04.png","NRG_05.png","NRG_06.png","NRG_07.png","NRG_08.png","NRG_09.png","NRG_10.png"],
              month_en_array: ["NRG_01.png","NRG_02.png","NRG_03.png","NRG_04.png","NRG_05.png","NRG_06.png","NRG_07.png","NRG_08.png","NRG_09.png","NRG_10.png"],
              month_zero: 1,
              month_space: 7,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 15,
              y: 158,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 172,
              font_array: ["NRM_01.png","NRM_02.png","NRM_03.png","NRM_04.png","NRM_05.png","NRM_06.png","NRM_07.png","NRM_08.png","NRM_09.png","NRM_10.png"],
              padding: false,
              h_space: 4,
              negative_image: 'NRM_11.png',
              invalid_image: 'NRM_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 374,
              y: 121,
              image_array: ["Meteo_01.png","Meteo_02.png","Meteo_03.png","Meteo_04.png","Meteo_05.png","Meteo_06.png","Meteo_07.png","Meteo_08.png","Meteo_09.png","Meteo_10.png","Meteo_11.png","Meteo_12.png","Meteo_13.png","Meteo_14.png","Meteo_15.png","Meteo_16.png","Meteo_17.png","Meteo_18.png","Meteo_19.png","Meteo_20.png","Meteo_21.png","Meteo_22.png","Meteo_23.png","Meteo_24.png","Meteo_25.png","Meteo_26.png","Meteo_27.png","Meteo_28.png","Meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 12,
              y: 244,
              font_array: ["NRA_01.png","NRA_02.png","NRA_03.png","NRA_04.png","NRA_05.png","NRA_06.png","NRA_07.png","NRA_08.png","NRA_09.png","NRA_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 82,
              y: 245,
              image_array: ["Bat_01.png","Bat_02.png","Bat_03.png","Bat_04.png","Bat_05.png","Bat_06.png","Bat_07.png","Bat_08.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 68,
              hour_startY: 74,
              hour_array: ["NR1_01.png","NR1_02.png","NR1_03.png","NR1_04.png","NR1_05.png","NR1_06.png","NR1_07.png","NR1_08.png","NR1_09.png","NR1_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 175,
              minute_startY: 74,
              minute_array: ["NR1_01.png","NR1_02.png","NR1_03.png","NR1_04.png","NR1_05.png","NR1_06.png","NR1_07.png","NR1_08.png","NR1_09.png","NR1_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 293,
              second_startY: 74,
              second_array: ["NR2_01.png","NR2_02.png","NR2_03.png","NR2_04.png","NR2_05.png","NR2_06.png","NR2_07.png","NR2_08.png","NR2_09.png","NR2_10.png"],
              second_zero: 1,
              second_space: 10,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Sec_01.png',
              second_centerX: 226,
              second_centerY: 226,
              second_posX: 38,
              second_posY: 252,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 396,
              font_array: ["NRP_01.png","NRP_02.png","NRP_03.png","NRP_04.png","NRP_05.png","NRP_06.png","NRP_07.png","NRP_08.png","NRP_09.png","NRP_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'NRP_12.png',
              dot_image: 'NRP_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 416,
              font_array: ["NRP_01.png","NRP_02.png","NRP_03.png","NRP_04.png","NRP_05.png","NRP_06.png","NRP_07.png","NRP_08.png","NRP_09.png","NRP_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'NRP_12.png',
              dot_image: 'NRP_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 13,
              font_array: ["NRP_01.png","NRP_02.png","NRP_03.png","NRP_04.png","NRP_05.png","NRP_06.png","NRP_07.png","NRP_08.png","NRP_09.png","NRP_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 38,
              font_array: ["NRP_01.png","NRP_02.png","NRP_03.png","NRP_04.png","NRP_05.png","NRP_06.png","NRP_07.png","NRP_08.png","NRP_09.png","NRP_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 38,
              font_array: ["NRP_01.png","NRP_02.png","NRP_03.png","NRP_04.png","NRP_05.png","NRP_06.png","NRP_07.png","NRP_08.png","NRP_09.png","NRP_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'NRP_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 213,
              font_array: ["NRA_01.png","NRA_02.png","NRA_03.png","NRA_04.png","NRA_05.png","NRA_06.png","NRA_07.png","NRA_08.png","NRA_09.png","NRA_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 233,
              image_array: ["Hrt_01.png","Hrt_02.png","Hrt_03.png","Hrt_04.png","Hrt_05.png","Hrt_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 357,
              font_array: ["NRA_01.png","NRA_02.png","NRA_03.png","NRA_04.png","NRA_05.png","NRA_06.png","NRA_07.png","NRA_08.png","NRA_09.png","NRA_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 308,
              font_array: ["NRA_01.png","NRA_02.png","NRA_03.png","NRA_04.png","NRA_05.png","NRA_06.png","NRA_07.png","NRA_08.png","NRA_09.png","NRA_10.png"],
              padding: false,
              h_space: 3,
              dot_image: 'NRA_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 260,
              font_array: ["NRA_01.png","NRA_02.png","NRA_03.png","NRA_04.png","NRA_05.png","NRA_06.png","NRA_07.png","NRA_08.png","NRA_09.png","NRA_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 231,
              y: 260,
              image_array: ["Steps_01.png","Steps_02.png","Steps_03.png","Steps_04.png","Steps_05.png","Steps_06.png","Steps_07.png","Steps_08.png","Steps_09.png"],
              image_length: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 292,
              y: 182,
              src: 'Lk_01.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 38,
              y: 117,
              src: 'Bt_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 377,
              y: 93,
              src: 'Al_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 95,
              month_startY: 182,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 33,
              month_startY: 182,
              month_sc_array: ["NRG_01.png","NRG_02.png","NRG_03.png","NRG_04.png","NRG_05.png","NRG_06.png","NRG_07.png","NRG_08.png","NRG_09.png","NRG_10.png"],
              month_tc_array: ["NRG_01.png","NRG_02.png","NRG_03.png","NRG_04.png","NRG_05.png","NRG_06.png","NRG_07.png","NRG_08.png","NRG_09.png","NRG_10.png"],
              month_en_array: ["NRG_01.png","NRG_02.png","NRG_03.png","NRG_04.png","NRG_05.png","NRG_06.png","NRG_07.png","NRG_08.png","NRG_09.png","NRG_10.png"],
              month_zero: 1,
              month_space: 7,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 15,
              y: 158,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 172,
              font_array: ["NRM_01.png","NRM_02.png","NRM_03.png","NRM_04.png","NRM_05.png","NRM_06.png","NRM_07.png","NRM_08.png","NRM_09.png","NRM_10.png"],
              padding: false,
              h_space: 4,
              negative_image: 'NRM_11.png',
              invalid_image: 'NRM_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 374,
              y: 121,
              image_array: ["Meteo_01.png","Meteo_02.png","Meteo_03.png","Meteo_04.png","Meteo_05.png","Meteo_06.png","Meteo_07.png","Meteo_08.png","Meteo_09.png","Meteo_10.png","Meteo_11.png","Meteo_12.png","Meteo_13.png","Meteo_14.png","Meteo_15.png","Meteo_16.png","Meteo_17.png","Meteo_18.png","Meteo_19.png","Meteo_20.png","Meteo_21.png","Meteo_22.png","Meteo_23.png","Meteo_24.png","Meteo_25.png","Meteo_26.png","Meteo_27.png","Meteo_28.png","Meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 12,
              y: 244,
              font_array: ["NRA_01.png","NRA_02.png","NRA_03.png","NRA_04.png","NRA_05.png","NRA_06.png","NRA_07.png","NRA_08.png","NRA_09.png","NRA_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 82,
              y: 245,
              image_array: ["Bat_01.png","Bat_02.png","Bat_03.png","Bat_04.png","Bat_05.png","Bat_06.png","Bat_07.png","Bat_08.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 68,
              hour_startY: 74,
              hour_array: ["NR1_01.png","NR1_02.png","NR1_03.png","NR1_04.png","NR1_05.png","NR1_06.png","NR1_07.png","NR1_08.png","NR1_09.png","NR1_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 175,
              minute_startY: 74,
              minute_array: ["NR1_01.png","NR1_02.png","NR1_03.png","NR1_04.png","NR1_05.png","NR1_06.png","NR1_07.png","NR1_08.png","NR1_09.png","NR1_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 293,
              second_startY: 74,
              second_array: ["NR2_01.png","NR2_02.png","NR2_03.png","NR2_04.png","NR2_05.png","NR2_06.png","NR2_07.png","NR2_08.png","NR2_09.png","NR2_10.png"],
              second_zero: 1,
              second_space: 10,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Sec_01.png',
              second_centerX: 226,
              second_centerY: 226,
              second_posX: 38,
              second_posY: 252,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}