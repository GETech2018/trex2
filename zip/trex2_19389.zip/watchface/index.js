/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v2.1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img1 = '';
		let normal_moon_phase30_imageset2 = '';
		let normal_daynight_imageset3 = '';
		let normal_daynight_imageset4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_battery_imageset7 = '';
		let normal_img8 = '';
		let normal_sunrise_text9 = '';
		let normal_sunset_text10 = '';
		let normal_img11 = '';
		let normal_img12 = '';
		let normal_altitude_imagecombo15 = '';
		let normal_img16 = '';
		let normal_temperature_current_imagecombo18 = '';
		let normal_wind_bearing_imageset20 = '';
		let normal_img21 = '';
		let normal_steps_imagecombo24 = '';
		let normal_img25 = '';
		let normal_second_rotary27 = '';
		let timeInterval;
		let normal_hour24_rotary28 = '';
		let normal_minute_rotary29 = '';
		let normal_month_imageset31 = '';
		let normal_week_imageset32 = '';
		let normal_date_imagecombo33 = '';
		let normal_month_imageset35 = '';
		let normal_week_imageset36 = '';
		let normal_date_imagecombo37 = '';
		let normal_month_imageset39 = '';
		let normal_week_imageset40 = '';
		let normal_date_imagecombo41 = '';
		let normal_month_imageset43 = '';
		let normal_week_imageset44 = '';
		let normal_date_imagecombo45 = '';
		let normal_month_imageset47 = '';
		let normal_week_imageset48 = '';
		let normal_date_imagecombo49 = '';
		let normal_month_imageset51 = '';
		let normal_week_imageset52 = '';
		let normal_date_imagecombo53 = '';
		let normal_air_temperature_shortcut57 = '';
		let normal_altimeter_shortcut58 = '';
		let normal_steps_shortcut59 = '';
		let normal_sun_shortcut60 = '';
		let normal_battery_shortcut61 = '';
		let normal_calendar_shortcut62 = '';
		let normal_sun_shortcut63 = '';
		let container_1790007529917 = '';
		let container_1790007529917_customs = [
			{
				label: 'It',
				widgets: [
					'normal_month_imageset31',
					'normal_week_imageset32',
					'normal_date_imagecombo33',
				]
			},
			{
				label: 'En',
				widgets: [
					'normal_month_imageset35',
					'normal_week_imageset36',
					'normal_date_imagecombo37',
				]
			},
			{
				label: 'Fr',
				widgets: [
					'normal_month_imageset39',
					'normal_week_imageset40',
					'normal_date_imagecombo41',
				]
			},
			{
				label: 'De',
				widgets: [
					'normal_month_imageset43',
					'normal_week_imageset44',
					'normal_date_imagecombo45',
				]
			},
			{
				label: 'Es',
				widgets: [
					'normal_month_imageset47',
					'normal_week_imageset48',
					'normal_date_imagecombo49',
				]
			},
			{
				label: 'Pr',
				widgets: [
					'normal_month_imageset51',
					'normal_week_imageset52',
					'normal_date_imagecombo53',
				]
			},
		];
		let container_1790007529917_selected = 0;
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				const vibrateSensor = hmSensor.createSensor(hmSensor.id.VIBRATE);
				let screenType = hmSetting.getScreenType();

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 272,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_moon_phase30_imageset2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 141,
					y: 118,
					image_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					image_length: 30,
					type: hmUI.data_type.MOON,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_daynight_imageset3 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 0,
					y: 0,
					image_array: ["0033.png","0033.png","0033.png","0033.png","0033.png","0033.png","0033.png","0033.png","0033.png","0033.png","0033.png"],
					image_length: 11,
					type: hmUI.data_type.SUN_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_daynight_imageset4 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 0,
					y: 0,
					image_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
					image_length: 11,
					type: hmUI.data_type.SUN_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -11,
					y: 125,
					w: 473,
					h: 337,
					src: '0045.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0046.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset7 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 8,
					y: 8,
					image_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 4,
					y: 4,
					w: 446,
					h: 446,
					src: '0058.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunrise_text9 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 44,
					y: 200,
					w: 95,
					h: 25,
					color: 0xFFFFFF,
					text_size: 25,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunset_text10 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 316,
					y: 199,
					w: 95,
					h: 25,
					color: 0xFFFFFF,
					text_size: 25,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 63,
					y: 220,
					w: 51,
					h: 39,
					src: '0059.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 338,
					y: 220,
					w: 51,
					h: 38,
					src: '0060.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_altitude_imagecombo15 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 88,
					y: 268,
					font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
					padding: false,
					h_space: 0,
					negative_image: '0071.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTITUDE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 108,
					y: 298,
					w: 42,
					h: 42,
					src: '0072.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 196,
					y: 351,
					font_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0084.png"],
					unit_tc: ["0084.png"],
					unit_en: ["0084.png"],
					negative_image: ["0083.png"],
					invalid_image: ["0083.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_bearing_imageset20 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 211,
					y: 267,
					image_array: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png"],
					image_length: 8,
					type: hmUI.data_type.WIND_DIRECTION,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 209,
					y: 299,
					w: 40,
					h: 40,
					src: '0093.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo24 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 286,
					y: 268,
					font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 309,
					y: 306,
					w: 33,
					h: 28,
					src: '0094.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					center_x: 227,
					center_y: 227,
					pos_x: 0,
					pos_y: 0,
					src: '0095.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour24_rotary28 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					center_x: 227,
					center_y: 227,
					pos_x: 211,
					pos_y: 47,
					src: '0096.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					center_x: 227,
					center_y: 227,
					pos_x: 211,
					pos_y: 13,
					src: '0097.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset31 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 257,
					month_startY: 208,
					month_sc_array: ["0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png"],
					month_tc_array: ["0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png"],
					month_en_array: ["0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset32 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 145,
					y: 209,
					week_en: ["0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png"],
					week_tc: ["0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png"],
					week_sc: ["0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo33 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 215,
					day_startY: 202,
					day_sc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_tc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_en_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset35 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 257,
					month_startY: 208,
					month_sc_array: ["0127.png","0099.png","0100.png","0101.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0108.png","0134.png"],
					month_tc_array: ["0127.png","0099.png","0100.png","0101.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0108.png","0134.png"],
					month_en_array: ["0127.png","0099.png","0100.png","0101.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0108.png","0134.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset35.setProperty(hmUI.prop.VISIBLE, false);

				normal_week_imageset36 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 145,
					y: 209,
					week_en: ["0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png"],
					week_tc: ["0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png"],
					week_sc: ["0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset36.setProperty(hmUI.prop.VISIBLE, false);

				normal_date_imagecombo37 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 215,
					day_startY: 202,
					day_sc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_tc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_en_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo37.setProperty(hmUI.prop.VISIBLE, false);

				normal_month_imageset39 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 257,
					month_startY: 208,
					month_sc_array: ["0127.png","0142.png","0100.png","0143.png","0144.png","0145.png","0145.png","0146.png","0132.png","0133.png","0108.png","0134.png"],
					month_tc_array: ["0127.png","0142.png","0100.png","0143.png","0144.png","0145.png","0145.png","0146.png","0132.png","0133.png","0108.png","0134.png"],
					month_en_array: ["0127.png","0142.png","0100.png","0143.png","0144.png","0145.png","0145.png","0146.png","0132.png","0133.png","0108.png","0134.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset39.setProperty(hmUI.prop.VISIBLE, false);

				normal_week_imageset40 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 145,
					y: 209,
					week_en: ["0110.png","0111.png","0112.png","0147.png","0114.png","0148.png","0149.png"],
					week_tc: ["0110.png","0111.png","0112.png","0147.png","0114.png","0148.png","0149.png"],
					week_sc: ["0110.png","0111.png","0112.png","0147.png","0114.png","0148.png","0149.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset40.setProperty(hmUI.prop.VISIBLE, false);

				normal_date_imagecombo41 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 215,
					day_startY: 202,
					day_sc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_tc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_en_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo41.setProperty(hmUI.prop.VISIBLE, false);

				normal_month_imageset43 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 257,
					month_startY: 208,
					month_sc_array: ["0127.png","0099.png","0100.png","0101.png","0144.png","0129.png","0130.png","0131.png","0132.png","0150.png","0108.png","0151.png"],
					month_tc_array: ["0127.png","0099.png","0100.png","0101.png","0144.png","0129.png","0130.png","0131.png","0132.png","0150.png","0108.png","0151.png"],
					month_en_array: ["0127.png","0099.png","0100.png","0101.png","0144.png","0129.png","0130.png","0131.png","0132.png","0150.png","0108.png","0151.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset43.setProperty(hmUI.prop.VISIBLE, false);

				normal_week_imageset44 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 145,
					y: 209,
					week_en: ["0135.png","0152.png","0153.png","0154.png","0155.png","0148.png","0156.png"],
					week_tc: ["0135.png","0152.png","0153.png","0154.png","0155.png","0148.png","0156.png"],
					week_sc: ["0135.png","0152.png","0153.png","0154.png","0155.png","0148.png","0156.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset44.setProperty(hmUI.prop.VISIBLE, false);

				normal_date_imagecombo45 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 215,
					day_startY: 202,
					day_sc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_tc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_en_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo45.setProperty(hmUI.prop.VISIBLE, false);

				normal_month_imageset47 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 257,
					month_startY: 208,
					month_sc_array: ["0157.png","0099.png","0100.png","0158.png","0128.png","0129.png","0130.png","0105.png","0132.png","0133.png","0108.png","0109.png"],
					month_tc_array: ["0157.png","0099.png","0100.png","0158.png","0128.png","0129.png","0130.png","0105.png","0132.png","0133.png","0108.png","0109.png"],
					month_en_array: ["0157.png","0099.png","0100.png","0158.png","0128.png","0129.png","0130.png","0105.png","0132.png","0133.png","0108.png","0109.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset47.setProperty(hmUI.prop.VISIBLE, false);

				normal_week_imageset48 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 145,
					y: 209,
					week_en: ["0110.png","0111.png","0159.png","0160.png","0161.png","0115.png","0116.png"],
					week_tc: ["0110.png","0111.png","0159.png","0160.png","0161.png","0115.png","0116.png"],
					week_sc: ["0110.png","0111.png","0159.png","0160.png","0161.png","0115.png","0116.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset48.setProperty(hmUI.prop.VISIBLE, false);

				normal_date_imagecombo49 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 215,
					day_startY: 202,
					day_sc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_tc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_en_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo49.setProperty(hmUI.prop.VISIBLE, false);

				normal_month_imageset51 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 257,
					month_startY: 208,
					month_sc_array: ["0162.png","0142.png","0163.png","0158.png","0164.png","0165.png","0130.png","0105.png","0106.png","0166.png","0108.png","0151.png"],
					month_tc_array: ["0162.png","0142.png","0163.png","0158.png","0164.png","0165.png","0130.png","0105.png","0106.png","0166.png","0108.png","0151.png"],
					month_en_array: ["0162.png","0142.png","0163.png","0158.png","0164.png","0165.png","0130.png","0105.png","0106.png","0166.png","0108.png","0151.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset51.setProperty(hmUI.prop.VISIBLE, false);

				normal_week_imageset52 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 145,
					y: 209,
					week_en: ["0167.png","0168.png","0169.png","0170.png","0171.png","0115.png","0116.png"],
					week_tc: ["0167.png","0168.png","0169.png","0170.png","0171.png","0115.png","0116.png"],
					week_sc: ["0167.png","0168.png","0169.png","0170.png","0171.png","0115.png","0116.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset52.setProperty(hmUI.prop.VISIBLE, false);

				normal_date_imagecombo53 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 215,
					day_startY: 202,
					day_sc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_tc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_en_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo53.setProperty(hmUI.prop.VISIBLE, false);

				normal_air_temperature_shortcut57 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 199,
					y: 337,
					w: 58,
					h: 58,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_altimeter_shortcut58 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 92,
					y: 267,
					w: 74,
					h: 74,
					src: '',
					type: hmUI.data_type.ALTIMETER,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut59 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 288,
					y: 267,
					w: 74,
					h: 74,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sun_shortcut60 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 331,
					y: 195,
					w: 64,
					h: 64,
					src: '',
					type: hmUI.data_type.SUN_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_shortcut61 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 180,
					y: 393,
					w: 95,
					h: 95,
					src: '',
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut62 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 163,
					y: 193,
					w: 129,
					h: 69,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sun_shortcut63 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 59,
					y: 195,
					w: 64,
					h: 64,
					src: '',
					type: hmUI.data_type.SUN_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				function createSelectionMenu(title, options, values, selectedValue, onSelect, onVisibilityChange) {
					let menuPage = 0;
					let currentValue = selectedValue;
					let menu = hmUI.createWidget(hmUI.widget.GROUP, { x: 0, y: 0, w: 454, h: 454 });
					menu.createWidget(hmUI.widget.FILL_RECT, { x: 0, y: 0, w: 454, h: 454, color: 0x101010 });
					menu.createWidget(hmUI.widget.FILL_RECT, { x: 47, y: 22, w: 360, h: 390, color: 0x202020, radius: 10 });
					menu.createWidget(hmUI.widget.TEXT, { x: 57, y: 32, w: 340, h: 34, text: title, text_size: 24, color: 0xffffff, align_h: hmUI.align.CENTER_H });
					let menuItems = [];
					function hideMenu() {
						menu.setProperty(hmUI.prop.VISIBLE, false);
						if (onVisibilityChange) onVisibilityChange(false);
					}
					menuItems[0] = menu.createWidget(hmUI.widget.BUTTON, { x: 57, y: 66, w: 340, h: 52, text: '', text_size: 22, color: 0xffffff, normal_color: 0x303030, press_color: 0x505050, radius: 6, click_func: () => { let idx = (menuPage * 4) + 0; if (idx < options.length) { currentValue = values[idx]; if (onSelect) onSelect(currentValue, idx); hideMenu(); } } });
					menuItems[1] = menu.createWidget(hmUI.widget.BUTTON, { x: 57, y: 126, w: 340, h: 52, text: '', text_size: 22, color: 0xffffff, normal_color: 0x303030, press_color: 0x505050, radius: 6, click_func: () => { let idx = (menuPage * 4) + 1; if (idx < options.length) { currentValue = values[idx]; if (onSelect) onSelect(currentValue, idx); hideMenu(); } } });
					menuItems[2] = menu.createWidget(hmUI.widget.BUTTON, { x: 57, y: 186, w: 340, h: 52, text: '', text_size: 22, color: 0xffffff, normal_color: 0x303030, press_color: 0x505050, radius: 6, click_func: () => { let idx = (menuPage * 4) + 2; if (idx < options.length) { currentValue = values[idx]; if (onSelect) onSelect(currentValue, idx); hideMenu(); } } });
					menuItems[3] = menu.createWidget(hmUI.widget.BUTTON, { x: 57, y: 246, w: 340, h: 52, text: '', text_size: 22, color: 0xffffff, normal_color: 0x303030, press_color: 0x505050, radius: 6, click_func: () => { let idx = (menuPage * 4) + 3; if (idx < options.length) { currentValue = values[idx]; if (onSelect) onSelect(currentValue, idx); hideMenu(); } } });
					menu.createWidget(hmUI.widget.BUTTON, { x: 57, y: 306, w: 166, h: 44, text: 'Precedente', text_size: 22, color: 0xb0b0b0, normal_color: 0x303030, press_color: 0x505050, radius: 6, click_func: () => { if (menuPage > 0) { menuPage--; renderMenu(); } } });
					menu.createWidget(hmUI.widget.BUTTON, { x: 231, y: 306, w: 166, h: 44, text: 'Prossimo', text_size: 22, color: 0xb0b0b0, normal_color: 0x303030, press_color: 0x505050, radius: 6, click_func: () => { if (((menuPage + 1) * 4) < options.length) { menuPage++; renderMenu(); } } });
					menu.createWidget(hmUI.widget.BUTTON, { x: 57, y: 358, w: 340, h: 44, text: 'Chiudi', text_size: 22, color: 0xffffff, normal_color: 0x303030, press_color: 0x505050, radius: 6, click_func: hideMenu });
					function renderMenu() {
						for (let m = 0; m < menuItems.length; m++) {
							let idx = (menuPage * 4) + m;
							if (idx < options.length) {
								let prefix = values[idx] == currentValue ? '* ' : '';
								menuItems[m].setProperty(hmUI.prop.TEXT, prefix + options[idx].toString());
								menuItems[m].setProperty(hmUI.prop.VISIBLE, true);
							} else {
								menuItems[m].setProperty(hmUI.prop.TEXT, '');
								menuItems[m].setProperty(hmUI.prop.VISIBLE, false);
							}
						}
					}
					function showMenu() {
						let selectedIndex = values.indexOf(currentValue);
						menuPage = Math.floor(Math.max(0, selectedIndex) / 4);
						renderMenu();
						if (onVisibilityChange) onVisibilityChange(true);
						menu.setProperty(hmUI.prop.VISIBLE, true);
					}
					menu.setProperty(hmUI.prop.VISIBLE, false);
					return { show: showMenu, hide: hideMenu, getSelectedValue: () => currentValue };
				}

				container_1790007529917 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 190,
					y: 0,
					w: 100,
					h: 100,
					text: "",
					normal_src: '0172.png',
					press_src: '0172.png',
					click_func: () => container_1790007529917_menu.show(),
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				let container_1790007529917_menu = createSelectionMenu(
					'languages',
					container_1790007529917_customs.map((custom) => custom.label),
					container_1790007529917_customs.map((custom, index) => index),
					container_1790007529917_selected,
					(value) => { container_1790007529917_selected = value; updateContainer_1790007529917_visibility(true); },
					(visible) => {
						container_1790007529917.setProperty(hmUI.prop.VISIBLE, !visible);
					}
				);

				function updateContainer_1790007529917_visibility(showSelected = false) {
					for (let w = 0; w < container_1790007529917_customs.length; w++) {
						for (let z of container_1790007529917_customs[w].widgets) {
							let widget = eval(z);
							if (widget) {
								if (w == container_1790007529917_selected) {
									if (showSelected) {
										widget.setProperty(hmUI.prop.VISIBLE, true);
									}
								} else {
									widget.setProperty(hmUI.prop.VISIBLE, false);
								}
							}
						}
					}
				}

				updateContainer_1790007529917_visibility();

				function updateTime() {
					if (normal_second_rotary27) {
						normal_second_rotary27.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					normal_hour24_rotary28.setProperty(hmUI.prop.MORE, {
						angle: 0 + timeSensor.hour * (15 * 1) + (timeSensor.minute / 60) * (15 * 1)
					})
					if (normal_minute_rotary29) {
						normal_minute_rotary29.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
				}

				function updateWeather() {
					let tideData = weatherSensor.getForecastWeather().tideData;
					normal_sunrise_text9.setProperty(hmUI.prop.TEXT, tideData.data[0].sunrise.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunrise.minute.toString().padStart(2, '0'));
					normal_sunset_text10.setProperty(hmUI.prop.TEXT, tideData.data[0].sunset.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunset.minute.toString().padStart(2, '0'));
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						updateWeather();
						updateContainer_1790007529917_visibility();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}