    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''
        let btncolor = ''
			
	    const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		
        let colornumber = 1
        let totalcolors = 6
				
		function click_Color() {
            if(colornumber==totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }
			{
				 if(colornumber==2) hmUI.showToast({text: 'C Y A N'});
                 if(colornumber==3) hmUI.showToast({text: 'O R A N G E'});
				 if(colornumber==4) hmUI.showToast({text: 'R E D'});
                 if(colornumber==5) hmUI.showToast({text: 'W H I T E'});
				 if(colornumber==6) hmUI.showToast({text: 'L I M E'});
				
            }
            if(colornumber==1) hmUI.showToast({text: 'B L U E'});
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber) + ".png");
        }
		

//let hour_arraym =  ["dtn_y_1.png","dtn_y_2.png","dtn_y_3.png","dtn_y_4.png","dtn_y_5.png","dtn_y_6.png","dtn_y_7.png","dtn_y_8.png","dtn_y_9.png","dtn_y_10.png"]
	 function call_change_Hands() {

          colornumber = (colornumber + 1) % (totalcolors);
  
          switch (colornumber) {
            case 0:
              normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                hour_startX: 70,
                hour_startY: 131,
                hour_array: ["dtn_1.png","dtn_2.png","dtn_3.png","dtn_4.png","dtn_5.png","dtn_6.png","dtn_7.png","dtn_8.png","dtn_9.png","dtn_10.png"],
                hour_zero: 1,
                hour_space: -93,
                hour_align: hmUI.align.CENTER_H,
  
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
           
              bot_circle_state_txt = 'B L U E';
              break;
              case 1:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                  hour_startX: 70,
                  hour_startY: 131,
                  hour_array: ["dtn_y_1.png","dtn_y_2.png","dtn_y_3.png","dtn_y_4.png","dtn_y_5.png","dtn_y_6.png","dtn_y_7.png","dtn_y_8.png","dtn_y_9.png","dtn_y_10.png"],
                  hour_zero: 1,
                  hour_space: -93,
                  hour_align: hmUI.align.CENTER_H,

                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
       
                bot_circle_state_txt = 'L I M E';
                break;
              case 2:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                  hour_startX: 70,
                  hour_startY: 131,
                  hour_array: ["dtn_w_1.png","dtn_w_2.png","dtn_w_3.png","dtn_w_4.png","dtn_w_5.png","dtn_w_6.png","dtn_w_7.png","dtn_w_8.png","dtn_w_9.png","dtn_w_10.png"],
                  hour_zero: 1,
                  hour_space: -93,
                  hour_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                bot_circle_state_txt = 'W H I T E';
                break;
              case 3:
                  normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                    hour_startX: 70,
                    hour_startY: 131,
                    hour_array: ["dtn_o_1.png","dtn_o_2.png","dtn_o_3.png","dtn_o_4.png","dtn_o_5.png","dtn_o_6.png","dtn_o_7.png","dtn_o_8.png","dtn_o_9.png","dtn_o_10.png"],
                    hour_zero: 1,
                    hour_space: -93,
                    hour_align: hmUI.align.CENTER_H,
      
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                bot_circle_state_txt = 'O R A N G E';
				break;
              case 4:
                  normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                    hour_startX: 70,
                    hour_startY: 131,
                    hour_array: ["dtn_c_1.png","dtn_c_2.png","dtn_c_3.png","dtn_c_4.png","dtn_c_5.png","dtn_c_6.png","dtn_c_7.png","dtn_c_8.png","dtn_c_9.png","dtn_c_10.png"],
                    hour_zero: 1,
                    hour_space: -93,
                    hour_align: hmUI.align.CENTER_H,
      
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  bot_circle_state_txt = 'C Y A N';
				break;				  				
              case 5:
                  normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                    hour_startX: 70,
                    hour_startY: 131,
                    hour_array: ["dtn_r_1.png","dtn_r_2.png","dtn_r_3.png","dtn_r_4.png","dtn_r_5.png","dtn_r_6.png","dtn_r_7.png","dtn_r_8.png","dtn_r_9.png","dtn_r_10.png"],
                    hour_zero: 1,
                    hour_space: -93,
                    hour_follow: 0,
                    hour_align: hmUI.align.CENTER_H,
    
                   show_level: hmUI.show_level.ONLY_NORMAL,
                 }); 
				  
                  bot_circle_state_txt = 'R E D';						
				  
                    break;
  
                default:
              break;
            }
            
            hmUI.showToast({ text: bot_circle_state_txt });
          }

          let delay_Timer = null;
          let clicks = 0;
          let clicksDelay = 400;       // задержка между кликами в мс 
  
        //--------------------- обработка множественных кликов (тапов) 1, 2, 3, ...  ---------------------	
   
        function checkClicks() {
  
          switch(clicks) {
            case 1:
              call_change_Hands();
           break;
          //  case 3:
          //    click_bot_ssmoth_Switcher() ;// функции на тройной клик
          // break;
           // case 4:
             // функции на 4-ной клик
           //break;
            default:
           break;
         }
          
         timer.stopTimer(delay_Timer);
         clicks = 0;
  
        }
		
		    function getClick() {		
    
          clicks++;
          if(delay_Timer) timer.stopTimer(delay_Timer);
          delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
    
       }



        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 242,
              font_array: ["0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0103.png',
              unit_tc: '0103.png',
              unit_en: '0103.png',
              negative_image: '0104.png',
              invalid_image: '0105.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 38,
              y: 178,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 126,
              y: 320,
              src: '0111.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 125,
              y: 120,
              src: '0109.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 279,
              font_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0110.png',
              unit_tc: '0110.png',
              unit_en: '0110.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 351,
              y: 161,
              week_en: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_tc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_sc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 297,
              day_startY: 161,
              day_sc_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              day_tc_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              day_en_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 131,
              hour_array: ["dtn_1.png","dtn_2.png","dtn_3.png","dtn_4.png","dtn_5.png","dtn_6.png","dtn_7.png","dtn_8.png","dtn_9.png","dtn_10.png"],
              hour_zero: 1,
              hour_space: -93,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 296,
              minute_startY: 188,
              minute_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0100.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: '0100.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 20,
                anim_auto_start: 1,
                anim_repeat: 1,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 20,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 126,
              y: 320,
              src: '0111.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 125,
              y: 120,
              src: '0109.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 359,
              y: 279,
              font_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0110.png',
              unit_tc: '0110.png',
              unit_en: '0110.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 351,
              y: 161,
              week_en: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_tc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_sc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

             btn_color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 179, //x кнопки
              y: 395, //y кнопки
              text: '',
              w: 97, //ширина кнопки
              h: 60, //высота кнопки
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                getClick();    //имя вызываемой функции
                vibro(2);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_color.setProperty(hmUI.prop.VISIBLE, true);
				
            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 297,
              day_startY: 161,
              day_sc_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              day_tc_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              day_en_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 131,
              hour_array: ["dtn_w_1.png","dtn_w_2.png","dtn_w_3.png","dtn_w_4.png","dtn_w_5.png","dtn_w_6.png","dtn_w_7.png","dtn_w_8.png","dtn_w_9.png","dtn_w_10.png"],
              hour_zero: 1,
              hour_space: -93,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 296,
              minute_startY: 188,
              minute_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 182,
              w: 95,
              h: 95,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 141,
              y: 182,
              w: 95,
              h: 95,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 61,
              y: 320,
              w: 97,
              h: 97,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 17,
              y: 232,
              w: 95,
              h: 78,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 66,
              y: 37,
              w: 95,
              h: 95,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 17,
              y: 149,
              w: 95,
              h: 78,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 294,
              y: 321,
              w: 97,
              h: 97,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 179,
              y: 312,
              w: 97,
              h: 78,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 82,
              w: 95,
              h: 95,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});
			
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 177,
              y: 0,
              text: '',
              w: 97,
              h: 60,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
			   vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 68,
              w: 97,
              h: 78,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}