﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0

		
		let night_var = 1
        let night_all = 2
		let name_text = ' '
		
		let color_c = 1
		let color_digt = 1
        let all_digt = 8
		let color_text = '0xFFFFFFFF'
		let namecolor_digt = ' '
		
		let color_bg = 1
        let totalcolors_bg = 14
		let namecolor_main = ' '
		

		
		

	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	

		


//	переход в ночной режим (подставлением полупрозрачной картинки поверх циферблата)
		

			
		function click_Night() {
            if(night_var>=night_all) {
            night_var=1;
                }
            else {
                night_var=night_var+1;
            }
			if ( night_var == 1)    name_text = "DAYTIME MODE"
			if ( night_var == 2) 	name_text = "NIGHT MODE"
			
			hmUI.showToast({text: name_text });
			image_top_img.setProperty(hmUI.prop.SRC, "night_" + parseInt(night_var) + ".png");
			vibro(28);
		}
		
//	конец перехода в ночной режим 



function click_BG() {
            if(color_bg>=totalcolors_bg) {
            color_bg=1;
                }
            else { 
			color_bg=color_bg+1;   
			}
			if ( color_bg == 1) namecolor_main = "BACKGROUND YELLOW"
			if ( color_bg == 2) namecolor_main = "BACKGROUND GREEN"
			if ( color_bg == 3) namecolor_main = "EMERALD BACKGROUND"
			if ( color_bg == 4) namecolor_main = "BACKGROUND AQUA"
			if ( color_bg == 5) namecolor_main = "BACKGROUND LIGHT GREEN"
			if ( color_bg == 6) namecolor_main = "BACKGROUND ORANGE"
			if ( color_bg == 7) namecolor_main = "BACKGROUND RASPBERRY"
			if ( color_bg == 8) namecolor_main = "GREY-BLUE BACKGROUND"
			if ( color_bg == 9) namecolor_main = "BACKGROUND WHITE WITH GREEN"
			if ( color_bg == 10) namecolor_main = "BACKGROUND WHITE WITH EMERALD"
			if ( color_bg == 11) namecolor_main = "BACKGROUND WHITE WITH BLUE"
			if ( color_bg == 12) namecolor_main = "BLUE AND YELLOW BACKGROUND"
			if ( color_bg == 13) namecolor_main = "BACKGROUND LIGHT GREEN WITH ORANGE"
			if ( color_bg == 14) namecolor_main = "BLUE AND RASPBERRY BACKGROUND"

	



		normal_step_icon_img.setProperty(hmUI.prop.SRC, "scale_" + parseInt(color_bg) + ".png");	
		normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + parseInt(color_bg) + ".png");	

			hmUI.showToast({text: namecolor_main });	
				
			vibro(28);
					
			}
 //  конец  изменения цвета фона	

//  изменение цвета
  

	function click_DIGT() {
            if(color_digt>=all_digt) {
            color_digt=1;
                }
            else { 
			color_digt=color_digt+1;   
			}
		
            		

		
    normal_stand_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_alarm.png");

	normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: parseInt(color_digt) + '_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
		
	normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 238,
              y: 399,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_digt) + '_int.png',
              unit_tc: parseInt(color_digt) + '_int.png',
              unit_en: parseInt(color_digt) + '_int.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			
	
/////////////////////////////////////////////////////
			
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: 47,
              hour_startY: 175,
              hour_array: [parseInt(color_digt) + "_001.png",parseInt(color_digt) + "_002.png",parseInt(color_digt) + "_003.png",parseInt(color_digt) + "_004.png",parseInt(color_digt) + "_005.png",parseInt(color_digt) + "_006.png",parseInt(color_digt) + "_007.png",parseInt(color_digt) + "_008.png",parseInt(color_digt) + "_009.png",parseInt(color_digt) + "_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 177,
              minute_startY: 175,
              minute_array: [parseInt(color_digt) + "_001.png",parseInt(color_digt) + "_002.png",parseInt(color_digt) + "_003.png",parseInt(color_digt) + "_004.png",parseInt(color_digt) + "_005.png",parseInt(color_digt) + "_006.png",parseInt(color_digt) + "_007.png",parseInt(color_digt) + "_008.png",parseInt(color_digt) + "_009.png",parseInt(color_digt) + "_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 307,
              second_startY: 175,
              second_array: [parseInt(color_digt) + "_001.png",parseInt(color_digt) + "_002.png",parseInt(color_digt) + "_003.png",parseInt(color_digt) + "_004.png",parseInt(color_digt) + "_005.png",parseInt(color_digt) + "_006.png",parseInt(color_digt) + "_007.png",parseInt(color_digt) + "_008.png",parseInt(color_digt) + "_009.png",parseInt(color_digt) + "_010.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

    normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_011.png");
    normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_011.png");
    normal_digital_clock_second_separator_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_t24h.png");	

	normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: parseInt(color_digt) + '_am.png',
              am_en_path: parseInt(color_digt) + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: parseInt(color_digt) + '_pm.png',
              pm_en_path: parseInt(color_digt) + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
		normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 203,
              day_startY: 111,
              day_sc_array: [parseInt(color_digt) + "_013.png",parseInt(color_digt) + "_014.png",parseInt(color_digt) + "_015.png",parseInt(color_digt) + "_016.png",parseInt(color_digt) + "_017.png",parseInt(color_digt) + "_018.png",parseInt(color_digt) + "_019.png",parseInt(color_digt) + "_020.png",parseInt(color_digt) + "_021.png",parseInt(color_digt) + "_022.png"],
              day_tc_array: [parseInt(color_digt) + "_013.png",parseInt(color_digt) + "_014.png",parseInt(color_digt) + "_015.png",parseInt(color_digt) + "_016.png",parseInt(color_digt) + "_017.png",parseInt(color_digt) + "_018.png",parseInt(color_digt) + "_019.png",parseInt(color_digt) + "_020.png",parseInt(color_digt) + "_021.png",parseInt(color_digt) + "_022.png"],
              day_en_array: [parseInt(color_digt) + "_013.png",parseInt(color_digt) + "_014.png",parseInt(color_digt) + "_015.png",parseInt(color_digt) + "_016.png",parseInt(color_digt) + "_017.png",parseInt(color_digt) + "_018.png",parseInt(color_digt) + "_019.png",parseInt(color_digt) + "_020.png",parseInt(color_digt) + "_021.png",parseInt(color_digt) + "_022.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 278,
              month_startY: 126,
              month_sc_array: [parseInt(color_digt) + "_051.png",parseInt(color_digt) + "_052.png",parseInt(color_digt) + "_053.png",parseInt(color_digt) + "_054.png",parseInt(color_digt) + "_055.png",parseInt(color_digt) + "_056.png",parseInt(color_digt) + "_057.png",parseInt(color_digt) + "_058.png",parseInt(color_digt) + "_059.png",parseInt(color_digt) + "_060.png",parseInt(color_digt) + "_061.png",parseInt(color_digt) + "_062.png"],
              month_tc_array: [parseInt(color_digt) + "_051.png",parseInt(color_digt) + "_052.png",parseInt(color_digt) + "_053.png",parseInt(color_digt) + "_054.png",parseInt(color_digt) + "_055.png",parseInt(color_digt) + "_056.png",parseInt(color_digt) + "_057.png",parseInt(color_digt) + "_058.png",parseInt(color_digt) + "_059.png",parseInt(color_digt) + "_060.png",parseInt(color_digt) + "_061.png",parseInt(color_digt) + "_062.png"],
              month_en_array: [parseInt(color_digt) + "_051.png",parseInt(color_digt) + "_052.png",parseInt(color_digt) + "_053.png",parseInt(color_digt) + "_054.png",parseInt(color_digt) + "_055.png",parseInt(color_digt) + "_056.png",parseInt(color_digt) + "_057.png",parseInt(color_digt) + "_058.png",parseInt(color_digt) + "_059.png",parseInt(color_digt) + "_060.png",parseInt(color_digt) + "_061.png",parseInt(color_digt) + "_062.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 94,
              y: 127,
              week_en: [parseInt(color_digt) + "_023.png",parseInt(color_digt) + "_024.png",parseInt(color_digt) + "_025.png",parseInt(color_digt) + "_026.png",parseInt(color_digt) + "_027.png",parseInt(color_digt) + "_028.png",parseInt(color_digt) + "_029.png"],
              week_tc: [parseInt(color_digt) + "_023.png",parseInt(color_digt) + "_024.png",parseInt(color_digt) + "_025.png",parseInt(color_digt) + "_026.png",parseInt(color_digt) + "_027.png",parseInt(color_digt) + "_028.png",parseInt(color_digt) + "_029.png"],
              week_sc: [parseInt(color_digt) + "_023.png",parseInt(color_digt) + "_024.png",parseInt(color_digt) + "_025.png",parseInt(color_digt) + "_026.png",parseInt(color_digt) + "_027.png",parseInt(color_digt) + "_028.png",parseInt(color_digt) + "_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
	
        
///////////////////////////////////////////////////////	
	


        normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 242,
              y: 336,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
			
		normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 145,
              y: 336,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 135,
              y: 399,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_stand_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 328,
              y: 290,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_fat_burning_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 285,
              y: 290,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_pai_weekly_text_img.setProperty(hmUI.prop.MORE, {
              x: 115,
              y: 290,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_pai_day_text_img.setProperty(hmUI.prop.MORE, {
              x: 59,
              y: 290,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			
			
/////////////////////////////////////////////////////////			
			

				
				
        normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 158,
              y: 16,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_digt) + '_dig.png',
              unit_tc: parseInt(color_digt) + '_dig.png',
              unit_en: parseInt(color_digt) + '_dig.png',
              imperial_unit_sc: parseInt(color_digt) + '_dig.png',
              imperial_unit_tc: parseInt(color_digt) + '_dig.png',
              imperial_unit_en: parseInt(color_digt) + '_dig.png',
              negative_image: parseInt(color_digt) + '_minus.png',
              invalid_image: parseInt(color_digt) + '_eror.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	


            if ( color_digt == 1) {color_text = '0xFFFFFFFF'}    // белый
			if ( color_digt == 2) {color_text = '0xFF00FF00'}    //  зелёный
			if ( color_digt == 3) {color_text = '0xFF00fe9a'}	//  пип-бой
			if ( color_digt == 4) {color_text = '0xFFFFFF00'}	//  жёлтый
			if ( color_digt == 5) {color_text = '0xFF00FFFF'}    // аква
			if ( color_digt == 6) {color_text = '0xFFfe9a00'}	// оранжевый
			if ( color_digt == 7) {color_text = '0xFFff004e'}	// Малиновый
			if ( color_digt == 8) {color_text = '0xFFb8b8b8'}	// серый
		//	if ( color_digt == 10) {color_text = '0xFF7e7e7e'}	// ТЁМНО СЕРЫЙ

		normal_city_name_text.setProperty(hmUI.prop.MORE, {
              x: 161,
              y: 71,
              w: 132,
              h: 26,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: color_text,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		normal_sun_high_text_img.setProperty(hmUI.prop.MORE, {
              x: 96,
              y: 96,
              font_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              padding: false,
              h_space: 0,
              dot_image: parseInt(color_digt) + '_012.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_sun_low_text_img.setProperty(hmUI.prop.MORE, {
              x: 298,
              y: 96,
              font_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              padding: false,
              h_space: 0,
              dot_image: parseInt(color_digt) + '_012.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


			if ( color_digt == 1) 	namecolor_digt = "WHITE NUMBERS";
			if ( color_digt == 2) 	namecolor_digt = "GREEN NUMBERS";
			if ( color_digt == 3)	namecolor_digt = "EMERALD NUMBERS";
			if ( color_digt == 4) 	namecolor_digt = "YELLOW NUMBERS";
			if ( color_digt == 5)	namecolor_digt = "AQUA NUMBERS";
			if ( color_digt == 6)	namecolor_digt = "ORANGE NUMBERS";
			if ( color_digt == 7) 	namecolor_digt = "RASPBERRY NUMBERS";
			if ( color_digt == 8) 	namecolor_digt = "GRAY NUMBERS";
			
			hmUI.showToast({text: namecolor_digt });	
				
			
        	vibro(28);

			} 
 
//  конец  изменения цвета цифр


        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_stand_icon_img = ''
        let normal_stand_current_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_city_name_text = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_circle_scale = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: lcddisplaycapssskcyrillic.ttf; FontSize: 31; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 452,
              y: 452,
              w: 37,
              h: 37,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1_alarm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img.setAlpha(125);

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 290,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 285,
              y: 290,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 290,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 290,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 238,
              y: 1,
              image_array: ["1_wth00.png","1_wth01.png","1_wth02.png","1_wth03.png","1_wth04.png","1_wth05.png","1_wth06.png","1_wth07.png","1_wth08.png","1_wth09.png","1_wth10.png","1_wth11.png","1_wth12.png","1_wth13.png","1_wth14.png","1_wth15.png","1_wth16.png","1_wth17.png","1_wth18.png","1_wth19.png","1_wth20.png","1_wth21.png","1_wth22.png","1_wth23.png","1_wth24.png","1_wth25.png","1_wth26.png","1_wth27.png","1_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 16,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_dig.png',
              unit_tc: '1_dig.png',
              unit_en: '1_dig.png',
              imperial_unit_sc: '1_dig.png',
              imperial_unit_tc: '1_dig.png',
              imperial_unit_en: '1_dig.png',
              negative_image: '1_minus.png',
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 158,
                y: 16,
                font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
                padding: false,
                h_space: 0,
                unit_sc: '1_dig.png',
                unit_tc: '1_dig.png',
                unit_en: '1_dig.png',
                imperial_unit_sc: '1_dig.png',
                imperial_unit_tc: '1_dig.png',
                imperial_unit_en: '1_dig.png',
                negative_image: '1_minus.png',
                invalid_image: '1_eror.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 161,
              y: 71,
              w: 132,
              h: 26,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 203,
              day_startY: 111,
              day_sc_array: ["1_013.png","1_014.png","1_015.png","1_016.png","1_017.png","1_018.png","1_019.png","1_020.png","1_021.png","1_022.png"],
              day_tc_array: ["1_013.png","1_014.png","1_015.png","1_016.png","1_017.png","1_018.png","1_019.png","1_020.png","1_021.png","1_022.png"],
              day_en_array: ["1_013.png","1_014.png","1_015.png","1_016.png","1_017.png","1_018.png","1_019.png","1_020.png","1_021.png","1_022.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 278,
              month_startY: 126,
              month_sc_array: ["1_051.png","1_052.png","1_053.png","1_054.png","1_055.png","1_056.png","1_057.png","1_058.png","1_059.png","1_060.png","1_061.png","1_062.png"],
              month_tc_array: ["1_051.png","1_052.png","1_053.png","1_054.png","1_055.png","1_056.png","1_057.png","1_058.png","1_059.png","1_060.png","1_061.png","1_062.png"],
              month_en_array: ["1_051.png","1_052.png","1_053.png","1_054.png","1_055.png","1_056.png","1_057.png","1_058.png","1_059.png","1_060.png","1_061.png","1_062.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 94,
              y: 127,
              week_en: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_tc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_sc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 96,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: true,
              h_space: 0,
              dot_image: '1_012.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 96,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: true,
              h_space: 0,
              dot_image: '1_012.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 336,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 336,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 399,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icons.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 226,
              // start_angle: 150,
              // end_angle: 28,
              // radius: 208,
              // line_width: 18,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 226,
              start_angle: 28,
              end_angle: 150,
              radius: 199,
              line_width: 18,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(150);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 399,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: -150,
              // end_angle: -28,
              // radius: 207,
              // line_width: 17,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: -28,
              end_angle: -150,
              radius: 199,
              line_width: 17,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale.setAlpha(150);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'scale_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 209,
              y: 313,
              src: 'BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '1_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 47,
              hour_startY: 175,
              hour_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 177,
              minute_startY: 175,
              minute_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 307,
              second_startY: 175,
              second_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 153,
              y: 175,
              src: '1_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 284,
              y: 175,
              src: '1_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1_t24h.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '1_am.png',
              am_en_path: '1_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '1_pm.png',
              pm_en_path: '1_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 203,
              day_startY: 111,
              day_sc_array: ["AOD_013.png","AOD_014.png","AOD_015.png","AOD_016.png","AOD_017.png","AOD_018.png","AOD_019.png","AOD_020.png","AOD_021.png","AOD_022.png"],
              day_tc_array: ["AOD_013.png","AOD_014.png","AOD_015.png","AOD_016.png","AOD_017.png","AOD_018.png","AOD_019.png","AOD_020.png","AOD_021.png","AOD_022.png"],
              day_en_array: ["AOD_013.png","AOD_014.png","AOD_015.png","AOD_016.png","AOD_017.png","AOD_018.png","AOD_019.png","AOD_020.png","AOD_021.png","AOD_022.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 127,
              month_sc_array: ["AOD_051.png","AOD_052.png","AOD_053.png","AOD_054.png","AOD_055.png","AOD_056.png","AOD_057.png","AOD_058.png","AOD_059.png","AOD_060.png","AOD_061.png","AOD_062.png"],
              month_tc_array: ["AOD_051.png","AOD_052.png","AOD_053.png","AOD_054.png","AOD_055.png","AOD_056.png","AOD_057.png","AOD_058.png","AOD_059.png","AOD_060.png","AOD_061.png","AOD_062.png"],
              month_en_array: ["AOD_051.png","AOD_052.png","AOD_053.png","AOD_054.png","AOD_055.png","AOD_056.png","AOD_057.png","AOD_058.png","AOD_059.png","AOD_060.png","AOD_061.png","AOD_062.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 77,
              y: 127,
              week_en: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_tc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_sc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 396,
              font_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD_int.png',
              unit_tc: 'AOD_int.png',
              unit_en: 'AOD_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 150,
              // end_angle: 29,
              // radius: 207,
              // line_width: 16,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 170,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 29,
              end_angle: 150,
              radius: 199,
              line_width: 16,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_circle_scale.setAlpha(170);

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 47,
              hour_startY: 175,
              hour_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 177,
              minute_startY: 175,
              minute_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 307,
              second_startY: 175,
              second_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 153,
              y: 175,
              src: 'AOD_011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 284,
              y: 175,
              src: 'AOD_011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOD_t24h.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'AOD_am.png',
              am_en_path: 'AOD_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'AOD_pm.png',
              pm_en_path: 'AOD_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 0,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'night_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 116,
              y: 375,
              w: 109,
              h: 76,
              src: '00_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 306,
              w: 61,
              h: 66,
              src: '00_empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 231,
              y: 306,
              w: 61,
              h: 65,
              src: '00_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 56,
              y: 287,
              w: 100,
              h: 83,
              src: '00_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 232,
              y: 375,
              w: 116,
              h: 76,
              src: '00_empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 96,
              y: 69,
              w: 95,
              h: 51,
              src: '00_empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 136,
              y: 0,
              w: 95,
              h: 67,
              src: '00_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 345,
              y: 287,
              w: 47,
              h: 75,
              src: '00_empty.png',
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 26,
              y: 112,
              w: 64,
              h: 58,
              src: '00_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 297,
              y: 287,
              w: 45,
              h: 79,
              src: '00_empty.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 179,
              y: 174,
              w: 95,
              h: 101,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 124,
              w: 284,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 237,
              y: 1,
              w: 88,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
vibro(28);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 53,
              y: 176,
              w: 90,
              h: 99,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_BG()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 313,
              y: 176,
              w: 90,
              h: 99,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_DIGT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 226,
                      start_angle: 28,
                      end_angle: 150,
                      radius: 199,
                      line_width: 18,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: -28,
                      end_angle: -150,
                      radius: 199,
                      line_width: 17,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 29,
                      end_angle: 150,
                      radius: 199,
                      line_width: 16,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}