﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 295,
              y: 57,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 397,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ACT_Weather_Font_01.png',
              unit_tc: 'ACT_Weather_Font_01.png',
              unit_en: 'ACT_Weather_Font_01.png',
              negative_image: 'ACT_Weather_Font_02.png',
              invalid_image: 'ACT_Weather_Font_02.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 216,
              y: 360,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 243,
              y: 302,
              week_en: ["Week_dayi_icon_01.png","Week_dayi_icon_02.png","Week_dayi_icon_03.png","Week_dayi_icon_04.png","Week_dayi_icon_05.png","Week_dayi_icon_06.png","Week_dayi_icon_07.png"],
              week_tc: ["Week_dayi_icon_01.png","Week_dayi_icon_02.png","Week_dayi_icon_03.png","Week_dayi_icon_04.png","Week_dayi_icon_05.png","Week_dayi_icon_06.png","Week_dayi_icon_07.png"],
              week_sc: ["Week_dayi_icon_01.png","Week_dayi_icon_02.png","Week_dayi_icon_03.png","Week_dayi_icon_04.png","Week_dayi_icon_05.png","Week_dayi_icon_06.png","Week_dayi_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 161,
              y: 183,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 162,
              y: 249,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 25,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 67,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'ACT_Font_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 377,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 281,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 157,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 260,
              month_startY: 145,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 145,
              day_sc_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              day_tc_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              day_en_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 155,
              am_y: 221,
              am_sc_path: 'T_AM.png',
              am_en_path: 'T_AM.png',
              pm_x: 155,
              pm_y: 221,
              pm_sc_path: 'T_PM.png',
              pm_en_path: 'T_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 202,
              hour_startY: 185,
              hour_array: ["Font_H_01.png","Font_H_02.png","Font_H_03.png","Font_H_04.png","Font_H_05.png","Font_H_06.png","Font_H_07.png","Font_H_08.png","Font_H_09.png","Font_H_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 316,
              minute_startY: 185,
              minute_array: ["Font_M_01.png","Font_M_02.png","Font_M_03.png","Font_M_04.png","Font_M_05.png","Font_M_06.png","Font_M_07.png","Font_M_08.png","Font_M_09.png","Font_M_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 163,
              src: 'Bar_hour.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 43,
              second_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 116,
              y: 363,
              w: 67,
              h: 45,
              src: 'Week_dayi_icon_08.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 57,
              y: 143,
              w: 75,
              h: 53,
              src: 'Week_dayi_icon_08.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main2.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 202,
              hour_startY: 185,
              hour_array: ["Font_H_01.png","Font_H_02.png","Font_H_03.png","Font_H_04.png","Font_H_05.png","Font_H_06.png","Font_H_07.png","Font_H_08.png","Font_H_09.png","Font_H_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 316,
              minute_startY: 185,
              minute_array: ["Font_M_01.png","Font_M_02.png","Font_M_03.png","Font_M_04.png","Font_M_05.png","Font_M_06.png","Font_M_07.png","Font_M_08.png","Font_M_09.png","Font_M_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 163,
              src: 'Bar_hour.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  