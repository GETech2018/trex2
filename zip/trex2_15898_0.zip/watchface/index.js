﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_sun_low_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_hour_cover_pointer_img = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_hour = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let timeSensor = '';

let colornumber_main = 1
let totalcolors_main = 30
let namecolor_main = ''

function click_Color() {
    if (colornumber_main >= totalcolors_main) {
        colornumber_main = 1;
    }
    else {
        colornumber_main = colornumber_main + 1;
    }


    normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber_main) + ".png");

}

let colornumber_main2 = 1
let totalcolors_main2 = 5
let namecolor_main2 = ''

function click_Color2() {
    if (colornumber_main2 >= totalcolors_main2) {
        colornumber_main2 = 1;
    }
    else {
        colornumber_main2 = colornumber_main2 + 1;
    }


    normal_image_img.setProperty(hmUI.prop.SRC, "mask" + parseInt(colornumber_main2) + ".png");

}
let colornumber_main3 = 1
let totalcolors_main3 = 13
let namecolor_main3 = ''

function click_Color3() {
    if (colornumber_main3 >= totalcolors_main3) {
        colornumber_main3 = 1;
    }
    else {
        colornumber_main3 = colornumber_main3 + 1;
    }


    normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "hand_hour" + parseInt(colornumber_main3) + ".png");

}
let colornumber_main4 = 1
let totalcolors_main4 = 13
let namecolor_main4 = ''

function click_Color4() {
    if (colornumber_main4 >= totalcolors_main4) {
        colornumber_main4 = 1;
    }
    else {
        colornumber_main4 = colornumber_main4 + 1;
    }


    normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "hand_minute" + parseInt(colornumber_main4) + ".png");
normal_analog_clock_pro_hour_cover_pointer_img.setProperty(hmUI.prop.SRC, "hand_pivot" + parseInt(colornumber_main4) + ".png");

}


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg26.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: "mask" + parseInt(colornumber_main2) + ".png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 117,
              font_array: ["mini_digit_01.png","mini_digit_02.png","mini_digit_03.png","mini_digit_04.png","mini_digit_05.png","mini_digit_06.png","mini_digit_07.png","mini_digit_08.png","mini_digit_09.png","mini_digit_10.png"],
              padding: true,
              h_space: -9,
              invalid_image: 'alarm_off2EN.png',
              dot_image: 'mini_special_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 36,
              src: 'top_logo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 352,
              y: 227,
              font_array: ["mini_digit_01.png","mini_digit_02.png","mini_digit_03.png","mini_digit_04.png","mini_digit_05.png","mini_digit_06.png","mini_digit_07.png","mini_digit_08.png","mini_digit_09.png","mini_digit_10.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 344,
              y: 201,
              src: 'oth_day_02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 7,
              y: 227,
              font_array: ["mini_digit_01.png","mini_digit_02.png","mini_digit_03.png","mini_digit_04.png","mini_digit_05.png","mini_digit_06.png","mini_digit_07.png","mini_digit_08.png","mini_digit_09.png","mini_digit_10.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 41,
              y: 201,
              src: 'oth_day_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 160,
              y: 309,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 232,
              month_startY: 281,
              month_sc_array: ["mini_digit_01.png","mini_digit_02.png","mini_digit_03.png","mini_digit_04.png","mini_digit_05.png","mini_digit_06.png","mini_digit_07.png","mini_digit_08.png","mini_digit_09.png","mini_digit_10.png"],
              month_tc_array: ["mini_digit_01.png","mini_digit_02.png","mini_digit_03.png","mini_digit_04.png","mini_digit_05.png","mini_digit_06.png","mini_digit_07.png","mini_digit_08.png","mini_digit_09.png","mini_digit_10.png"],
              month_en_array: ["mini_digit_01.png","mini_digit_02.png","mini_digit_03.png","mini_digit_04.png","mini_digit_05.png","mini_digit_06.png","mini_digit_07.png","mini_digit_08.png","mini_digit_09.png","mini_digit_10.png"],
              month_zero: 1,
              month_space: -5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 173,
              day_startY: 281,
              day_sc_array: ["mini_digit_01.png","mini_digit_02.png","mini_digit_03.png","mini_digit_04.png","mini_digit_05.png","mini_digit_06.png","mini_digit_07.png","mini_digit_08.png","mini_digit_09.png","mini_digit_10.png"],
              day_tc_array: ["mini_digit_01.png","mini_digit_02.png","mini_digit_03.png","mini_digit_04.png","mini_digit_05.png","mini_digit_06.png","mini_digit_07.png","mini_digit_08.png","mini_digit_09.png","mini_digit_10.png"],
              day_en_array: ["mini_digit_01.png","mini_digit_02.png","mini_digit_03.png","mini_digit_04.png","mini_digit_05.png","mini_digit_06.png","mini_digit_07.png","mini_digit_08.png","mini_digit_09.png","mini_digit_10.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 273,
              src: 'mini_special_14.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 92,
              y: 95,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 65,
              font_array: ["mini_digit_01.png","mini_digit_02.png","mini_digit_03.png","mini_digit_04.png","mini_digit_05.png","mini_digit_06.png","mini_digit_07.png","mini_digit_08.png","mini_digit_09.png","mini_digit_10.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'mini_special_13.png',
              unit_tc: 'mini_special_13.png',
              unit_en: 'mini_special_13.png',
              imperial_unit_sc: 'mini_special_13.png',
              imperial_unit_tc: 'mini_special_13.png',
              imperial_unit_en: 'mini_special_13.png',
              negative_image: 'mini_special_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 397,
              font_array: ["mini_digit_01.png","mini_digit_02.png","mini_digit_03.png","mini_digit_04.png","mini_digit_05.png","mini_digit_06.png","mini_digit_07.png","mini_digit_08.png","mini_digit_09.png","mini_digit_10.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'mini_special_15.png',
              unit_tc: 'mini_special_15.png',
              unit_en: 'mini_special_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 211,
              am_y: 376,
              am_sc_path: 'mini2_special_01.png',
              am_en_path: 'mini2_special_01.png',
              pm_x: 211,
              pm_y: 376,
              pm_sc_path: 'mini2_special_02.png',
              pm_en_path: 'mini2_special_02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 157,
              hour_startY: 333,
              hour_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_unit_sc: 'special_11.png',
              hour_unit_tc: 'special_11.png',
              hour_unit_en: 'special_11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 241,
              minute_startY: 333,
              minute_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_minute1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 22,
              // y: 202,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 22,
              pos_y: 227 - 202,
              center_x: 227,
              center_y: 227,
              src: "hand_minute" + parseInt(colornumber_main4) + ".png",
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_seconds.png',
              // center_x: 227,
              // center_y: 227,
              // x: 21,
              // y: 221,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 21,
              pos_y: 227 - 221,
              center_x: 227,
              center_y: 227,
              src: 'hand_seconds.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_hour1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 21,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'hand_pivot1.png',
              // cover_x: 205,
              // cover_y: 205,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 21,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: "hand_hour" + parseInt(colornumber_main3) + ".png",
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_hour_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 205,
              src: "hand_pivot" + parseInt(colornumber_main4) + ".png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 211,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 399,
              font_array: ["mini_digit_01.png","mini_digit_02.png","mini_digit_03.png","mini_digit_04.png","mini_digit_05.png","mini_digit_06.png","mini_digit_07.png","mini_digit_08.png","mini_digit_09.png","mini_digit_10.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'mini_special_15.png',
              unit_tc: 'mini_special_15.png',
              unit_en: 'mini_special_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_minute13.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 22,
              minute_posY: 202,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour13.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 21,
              hour_posY: 227,
              hour_cover_path: 'hand_pivot6.png',
              hour_cover_x: 205,
              hour_cover_y: 205,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 181,
              y: 21,
              w: 95,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 44,
              y: 294,
              w: 47,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                click_Color3();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 363,
              y: 294,
              w: 47,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                click_Color4();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 17,
              y: 202,
              w: 95,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 157,
              y: 282,
              w: 142,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 347,
              y: 202,
              w: 95,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 173,
              y: 70,
              w: 113,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 205,
              w: 47,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '_WFbyTRK88PL.png',
              normal_src: '_WFbyTRK88PL.png',
              click_func: (button_widget) => {
                click_Color2();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}