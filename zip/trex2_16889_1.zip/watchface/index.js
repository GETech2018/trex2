﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

		
		let night_var = 1
        let night_all = 2
		let name_text = ' '
		let night_dig = 1
		

		
		let color_digt = 1
        let all_digt = 7
		let color_text = '0xFFFFFFFF'
		let namecolor_digt = ' '
		
		let color_bg = 1
        let totalcolors_bg = 9
		let namecolor_main = ' '
		

		
		let xxx_clock_h = 90
		let yyy_clock_h = 274
		let xxx_clock_m = 213
		let yyy_clock_m = 274
		let xxx_clock_s = 307
		let yyy_clock_s = 308
		let xxx_clock = 174
		let yyy_clock = 287
		let xxx_day = 131
		let yyy_day = 214
		let xxx_month = 184
		let yyy_month = 214
		let xxx_day_w = 53
		let yyy_day_w = 213
		let xxx_batt = 134
		let yyy_batt = 96

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
//  вызов меню

function click_Menu() {
	
		Button_1.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка переход в ночной режим
		Button_2.setProperty(hmUI.prop.VISIBLE, false);      //   кнопка календарь
		Button_3.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка погодная программа
		Button_4.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка изменения цвета
		
//		Button_5.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка возврат в дневной режим
		
		Button_6.setProperty(hmUI.prop.VISIBLE, true);      //   кнопка цвета фона
		Button_7.setProperty(hmUI.prop.VISIBLE, true);      //   кнопка цвета цифр
		Button_8.setProperty(hmUI.prop.VISIBLE, true);      //   кнопка выход их меню

	
		
		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык статистика активностей (калории)
		normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);          //   ярлык шаги 
		normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык пульса 
		normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык температуры
		normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык будильник
		normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);       //   ярлык секундомер
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык батарея
		normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //  ярлык кислород в крови
		normal_bodyTemp_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык температура руки		
	
	    image_top_img.setProperty(hmUI.prop.VISIBLE, true); 
		
		vibro(28);
	
}


// конец вызова меню

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	

// выход из меню

function click_Exit() {
	
	    Button_1.setProperty(hmUI.prop.VISIBLE, true);      //   кнопка переход в ночной режим
		Button_2.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка календарь
		Button_3.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка погодная программа
		Button_4.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка вызов меню цвета
		
//		Button_5.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка возврат в дневной режим
		
		Button_6.setProperty(hmUI.prop.VISIBLE, false);      //   кнопка цвета фона
		Button_7.setProperty(hmUI.prop.VISIBLE, false);      //   кнопка цвета цифр
		Button_8.setProperty(hmUI.prop.VISIBLE, false);      //   кнопка выход их меню

		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык статистика активностей (калории)
		normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);          //   ярлык шаги 
		normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык пульса 
		normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык температуры
		normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык будильник
		normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);       //   ярлык секундомер
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык батарея	
		normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //  ярлык кислород в крови
		normal_bodyTemp_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык температура руки	
	
	    image_top_img.setProperty(hmUI.prop.VISIBLE, false); 
		
		vibro(28);
	
}



// конец выхода из меню

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	





//	возврат в дневной режим 

		function click_Day() {

		name_text = "ДНЕВНОЙ РЕЖИМ";  // "DAYTIME MODE"
		night_dig = color_digt;		
		
		 xxx_clock_h = 90
		 yyy_clock_h = 274
		 xxx_clock_m = 213
		 yyy_clock_m = 274
		 xxx_clock_s = 307
		 yyy_clock_s = 308
		 xxx_clock = 174
		 yyy_clock = 287
		 xxx_day = 131
		 yyy_day = 214
		 xxx_month = 184
		 yyy_month = 214
		 xxx_day_w = 53
		 yyy_day_w = 213
		 xxx_batt = 134
		 yyy_batt = 96

	
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: parseInt(xxx_clock_h),
              hour_startY: parseInt(yyy_clock_h),
              hour_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: parseInt(xxx_clock_m),
              minute_startY: parseInt(yyy_clock_m),
              minute_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: parseInt(xxx_clock_s),
              second_startY: parseInt(yyy_clock_s),
              second_array: [night_dig + "_013.png",night_dig + "_014.png",night_dig + "_015.png",night_dig + "_016.png",night_dig + "_017.png",night_dig + "_018.png",night_dig + "_019.png",night_dig + "_020.png",night_dig + "_021.png",night_dig + "_022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: xxx_clock,
              y: yyy_clock,
              src: night_dig + '_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: night_dig + '_am.png',
              am_en_path: night_dig + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: night_dig + '_pm.png',
              pm_en_path: night_dig + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	


		normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: xxx_day_w,
              y: yyy_day_w,
              week_en: ["b_023.png","b_024.png","b_025.png","b_026.png","b_027.png","b_028.png","b_029.png"],
              week_tc: ["b_023.png","b_024.png","b_025.png","b_026.png","b_027.png","b_028.png","b_029.png"],
              week_sc: ["b_023.png","b_024.png","b_025.png","b_026.png","b_027.png","b_028.png","b_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_date_img_date_month.setProperty(hmUI.prop.MORE, {
              month_startX: xxx_month,
              month_startY: yyy_month,
              month_sc_array: ["b_001.png","b_002.png","b_003.png","b_004.png","b_005.png","b_006.png","b_007.png","b_008.png","b_009.png","b_010.png"],
              month_tc_array: ["b_001.png","b_002.png","b_003.png","b_004.png","b_005.png","b_006.png","b_007.png","b_008.png","b_009.png","b_010.png"],
              month_en_array: ["b_001.png","b_002.png","b_003.png","b_004.png","b_005.png","b_006.png","b_007.png","b_008.png","b_009.png","b_010.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: xxx_day,
              day_startY: yyy_day,
              day_sc_array: ["b_001.png","b_002.png","b_003.png","b_004.png","b_005.png","b_006.png","b_007.png","b_008.png","b_009.png","b_010.png"],
              day_tc_array: ["b_001.png","b_002.png","b_003.png","b_004.png","b_005.png","b_006.png","b_007.png","b_008.png","b_009.png","b_010.png"],
              day_en_array: ["b_001.png","b_002.png","b_003.png","b_004.png","b_005.png","b_006.png","b_007.png","b_008.png","b_009.png","b_010.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


		normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: xxx_batt,
              y: yyy_batt,
              font_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              padding: false,
              h_space: 0,
              unit_sc: night_dig + '_int.png',
              unit_tc: night_dig + '_int.png',
              unit_en: night_dig + '_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	
		normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		
			
		normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + color_bg + ".png");
		image_top_img.setProperty(hmUI.prop.VISIBLE, false);
			
			
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_body_temp_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_system_lock_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.VISIBLE, true);	
		

		
		Button_1.setProperty(hmUI.prop.VISIBLE, true);      //   кнопка переход в ночной режим
		Button_2.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка календарь
		Button_3.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка погодная программа
		Button_4.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка изменения цвета
		Button_5.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка возврат в дневной режим


		
		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык статистика активностей (калории)
		normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);          //   ярлык шаги 
		normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык пульса 
		normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык температуры
		normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык будильник
		normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);       //   ярлык секундомер
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык батарея	
		normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //  ярлык кислород в крови
		normal_bodyTemp_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык температура руки	
		
		hmUI.showToast({text: name_text });
			
		vibro(28);		
				
			}
			
//	конец возврата в дневной режим 			

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
//	переход в ночной режим 			
			
		function click_Night() {		
				
		name_text = "НОЧНОЙ РЕЖИМ"   // "NIGHT MODE"
		night_dig = 'AOD'
		
		 xxx_clock_h = 48
		 yyy_clock_h = 245
		 xxx_clock_m = 218
		 yyy_clock_m = 245
		 xxx_clock_s = 351
		 yyy_clock_s = 247
		 xxx_clock = 172
		 yyy_clock = 258
		 xxx_day = 111
		 yyy_day = 182
		 xxx_month = 180
		 yyy_month = 182
		 xxx_day_w = 8
		 yyy_day_w = 181
		 xxx_batt = 189
		 yyy_batt = 74


			normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: parseInt(xxx_clock_h),
              hour_startY: parseInt(yyy_clock_h),
              hour_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: parseInt(xxx_clock_m),
              minute_startY: parseInt(yyy_clock_m),
              minute_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: parseInt(xxx_clock_s),
              second_startY: parseInt(yyy_clock_s),
              second_array: [night_dig + "_013.png",night_dig + "_014.png",night_dig + "_015.png",night_dig + "_016.png",night_dig + "_017.png",night_dig + "_018.png",night_dig + "_019.png",night_dig + "_020.png",night_dig + "_021.png",night_dig + "_022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: xxx_clock,
              y: yyy_clock,
              src: night_dig + '_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: night_dig + '_am.png',
              am_en_path: night_dig + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: night_dig + '_pm.png',
              pm_en_path: night_dig + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	


		normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: xxx_day_w,
              y: yyy_day_w,
              week_en: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              week_tc: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              week_sc: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
		normal_date_img_date_month.setProperty(hmUI.prop.MORE, {
              month_startX: xxx_month,
              month_startY: yyy_month,
              month_sc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_tc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_en_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	
        normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: xxx_day,
              day_startY: yyy_day,
              day_sc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_tc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_en_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: xxx_batt,
              y: yyy_batt,
              font_array: [night_dig + "_040.png",night_dig + "_041.png",night_dig + "_042.png",night_dig + "_043.png",night_dig + "_044.png",night_dig + "_045.png",night_dig + "_046.png",night_dig + "_047.png",night_dig + "_048.png",night_dig + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: night_dig + '_int.png',
              unit_tc: night_dig + '_int.png',
              unit_en: night_dig + '_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		
				
		normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);	
		normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
		normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
		normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_body_temp_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		
		normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_system_lock_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.VISIBLE, false);
		
		Button_1.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка переход в ночной режим
		Button_2.setProperty(hmUI.prop.VISIBLE, false);      //   кнопка календарь
		Button_3.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка погодная программа
		Button_4.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка изменения цвета
		Button_5.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка возврат в дневной режим
	
		
		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык статистика активностей (калории)
		normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);          //   ярлык шаги 
		normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык пульса 
		normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык температуры
		normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык будильник
		normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);       //   ярлык секундомер
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык батарея
		normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //  ярлык кислород в крови
		normal_bodyTemp_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык температура руки	
		
		
		normal_background_bg_img.setProperty(hmUI.prop.SRC, night_dig + ".png");
		
		
		hmUI.showToast({text: name_text });
		vibro(28);
	
		}
		
//	конец перехода в ночной режим 		

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//  изменение цвета фона

function click_BG() {
            if(color_bg>=totalcolors_bg) {
            color_bg=1;
                }
            else { 
			color_bg=color_bg+1;   
			}
			
			if ( color_bg == 1) namecolor_main = "БЕЛЫЙ"
			if ( color_bg == 2) namecolor_main = "ЗЕЛЁНЫЙ"
			if ( color_bg == 3) namecolor_main = "ГОЛУБОЙ"
			if ( color_bg == 4) namecolor_main = "ЖЁЛТЫЙ"
			if ( color_bg == 5) namecolor_main = "ОРАНЖЕВЫЙ"
			if ( color_bg == 6) namecolor_main = "ЗЕЛЁНОСИНИЙ"
			if ( color_bg == 7) namecolor_main = "СЕРЫЙ"
			if ( color_bg == 8) namecolor_main = "КРАСНЫЙ"
			if ( color_bg == 9) namecolor_main = "ЦВЕТНОЙ"


//			normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.MORE, {
//              second_path: 'sek_' + parseInt(color_bg) + '.png',
//             second_centerX: 240,
//              second_centerY: 240,
//              second_posX: 133,
//              second_posY: 254,
//              fresh_frequency: 17,
//              fresh_freqency: 17,
//              show_level: hmUI.show_level.ONLY_NORMAL,
//            });

		normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + parseInt(color_bg) + ".png");
		normal_battery_icon_img.setProperty(hmUI.prop.SRC, "scale_" + parseInt(color_bg) + ".png");		
		
		hmUI.showToast({text: namecolor_main });	
				
		vibro(28);
					
			}
		
		
 //  конец  изменения цвета фона		

//////////////////////////////////////////////////////////////////////////////////////////////////////

//  изменение цвета цифр


function click_Digit() {
            if(color_digt>=all_digt) {
            color_digt=1;
                }
            else { 
			color_digt=color_digt+1;   
			}
			
			if ( color_digt == 1) namecolor_digt = "БЕЛЫЙ"
			if ( color_digt == 2) namecolor_digt = "ЗЕЛЁНЫЙ"
			if ( color_digt == 3) namecolor_digt = "ГОЛУБОЙ"
			if ( color_digt == 4) namecolor_digt = "ЖЁЛТЫЙ"
			if ( color_digt == 5) namecolor_digt = "ОРАНЖЕВЫЙ"
			if ( color_digt == 6) namecolor_digt = "ЗЕЛЁНОСИНИЙ"
			if ( color_digt == 7) namecolor_digt = "СЕРЫЙ"

		 xxx_clock_h = 90
		 yyy_clock_h = 274
		 xxx_clock_m = 213
		 yyy_clock_m = 274
		 xxx_clock_s = 307
		 yyy_clock_s = 308
		 xxx_clock = 174
		 yyy_clock = 287
		 xxx_day = 131
		 yyy_day = 214
		 xxx_month = 184
		 yyy_month = 214
		 xxx_day_w = 53
		 yyy_day_w = 213
		 xxx_batt = 134
		 yyy_batt = 96



			
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: parseInt(color_digt) + '_am.png',
              am_en_path: parseInt(color_digt) + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: parseInt(color_digt) + '_pm.png',
              pm_en_path: parseInt(color_digt) + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
		
		normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 287,
              y: 234,
              src: parseInt(color_digt) + '_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
			
		normal_alarm_clock_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_alarm.png");
   
		
		normal_alarm_clock_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 325,
              y: 236,
              font_array: [parseInt(color_digt) + "_050.png",parseInt(color_digt) + "_051.png",parseInt(color_digt) + "_052.png",parseInt(color_digt) + "_053.png",parseInt(color_digt) + "_054.png",parseInt(color_digt) + "_055.png",parseInt(color_digt) + "_056.png",parseInt(color_digt) + "_057.png",parseInt(color_digt) + "_058.png",parseInt(color_digt) + "_059.png"],
              padding: true,
              h_space: 2,
              invalid_image: parseInt(color_digt) + '_eror_a.png',
              dot_image: parseInt(color_digt) + '_012.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
		
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: xxx_clock_h,
              hour_startY: yyy_clock_h,
              hour_array: [parseInt(color_digt) + "_001.png",parseInt(color_digt) + "_002.png",parseInt(color_digt) + "_003.png",parseInt(color_digt) + "_004.png",parseInt(color_digt) + "_005.png",parseInt(color_digt) + "_006.png",parseInt(color_digt) + "_007.png",parseInt(color_digt) + "_008.png",parseInt(color_digt) + "_009.png",parseInt(color_digt) + "_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: xxx_clock_m,
              minute_startY: yyy_clock_m,
              minute_array: [parseInt(color_digt) + "_001.png",parseInt(color_digt) + "_002.png",parseInt(color_digt) + "_003.png",parseInt(color_digt) + "_004.png",parseInt(color_digt) + "_005.png",parseInt(color_digt) + "_006.png",parseInt(color_digt) + "_007.png",parseInt(color_digt) + "_008.png",parseInt(color_digt) + "_009.png",parseInt(color_digt) + "_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: xxx_clock_s,
              second_startY: yyy_clock_s,
              second_array: [parseInt(color_digt) + "_013.png",parseInt(color_digt) + "_014.png",parseInt(color_digt) + "_015.png",parseInt(color_digt) + "_016.png",parseInt(color_digt) + "_017.png",parseInt(color_digt) + "_018.png",parseInt(color_digt) + "_019.png",parseInt(color_digt) + "_020.png",parseInt(color_digt) + "_021.png",parseInt(color_digt) + "_022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_011.png");
	
	
		
			
			
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 352,
              y: 167,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
			
		normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 255,
              y: 167,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 257,
              y: 79,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
				
		normal_pai_weekly_text_img.setProperty(hmUI.prop.MORE, {
              x: 229,
              y: 394,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_pai_day_text_img.setProperty(hmUI.prop.MORE, {
              x: 159,
              y: 394,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

		normal_pai_day_separator_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_tire.png");	
	
		
		
		
		normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: xxx_batt,
              y: yyy_batt,
              font_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_digt) + '_int.png',
              unit_tc: parseInt(color_digt) + '_int.png',
              unit_en: parseInt(color_digt) + '_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
		
		
        normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 6,
              y: 169,
              font_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_digt) + '_dig.png',
              unit_tc: parseInt(color_digt) + '_dig.png',
              unit_en: parseInt(color_digt) + '_dig.png',
              imperial_unit_sc: parseInt(color_digt) + '_dig.png',
              imperial_unit_tc: parseInt(color_digt) + '_dig.png',
              imperial_unit_en: parseInt(color_digt) + '_dig.png',
              negative_image: parseInt(color_digt) + '_minus.png',
              invalid_image: parseInt(color_digt) + '_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
		
        normal_spo2_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 375,
              y: 297,
              font_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_digt) + '_int.png',
              unit_tc: parseInt(color_digt) + '_int.png',
              unit_en: parseInt(color_digt) + '_int.png',
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_body_temp_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 6,
              y: 297,
              w: 84,
              h: 29,
              font_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              padding: false,
              h_space: 0,
              invalid_image: parseInt(color_digt) + '_eror.png',
              dot_image: parseInt(color_digt) + '_point.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			hmUI.showToast({text: namecolor_digt });	
				
			vibro(28);
					
			}
 //  конец  изменения цвета цифр







		
	
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_pai_day_separator_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_alarm_clock_icon_img = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_image_img = ''
        let normal_spo2_text_text_img = ''
        let normal_body_temp_text_text_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_bodyTemp_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 394,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 159,
              y: 394,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 394,
              src: '1_tire.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_heart_rate_linear_scale.setAlpha(150);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 355,
              // start_y: 133,
              // color: 0xFF000000,
              // lenght: 46,
              // line_width: 21,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 352,
              y: 167,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 1,
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_calorie_linear_scale.setAlpha(150);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 249,
              // start_y: 133,
              // color: 0xFF000000,
              // lenght: 78,
              // line_width: 20,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 167,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 287,
              y: 234,
              src: '1_alarm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_icon_img.setAlpha(125);

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 236,
              font_array: ["1_050.png","1_051.png","1_052.png","1_053.png","1_054.png","1_055.png","1_056.png","1_057.png","1_058.png","1_059.png"],
              padding: true,
              h_space: 2,
              invalid_image: '1_eror_a.png',
              dot_image: '1_012.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_step_linear_scale.setAlpha(150);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 248,
              // start_y: 44,
              // color: 0xFF000000,
              // lenght: 82,
              // line_width: 20,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 79,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 53,
              y: 213,
              week_en: ["b_023.png","b_024.png","b_025.png","b_026.png","b_027.png","b_028.png","b_029.png"],
              week_tc: ["b_023.png","b_024.png","b_025.png","b_026.png","b_027.png","b_028.png","b_029.png"],
              week_sc: ["b_023.png","b_024.png","b_025.png","b_026.png","b_027.png","b_028.png","b_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 184,
              month_startY: 214,
              month_sc_array: ["b_001.png","b_002.png","b_003.png","b_004.png","b_005.png","b_006.png","b_007.png","b_008.png","b_009.png","b_010.png"],
              month_tc_array: ["b_001.png","b_002.png","b_003.png","b_004.png","b_005.png","b_006.png","b_007.png","b_008.png","b_009.png","b_010.png"],
              month_en_array: ["b_001.png","b_002.png","b_003.png","b_004.png","b_005.png","b_006.png","b_007.png","b_008.png","b_009.png","b_010.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 131,
              day_startY: 214,
              day_sc_array: ["b_001.png","b_002.png","b_003.png","b_004.png","b_005.png","b_006.png","b_007.png","b_008.png","b_009.png","b_010.png"],
              day_tc_array: ["b_001.png","b_002.png","b_003.png","b_004.png","b_005.png","b_006.png","b_007.png","b_008.png","b_009.png","b_010.png"],
              day_en_array: ["b_001.png","b_002.png","b_003.png","b_004.png","b_005.png","b_006.png","b_007.png","b_008.png","b_009.png","b_010.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 163,
              // center_y: 111,
              // start_angle: -181,
              // end_angle: 181,
              // radius: 53,
              // line_width: 20,
              // line_cap: Flat,
              // color: 0xFF151515,
              // mirror: False,
              // inversion: True,
              // alpha: 180,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 163,
              center_y: 111,
              start_angle: 181,
              end_angle: -181,
              radius: 43,
              line_width: 20,
              corner_flag: 3,
              color: 0xFF151515,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(180);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 96,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["AOD_batt_01.png","AOD_batt_02.png","AOD_batt_03.png","AOD_batt_04.png","AOD_batt_05.png","AOD_batt_06.png","AOD_batt_07.png","AOD_batt_08.png","AOD_batt_09.png","AOD_batt_10.png","AOD_batt_11.png","AOD_batt_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'scale_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '1_am.png',
              am_en_path: '1_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '1_pm.png',
              pm_en_path: '1_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 90,
              hour_startY: 274,
              hour_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 213,
              minute_startY: 274,
              minute_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 307,
              second_startY: 308,
              second_array: ["1_013.png","1_014.png","1_015.png","1_016.png","1_017.png","1_018.png","1_019.png","1_020.png","1_021.png","1_022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 274,
              src: '1_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sek_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 126,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sek_1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 126,
              second_posY: 240,
              fresh_frequency: 17,
              fresh_freqency: 17,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 17,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'wp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 21,
              y: 104,
              image_array: ["wth00.png","wth01.png","wth02.png","wth03.png","wth04.png","wth05.png","wth06.png","wth07.png","wth08.png","wth09.png","wth10.png","wth11.png","wth12.png","wth13.png","wth14.png","wth15.png","wth16.png","wth17.png","wth18.png","wth19.png","wth20.png","wth21.png","wth22.png","wth23.png","wth24.png","wth25.png","wth26.png","wth27.png","wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 6,
              y: 169,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_dig.png',
              unit_tc: '1_dig.png',
              unit_en: '1_dig.png',
              imperial_unit_sc: '1_dig.png',
              imperial_unit_tc: '1_dig.png',
              imperial_unit_en: '1_dig.png',
              negative_image: '1_minus.png',
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 6,
                y: 169,
                font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
                padding: false,
                h_space: 0,
                unit_sc: '1_dig.png',
                unit_tc: '1_dig.png',
                unit_en: '1_dig.png',
                imperial_unit_sc: '1_dig.png',
                imperial_unit_tc: '1_dig.png',
                imperial_unit_en: '1_dig.png',
                negative_image: '1_minus.png',
                invalid_image: '1_eror.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 287,
              y: 234,
              src: '1_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG-TOP.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 375,
              y: 297,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_body_temp_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 6,
              y: 297,
              w: 84,
              h: 29,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 0,
              invalid_image: '1_eror.png',
              dot_image: '1_point.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 8,
              y: 181,
              week_en: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_tc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_sc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 180,
              month_startY: 182,
              month_sc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_tc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_en_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 111,
              day_startY: 182,
              day_sc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_tc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_en_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 74,
              font_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD_int.png',
              unit_tc: 'AOD_int.png',
              unit_en: 'AOD_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["AOD_batt_01.png","AOD_batt_02.png","AOD_batt_03.png","AOD_batt_04.png","AOD_batt_05.png","AOD_batt_06.png","AOD_batt_07.png","AOD_batt_08.png","AOD_batt_09.png","AOD_batt_10.png","AOD_batt_11.png","AOD_batt_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'AOD_am.png',
              am_en_path: 'AOD_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'AOD_pm.png',
              pm_en_path: 'AOD_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 48,
              hour_startY: 245,
              hour_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 218,
              minute_startY: 245,
              minute_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 351,
              second_startY: 247,
              second_array: ["AOD_013.png","AOD_014.png","AOD_015.png","AOD_016.png","AOD_017.png","AOD_018.png","AOD_019.png","AOD_020.png","AOD_021.png","AOD_022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 172,
              y: 258,
              src: 'AOD_011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'menu_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: 35,
              w: 126,
              h: 83,
              src: '00_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: 130,
              w: 95,
              h: 79,
              src: '00_empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 345,
              y: 128,
              w: 76,
              h: 81,
              src: '00_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 169,
              y: 383,
              w: 112,
              h: 60,
              src: '00_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,
              y: 55,
              w: 121,
              h: 115,
              src: '00_empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bodyTemp_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 267,
              w: 69,
              h: 74,
              src: '00_empty.png',
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 167,
              w: 56,
              h: 54,
              src: '00_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 368,
              y: 271,
              w: 72,
              h: 69,
              src: '00_empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 306,
              y: 283,
              w: 58,
              h: 70,
              src: '00_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 287,
              y: 218,
              w: 102,
              h: 45,
              src: '00_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 96,
              y: 270,
              w: 95,
              h: 97,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 198,
              w: 173,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 7,
              y: 95,
              w: 74,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index' });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 272,
              w: 91,
              h: 94,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Menu()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 63,
              y: 241,
              w: 297,
              h: 126,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Day()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 27,
              y: 150,
              w: 157,
              h: 137,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_BG()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 271,
              y: 150,
              w: 157,
              h: 137,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Digit()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 144,
              y: 298,
              w: 157,
              h: 137,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Exit()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	
Button_5.setProperty(hmUI.prop.VISIBLE, false);	
Button_6.setProperty(hmUI.prop.VISIBLE, false);      //   кнопка цвета фона
Button_7.setProperty(hmUI.prop.VISIBLE, false);      //   кнопка цвета цифр
Button_8.setProperty(hmUI.prop.VISIBLE, false);      //   кнопка выход их меню
image_top_img.setProperty(hmUI.prop.VISIBLE, false); 





            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 401;
                  let start_y_normal_heart_rate = 133;
                  let lenght_ls_normal_heart_rate = -46;
                  let line_width_ls_normal_heart_rate = 21;
                  let color_ls_normal_heart_rate = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = 1 - progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 327;
                  let start_y_normal_calorie = 133;
                  let lenght_ls_normal_calorie = -78;
                  let line_width_ls_normal_calorie = 20;
                  let color_ls_normal_calorie = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 330;
                  let start_y_normal_step = 44;
                  let lenght_ls_normal_step = -82;
                  let line_width_ls_normal_step = 20;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 163,
                      center_y: 111,
                      start_angle: 181,
                      end_angle: -181,
                      radius: 43,
                      line_width: 20,
                      corner_flag: 3,
                      color: 0xFF151515,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}