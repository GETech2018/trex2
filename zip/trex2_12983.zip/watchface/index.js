﻿/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start

    let normal_background_bg_img = "";
    let normal_day_TextRotate = new Array(2);
    let normal_day_TextRotate_ASCIIARRAY = new Array(10);
    let normal_day_TextRotate_img_width = 17;
    let normal_timerTextUpdate = undefined;
    let normal_analog_clock_pro_hour_pointer_img = "";
    let normal_analog_clock_pro_minute_pointer_img = "";
    let normal_analog_clock_pro_second_pointer_img = "";
    let normal_timerUpdate = undefined;
    let normal_timerUpdateSec = undefined;
    let idle_background_bg_img = "";
    let idle_analog_clock_time_pointer_hour = "";
    let idle_analog_clock_time_pointer_minute = "";
    let timeSensor = "";

    let timer_animate_seconds = undefined;

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start

        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "normal_bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
        // x: 364,
        // y: 354,
        // font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
        // zero: true,
        // unit_in_alignment: false,
        // h_space: 0,
        // angle: 44,
        // align_h: hmUI.align.RIGHT,
        // type: hmUI.data_type.DAY,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_day_TextRotate_ASCIIARRAY[0] = "date_0.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[1] = "date_1.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[2] = "date_2.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[3] = "date_3.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[4] = "date_4.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[5] = "date_5.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[6] = "date_6.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[7] = "date_7.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[8] = "date_8.png"; // set of images with numbers
        normal_day_TextRotate_ASCIIARRAY[9] = "date_9.png"; // set of images with numbers

        //start of ignored block
        for (let i = 0; i < 2; i++) {
          normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 454,
            h: 454,
            center_x: 364,
            center_y: 354,
            pos_x: 364,
            pos_y: 354,
            angle: 44,
            src: "date_0.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
        }
        //end of ignored block

        const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

        let screenType = hmSetting.getScreenType();
        const deviceInfo = hmSetting.getDeviceInfo();
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
          time_update(true, true);
        });

        // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'normal_hour.png',
        // center_x: 227,
        // center_y: 227,
        // x: 32,
        // y: 226,
        // start_angle: 0,
        // end_angle: 360,
        // type: hmUI.data_type.hour,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 32,
          pos_y: 227 - 226,
          center_x: 227,
          center_y: 227,
          src: "normal_hour.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'normal_minute.png',
        // center_x: 227,
        // center_y: 227,
        // x: 29,
        // y: 226,
        // start_angle: 0,
        // end_angle: 360,
        // type: hmUI.data_type.minute,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 29,
          pos_y: 227 - 226,
          center_x: 227,
          center_y: 227,
          src: "normal_minute.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'normal_seconds.png',
        // center_x: 227,
        // center_y: 227,
        // x: 30,
        // y: 227,
        // start_angle: 0,
        // end_angle: 360,
        // type: hmUI.data_type.second,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 30,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_seconds.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "aod_bg.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: "aod_hour.png",
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 29,
          hour_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: "aod_minute.png",
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 30,
          minute_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        function time_update(updateHour = false, updateMinute = false) {
          let hour = timeSensor.hour;
          let minute = timeSensor.minute;
          let second = timeSensor.second;

          if (updateHour) {
            let normal_hour = hour;
            let normal_fullAngle_hour = 360;
            if (normal_hour > 11) normal_hour -= 12;
            let normal_angle_hour = 0 + (normal_fullAngle_hour * normal_hour) / 12 + ((normal_fullAngle_hour / 12) * minute) / 60;
            if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
          }

          if (updateMinute) {
            let normal_fullAngle_minute = 360;
            let normal_angle_minute = 0 + (normal_fullAngle_minute * minute) / 60;
            if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
          }

          // let normal_fullAngle_second = 360;
          // let normal_angle_second = 0 + (normal_fullAngle_second * second) / 60;
          // if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);
        }

        let lastAngleSeconds = 0;
        let second_current_angle = 0;

        function time_update_sec() {
          // start timer
          second_current_angle = getSecondsNormalAngle(timeSensor.second - 1);
          lastAngleSeconds = getSecondsNormalAngle(timeSensor.second);
          setSeconds(second_current_angle);

          if (!timer_animate_seconds) {
            timer_animate_seconds = timer.createTimer(30, 30, function (option) {
              animate_seconds();
            });
          }
        }

        function animate_seconds() {
          second_current_angle += 360 / 60 / 3;

          setSeconds(second_current_angle);

          if (timer_animate_seconds && second_current_angle == lastAngleSeconds) {
            timer.stopTimer(timer_animate_seconds);
            timer_animate_seconds = undefined;

            lastAngleSeconds = second_current_angle;
          }
        }

        function setSeconds(angle) {
          if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, angle);
        }

        function getSecondsNormalAngle(second) {
          let normal_fullAngle_second = 360;
          let normal_angle_second = 0 + (normal_fullAngle_second * second) / 60;

          return normal_angle_second;
        }

        function text_update() {
          console.log("update text rotate day_TIME");
          let valueDay = timeNaw.day;
          let normal_day_rotate_string = parseInt(valueDay).toString();
          normal_day_rotate_string = normal_day_rotate_string.padStart(2, "0");

          if (screenType != hmSetting.screen_type.AOD) {
            for (var i = 1; i < 2; i++) {
              // hide all symbols
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            }
            if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {
              // display data if it was possible to get it
              let img_offset = 0;
              // alignment = RIGHT
              let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
              img_offset -= normal_day_TextRotate_posOffset;
              // alignment end

              let index = 0;
              for (let char of normal_day_rotate_string) {
                let charCode = char.charCodeAt() - 48;
                if (index >= 2) break;
                if (charCode >= 0 && charCode < 10) {
                  normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 364 + img_offset);
                  normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                  normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                  img_offset += normal_day_TextRotate_img_width;
                  index++;
                } // end if digit
              } // end char of string
            } // end isFinite
          }
        }

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            time_update(true, true);
            // init seconds arrow angle
            second_current_angle = getSecondsNormalAngle(timeSensor.second - 1);
            lastAngleSeconds = getSecondsNormalAngle(timeSensor.second);
            setSeconds(second_current_angle);

            text_update();
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerTextUpdate) {
                normal_timerTextUpdate = timer.createTimer(0, 1000, function (option) {
                  text_update();
                }); // end timer
              } // end timer check
            } // end screenType

            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdate) {
                let animDelay = timeSensor.utc % 1000;
                let animRepeat = 1000;
                normal_timerUpdate = timer.createTimer(animDelay, animRepeat, function (option) {
                  time_update(false, false);
                }); // end timer
              } // end timer check
            } // end screenType

            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSec) {
                normal_timerUpdateSec = timer.createTimer(0, 1000, function (option) {
                  time_update_sec();
                }); // end timer
              } // end timer check
            } // end screenType
          },
          pause_call: function () {
            if (normal_timerTextUpdate) {
              timer.stopTimer(normal_timerTextUpdate);
              normal_timerTextUpdate = undefined;
            }
            if (normal_timerUpdate) {
              timer.stopTimer(normal_timerUpdate);
              normal_timerUpdate = undefined;
            }
            if (normal_timerUpdateSec) {
              timer.stopTimer(normal_timerUpdateSec);
              normal_timerUpdateSec = undefined;
            }
          },
        });

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e && e.stack && e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
