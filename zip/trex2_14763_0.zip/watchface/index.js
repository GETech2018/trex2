﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start change color Hour and weekday
         let colornumber = 1
        let totalcolors = 8
        let namecolor = ''

        function click_ColorD() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "BLUE"}
if ( colornumber == 2) { namecolor = "YELLOW"}
if ( colornumber == 3) { namecolor = "RED"}
if ( colornumber == 4) { namecolor = "PINK"}
if ( colornumber == 5) { namecolor = "GREEN"}
if ( colornumber == 6) { namecolor = "VIOLET"}
if ( colornumber == 7) { namecolor = "ORANGE"}
if ( colornumber == 8) { namecolor = "GRAY"}
hmUI.showToast({text: namecolor });

             //hmUI.showToast({text: "color " + parseInt(colornumber) });
             normal_pai_icon_img.setProperty(hmUI.prop.SRC, "BG_Time_" + parseInt(colornumber) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

        // Start change color Progress
         let colornumberP = 1
        let totalcolorsP = 8
        let namecolorP = ''

        function click_ColorP() {
            if(colornumberP>=totalcolorsP) {
            colornumberP=1;
                }
            else {
                colornumberP=colornumberP+1;
            }

if ( colornumberP == 1) { namecolorP = "BLUE"}
if ( colornumberP == 2) { namecolorP = "YELLOW"}
if ( colornumberP == 3) { namecolorP = "RED"}
if ( colornumberP == 4) { namecolorP = "PINK"}
if ( colornumberP == 5) { namecolorP = "GREEN"}
if ( colornumberP == 6) { namecolorP = "VIOLET"}
if ( colornumberP == 7) { namecolorP = "ORANGE"}
if ( colornumberP == 8) { namecolorP = "GRAY"}
hmUI.showToast({text: namecolorP });

             normal_image_img.setProperty(hmUI.prop.SRC, "Progress_" + parseInt(colornumberP) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_pai_icon_img = ''
        let normal_pai_total_TextCircle = new Array(3);
        let normal_pai_total_TextCircle_ASCIIARRAY = new Array(10);
        let normal_pai_total_TextCircle_img_width = 13;
        let normal_pai_total_TextCircle_img_height = 14;
        let normal_pai_total_TextCircle_dot_width = 6;
        let normal_pai_total_TextCircle_error_img_width = 13;
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_spo2_TextCircle = new Array(3);
        let normal_spo2_TextCircle_ASCIIARRAY = new Array(10);
        let normal_spo2_TextCircle_img_width = 13;
        let normal_spo2_TextCircle_img_height = 14;
        let normal_spo2_TextCircle_unit = null;
        let normal_spo2_TextCircle_unit_width = 13;
        let normal_spo2_TextCircle_dot_width = 6;
        let normal_spo2_TextCircle_error_img_width = 13;
        let normal_sunset_TextCircle = new Array(5);
        let normal_sunset_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunset_TextCircle_img_width = 13;
        let normal_sunset_TextCircle_img_height = 14;
        let normal_sunset_TextCircle_dot_width = 6;
        let normal_sunrise_TextCircle = new Array(5);
        let normal_sunrise_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunrise_TextCircle_img_width = 13;
        let normal_sunrise_TextCircle_img_height = 14;
        let normal_sunrise_TextCircle_dot_width = 6;
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_pai_icon_img = ''
        let idle_pai_total_TextCircle = new Array(3);
        let idle_pai_total_TextCircle_ASCIIARRAY = new Array(10);
        let idle_pai_total_TextCircle_img_width = 13;
        let idle_pai_total_TextCircle_img_height = 14;
        let idle_pai_total_TextCircle_dot_width = 6;
        let idle_pai_total_TextCircle_error_img_width = 13;
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_spo2_TextCircle = new Array(3);
        let idle_spo2_TextCircle_ASCIIARRAY = new Array(10);
        let idle_spo2_TextCircle_img_width = 13;
        let idle_spo2_TextCircle_img_height = 14;
        let idle_spo2_TextCircle_unit = null;
        let idle_spo2_TextCircle_unit_width = 13;
        let idle_spo2_TextCircle_dot_width = 6;
        let idle_spo2_TextCircle_error_img_width = 13;
        let idle_sunset_TextCircle = new Array(5);
        let idle_sunset_TextCircle_ASCIIARRAY = new Array(10);
        let idle_sunset_TextCircle_img_width = 13;
        let idle_sunset_TextCircle_img_height = 14;
        let idle_sunset_TextCircle_dot_width = 6;
        let idle_sunrise_TextCircle = new Array(5);
        let idle_sunrise_TextCircle_ASCIIARRAY = new Array(10);
        let idle_sunrise_TextCircle_img_width = 13;
        let idle_sunrise_TextCircle_img_height = 14;
        let idle_sunrise_TextCircle_dot_width = 6;
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_circle_scale = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 226,
              src: 'Progress_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 73,
              src: 'BG_Time_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_pai_total_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["SS_Font_0.png","SS_Font_1.png","SS_Font_2.png","SS_Font_3.png","SS_Font_4.png","SS_Font_5.png","SS_Font_6.png","SS_Font_7.png","SS_Font_8.png","SS_Font_9.png"],
              // radius: 201,
              // angle: -21,
              // char_space_angle: 0,
              // dot_image: 'SS_Dot.png',
              // error_image: 'SS_Font_0.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_pai_total_TextCircle_ASCIIARRAY[0] = 'SS_Font_0.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[1] = 'SS_Font_1.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[2] = 'SS_Font_2.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[3] = 'SS_Font_3.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[4] = 'SS_Font_4.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[5] = 'SS_Font_5.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[6] = 'SS_Font_6.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[7] = 'SS_Font_7.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[8] = 'SS_Font_8.png';  // set of images with numbers
            normal_pai_total_TextCircle_ASCIIARRAY[9] = 'SS_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_pai_total_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_pai_total_TextCircle_img_width / 2,
                pos_y: 227 - 215,
                src: 'SS_Font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 62,
              y: 79,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 174,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_spo2_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["SS_Font_0.png","SS_Font_1.png","SS_Font_2.png","SS_Font_3.png","SS_Font_4.png","SS_Font_5.png","SS_Font_6.png","SS_Font_7.png","SS_Font_8.png","SS_Font_9.png"],
              // radius: 201,
              // angle: -68,
              // char_space_angle: 0,
              // unit: 'O2_unit.png',
              // dot_image: 'SS_Dot.png',
              // error_image: 'SS_Font_0.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SPO2,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_spo2_TextCircle_ASCIIARRAY[0] = 'SS_Font_0.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[1] = 'SS_Font_1.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[2] = 'SS_Font_2.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[3] = 'SS_Font_3.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[4] = 'SS_Font_4.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[5] = 'SS_Font_5.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[6] = 'SS_Font_6.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[7] = 'SS_Font_7.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[8] = 'SS_Font_8.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[9] = 'SS_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_spo2_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_spo2_TextCircle_img_width / 2,
                pos_y: 227 - 215,
                src: 'SS_Font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_spo2_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 227,
              center_y: 227,
              pos_x: 227 - normal_spo2_TextCircle_unit_width / 2,
              pos_y: 227 - 215,
              src: 'O2_unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
            spo2.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_sunset_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["SS_Font_0.png","SS_Font_1.png","SS_Font_2.png","SS_Font_3.png","SS_Font_4.png","SS_Font_5.png","SS_Font_6.png","SS_Font_7.png","SS_Font_8.png","SS_Font_9.png"],
              // radius: 198,
              // angle: 54,
              // char_space_angle: 0,
              // dot_image: 'SS_Dot.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunset_TextCircle_ASCIIARRAY[0] = 'SS_Font_0.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[1] = 'SS_Font_1.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[2] = 'SS_Font_2.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[3] = 'SS_Font_3.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[4] = 'SS_Font_4.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[5] = 'SS_Font_5.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[6] = 'SS_Font_6.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[7] = 'SS_Font_7.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[8] = 'SS_Font_8.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[9] = 'SS_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_sunset_TextCircle_img_width / 2,
                pos_y: 227 - 212,
                src: 'SS_Font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_sunrise_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["SS_Font_0.png","SS_Font_1.png","SS_Font_2.png","SS_Font_3.png","SS_Font_4.png","SS_Font_5.png","SS_Font_6.png","SS_Font_7.png","SS_Font_8.png","SS_Font_9.png"],
              // radius: 198,
              // angle: 27,
              // char_space_angle: 0,
              // dot_image: 'SS_Dot.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunrise_TextCircle_ASCIIARRAY[0] = 'SS_Font_0.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[1] = 'SS_Font_1.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[2] = 'SS_Font_2.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[3] = 'SS_Font_3.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[4] = 'SS_Font_4.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[5] = 'SS_Font_5.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[6] = 'SS_Font_6.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[7] = 'SS_Font_7.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[8] = 'SS_Font_8.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[9] = 'SS_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_sunrise_TextCircle_img_width / 2,
                pos_y: 227 - 212,
                src: 'SS_Font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 85,
              year_startY: 131,
              year_sc_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              year_tc_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              year_en_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              year_zero: 1,
              year_space: -1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 97,
              month_startY: 97,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 220,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 306,
              y: 80,
              image_array: ["Weather_small_01.png","Weather_small_02.png","Weather_small_03.png","Weather_small_04.png","Weather_small_05.png","Weather_small_06.png","Weather_small_07.png","Weather_small_08.png","Weather_small_09.png","Weather_small_10.png","Weather_small_11.png","Weather_small_12.png","Weather_small_13.png","Weather_small_14.png","Weather_small_15.png","Weather_small_16.png","Weather_small_17.png","Weather_small_18.png","Weather_small_19.png","Weather_small_20.png","Weather_small_21.png","Weather_small_22.png","Weather_small_23.png","Weather_small_24.png","Weather_small_25.png","Weather_small_26.png","Weather_small_27.png","Weather_small_28.png","Weather_small_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 126,
              font_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_Symbol1.png',
              unit_tc: 'Temp_Symbol1.png',
              unit_en: 'Temp_Symbol1.png',
              imperial_unit_sc: 'Temp_Symbol1.png',
              imperial_unit_tc: 'Temp_Symbol1.png',
              imperial_unit_en: 'Temp_Symbol1.png',
              negative_image: 'Temp_Symbol2.png',
              invalid_image: 'Temp_Symbol2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 305,
                y: 126,
                font_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_Symbol1.png',
                unit_tc: 'Temp_Symbol1.png',
                unit_en: 'Temp_Symbol1.png',
                imperial_unit_sc: 'Temp_Symbol1.png',
                imperial_unit_tc: 'Temp_Symbol1.png',
                imperial_unit_en: 'Temp_Symbol1.png',
                negative_image: 'Temp_Symbol2.png',
                invalid_image: 'Temp_Symbol2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 186,
              day_startY: 108,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 83,
              // center_y: 331,
              // start_angle: 202,
              // end_angle: 518,
              // radius: 23,
              // line_width: 5,
              // line_cap: Flat,
              // color: 0xFF3A3A3A,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 83,
              center_y: 331,
              start_angle: 518,
              end_angle: 202,
              radius: 21,
              line_width: 5,
              corner_flag: 3,
              color: 0xFF3A3A3A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 360,
              font_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 146,
              // center_y: 331,
              // start_angle: 202,
              // end_angle: 518,
              // radius: 23,
              // line_width: 5,
              // line_cap: Flat,
              // color: 0xFF3A3A3A,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 146,
              center_y: 331,
              start_angle: 518,
              end_angle: 202,
              radius: 21,
              line_width: 5,
              corner_flag: 3,
              color: 0xFF3A3A3A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 360,
              font_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 218,
              // center_y: 229,
              // start_angle: 175,
              // end_angle: 111,
              // radius: 224,
              // line_width: 22,
              // line_cap: Flat,
              // color: 0xFF444444,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 218,
              center_y: 229,
              start_angle: 111,
              end_angle: 175,
              radius: 213,
              line_width: 22,
              corner_flag: 3,
              color: 0xFF444444,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 300,
              src: 'TopStepProgress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 337,
              font_array: ["Step_font_0.png","Step_font_1.png","Step_font_2.png","Step_font_3.png","Step_font_4.png","Step_font_5.png","Step_font_6.png","Step_font_7.png","Step_font_8.png","Step_font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 392,
              font_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 195,
              y: 71,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 399,
              am_y: 201,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 399,
              pm_y: 201,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 397,
              second_startY: 233,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 241,
              minute_startY: 189,
              minute_array: ["Time_M_0.png","Time_M_1.png","Time_M_2.png","Time_M_3.png","Time_M_4.png","Time_M_5.png","Time_M_6.png","Time_M_7.png","Time_M_8.png","Time_M_9.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 68,
              hour_startY: 190,
              hour_array: ["Time_H_0.png","Time_H_1.png","Time_H_2.png","Time_H_3.png","Time_H_4.png","Time_H_5.png","Time_H_6.png","Time_H_7.png","Time_H_8.png","Time_H_9.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 226,
              src: 'Progress_8.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 73,
              src: 'BG_Time_8.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_pai_total_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["SS_Font_0.png","SS_Font_1.png","SS_Font_2.png","SS_Font_3.png","SS_Font_4.png","SS_Font_5.png","SS_Font_6.png","SS_Font_7.png","SS_Font_8.png","SS_Font_9.png"],
              // radius: 201,
              // angle: -21,
              // char_space_angle: 0,
              // dot_image: 'SS_Dot.png',
              // error_image: 'SS_Font_0.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_pai_total_TextCircle_ASCIIARRAY[0] = 'SS_Font_0.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[1] = 'SS_Font_1.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[2] = 'SS_Font_2.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[3] = 'SS_Font_3.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[4] = 'SS_Font_4.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[5] = 'SS_Font_5.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[6] = 'SS_Font_6.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[7] = 'SS_Font_7.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[8] = 'SS_Font_8.png';  // set of images with numbers
            idle_pai_total_TextCircle_ASCIIARRAY[9] = 'SS_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_pai_total_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - idle_pai_total_TextCircle_img_width / 2,
                pos_y: 227 - 215,
                src: 'SS_Font_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 62,
              y: 79,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 174,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_spo2_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["SS_Font_0.png","SS_Font_1.png","SS_Font_2.png","SS_Font_3.png","SS_Font_4.png","SS_Font_5.png","SS_Font_6.png","SS_Font_7.png","SS_Font_8.png","SS_Font_9.png"],
              // radius: 201,
              // angle: -68,
              // char_space_angle: 0,
              // unit: 'O2_unit.png',
              // dot_image: 'SS_Dot.png',
              // error_image: 'SS_Font_0.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SPO2,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_spo2_TextCircle_ASCIIARRAY[0] = 'SS_Font_0.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[1] = 'SS_Font_1.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[2] = 'SS_Font_2.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[3] = 'SS_Font_3.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[4] = 'SS_Font_4.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[5] = 'SS_Font_5.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[6] = 'SS_Font_6.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[7] = 'SS_Font_7.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[8] = 'SS_Font_8.png';  // set of images with numbers
            idle_spo2_TextCircle_ASCIIARRAY[9] = 'SS_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_spo2_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - idle_spo2_TextCircle_img_width / 2,
                pos_y: 227 - 215,
                src: 'SS_Font_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_spo2_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 227,
              center_y: 227,
              pos_x: 227 - idle_spo2_TextCircle_unit_width / 2,
              pos_y: 227 - 215,
              src: 'O2_unit.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_sunset_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["SS_Font_0.png","SS_Font_1.png","SS_Font_2.png","SS_Font_3.png","SS_Font_4.png","SS_Font_5.png","SS_Font_6.png","SS_Font_7.png","SS_Font_8.png","SS_Font_9.png"],
              // radius: 198,
              // angle: 54,
              // char_space_angle: 0,
              // dot_image: 'SS_Dot.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_sunset_TextCircle_ASCIIARRAY[0] = 'SS_Font_0.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[1] = 'SS_Font_1.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[2] = 'SS_Font_2.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[3] = 'SS_Font_3.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[4] = 'SS_Font_4.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[5] = 'SS_Font_5.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[6] = 'SS_Font_6.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[7] = 'SS_Font_7.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[8] = 'SS_Font_8.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[9] = 'SS_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - idle_sunset_TextCircle_img_width / 2,
                pos_y: 227 - 212,
                src: 'SS_Font_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_sunrise_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["SS_Font_0.png","SS_Font_1.png","SS_Font_2.png","SS_Font_3.png","SS_Font_4.png","SS_Font_5.png","SS_Font_6.png","SS_Font_7.png","SS_Font_8.png","SS_Font_9.png"],
              // radius: 198,
              // angle: 27,
              // char_space_angle: 0,
              // dot_image: 'SS_Dot.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_sunrise_TextCircle_ASCIIARRAY[0] = 'SS_Font_0.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[1] = 'SS_Font_1.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[2] = 'SS_Font_2.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[3] = 'SS_Font_3.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[4] = 'SS_Font_4.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[5] = 'SS_Font_5.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[6] = 'SS_Font_6.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[7] = 'SS_Font_7.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[8] = 'SS_Font_8.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[9] = 'SS_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - idle_sunrise_TextCircle_img_width / 2,
                pos_y: 227 - 212,
                src: 'SS_Font_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 85,
              year_startY: 131,
              year_sc_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              year_tc_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              year_en_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              year_zero: 1,
              year_space: -1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 97,
              month_startY: 97,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 220,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 306,
              y: 80,
              image_array: ["Weather_small_01.png","Weather_small_02.png","Weather_small_03.png","Weather_small_04.png","Weather_small_05.png","Weather_small_06.png","Weather_small_07.png","Weather_small_08.png","Weather_small_09.png","Weather_small_10.png","Weather_small_11.png","Weather_small_12.png","Weather_small_13.png","Weather_small_14.png","Weather_small_15.png","Weather_small_16.png","Weather_small_17.png","Weather_small_18.png","Weather_small_19.png","Weather_small_20.png","Weather_small_21.png","Weather_small_22.png","Weather_small_23.png","Weather_small_24.png","Weather_small_25.png","Weather_small_26.png","Weather_small_27.png","Weather_small_28.png","Weather_small_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 126,
              font_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_Symbol1.png',
              unit_tc: 'Temp_Symbol1.png',
              unit_en: 'Temp_Symbol1.png',
              imperial_unit_sc: 'Temp_Symbol1.png',
              imperial_unit_tc: 'Temp_Symbol1.png',
              imperial_unit_en: 'Temp_Symbol1.png',
              negative_image: 'Temp_Symbol2.png',
              invalid_image: 'Temp_Symbol2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 305,
                y: 126,
                font_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_Symbol1.png',
                unit_tc: 'Temp_Symbol1.png',
                unit_en: 'Temp_Symbol1.png',
                imperial_unit_sc: 'Temp_Symbol1.png',
                imperial_unit_tc: 'Temp_Symbol1.png',
                imperial_unit_en: 'Temp_Symbol1.png',
                negative_image: 'Temp_Symbol2.png',
                invalid_image: 'Temp_Symbol2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 186,
              day_startY: 108,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 83,
              // center_y: 331,
              // start_angle: 202,
              // end_angle: 518,
              // radius: 23,
              // line_width: 5,
              // line_cap: Flat,
              // color: 0xFF3A3A3A,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 83,
              center_y: 331,
              start_angle: 518,
              end_angle: 202,
              radius: 21,
              line_width: 5,
              corner_flag: 3,
              color: 0xFF3A3A3A,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 360,
              font_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 146,
              // center_y: 331,
              // start_angle: 202,
              // end_angle: 518,
              // radius: 23,
              // line_width: 5,
              // line_cap: Flat,
              // color: 0xFF3A3A3A,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 146,
              center_y: 331,
              start_angle: 518,
              end_angle: 202,
              radius: 21,
              line_width: 5,
              corner_flag: 3,
              color: 0xFF3A3A3A,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 360,
              font_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 218,
              // center_y: 229,
              // start_angle: 175,
              // end_angle: 111,
              // radius: 224,
              // line_width: 22,
              // line_cap: Flat,
              // color: 0xFF444444,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 218,
              center_y: 229,
              start_angle: 111,
              end_angle: 175,
              radius: 213,
              line_width: 22,
              corner_flag: 3,
              color: 0xFF444444,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 300,
              src: 'TopStepProgress.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 337,
              font_array: ["Step_font_0.png","Step_font_1.png","Step_font_2.png","Step_font_3.png","Step_font_4.png","Step_font_5.png","Step_font_6.png","Step_font_7.png","Step_font_8.png","Step_font_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 392,
              font_array: ["Dis_font_0.png","Dis_font_1.png","Dis_font_2.png","Dis_font_3.png","Dis_font_4.png","Dis_font_5.png","Dis_font_6.png","Dis_font_7.png","Dis_font_8.png","Dis_font_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 195,
              y: 71,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 399,
              am_y: 201,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 399,
              pm_y: 201,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 241,
              minute_startY: 189,
              minute_array: ["Time_M_0.png","Time_M_1.png","Time_M_2.png","Time_M_3.png","Time_M_4.png","Time_M_5.png","Time_M_6.png","Time_M_7.png","Time_M_8.png","Time_M_9.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 68,
              hour_startY: 190,
              hour_array: ["Time_H_0.png","Time_H_1.png","Time_H_2.png","Time_H_3.png","Time_H_4.png","Time_H_5.png","Time_H_6.png","Time_H_7.png","Time_H_8.png","Time_H_9.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BL.Rozłączony,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BL.Połączony,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BL.Rozłączony"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BL.Połączony"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
              // everyHour_toast_text: Godz.,
              // repeatingAlert_vibrate_type: 0,
              // repeatingAlert_toast_text: pół.,
              // repeatingAlert_repeat_period: 30,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                hmUI.showToast({text: "Godz."});
                vibro(0);
              }
              if(timeSensor.minute % 30 == 0 && !hourEnd) {
                hmUI.showToast({text: "pół."});
                vibro(0);
              }
            };

            // end repeat alerts
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 311,
              w: 175,
              h: 21,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 122,
              y: 309,
              w: 48,
              h: 44,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 22,
              w: 95,
              h: 45,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 288,
              y: 11,
              w: 117,
              h: 75,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 307,
              y: 111,
              w: 56,
              h: 41,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 131,
              w: 38,
              h: 58,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 275,
              y: 191,
              w: 88,
              h: 72,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 379,
              y: 215,
              w: 79,
              h: 44,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 214,
              y: 167,
              w: 36,
              h: 91,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 309,
              w: 47,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 87,
              w: 67,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 166,
              y: 388,
              w: 119,
              h: 27,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 56,
              y: 143,
              w: 40,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //Change color  Hour and weekday
                click_ColorD()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 14,
              y: 267,
              w: 41,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change color progress and seconds
                click_ColorP()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle pai_total_PAI');
              let totalPAI = pai.totalpai;
              let normal_pai_total_circle_string = parseInt(totalPAI).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -21;
                if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && normal_pai_total_circle_string.length > 0 && normal_pai_total_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_pai_total_TextCircle_img_angle = 0;
                  let normal_pai_total_TextCircle_dot_img_angle = 0;
                  normal_pai_total_TextCircle_img_angle = toDegree(Math.atan2(normal_pai_total_TextCircle_img_width/2, 201));
                  normal_pai_total_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_pai_total_TextCircle_dot_width/2, 201));
                  // alignment = RIGHT
                  let normal_pai_total_TextCircle_angleOffset = normal_pai_total_TextCircle_img_angle * (normal_pai_total_circle_string.length - 1);
                  char_Angle -= 2 * normal_pai_total_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_pai_total_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_pai_total_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_pai_total_TextCircle_img_width / 2);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, normal_pai_total_TextCircle_ASCIIARRAY[charCode]);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_pai_total_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_pai_total_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_pai_total_TextCircle_dot_width / 2);
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, 'SS_Dot.png');
                      normal_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_pai_total_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_pai_total_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_pai_total_TextCircle[0].setProperty(hmUI.prop.POS_X, 227 - normal_pai_total_TextCircle_error_img_width / 2);
                  normal_pai_total_TextCircle[0].setProperty(hmUI.prop.SRC, 'SS_Font_0.png');
                  normal_pai_total_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle spo2_SPO2');
              let valueSpO2 = spo2.current;
              let normal_spo2_circle_string = parseInt(valueSpO2).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -68;
                if (valueSpO2 != null && valueSpO2 != undefined && isFinite(valueSpO2) && normal_spo2_circle_string.length > 0 && normal_spo2_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_spo2_TextCircle_img_angle = 0;
                  let normal_spo2_TextCircle_dot_img_angle = 0;
                  let normal_spo2_TextCircle_unit_angle = 0;
                  normal_spo2_TextCircle_img_angle = toDegree(Math.atan2(normal_spo2_TextCircle_img_width/2, 201));
                  normal_spo2_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_spo2_TextCircle_dot_width/2, 201));
                  normal_spo2_TextCircle_unit_angle = toDegree(Math.atan2(normal_spo2_TextCircle_unit_width/2, 201));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_spo2_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_spo2_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_spo2_TextCircle_img_width / 2);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.SRC, normal_spo2_TextCircle_ASCIIARRAY[charCode]);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_spo2_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_spo2_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_spo2_TextCircle_dot_width / 2);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.SRC, 'SS_Dot.png');
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_spo2_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_spo2_TextCircle_unit_angle;
                  normal_spo2_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_spo2_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_spo2_TextCircle[0].setProperty(hmUI.prop.POS_X, 227 - normal_spo2_TextCircle_error_img_width / 2);
                  normal_spo2_TextCircle[0].setProperty(hmUI.prop.SRC, 'SS_Font_0.png');
                  normal_spo2_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let tideData = weatherData.tideData;
              let sunset_hour = -1;
              let sunset_minute = -1;
              if (tideData.count > 0) {
                sunset_hour = tideData.data[0].sunset.hour;
                sunset_minute = tideData.data[0].sunset.minute;
              }; // end tideData;

              console.log('update text circle sunset_tideData');
              let sunsetTime = undefined;
              let normal_sunset_circle_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                normal_sunset_circle_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 54;
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_circle_string.length > 0 && normal_sunset_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_sunset_TextCircle_img_angle = 0;
                  let normal_sunset_TextCircle_dot_img_angle = 0;
                  normal_sunset_TextCircle_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_img_width/2, 198));
                  normal_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_dot_width/2, 198));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunset_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_sunset_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_sunset_TextCircle_img_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunset_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunset_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_sunset_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_sunset_TextCircle_dot_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'SS_Dot.png');
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunset_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };
              let sunrise_hour = -1;
              let sunrise_minute = -1;
              if (tideData.count > 0) {
                sunrise_hour = tideData.data[0].sunrise.hour;
                sunrise_minute = tideData.data[0].sunrise.minute;
              }; // end tideData;

              console.log('update text circle sunrise_tideData');
              let sunriseTime = undefined;
              let normal_sunrise_circle_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                normal_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 27;
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_circle_string.length > 0 && normal_sunrise_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_sunrise_TextCircle_img_angle = 0;
                  let normal_sunrise_TextCircle_dot_img_angle = 0;
                  normal_sunrise_TextCircle_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_img_width/2, 198));
                  normal_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_dot_width/2, 198));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunrise_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_sunrise_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_sunrise_TextCircle_img_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunrise_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_sunrise_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_sunrise_TextCircle_dot_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'SS_Dot.png');
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunrise_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle pai_total_PAI');
              let idle_pai_total_circle_string = parseInt(totalPAI).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_pai_total_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -21;
                if (totalPAI != null && totalPAI != undefined && isFinite(totalPAI) && idle_pai_total_circle_string.length > 0 && idle_pai_total_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_pai_total_TextCircle_img_angle = 0;
                  let idle_pai_total_TextCircle_dot_img_angle = 0;
                  idle_pai_total_TextCircle_img_angle = toDegree(Math.atan2(idle_pai_total_TextCircle_img_width/2, 201));
                  idle_pai_total_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_pai_total_TextCircle_dot_width/2, 201));
                  // alignment = RIGHT
                  let idle_pai_total_TextCircle_angleOffset = idle_pai_total_TextCircle_img_angle * (idle_pai_total_circle_string.length - 1);
                  char_Angle -= 2 * idle_pai_total_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_pai_total_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_pai_total_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_pai_total_TextCircle_img_width / 2);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, idle_pai_total_TextCircle_ASCIIARRAY[charCode]);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_pai_total_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_pai_total_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_pai_total_TextCircle_dot_width / 2);
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.SRC, 'SS_Dot.png');
                      idle_pai_total_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_pai_total_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_pai_total_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_pai_total_TextCircle[0].setProperty(hmUI.prop.POS_X, 227 - idle_pai_total_TextCircle_error_img_width / 2);
                  idle_pai_total_TextCircle[0].setProperty(hmUI.prop.SRC, 'SS_Font_0.png');
                  idle_pai_total_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle spo2_SPO2');
              let idle_spo2_circle_string = parseInt(valueSpO2).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -68;
                if (valueSpO2 != null && valueSpO2 != undefined && isFinite(valueSpO2) && idle_spo2_circle_string.length > 0 && idle_spo2_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_spo2_TextCircle_img_angle = 0;
                  let idle_spo2_TextCircle_dot_img_angle = 0;
                  let idle_spo2_TextCircle_unit_angle = 0;
                  idle_spo2_TextCircle_img_angle = toDegree(Math.atan2(idle_spo2_TextCircle_img_width/2, 201));
                  idle_spo2_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_spo2_TextCircle_dot_width/2, 201));
                  idle_spo2_TextCircle_unit_angle = toDegree(Math.atan2(idle_spo2_TextCircle_unit_width/2, 201));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_spo2_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_spo2_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_spo2_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_spo2_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_spo2_TextCircle_img_width / 2);
                      idle_spo2_TextCircle[index].setProperty(hmUI.prop.SRC, idle_spo2_TextCircle_ASCIIARRAY[charCode]);
                      idle_spo2_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_spo2_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_spo2_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_spo2_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_spo2_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_spo2_TextCircle_dot_width / 2);
                      idle_spo2_TextCircle[index].setProperty(hmUI.prop.SRC, 'SS_Dot.png');
                      idle_spo2_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_spo2_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += idle_spo2_TextCircle_unit_angle;
                  idle_spo2_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_spo2_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_spo2_TextCircle[0].setProperty(hmUI.prop.POS_X, 227 - idle_spo2_TextCircle_error_img_width / 2);
                  idle_spo2_TextCircle[0].setProperty(hmUI.prop.SRC, 'SS_Font_0.png');
                  idle_spo2_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle sunset_tideData');
              let idle_sunset_circle_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                idle_sunset_circle_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 54;
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && idle_sunset_circle_string.length > 0 && idle_sunset_circle_string.length <= 5) {  // display data if it was possible to get it
                  let idle_sunset_TextCircle_img_angle = 0;
                  let idle_sunset_TextCircle_dot_img_angle = 0;
                  idle_sunset_TextCircle_img_angle = toDegree(Math.atan2(idle_sunset_TextCircle_img_width/2, 198));
                  idle_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_sunset_TextCircle_dot_width/2, 198));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_sunset_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_sunset_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_sunset_TextCircle_img_width / 2);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, idle_sunset_TextCircle_ASCIIARRAY[charCode]);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_sunset_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_sunset_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_sunset_TextCircle_dot_width / 2);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'SS_Dot.png');
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_sunset_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle sunrise_tideData');
              let idle_sunrise_circle_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                idle_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 27;
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && idle_sunrise_circle_string.length > 0 && idle_sunrise_circle_string.length <= 5) {  // display data if it was possible to get it
                  let idle_sunrise_TextCircle_img_angle = 0;
                  let idle_sunrise_TextCircle_dot_img_angle = 0;
                  idle_sunrise_TextCircle_img_angle = toDegree(Math.atan2(idle_sunrise_TextCircle_img_width/2, 198));
                  idle_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_sunrise_TextCircle_dot_width/2, 198));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_sunrise_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_sunrise_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_sunrise_TextCircle_img_width / 2);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, idle_sunrise_TextCircle_ASCIIARRAY[charCode]);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_sunrise_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_sunrise_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_sunrise_TextCircle_dot_width / 2);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'SS_Dot.png');
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_sunrise_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 83,
                      center_y: 331,
                      start_angle: 518,
                      end_angle: 202,
                      radius: 21,
                      line_width: 5,
                      corner_flag: 3,
                      color: 0xFF3A3A3A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 146,
                      center_y: 331,
                      start_angle: 518,
                      end_angle: 202,
                      radius: 21,
                      line_width: 5,
                      corner_flag: 3,
                      color: 0xFF3A3A3A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 218,
                      center_y: 229,
                      start_angle: 111,
                      end_angle: 175,
                      radius: 213,
                      line_width: 22,
                      corner_flag: 3,
                      color: 0xFF444444,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 83,
                      center_y: 331,
                      start_angle: 518,
                      end_angle: 202,
                      radius: 21,
                      line_width: 5,
                      corner_flag: 3,
                      color: 0xFF3A3A3A,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                let progress_cs_idle_heart_rate = 1 - progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_heart_rate * 100);
                  if (idle_heart_rate_circle_scale) {
                    idle_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 146,
                      center_y: 331,
                      start_angle: 518,
                      end_angle: 202,
                      radius: 21,
                      line_width: 5,
                      corner_flag: 3,
                      color: 0xFF3A3A3A,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = 1 - progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 218,
                      center_y: 229,
                      start_angle: 111,
                      end_angle: 175,
                      radius: 213,
                      line_width: 22,
                      corner_flag: 3,
                      color: 0xFF444444,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}