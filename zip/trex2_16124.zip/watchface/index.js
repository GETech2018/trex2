﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_clock_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Seiko_Arnie_1_copy.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 131,
              y: 45,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 131,
              y: 62,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_17x105_shadow.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 16,
              hour_posY: 99,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_25x149_shadow.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 24,
              minute_posY: 141,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_12x176_shadow.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 11,
              second_posY: 166,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 185,
              hour_startY: 47,
              hour_array: ["minute_0.png","minute_1.png","minute_2.png","minute_3.png","minute_4.png","minute_5.png","minute_6.png","minute_7.png","minute_8.png","minute_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'dot_dot.png',
              hour_unit_tc: 'dot_dot.png',
              hour_unit_en: 'dot_dot.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 232,
              minute_startY: 47,
              minute_array: ["minute_0.png","minute_1.png","minute_2.png","minute_3.png","minute_4.png","minute_5.png","minute_6.png","minute_7.png","minute_8.png","minute_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 272,
              second_startY: 52,
              second_array: ["second_0.png","second_1.png","second_2.png","second_3.png","second_4.png","second_5.png","second_6.png","second_7.png","second_8.png","second_9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Seiko_snj025_AOD_k.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 131,
              y: 62,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_17x105_AOD_2.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 16,
              hour_posY: 99,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_25x149_AOD_2.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 24,
              minute_posY: 141,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 185,
              hour_startY: 47,
              hour_array: ["minute_0.png","minute_1.png","minute_2.png","minute_3.png","minute_4.png","minute_5.png","minute_6.png","minute_7.png","minute_8.png","minute_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'dot_dot.png',
              hour_unit_tc: 'dot_dot.png',
              hour_unit_en: 'dot_dot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 232,
              minute_startY: 47,
              minute_array: ["minute_0.png","minute_1.png","minute_2.png","minute_3.png","minute_4.png","minute_5.png","minute_6.png","minute_7.png","minute_8.png","minute_9.png"],
              minute_zero: 0,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 272,
              second_startY: 52,
              second_array: ["second_0.png","second_1.png","second_2.png","second_3.png","second_4.png","second_5.png","second_6.png","second_7.png","second_8.png","second_9.png"],
              second_zero: 0,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 334,
              w: 95,
              h: 95,
              src: 'hotzone50x50.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 181,
              w: 95,
              h: 95,
              src: 'hotzone50x50.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 181,
              w: 95,
              h: 95,
              src: 'hotzone50x50.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 182,
              w: 95,
              h: 95,
              src: 'hotzone50x50.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 139,
              y: 37,
              w: 179,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'hotzone50x50.png',
              normal_src: 'hotzone50x50.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}