﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_time_hour_min_sec_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_time_hour_min_sec_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 326,
              day_startY: 337,
              day_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_zero: 0,
              day_space: 7,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 199,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 237,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 230,
              // center_y: 341,
              // start_angle: 122,
              // end_angle: -123,
              // radius: 68,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 230,
              center_y: 341,
              start_angle: 122,
              end_angle: -123,
              radius: 66,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 320,
              font_array: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'day.png',
              center_x: 112,
              center_y: 225,
              posX: 20,
              posY: 48,
              start_angle: 187,
              end_angle: 333,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_time_hour_min_sec_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 151,
              y: 89,
              w: 150,
              h: 42,
              text_size: 26,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0005.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 229,
              hour_posY: 256,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0003.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 227,
              minute_posY: 282,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0004.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 228,
              second_posY: 259,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 326,
              day_startY: 337,
              day_sc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_tc_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_en_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              day_zero: 0,
              day_space: 7,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 199,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 237,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 230,
              // center_y: 341,
              // start_angle: 122,
              // end_angle: -123,
              // radius: 68,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 230,
              center_y: 341,
              start_angle: 122,
              end_angle: -123,
              radius: 66,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 320,
              font_array: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'day.png',
              center_x: 112,
              center_y: 225,
              posX: 20,
              posY: 48,
              start_angle: 187,
              end_angle: 333,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_sec_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 151,
              y: 89,
              w: 150,
              h: 42,
              text_size: 26,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0005.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 229,
              hour_posY: 256,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0003.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 227,
              minute_posY: 282,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0004.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 228,
              second_posY: 259,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min:sec font');
              let normal_HourMinSecStr = format_hour.toString();
              normal_HourMinSecStr = normal_HourMinSecStr.padStart(2, '0');
              normal_HourMinSecStr = normal_HourMinSecStr + ':' + minute.toString().padStart(2, '0') + ':' + second.toString().padStart(2, '0');
              if (!timeSensor.is24Hour) {
                if (hour > 11) normal_HourMinSecStr = 'Pm ' + normal_HourMinSecStr
                else normal_HourMinSecStr = 'Am ' + normal_HourMinSecStr
              };
              normal_time_hour_min_sec_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinSecStr );
              console.log('hour:min:sec font');
              let idle_HourMinSecStr = format_hour.toString();
              idle_HourMinSecStr = idle_HourMinSecStr.padStart(2, '0');
              idle_HourMinSecStr = idle_HourMinSecStr + ':' + minute.toString().padStart(2, '0') + ':' + second.toString().padStart(2, '0');
              if (!timeSensor.is24Hour) {
                if (hour > 11) idle_HourMinSecStr = 'Pm ' + idle_HourMinSecStr
                else idle_HourMinSecStr = 'Am ' + idle_HourMinSecStr
              };
              idle_time_hour_min_sec_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinSecStr );
            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 230,
                      center_y: 341,
                      start_angle: 122,
                      end_angle: -123,
                      radius: 66,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFFF8C00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 230,
                      center_y: 341,
                      start_angle: 122,
                      end_angle: -123,
                      radius: 66,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFFF8C00,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}