﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 38;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 38;
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 38;
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 38;
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'base01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 147,
              // y: 246,
              // font_array: ["550.png","551.png","552.png","553.png","554.png","555.png","556.png","557.png","558.png","559.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -48,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = '550.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = '551.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = '552.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = '553.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = '554.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = '555.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = '556.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = '557.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = '558.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = '559.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 147,
                center_y: 246,
                pos_x: 147,
                pos_y: 246,
                angle: -48,
                src: '550.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 240,
              // y: 143,
              // font_array: ["550.png","551.png","552.png","553.png","554.png","555.png","556.png","557.png","558.png","559.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -48,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = '550.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = '551.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = '552.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = '553.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = '554.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = '555.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = '556.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = '557.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = '558.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = '559.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 240,
                center_y: 143,
                pos_x: 240,
                pos_y: 143,
                angle: -48,
                src: '550.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 347,
              day_startY: 229,
              day_sc_array: ["440.png","441.png","442.png","443.png","444.png","445.png","446.png","447.png","448.png","449.png"],
              day_tc_array: ["440.png","441.png","442.png","443.png","444.png","445.png","446.png","447.png","448.png","449.png"],
              day_en_array: ["440.png","441.png","442.png","443.png","444.png","445.png","446.png","447.png","448.png","449.png"],
              day_zero: 1,
              day_space: -29,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 161,
              y: 199,
              week_en: ["220mo.png","221tu.png","222we.png","223th.png","224fr.png","224th.png","225fr.png"],
              week_tc: ["220mo.png","221tu.png","222we.png","223th.png","224fr.png","224th.png","225fr.png"],
              week_sc: ["220mo.png","221tu.png","222we.png","223th.png","224fr.png","224th.png","225fr.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 204,
              month_startY: 155,
              month_sc_array: ["330ja.png","331fe.png","332ma.png","333ap.png","334ma.png","335ju.png","336ju.png","337au.png","338se.png","3391oc.png","3392no.png","3393de.png"],
              month_tc_array: ["330ja.png","331fe.png","332ma.png","333ap.png","334ma.png","335ju.png","336ju.png","337au.png","338se.png","3391oc.png","3392no.png","3393de.png"],
              month_en_array: ["330ja.png","331fe.png","332ma.png","333ap.png","334ma.png","335ju.png","336ju.png","337au.png","338se.png","3391oc.png","3392no.png","3393de.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hr.png',
              hour_centerX: 214,
              hour_centerY: 211,
              hour_posX: 17,
              hour_posY: 144,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'mn.png',
              minute_centerX: 214,
              minute_centerY: 211,
              minute_posX: 17,
              minute_posY: 145,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 214,
              second_centerY: 211,
              second_posX: 17,
              second_posY: 146,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 190,
              y: 396,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 141,
              y: 120,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'base02.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 147,
              // y: 246,
              // font_array: ["550.png","551.png","552.png","553.png","554.png","555.png","556.png","557.png","558.png","559.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -48,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = '550.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = '551.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = '552.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = '553.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = '554.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = '555.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = '556.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = '557.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = '558.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = '559.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 147,
                center_y: 246,
                pos_x: 147,
                pos_y: 246,
                angle: -48,
                src: '550.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 240,
              // y: 143,
              // font_array: ["550.png","551.png","552.png","553.png","554.png","555.png","556.png","557.png","558.png","559.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -48,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = '550.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = '551.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = '552.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = '553.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = '554.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = '555.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = '556.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = '557.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = '558.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = '559.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 240,
                center_y: 143,
                pos_x: 240,
                pos_y: 143,
                angle: -48,
                src: '550.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 347,
              day_startY: 229,
              day_sc_array: ["440.png","441.png","442.png","443.png","444.png","445.png","446.png","447.png","448.png","449.png"],
              day_tc_array: ["440.png","441.png","442.png","443.png","444.png","445.png","446.png","447.png","448.png","449.png"],
              day_en_array: ["440.png","441.png","442.png","443.png","444.png","445.png","446.png","447.png","448.png","449.png"],
              day_zero: 1,
              day_space: -29,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hr.png',
              hour_centerX: 214,
              hour_centerY: 211,
              hour_posX: 17,
              hour_posY: 144,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'mn.png',
              minute_centerX: 214,
              minute_centerY: 211,
              minute_posX: 17,
              minute_posY: 145,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 214,
              second_centerY: 211,
              second_posX: 17,
              second_posY: 146,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 190,
              y: 396,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 141,
              y: 120,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 131,
              y: 142,
              w: 150,
              h: 150,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 159,
              y: 321,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();
              normal_battery_rotate_string = normal_battery_rotate_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + -20 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 147 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + -20 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 240 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();
              idle_battery_rotate_string = idle_battery_rotate_string.padStart(3, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + -20 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 147 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  idle_step_TextRotate_posOffset = idle_step_TextRotate_posOffset + -20 * (idle_step_rotate_string.length - 1);
                  img_offset -= idle_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 240 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}