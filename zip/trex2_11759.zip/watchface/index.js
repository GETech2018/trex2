﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_second_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'floating-ring-160536_640.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 263,
              day_startY: 140,
              day_sc_array: ["a0005_(Copy).png","a0006_(Copy).png","a0007_(Copy).png","a0008_(Copy).png","a0009_(Copy).png","a0010_(Copy).png","a0011_(Copy).png","a0012_(Copy).png","a0013_(Copy).png","a0014_(Copy).png"],
              day_tc_array: ["a0005_(Copy).png","a0006_(Copy).png","a0007_(Copy).png","a0008_(Copy).png","a0009_(Copy).png","a0010_(Copy).png","a0011_(Copy).png","a0012_(Copy).png","a0013_(Copy).png","a0014_(Copy).png"],
              day_en_array: ["a0005_(Copy).png","a0006_(Copy).png","a0007_(Copy).png","a0008_(Copy).png","a0009_(Copy).png","a0010_(Copy).png","a0011_(Copy).png","a0012_(Copy).png","a0013_(Copy).png","a0014_(Copy).png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 225,
              month_startY: 140,
              month_sc_array: ["a0005_(Copy).png","a0006_(Copy).png","a0007_(Copy).png","a0008_(Copy).png","a0009_(Copy).png","a0010_(Copy).png","a0011_(Copy).png","a0012_(Copy).png","a0013_(Copy).png","a0014_(Copy).png"],
              month_tc_array: ["a0005_(Copy).png","a0006_(Copy).png","a0007_(Copy).png","a0008_(Copy).png","a0009_(Copy).png","a0010_(Copy).png","a0011_(Copy).png","a0012_(Copy).png","a0013_(Copy).png","a0014_(Copy).png"],
              month_en_array: ["a0005_(Copy).png","a0006_(Copy).png","a0007_(Copy).png","a0008_(Copy).png","a0009_(Copy).png","a0010_(Copy).png","a0011_(Copy).png","a0012_(Copy).png","a0013_(Copy).png","a0014_(Copy).png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 160,
              src: 'Bez_tytulu_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 160,
              year_startY: 140,
              year_sc_array: ["a0005_(Copy).png","a0006_(Copy).png","a0007_(Copy).png","a0008_(Copy).png","a0009_(Copy).png","a0010_(Copy).png","a0011_(Copy).png","a0012_(Copy).png","a0013_(Copy).png","a0014_(Copy).png"],
              year_tc_array: ["a0005_(Copy).png","a0006_(Copy).png","a0007_(Copy).png","a0008_(Copy).png","a0009_(Copy).png","a0010_(Copy).png","a0011_(Copy).png","a0012_(Copy).png","a0013_(Copy).png","a0014_(Copy).png"],
              year_en_array: ["a0005_(Copy).png","a0006_(Copy).png","a0007_(Copy).png","a0008_(Copy).png","a0009_(Copy).png","a0010_(Copy).png","a0011_(Copy).png","a0012_(Copy).png","a0013_(Copy).png","a0014_(Copy).png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 160,
              src: 'Bez_tytulu_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 126,
              hour_startY: 200,
              hour_array: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 242,
              minute_startY: 200,
              minute_array: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 208,
              second_startY: 287,
              second_array: ["z0005_(Copy).png","z0006_(Copy).png","z0007_(Copy).png","z0008_(Copy).png","z0009_(Copy).png","z0010_(Copy).png","z0011_(Copy).png","z0012_(Copy).png","z0013_(Copy).png","z0014_(Copy).png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 184,
              hour_array: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 219,
              minute_startY: 184,
              minute_array: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 319,
              second_startY: 208,
              second_array: ["z0005_(Copy).png","z0006_(Copy).png","z0007_(Copy).png","z0008_(Copy).png","z0009_(Copy).png","z0010_(Copy).png","z0011_(Copy).png","z0012_(Copy).png","z0013_(Copy).png","z0014_(Copy).png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 216,
              src: 'Bez_tytulu_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 198,
              y: 237,
              src: 'Bez_tytulu_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 200,
              w: 88,
              h: 88,
              src: 'transparent.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 200,
              w: 88,
              h: 88,
              src: 'transparent.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 360,
              w: 100,
              h: 86,
              src: 'transparent.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 161,
              y: 17,
              w: 125,
              h: 79,
              src: 'transparent.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 362,
              y: 158,
              w: 107,
              h: 138,
              src: 'transparent.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 14,
              y: 160,
              w: 71,
              h: 140,
              src: 'transparent.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 44,
              w: 97,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 313,
              y: 302,
              w: 100,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 314,
              w: 95,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 307,
              y: 41,
              w: 100,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
