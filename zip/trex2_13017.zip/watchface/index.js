﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_frame_animation_1 = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_heart_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Casio_1500_Ce2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 321,
              font_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 275,
              month_startY: 91,
              month_sc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              month_tc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              month_en_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 173,
              y: 196,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "pisca_segundo",
              anim_fps: 10,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 167,
              hour_array: ["Dig0010.png","Dig0011.png","Dig0012.png","Dig0013.png","Dig0014.png","Dig0015.png","Dig0016.png","Dig0017.png","Dig0018.png","Dig0019.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 221,
              minute_startY: 167,
              minute_array: ["Dig0010.png","Dig0011.png","Dig0012.png","Dig0013.png","Dig0014.png","Dig0015.png","Dig0016.png","Dig0017.png","Dig0018.png","Dig0019.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 190,
              day_startY: 91,
              day_sc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              day_tc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              day_en_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 100,
              y: 91,
              week_en: ["DigW0001.png","DigW0002.png","DigW0003.png","DigW0004.png","DigW0005.png","DigW0006.png","DigW0007.png"],
              week_tc: ["DigW0001.png","DigW0002.png","DigW0003.png","DigW0004.png","DigW0005.png","DigW0006.png","DigW0007.png"],
              week_sc: ["DigW0001.png","DigW0002.png","DigW0003.png","DigW0004.png","DigW0005.png","DigW0006.png","DigW0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 55,
              hour_startY: 167,
              hour_array: ["Dig0010.png","Dig0011.png","Dig0012.png","Dig0013.png","Dig0014.png","Dig0015.png","Dig0016.png","Dig0017.png","Dig0018.png","Dig0019.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 223,
              minute_startY: 167,
              minute_array: ["Dig0010.png","Dig0011.png","Dig0012.png","Dig0013.png","Dig0014.png","Dig0015.png","Dig0016.png","Dig0017.png","Dig0018.png","Dig0019.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 167,
              src: 'Dig9990.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 59,
              y: 299,
              w: 191,
              h: 100,
              src: 'coracao.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}