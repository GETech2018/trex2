﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Buttons OFF / ON (SETTINGS)

    let bt_on_text = "Tryb ustawien ON"
    let bt_off_text = "Tryb ustawien OFF"

// Select background (SETTINGS)

    let total_backgrounds = 6
    let background_prefix = "01_bg_"
    let bg_cover_prefix = "01_bg_cover_"
    
// Select color hours/minutes (SETTINGS)

    let total_colors = 6
    let hh_color_prefix = "02_col_hh_"
    
// Select compass (SETTINGS)
    
    let total_compass = 7
    let compass_prefix = "00_compass_"
        

///////////////////////////// NOT EDIT BELOW ///////////////////////////
 
/////////////  Buttons OFF / ON (SCRIPT) ////////////// 

    let switch_pos_buttons = 1
    let total_pos_buttons = 2
    
    function switch_buttons() {
    
        if(switch_pos_buttons == total_pos_buttons) {
            switch_pos_buttons = 1; // Buttons OFF
           
            image_top_img.setProperty(hmUI.prop.VISIBLE, false);           

    		Button_2.setProperty(hmUI.prop.VISIBLE, false);
    		Button_3.setProperty(hmUI.prop.VISIBLE, false);
    		Button_4.setProperty(hmUI.prop.VISIBLE, false);
    		Button_5.setProperty(hmUI.prop.VISIBLE, false);
    		Button_6.setProperty(hmUI.prop.VISIBLE, false);
    		Button_7.setProperty(hmUI.prop.VISIBLE, false);
    		Button_8.setProperty(hmUI.prop.VISIBLE, false);
            
            hmUI.showToast({text: bt_off_text});
            
        }
        else {
           switch_pos_buttons = switch_pos_buttons + 1; // Buttons ON

           if(switch_pos_buttons == 2) {
           
                image_top_img.setProperty(hmUI.prop.VISIBLE, true);
        
        		Button_2.setProperty(hmUI.prop.VISIBLE, true);
        		Button_3.setProperty(hmUI.prop.VISIBLE, true);
        		Button_4.setProperty(hmUI.prop.VISIBLE, true);
        		Button_5.setProperty(hmUI.prop.VISIBLE, true);
        		Button_6.setProperty(hmUI.prop.VISIBLE, true);
        		Button_7.setProperty(hmUI.prop.VISIBLE, true);
        		Button_8.setProperty(hmUI.prop.VISIBLE, true);
                
                hmUI.showToast({text: bt_on_text});                           
                    
            }
        } 
            
     };
  
//////////////  Select background (SCRIPTS) ////////////// 

    let background_number = 1

    function up_background() {
  
        if(background_number >= total_backgrounds) {
            background_number = 1;
        }
        else {
            background_number = background_number + 1;
        }

        normal_background_bg_img.setProperty(hmUI.prop.SRC, background_prefix + parseInt(background_number) + ".png");
        normal_image_img.setProperty(hmUI.prop.SRC, bg_cover_prefix + parseInt(background_number) + ".png");
    
    };

//////////////  Select color (SCRIPT) ////////////// 

    let color_number = 1

    function up_hour_color() {
  
        if(color_number >= total_colors) {
            color_number = 1;
        }
        else {
            color_number = color_number + 1;
        }

        normal_stress_icon_img.setProperty(hmUI.prop.SRC, hh_color_prefix + parseInt(color_number) + ".png");
    
    };
 
//////////////  Select compass (SCRIPT) //////////////     

    let compass_number = 1
		
    function up_compass() {
      
        if(compass_number >= total_compass) {
            compass_number = 1;
        }
        else {
            compass_number = compass_number + 1;
        }

        normal_compass_direction_pointer_img.setProperty(hmUI.prop.SRC, compass_prefix + parseInt(compass_number) + ".png");
  
    };
  
/////////////  Compass OFF / ON (SCRIPT) //////////////
  
    let switch_pos_compass = 1
    let total_pos_compass = 2

    function switch_compass() {
          
        if(switch_pos_compass == total_pos_compass) {
           switch_pos_compass = 1; // Compass OFF

           if (compass) {
           
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '000');
                normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
                compass.stop();
                
            }        

        }
        else {
           switch_pos_compass = switch_pos_compass + 1; // Compass ON

           if(switch_pos_compass == 2) {
               if (compass)  {
                          
                    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                    
                    normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                    normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
                    compass.start();
                    
                }        
                    
            }
        }
          
    };
    
    
//////////////  Alternate Elements (SCRIPTS) //////////////

    let switch_pos_top_dial = 1
    let total_pos_top_dial = 3

    function click_top_dial() {
          
        if(switch_pos_top_dial == total_pos_top_dial) {
           switch_pos_top_dial = 1; // Default
           
          normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          
          normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);

          normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                      
          normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);            
          
        }
        else {
           switch_pos_top_dial = switch_pos_top_dial + 1; // Alternatives

           if(switch_pos_top_dial == 2) {
           
              normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
              normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
              normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true); 
              
              normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                    
            }
           
           if(switch_pos_top_dial == 3) {

              normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_uvi_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              
              normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, false);

              normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

              normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                    
            }

        }
          
    };
        
    let middle_items_index = 1
    let middle_items_count = 5
    
    function click_middle_dial() {
    
        middle_items_index++;
        if(middle_items_index > middle_items_count) middle_items_index = 1;

        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, middle_items_index == 1);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, middle_items_index == 1);
        normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, middle_items_index == 1);

        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, middle_items_index == 2);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, middle_items_index == 2);
        normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, middle_items_index == 2);

        normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, middle_items_index == 3);
        normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, middle_items_index == 3);
        normal_pai_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, middle_items_index == 3);

        normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, middle_items_index == 4);
        normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, middle_items_index == 4);
        normal_fat_burning_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, middle_items_index == 4);

        normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, middle_items_index == 5);
        normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, middle_items_index == 5);
        normal_stand_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, middle_items_index == 5);

    };
 
    let bottom_items_index = 1
    let bottom_items_count = 5
    
    function click_bottom_dial() {
    
        bottom_items_index++;
        if(bottom_items_index > bottom_items_count) bottom_items_index = 1;
        
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_items_index == 1);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_items_index == 1);

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_items_index == 2);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_items_index == 2);

        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, bottom_items_index == 3);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_items_index == 3);

        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_items_index == 4);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_items_index == 4);

        normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_items_index == 5);
        normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_items_index == 5);

    };
    
////////////////////////////////////////////////////////////////////////////////

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_stress_icon_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_stand_image_progress_img_level = ''
        let normal_fat_burning_current_text_img = ''
        let normal_fat_burning_current_separator_img = ''
        let normal_fat_burning_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_img = new Array(4);
        let normal_forecast_date_week_img_array = ['08_lite_wd_1.png', '08_lite_wd_2.png', '08_lite_wd_3.png', '08_lite_wd_4.png', '08_lite_wd_5.png', '08_lite_wd_6.png', '08_lite_wd_7.png'];
        let normal_forecast_average_text_img = new Array(4);
        let normal_forecast_image_progress_img_level = new Array(4);
        let normal_forecast_image_array = ['09_forecast_01.png', '09_forecast_02.png', '09_forecast_03.png', '09_forecast_04.png', '09_forecast_05.png', '09_forecast_06.png', '09_forecast_07.png', '09_forecast_08.png', '09_forecast_09.png', '09_forecast_10.png', '09_forecast_11.png', '09_forecast_12.png', '09_forecast_13.png', '09_forecast_14.png', '09_forecast_15.png', '09_forecast_16.png', '09_forecast_17.png', '09_forecast_18.png', '09_forecast_19.png', '09_forecast_20.png', '09_forecast_21.png', '09_forecast_22.png', '09_forecast_23.png', '09_forecast_24.png', '09_forecast_25.png', '09_forecast_26.png', '09_forecast_27.png', '09_forecast_28.png', '09_forecast_29.png'];
        let normal_image_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_high_text_img = ''
        let normal_moon_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_uvi_text_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_compass_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_wind_icon_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_image_img = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '02_col_hh_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 168,
              y: 30,
              image_array: ["13_wind_1.png","13_wind_2.png","13_wind_3.png","13_wind_4.png","13_wind_5.png","13_wind_6.png","13_wind_7.png","13_wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 32,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 30,
              src: '10_wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 121,
              day_startY: 355,
              day_sc_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_tc_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_en_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 69,
              y: 311,
              week_en: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              week_tc: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              week_sc: ["08_wd_1.png","08_wd_2.png","08_wd_3.png","08_wd_4.png","08_wd_5.png","08_wd_6.png","08_wd_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 236,
              y: 336,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_M.png',
              unit_tc: '10_percent_M.png',
              unit_en: '10_percent_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 333,
              src: '10_spo2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 336,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              negative_image: '10_dash_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 337,
              y: 331,
              src: '10_alt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 336,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 336,
              y: 334,
              src: '10_baro.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 223,
              y: 336,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '10_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 337,
              y: 333,
              src: '10_dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 336,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 337,
              y: 333,
              src: '10_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 285,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 372,
              y: 282,
              src: '10_stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 45,
              y: 283,
              image_array: ["10_target_1.png","10_target_2.png","10_target_3.png","10_target_4.png","10_target_5.png","10_target_6.png"],
              image_length: 6,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 285,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 372,
              y: 282,
              src: '10_fat_burn.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 45,
              y: 283,
              image_array: ["10_target_1.png","10_target_2.png","10_target_3.png","10_target_4.png","10_target_5.png","10_target_6.png"],
              image_length: 6,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 285,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 372,
              y: 282,
              src: '10_PAI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 45,
              y: 283,
              image_array: ["10_target_1.png","10_target_2.png","10_target_3.png","10_target_4.png","10_target_5.png","10_target_6.png"],
              image_length: 6,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 285,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 376,
              y: 282,
              src: '10_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 45,
              y: 283,
              image_array: ["10_target_1.png","10_target_2.png","10_target_3.png","10_target_4.png","10_target_5.png","10_target_6.png"],
              image_length: 6,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 285,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 376,
              y: 282,
              src: '10_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 45,
              y: 283,
              image_array: ["10_target_1.png","10_target_2.png","10_target_3.png","10_target_4.png","10_target_5.png","10_target_6.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 39,
              hour_startY: 184,
              hour_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '10_sep_hhmm.png',
              hour_unit_tc: '10_sep_hhmm.png',
              hour_unit_en: '10_sep_hhmm.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 346,
              second_startY: 184,
              second_array: ["03_ss_0.png","03_ss_1.png","03_ss_2.png","03_ss_3.png","03_ss_4.png","03_ss_5.png","03_ss_6.png","03_ss_7.png","03_ss_8.png","03_ss_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 346,
              am_y: 234,
              am_sc_path: '10_AM.png',
              am_en_path: '10_AM.png',
              pm_x: 346,
              pm_y: 234,
              pm_sc_path: '10_PM.png',
              pm_en_path: '10_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 74,
              // DaysCount: 4,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_img = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 92,
              // y: 70,
              // image_array: ["08_lite_wd_1.png","08_lite_wd_2.png","08_lite_wd_3.png","08_lite_wd_4.png","08_lite_wd_5.png","08_lite_wd_6.png","08_lite_wd_7.png"],
              // image_length: 7,
              // type: hmUI.data_type.forecast_date_week_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_date_week_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 92 + i*74,
                  y: 70,
                  src: normal_forecast_date_week_img_array[0],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_average_text_img = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG_Options, {
              // x: 65,
              // y: 151,
              // font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              // padding: false,
              // h_space: 0,
              // unit_en: '10_degree_S.png',
              // imperial_unit_en: '10_degree_S.png',
              // negative_image: '10_dash_S.png',
              // invalid_image: '10_null_S.png',
              // dot_image: '10_dash_S.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.forecast_average_text_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_average_text_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 65 + i*74,
                  y: 151,
                  font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: '10_degree_S.png',
                  unit_tc: '10_degree_S.png',
                  unit_en: '10_degree_S.png',
                  negative_image: '10_dash_S.png',
                  align_h: hmUI.align.CENTER_H,
                  // type: hmUI.data_type.FORECAST_NUMBER_MAX,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 92,
              // y: 98,
              // image_array: ["09_forecast_01.png","09_forecast_02.png","09_forecast_03.png","09_forecast_04.png","09_forecast_05.png","09_forecast_06.png","09_forecast_07.png","09_forecast_08.png","09_forecast_09.png","09_forecast_10.png","09_forecast_11.png","09_forecast_12.png","09_forecast_13.png","09_forecast_14.png","09_forecast_15.png","09_forecast_16.png","09_forecast_17.png","09_forecast_18.png","09_forecast_19.png","09_forecast_20.png","09_forecast_21.png","09_forecast_22.png","09_forecast_23.png","09_forecast_24.png","09_forecast_25.png","09_forecast_26.png","09_forecast_27.png","09_forecast_28.png","09_forecast_29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 92 + i*74,
                  y: 98,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '01_bg_cover_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_top_cover.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 79,
              image_array: ["09_weather_01.png","09_weather_02.png","09_weather_03.png","09_weather_04.png","09_weather_05.png","09_weather_06.png","09_weather_07.png","09_weather_08.png","09_weather_09.png","09_weather_10.png","09_weather_11.png","09_weather_12.png","09_weather_13.png","09_weather_14.png","09_weather_15.png","09_weather_16.png","09_weather_17.png","09_weather_18.png","09_weather_19.png","09_weather_20.png","09_weather_21.png","09_weather_22.png","09_weather_23.png","09_weather_24.png","09_weather_25.png","09_weather_26.png","09_weather_27.png","09_weather_28.png","09_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 55,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_S.png',
              unit_tc: '10_degree_S.png',
              unit_en: '10_degree_S.png',
              imperial_unit_sc: '10_degree_S.png',
              imperial_unit_tc: '10_degree_S.png',
              imperial_unit_en: '10_degree_S.png',
              negative_image: '10_dash_S.png',
              invalid_image: '10_null_S.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 273,
                y: 55,
                font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: '10_degree_S.png',
                unit_tc: '10_degree_S.png',
                unit_en: '10_degree_S.png',
                imperial_unit_sc: '10_degree_S.png',
                imperial_unit_tc: '10_degree_S.png',
                imperial_unit_en: '10_degree_S.png',
                negative_image: '10_dash_S.png',
                invalid_image: '10_null_S.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 55,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_S.png',
              unit_tc: '10_degree_S.png',
              unit_en: '10_degree_S.png',
              imperial_unit_sc: '10_degree_S.png',
              imperial_unit_tc: '10_degree_S.png',
              imperial_unit_en: '10_degree_S.png',
              negative_image: '10_dash_S.png',
              invalid_image: '10_null_S.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 116,
                y: 55,
                font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: '10_degree_S.png',
                unit_tc: '10_degree_S.png',
                unit_en: '10_degree_S.png',
                imperial_unit_sc: '10_degree_S.png',
                imperial_unit_tc: '10_degree_S.png',
                imperial_unit_en: '10_degree_S.png',
                negative_image: '10_dash_S.png',
                invalid_image: '10_null_S.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 37,
              font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_M.png',
              unit_tc: '10_degree_M.png',
              unit_en: '10_degree_M.png',
              imperial_unit_sc: '10_degree_M.png',
              imperial_unit_tc: '10_degree_M.png',
              imperial_unit_en: '10_degree_M.png',
              negative_image: '10_dash_M.png',
              invalid_image: '10_null_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 184,
                y: 37,
                font_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: '10_degree_M.png',
                unit_tc: '10_degree_M.png',
                unit_en: '10_degree_M.png',
                imperial_unit_sc: '10_degree_M.png',
                imperial_unit_tc: '10_degree_M.png',
                imperial_unit_en: '10_degree_M.png',
                negative_image: '10_dash_M.png',
                invalid_image: '10_null_M.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_moon_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 100,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_separator_S.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 100,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_separator_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 79,
              image_array: ["12_moon_01.png","12_moon_02.png","12_moon_03.png","12_moon_04.png","12_moon_05.png","12_moon_06.png","12_moon_07.png","12_moon_08.png","12_moon_09.png","12_moon_10.png","12_moon_11.png","12_moon_12.png","12_moon_13.png","12_moon_14.png","12_moon_15.png","12_moon_16.png","12_moon_17.png","12_moon_18.png","12_moon_19.png","12_moon_20.png","12_moon_21.png","12_moon_22.png","12_moon_23.png","12_moon_24.png","12_moon_25.png","12_moon_26.png","12_moon_27.png","12_moon_28.png","12_moon_29.png","12_moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 144,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_M.png',
              unit_tc: '10_percent_M.png',
              unit_en: '10_percent_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 55,
              y: 141,
              src: '10_hum.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 155,
              src: '10_BT_ON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 144,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_M.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 350,
              y: 141,
              src: '10_uv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 100,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_separator_S.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 100,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '10_null_S.png',
              dot_image: '10_separator_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 388,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_M.png',
              unit_tc: '10_percent_M.png',
              unit_en: '10_percent_M.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 276,
              y: 387,
              src: '10_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: '00_compass_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: '00_compass_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 167,
              y: 388,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: '10_degree_M.png',
              unit_tc: '10_degree_M.png',
              unit_en: '10_degree_M.png',
              negative_image: '10_null_M.png',
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 277,
              y: 385,
              src: '10_compass.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 155,
              src: '10_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 176,
              y: 320,
              src: '10_AL_ON.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 39,
              hour_startY: 184,
              hour_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '10_sep_hhmm.png',
              hour_unit_tc: '10_sep_hhmm.png',
              hour_unit_en: '10_sep_hhmm.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 346,
              second_startY: 184,
              second_array: ["03_ss_0.png","03_ss_1.png","03_ss_2.png","03_ss_3.png","03_ss_4.png","03_ss_5.png","03_ss_6.png","03_ss_7.png","03_ss_8.png","03_ss_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 346,
              am_y: 234,
              am_sc_path: '10_AM.png',
              am_en_path: '10_AM.png',
              pm_x: 346,
              pm_y: 234,
              pm_sc_path: '10_PM.png',
              pm_en_path: '10_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_top_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 192,
              y: 192,
              src: '10_settings.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 200,
              w: 54,
              h: 54,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                switch_buttons()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 32,
              y: 187,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                up_hour_color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 384,
              w: 130,
              h: 45,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                switch_compass()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 72,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_top_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 250,
              y: 278,
              w: 130,
              h: 45,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_middle_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 215,
              y: 331,
              w: 130,
              h: 45,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_bottom_dial()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 310,
              w: 90,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                up_compass()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 343,
              y: 187,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                up_background()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

////////////  Initial visibility of elements //////////// 

    let cc = 0

    if (cc == 0 ){
    
        // BUTTONS
       
        image_top_img.setProperty(hmUI.prop.VISIBLE, false);
       
		Button_2.setProperty(hmUI.prop.VISIBLE, false);
		Button_3.setProperty(hmUI.prop.VISIBLE, false);
		Button_4.setProperty(hmUI.prop.VISIBLE, false);
		Button_5.setProperty(hmUI.prop.VISIBLE, false);
		Button_6.setProperty(hmUI.prop.VISIBLE, false);
		Button_7.setProperty(hmUI.prop.VISIBLE, false);
		Button_8.setProperty(hmUI.prop.VISIBLE, false);
    
        // TOP
   
        normal_moon_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_moon_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false); 

        // MIDDLE

        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_weekly_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_fat_burning_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_stand_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        
        // BOTTOM
        
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        
        // COMPASS

        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);

    cc = 1;

    };

/////////////////////////////////////////////////////////////////////////////////////////////////

            // end user_script_end.js

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 4; i++) {
                // DOW images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_img[i].setProperty(hmUI.prop.SRC, normal_forecast_date_week_img_array[dowIndex]);
                };
              
                // Number_Average
                let averageTemperature = '-';
                if (i < forecastData.count) averageTemperature = parseInt((forecastData.data[i].high + forecastData.data[i].low)/2).toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_average_text_img[i].setProperty(hmUI.prop.TEXT, averageTemperature);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

                }

              }); // Listener end              normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);              normal_compass_text_img.setProperty(hmUI.prop.TEXT, '000');              compass.stop();

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                if(switch_pos_compass == 2) {if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start()};

                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if(switch_pos_compass == 2) {if (compass) compass.stop()};

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}