﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        let colornumber_main = 1
        let totalcolors_main = 7
        let namecolor_main = ''

        function bgp() {
          if(colornumber_main>=totalcolors_main) {
             colornumber_main=1;
            }
          else {
             colornumber_main=colornumber_main+1;
          }

        if ( colornumber_main == 1) { namecolor_main = "1"
        }
        if ( colornumber_main == 2) { namecolor_main = "2"
        }
        if ( colornumber_main == 3) { namecolor_main = "3"        
        }
        if ( colornumber_main == 4) { namecolor_main = "4"   
        }
        if ( colornumber_main == 5) { namecolor_main = "5"   
        }
        if ( colornumber_main == 6) { namecolor_main = "6"   
        }
        if ( colornumber_main == 7) { namecolor_main = "7"   
        }
        
        normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber_main) + ".png");
        }

        let normal_background_bg_img = ''
        let idle_background_bg_img = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
               
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let timer_StopVibrate = null;

        function vibro(scene = 25) {
            let stopDelay = 50;
            stopVibro();
            vibrate.stop();
            vibrate.scene = scene;
            if(scene < 23 || scene > 25) stopDelay = 1300;
            vibrate.start();
            if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
        }

        function stopVibro(){
            vibrate.stop();
            if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
        }              
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'click.png',
              normal_src: 'click.png',
              click_func: (button_widget) => {
                bgp();
                vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}