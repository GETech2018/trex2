﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_humidity_text_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_text_separator_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bangraund.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 55,
              day_startY: 308,
              day_sc_array: ["dey001.png","dey002.png","dey003.png","dey004.png","dey005.png","dey006.png","dey007.png","dey008.png","dey009.png","dey010.png"],
              day_tc_array: ["dey001.png","dey002.png","dey003.png","dey004.png","dey005.png","dey006.png","dey007.png","dey008.png","dey009.png","dey010.png"],
              day_en_array: ["dey001.png","dey002.png","dey003.png","dey004.png","dey005.png","dey006.png","dey007.png","dey008.png","dey009.png","dey010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 39,
              month_startY: 279,
              month_sc_array: ["en001.png","en002.png","en003.png","en004.png","en005.png","en006.png","en007.png","en008.png","en009.png","en010.png","en011.png","en012.png"],
              month_tc_array: ["en001.png","en002.png","en003.png","en004.png","en005.png","en006.png","en007.png","en008.png","en009.png","en010.png","en011.png","en012.png"],
              month_en_array: ["en001.png","en002.png","en003.png","en004.png","en005.png","en006.png","en007.png","en008.png","en009.png","en010.png","en011.png","en012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 344,
              y: 293,
              week_en: ["den001.png","den002.png","den003.png","den004.png","den005.png","den006.png","den007.png"],
              week_tc: ["den001.png","den002.png","den003.png","den004.png","den005.png","den006.png","den007.png"],
              week_sc: ["den001.png","den002.png","den003.png","den004.png","den005.png","den006.png","den007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 349,
              font_array: ["mini001.png","mini002.png","mini003.png","mini004.png","mini005.png","mini006.png","mini007.png","mini008.png","mini009.png","mini010.png"],
              padding: false,
              h_space: -71,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 403,
              font_array: ["mini001.png","mini002.png","mini003.png","mini004.png","mini005.png","mini006.png","mini007.png","mini008.png","mini009.png","mini010.png"],
              padding: false,
              h_space: -72,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 170,
              font_array: ["sun001.png","sun002.png","sun003.png","sun004.png","sun005.png","sun006.png","sun007.png","sun008.png","sun009.png","sun010.png"],
              padding: false,
              h_space: 2,
              dot_image: 'sunkeno.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 134,
              src: 'sunrise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 138,
              font_array: ["sun001.png","sun002.png","sun003.png","sun004.png","sun005.png","sun006.png","sun007.png","sun008.png","sun009.png","sun010.png"],
              padding: false,
              h_space: 2,
              dot_image: 'sunkeno.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 167,
              src: 'sunsetdown.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 196,
              font_array: ["mini001.png","mini002.png","mini003.png","mini004.png","mini005.png","mini006.png","mini007.png","mini008.png","mini009.png","mini010.png"],
              padding: false,
              h_space: -66,
              unit_sc: 'mini%00999.png',
              unit_tc: 'mini%00999.png',
              unit_en: 'mini%00999.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 241,
              font_array: ["mini001.png","mini002.png","mini003.png","mini004.png","mini005.png","mini006.png","mini007.png","mini008.png","mini009.png","mini010.png"],
              padding: false,
              h_space: -73,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 262,
              y: 241,
              src: 'mini%00999.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 325,
              y: 250,
              image_array: ["vol001.png","vol002.png","vol003.png","vol004.png","vol005.png","vol006.png","vol007.png","vol008.png","vol009.png","vol010.png","vol011.png","vol012.png"],
              image_length: 12,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 27,
              // start_y: 253,
              // color: 0xFFFFFFFF,
              // lenght: 95,
              // line_width: 5,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 242,
              font_array: ["mini001.png","mini002.png","mini003.png","mini004.png","mini005.png","mini006.png","mini007.png","mini008.png","mini009.png","mini010.png"],
              padding: false,
              h_space: -73,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 159,
              y: 242,
              src: 'mini%00999.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 130,
              y: 47,
              w: 189,
              h: 38,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 123,
              font_array: ["minithe001.png","minithem002.png","minithem003.png","minithem004.png","minithem005.png","minithem006.png","minithem007.png","minithem008.png","minithem009.png","minithem010.png"],
              padding: false,
              h_space: -117,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 124,
              src: 'celsiou5x5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 36,
              y: 101,
              image_array: ["wather001.png","wather002.png","wather003.png","wather004.png","wather005.png","wather006.png","wather007.png","wather008.png","wather009.png","wather010.png","wather011.png","wather012.png","wather013.png","wather014.png","wather015.png","wather016.png","wather017.png","wather018.png","wather019.png","wather020.png","wather021.png","wather022.png","wather023.png","wather024.png","wather026.png","wather027.png","wather028.png","wather029.png","wather25.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 97,
              hour_startY: 280,
              hour_array: ["red001.png","red002.png","red003.png","red004.png","red005.png","red006.png","red007.png","red008.png","red009.png","red010.png"],
              hour_zero: 1,
              hour_space: -42,
              hour_align: hmUI.align.LEFT,

              minute_startX: 204,
              minute_startY: 280,
              minute_array: ["wite001.png","wite002.png","wite003.png","wite004.png","wite005.png","wite006.png","wite007.png","wite008.png","wite009.png","wite010.png"],
              minute_zero: 1,
              minute_space: -39,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'analogsec001.png',
              second_centerX: 226,
              second_centerY: 228,
              second_posX: 9,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 113,
              y: 142,
              week_en: ["den001.png","den002.png","den003.png","den004.png","den005.png","den006.png","den007.png"],
              week_tc: ["den001.png","den002.png","den003.png","den004.png","den005.png","den006.png","den007.png"],
              week_sc: ["den001.png","den002.png","den003.png","den004.png","den005.png","den006.png","den007.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 279,
              month_startY: 142,
              month_sc_array: ["en001.png","en002.png","en003.png","en004.png","en005.png","en006.png","en007.png","en008.png","en009.png","en010.png","en011.png","en012.png"],
              month_tc_array: ["en001.png","en002.png","en003.png","en004.png","en005.png","en006.png","en007.png","en008.png","en009.png","en010.png","en011.png","en012.png"],
              month_en_array: ["en001.png","en002.png","en003.png","en004.png","en005.png","en006.png","en007.png","en008.png","en009.png","en010.png","en011.png","en012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 142,
              day_sc_array: ["dey001.png","dey002.png","dey003.png","dey004.png","dey005.png","dey006.png","dey007.png","dey008.png","dey009.png","dey010.png"],
              day_tc_array: ["dey001.png","dey002.png","dey003.png","dey004.png","dey005.png","dey006.png","dey007.png","dey008.png","dey009.png","dey010.png"],
              day_en_array: ["dey001.png","dey002.png","dey003.png","dey004.png","dey005.png","dey006.png","dey007.png","dey008.png","dey009.png","dey010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 38,
              hour_startY: 175,
              hour_array: ["redg001.png","redg002.png","redg003.png","redg004.png","redg005.png","redg006.png","redg007.png","redg008.png","redg009.png","redg010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 250,
              minute_startY: 175,
              minute_array: ["redg001.png","redg002.png","redg003.png","redg004.png","redg005.png","redg006.png","redg007.png","redg008.png","redg009.png","redg010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 27;
                  let start_y_normal_battery = 253;
                  let lenght_ls_normal_battery = 95;
                  let line_width_ls_normal_battery = 5;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  