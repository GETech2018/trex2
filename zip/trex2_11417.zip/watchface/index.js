﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '9016.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 148,
              font_array: ["4014.png","4015.png","4016.png","4017.png","4018.png","4019.png","4020.png","4021.png","4022.png","4023.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 340,
              y: 144,
              src: '5495.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 331,
              y: 123,
              font_array: ["4014.png","4015.png","4016.png","4017.png","4018.png","4019.png","4020.png","4021.png","4022.png","4023.png"],
              padding: false,
              h_space: -1,
              unit_sc: '5124.png',
              unit_tc: '5124.png',
              unit_en: '5124.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 315,
              y: 121,
              src: '5394.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 389,
              font_array: ["4014.png","4015.png","4016.png","4017.png","4018.png","4019.png","4020.png","4021.png","4022.png","4023.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 229,
              y: 363,
              image_array: ["h001.png","h002.png","h003.png","h004.png","h005.png","h006.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 92,
              font_array: ["4014.png","4015.png","4016.png","4017.png","4018.png","4019.png","4020.png","4021.png","4022.png","4023.png"],
              padding: false,
              h_space: -1,
              dot_image: 'time012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 92,
              font_array: ["4014.png","4015.png","4016.png","4017.png","4018.png","4019.png","4020.png","4021.png","4022.png","4023.png"],
              padding: false,
              h_space: -1,
              dot_image: 'time012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 205,
              y: 92,
              image_array: ["moon_30_01.png","moon_30_02.png","moon_30_03.png","moon_30_04.png","moon_30_05.png","moon_30_06.png","moon_30_07.png","moon_30_08.png","moon_30_09.png","moon_30_10.png","moon_30_11.png","moon_30_12.png","moon_30_13.png","moon_30_14.png","moon_30_15.png","moon_30_16.png","moon_30_17.png","moon_30_18.png","moon_30_19.png","moon_30_20.png","moon_30_21.png","moon_30_22.png","moon_30_23.png","moon_30_24.png","moon_30_25.png","moon_30_26.png","moon_30_27.png","moon_30_28.png","moon_30_29.png","moon_30_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 184,
              font_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              padding: false,
              h_space: -1,
              dot_image: '4034.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 139,
              y: 169,
              src: 'transparent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 179,
              y: 395,
              src: '0213.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 294,
              y: 225,
              src: '1068.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '1011.png',
              center_x: 348,
              center_y: 349,
              x: 16,
              y: 72,
              start_angle: -120,
              end_angle: 31,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 365,
              font_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              padding: false,
              h_space: -2,
              unit_sc: '5125.png',
              unit_tc: '5125.png',
              unit_en: '5125.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 349,
              font_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              padding: false,
              h_space: -2,
              unit_sc: '4051.png',
              unit_tc: '4051.png',
              unit_en: '4051.png',
              negative_image: 'MinWh011.png',
              invalid_image: '5050.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 108,
              y: 271,
              image_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 41,
              y: 268,
              font_array: ["4014.png","4015.png","4016.png","4017.png","4018.png","4019.png","4020.png","4021.png","4022.png","4023.png"],
              padding: false,
              h_space: -1,
              unit_sc: '4050.png',
              unit_tc: '4050.png',
              unit_en: '4050.png',
              invalid_image: '5051.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 53,
              y: 244,
              src: '5496.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 41,
              y: 290,
              font_array: ["4014.png","4015.png","4016.png","4017.png","4018.png","4019.png","4020.png","4021.png","4022.png","4023.png"],
              padding: false,
              h_space: -1,
              unit_sc: '4050.png',
              unit_tc: '4050.png',
              unit_en: '4050.png',
              negative_image: 'MinWh011.png',
              invalid_image: '5051.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 53,
              y: 306,
              src: '5497.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 278,
              y: 177,
              week_en: ["d32.png","d33.png","d34.png","d35.png","d36.png","d37.png","d38.png"],
              week_tc: ["d32.png","d33.png","d34.png","d35.png","d36.png","d37.png","d38.png"],
              week_sc: ["d32.png","d33.png","d34.png","d35.png","d36.png","d37.png","d38.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 385,
              day_startY: 182,
              day_sc_array: ["1134.png","1135.png","1136.png","1137.png","1138.png","1139.png","1140.png","1141.png","1142.png","1143.png"],
              day_tc_array: ["1134.png","1135.png","1136.png","1137.png","1138.png","1139.png","1140.png","1141.png","1142.png","1143.png"],
              day_en_array: ["1134.png","1135.png","1136.png","1137.png","1138.png","1139.png","1140.png","1141.png","1142.png","1143.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 330,
              hour_startY: 228,
              hour_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: '0095.png',
              hour_unit_tc: '0095.png',
              hour_unit_en: '0095.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["MinWh001.png","MinWh002.png","MinWh003.png","MinWh004.png","MinWh005.png","MinWh006.png","MinWh007.png","MinWh008.png","MinWh009.png","MinWh010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 409,
              second_startY: 251,
              second_array: ["4014.png","4015.png","4016.png","4017.png","4018.png","4019.png","4020.png","4021.png","4022.png","4023.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 363,
              y: 227,
              src: 'transparent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '4510.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 30,
              hour_posY: 207,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '4509.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 26,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '4508.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 25,
              second_posY: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '4510.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 30,
              hour_posY: 207,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '4509.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 26,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '4508.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 25,
              second_posY: 218,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 195,
              w: 82,
              h: 82,
              src: 'transparent.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 195,
              w: 90,
              h: 82,
              src: 'transparent.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 204,
              y: 297,
              w: 82,
              h: 82,
              src: 'transparent.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 298,
              y: 88,
              w: 88,
              h: 88,
              src: 'transparent.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 197,
              y: 83,
              w: 82,
              h: 87,
              src: 'transparent.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: -32,
              w: 92,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 109,
              y: 286,
              w: 82,
              h: 87,
              src: 'transparent.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 307,
              w: 88,
              h: 88,
              src: 'transparent.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: -12,
              y: 195,
              w: 82,
              h: 90,
              src: 'transparent.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 398,
              w: 82,
              h: 82,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 82,
              y: 137,
              w: 82,
              h: 85,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
