﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
// Select background (SETTINGS)

  let total_backgrounds = 12
  let background_prefix = "01_bg_"

// Select hands (SETTINGS)

  let total_hands_types = 6
  let hands_hour_prefix = "02_hh_"
  let hands_minute_prefix = "02_mm_"
  let hands_second_prefix = "02_ss_"
  
// Select foreground (SETTINGS)  
  
  let total_foregrounds = 6 
  let foreground_prefix = "00_fg_"
  
// Select image (SETTINGS)

  let total_images = 43
  let image_prefix = "11_flag_"
  
////////////// ////////////// NOT EDIT BELOW /////////////////////////// 

//////////////  Select background (SCRIPTS) ////////////// 

    let background_number = 1

    function up_background() {
           
            if(background_number >= total_backgrounds) {
                background_number = 1;
            }
            else {
                background_number = background_number + 1;
            }

            normal_background_bg_img.setProperty(hmUI.prop.SRC, background_prefix + parseInt(background_number) + ".png");              
    
        }
    
    function down_background() {
           
            if(background_number <= 1) {
                background_number = total_backgrounds;
            }
            else {
                background_number = background_number - 1;
            }
                          
            normal_background_bg_img.setProperty(hmUI.prop.SRC, background_prefix + parseInt(background_number) + ".png");
    
        }

////////////// Select hands type (SCRIPT) ////////////// 

    let hands_types = 1

    function select_hands() {
    
            if(switch_pos == 1) {
    
                if(hands_types >= total_hands_types) {
                    hands_types = 1;
                }
                else {
                    hands_types = hands_types + 1;
                }
    
                normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, hands_hour_prefix + parseInt(hands_types) + ".png");
                normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, hands_minute_prefix + parseInt(hands_types) + ".png");
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, hands_second_prefix + parseInt(hands_types) + ".png");

            }
        
        }
        
////////////// Select foreground (SCRIPT) ////////////// 

    let foreground_number = 1

    function select_foreground() {
           
            if(foreground_number >= total_foregrounds) {
                foreground_number = 1;
            }
            else {
                foreground_number = foreground_number + 1;
            }

            normal_image_img.setProperty(hmUI.prop.SRC, foreground_prefix + parseInt(foreground_number) + ".png");              
    
        }  
        
////////////// Hands ON / OFF (SCRIPT) //////////////

    let switch_pos = 1
    let total_pos = 2

    function on_off_hands() {
            
            if(switch_pos == total_pos) {
                
                switch_pos = 1;
                normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);            
                }
            else {

                switch_pos = switch_pos + 1;
                
                if(switch_pos == 2) {
                    normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                }

            }

        }  
        
  //////////////  Select image (SCRIPT) //////////////

    let image_number = 1
		
	function select_image() {
    
            if(image_number >= total_images) {
                image_number = 1;
            }
            else {
                image_number = image_number + 1;
            }
            
            normal_stand_icon_img.setProperty(hmUI.prop.SRC, image_prefix + parseInt(image_number) + ".png");

        }       
        
/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_stand_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '01_bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_fg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 100,
              src: '11_flag_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '10_digi_screen.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 164,
              y: 304,
              src: '10_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 304,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 182,
              y: 338,
              image_array: ["09_batt_1.png","09_batt_2.png","09_batt_3.png","09_batt_4.png","09_batt_5.png","09_batt_6.png","09_batt_7.png","09_batt_8.png","09_batt_9.png","09_batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 289,
              am_y: 255,
              am_sc_path: '10_AM.png',
              am_en_path: '10_AM.png',
              pm_x: 289,
              pm_y: 255,
              pm_sc_path: '10_PM.png',
              pm_en_path: '10_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 138,
              hour_startY: 254,
              hour_array: ["04_hhmm_0.png","04_hhmm_1.png","04_hhmm_2.png","04_hhmm_3.png","04_hhmm_4.png","04_hhmm_5.png","04_hhmm_6.png","04_hhmm_7.png","04_hhmm_8.png","04_hhmm_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '10_separator_hhmm.png',
              hour_unit_tc: '10_separator_hhmm.png',
              hour_unit_en: '10_separator_hhmm.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["04_hhmm_0.png","04_hhmm_1.png","04_hhmm_2.png","04_hhmm_3.png","04_hhmm_4.png","04_hhmm_5.png","04_hhmm_6.png","04_hhmm_7.png","04_hhmm_8.png","04_hhmm_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 285,
              second_startY: 272,
              second_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_hh_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 15,
              // y: 155,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 15,
              pos_y: 227 - 155,
              center_x: 227,
              center_y: 227,
              src: '02_hh_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_mm_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 15,
              // y: 155,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 15,
              pos_y: 227 - 155,
              center_x: 227,
              center_y: 227,
              src: '02_mm_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_ss_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 13,
              // y: 194,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 13,
              pos_y: 227 - 194,
              center_x: 227,
              center_y: 227,
              src: '02_ss_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '00_fg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_hh_AOD.png',
              // center_x: 227,
              // center_y: 227,
              // x: 15,
              // y: 155,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 15,
              pos_y: 227 - 155,
              center_x: 227,
              center_y: 227,
              src: '02_hh_AOD.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_mm_AOD.png',
              // center_x: 227,
              // center_y: 227,
              // x: 15,
              // y: 155,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 15,
              pos_y: 227 - 155,
              center_x: 227,
              center_y: 227,
              src: '02_mm_AOD.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '02_ss_AOD.png',
              // center_x: 227,
              // center_y: 227,
              // x: 13,
              // y: 194,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 13,
              pos_y: 227 - 194,
              center_x: 227,
              center_y: 227,
              src: '02_ss_AOD.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 178,
              y: 101,
              w: 100,
              h: 67,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                select_image()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 177,
              y: 342,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                on_off_hands()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 12,
              y: 177,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                select_foreground()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 342,
              y: 177,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                up_background()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 177,
              y: 177,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                select_hands()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*(minute + second/60)/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}