﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_humidity_text_text_img = ''
        let normal_altitude_target_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_font = new Array(5);
        let normal_forecast_date_week_font_Array = ['Po', 'Út', 'St', 'Čt', 'Pá', 'So', 'Ne'];
        let normal_forecast_low_text_font = new Array(5);
        let normal_forecast_image_progress_img_level = new Array(5);
        let normal_forecast_image_array = ['wea_1.png', 'wea_2.png', 'wea_3.png', 'wea_4.png', 'wea_5.png', 'wea_6.png', 'wea_7.png', 'wea_8.png', 'wea_9.png', 'wea_10.png', 'wea_11.png', 'wea_12.png', 'wea_13.png', 'wea_14.png', 'wea_15.png', 'wea_16.png', 'wea_17.png', 'wea_18.png', 'wea_19.png', 'wea_20.png', 'wea_21.png', 'wea_22.png', 'wea_23.png', 'wea_24.png', 'wea_25.png', 'wea_26.png', 'wea_27.png', 'wea_28.png', 'wea_29.png'];
        let normal_uvi_current_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_humidity_text_text_img = ''
        let idle_altitude_target_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_group_ForecastWeather = ''
        let idle_forecast_date_week_font = new Array(5);
        let idle_forecast_date_week_font_Array = ['Po', 'Út', 'St', 'Čt', 'Pá', 'So', 'Ne'];
        let idle_forecast_low_text_font = new Array(5);
        let idle_forecast_image_progress_img_level = new Array(5);
        let idle_forecast_image_array = ['wea_1.png', 'wea_2.png', 'wea_3.png', 'wea_4.png', 'wea_5.png', 'wea_6.png', 'wea_7.png', 'wea_8.png', 'wea_9.png', 'wea_10.png', 'wea_11.png', 'wea_12.png', 'wea_13.png', 'wea_14.png', 'wea_15.png', 'wea_16.png', 'wea_17.png', 'wea_18.png', 'wea_19.png', 'wea_20.png', 'wea_21.png', 'wea_22.png', 'wea_23.png', 'wea_24.png', 'wea_25.png', 'wea_26.png', 'wea_27.png', 'wea_28.png', 'wea_29.png'];
        let idle_uvi_current_text_font = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 370,
              y: 123,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 395,
              y: 123,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 344,
              y: 124,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 319,
              y: 123,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 378,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 414,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 383,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 164,
              y: 378,
              w: 142,
              h: 28,
              text_size: 13,
              char_space: 0,
              line_space: 0,
              color: 0xFFB4F4D0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 51,
              y: 306,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 19,
              y: 356,
              w: 142,
              h: 28,
              text_size: 18,
              char_space: 1,
              line_space: 0,
              color: 0xFFB4F4D0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 58,
              // DaysCount: 5,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 128,
              // y: 316,
              // w: 142,
              // h: 28,
              // text_size: 15,
              // char_space: 1,
              // line_space: 0,
              // color: 0xFF9EE09B,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.LEFT,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: Po, Út, St, Čt, Pá, So, Ne,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 128 + i*58,
                  y: 316,
                  w: 142,
                  h: 28,
                  text_size: 15,
                  char_space: 1,
                  line_space: 0,
                  color: 0xFF9EE09B,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: Po, Út, St, Čt, Pá, So, Ne,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_low_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 66,
              // y: 348,
              // w: 142,
              // h: 28,
              // text_size: 15,
              // char_space: 1,
              // line_space: 0,
              // color: 0xFFB4F4D0,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_low_text_font,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 66 + i*58,
                  y: 348,
                  w: 142,
                  h: 28,
                  text_size: 15,
                  char_space: 1,
                  line_space: 0,
                  color: 0xFFB4F4D0,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 126,
              // y: 293,
              // image_array: ["wea_1.png","wea_2.png","wea_3.png","wea_4.png","wea_5.png","wea_6.png","wea_7.png","wea_8.png","wea_9.png","wea_10.png","wea_11.png","wea_12.png","wea_13.png","wea_14.png","wea_15.png","wea_16.png","wea_17.png","wea_18.png","wea_19.png","wea_20.png","wea_21.png","wea_22.png","wea_23.png","wea_24.png","wea_25.png","wea_26.png","wea_27.png","wea_28.png","wea_29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 126 + i*58,
                  y: 293,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            normal_uvi_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 340,
              y: 294,
              w: 142,
              h: 28,
              text_size: 21,
              char_space: 1,
              line_space: 0,
              color: 0xFFB4E0D0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 184,
              y: 125,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 153,
              year_startY: 128,
              year_sc_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              year_tc_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              year_en_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 119,
              month_startY: 128,
              month_sc_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              month_tc_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              month_en_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              month_zero: 1,
              month_space: 2,
              month_unit_sc: 'pointer_1.png',
              month_unit_tc: 'pointer_1.png',
              month_unit_en: 'pointer_1.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 85,
              day_startY: 128,
              day_sc_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              day_tc_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              day_en_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              day_zero: 0,
              day_space: 2,
              day_unit_sc: 'pointer_1.png',
              day_unit_tc: 'pointer_1.png',
              day_unit_en: 'pointer_1.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 91,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 285,
              y: 51,
              image_array: ["img_bat_1.png","img_bat_2.png","img_bat_3.png","img_bat_4.png","img_bat_5.png","img_bat_6.png","img_bat_7.png","img_bat_8.png","img_bat_9.png","img_bat_10.png","img_bat_11.png","img_bat_12.png","img_bat_13.png","img_bat_14.png","img_bat_15.png","img_bat_16.png","img_bat_17.png","img_bat_18.png","img_bat_19.png","img_bat_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 91,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 91,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 68,
              image_array: ["img_pulse_1.png","img_pulse_2.png","img_pulse_3.png","img_pulse_4.png","img_pulse_5.png","img_pulse_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 24,
              y: 244,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'dot.png',
              unit_tc: 'dot.png',
              unit_en: 'dot.png',
              imperial_unit_sc: 'dot.png',
              imperial_unit_tc: 'dot.png',
              imperial_unit_en: 'dot.png',
              dot_image: 'pointer_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 170,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 331,
              am_y: 140,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 331,
              pm_y: 140,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 107,
              hour_startY: 164,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_angle: 0,
              hour_unit_sc: 'pointer_0.png',
              hour_unit_tc: 'pointer_0.png',
              hour_unit_en: 'pointer_0.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 225,
              minute_startY: 164,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'pointer_0.png',
              minute_unit_tc: 'pointer_0.png',
              minute_unit_en: 'pointer_0.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 345,
              second_startY: 164,
              second_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              second_zero: 1,
              second_space: 9,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 370,
              y: 123,
              src: 'lock_1.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 395,
              y: 123,
              src: 'dnd_1.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 344,
              y: 124,
              src: 'bt_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 319,
              y: 123,
              src: 'alarm_1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 378,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 414,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 383,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 164,
              y: 378,
              w: 142,
              h: 28,
              text_size: 13,
              char_space: 0,
              line_space: 0,
              color: 0xFFB4F4D0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 51,
              y: 306,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 19,
              y: 356,
              w: 142,
              h: 28,
              text_size: 18,
              char_space: 1,
              line_space: 0,
              color: 0xFFB4F4D0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // idle_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 58,
              // DaysCount: 5,
            // });
            
            idle_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_forecast_date_week_font = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 128,
              // y: 316,
              // w: 142,
              // h: 28,
              // text_size: 15,
              // char_space: 1,
              // line_space: 0,
              // color: 0xFF9EE09B,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.LEFT,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: Po, Út, St, Čt, Pá, So, Ne,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_date_week_font[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 128 + i*58,
                  y: 316,
                  w: 142,
                  h: 28,
                  text_size: 15,
                  char_space: 1,
                  line_space: 0,
                  color: 0xFF9EE09B,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: Po, Út, St, Čt, Pá, So, Ne,
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //end of ignored block

            // idle_forecast_low_text_font = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 66,
              // y: 348,
              // w: 142,
              // h: 28,
              // text_size: 15,
              // char_space: 1,
              // line_space: 0,
              // color: 0xFFB4F4D0,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_low_text_font,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_low_text_font[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 66 + i*58,
                  y: 348,
                  w: 142,
                  h: 28,
                  text_size: 15,
                  char_space: 1,
                  line_space: 0,
                  color: 0xFFB4F4D0,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //end of ignored block

            // idle_forecast_image_progress_img_level = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 126,
              // y: 293,
              // image_array: ["wea_1.png","wea_2.png","wea_3.png","wea_4.png","wea_5.png","wea_6.png","wea_7.png","wea_8.png","wea_9.png","wea_10.png","wea_11.png","wea_12.png","wea_13.png","wea_14.png","wea_15.png","wea_16.png","wea_17.png","wea_18.png","wea_19.png","wea_20.png","wea_21.png","wea_22.png","wea_23.png","wea_24.png","wea_25.png","wea_26.png","wea_27.png","wea_28.png","wea_29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_image_progress_img_level[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 126 + i*58,
                  y: 293,
                  src: idle_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //end of ignored block

            idle_uvi_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 340,
              y: 294,
              w: 142,
              h: 28,
              text_size: 21,
              char_space: 1,
              line_space: 0,
              color: 0xFFB4E0D0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 184,
              y: 125,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 153,
              year_startY: 128,
              year_sc_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              year_tc_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              year_en_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 119,
              month_startY: 128,
              month_sc_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              month_tc_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              month_en_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              month_zero: 1,
              month_space: 2,
              month_unit_sc: 'pointer_1.png',
              month_unit_tc: 'pointer_1.png',
              month_unit_en: 'pointer_1.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 85,
              day_startY: 128,
              day_sc_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              day_tc_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              day_en_array: ["days_0.png","days_1.png","days_2.png","days_3.png","days_4.png","days_5.png","days_6.png","days_7.png","days_8.png","days_9.png"],
              day_zero: 0,
              day_space: 2,
              day_unit_sc: 'pointer_1.png',
              day_unit_tc: 'pointer_1.png',
              day_unit_en: 'pointer_1.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 91,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 285,
              y: 51,
              image_array: ["img_bat_1.png","img_bat_2.png","img_bat_3.png","img_bat_4.png","img_bat_5.png","img_bat_6.png","img_bat_7.png","img_bat_8.png","img_bat_9.png","img_bat_10.png","img_bat_11.png","img_bat_12.png","img_bat_13.png","img_bat_14.png","img_bat_15.png","img_bat_16.png","img_bat_17.png","img_bat_18.png","img_bat_19.png","img_bat_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 91,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 91,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 68,
              image_array: ["img_pulse_1.png","img_pulse_2.png","img_pulse_3.png","img_pulse_4.png","img_pulse_5.png","img_pulse_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 24,
              y: 244,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'dot.png',
              unit_tc: 'dot.png',
              unit_en: 'dot.png',
              imperial_unit_sc: 'dot.png',
              imperial_unit_tc: 'dot.png',
              imperial_unit_en: 'dot.png',
              dot_image: 'pointer_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 170,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 331,
              am_y: 140,
              am_sc_path: 'am_1.png',
              am_en_path: 'am_1.png',
              pm_x: 331,
              pm_y: 140,
              pm_sc_path: 'pm_1.png',
              pm_en_path: 'pm_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 107,
              hour_startY: 164,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_angle: 0,
              hour_unit_sc: 'pointer_0.png',
              hour_unit_tc: 'pointer_0.png',
              hour_unit_en: 'pointer_0.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 225,
              minute_startY: 164,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'pointer_0.png',
              minute_unit_tc: 'pointer_0.png',
              minute_unit_en: 'pointer_0.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 345,
              second_startY: 164,
              second_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              second_zero: 1,
              second_space: 9,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 17,
              y: 159,
              w: 85,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 17,
              y: 236,
              w: 85,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 61,
              w: 85,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 61,
              w: 85,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 285,
              y: 61,
              w: 85,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 123,
              w: 45,
              h: 31,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 396,
              y: 123,
              w: 25,
              h: 31,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 320,
              y: 123,
              w: 25,
              h: 31,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 175,
              y: 407,
              w: 111,
              h: 34,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 5; i++) {
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Number_Font_Min
                let minTemperature = '-';
                if (i < forecastData.count) minTemperature = forecastData.data[i].low.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_low_text_font[i].setProperty(hmUI.prop.TEXT, minTemperature);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.AOD) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  idle_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, idle_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Number_Font_Min
                if (screenType == hmSetting.screen_type.AOD) {
                  idle_forecast_low_text_font[i].setProperty(hmUI.prop.TEXT, minTemperature);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.AOD) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  idle_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, idle_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                weather_few_days();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}