﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0
	
		let colornumber_main = 1
        let totalcolors_main = 3
		
		function click_Night() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }
			normal_image_img.setProperty(hmUI.prop.SRC, "night_" + parseInt(colornumber_main) + ".png");
		}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_progress = ''
        let normal_pai_icon_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: 3555.ttf; FontSize: 25; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 452,
              y: 452,
              w: 30,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3555.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 57,
              y: 184,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "puls",
              anim_fps: 16,
              anim_size: 27,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 38,
              y: 154,
              src: '117.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 255,
              font_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [81,95,108,121,134,148],
              y: [349,349,349,349,349,349],
              image_array: ["hr1.png","hr2.png","hr3.png","hr4.png","hr5.png","hr6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 248,
              y: 305,
              src: '23.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 329,
              font_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 329,
              font_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              padding: false,
              h_space: 1,
              unit_sc: '129.png',
              unit_tc: '129.png',
              unit_en: '129.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 254,
              y: 310,
              image_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png"],
              image_length: 7,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 248,
              y: 250,
              src: '22.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 274,
              font_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 254,
              y: 255,
              image_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png"],
              image_length: 7,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 246,
              y: 196,
              src: '21.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 220,
              font_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 254,
              y: 200,
              image_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 379,
              font_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              padding: false,
              h_space: 1,
              unit_sc: '115.png',
              unit_tc: '115.png',
              unit_en: '115.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 173,
              y: 379,
              image_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 121,
              week_en: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              week_tc: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              week_sc: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 338,
              year_startY: 150,
              year_sc_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              year_tc_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              year_en_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 287,
              month_startY: 150,
              month_sc_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              month_tc_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              month_en_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'sl.png',
              month_unit_tc: 'sl.png',
              month_unit_en: 'sl.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 236,
              day_startY: 150,
              day_sc_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              day_tc_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              day_en_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'sl.png',
              day_unit_tc: 'sl.png',
              day_unit_en: 'sl.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 118,
              y: 365,
              src: '27.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 165,
              y: 23,
              src: '25.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 357,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 253,
              y: 24,
              src: 'alarms.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 99,
              y: 131,
              w: 90,
              h: 28,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/3555.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 122,
              y: 59,
              image_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 104,
              font_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              padding: false,
              h_space: 0,
              unit_sc: '76.png',
              unit_tc: '76.png',
              unit_en: '76.png',
              imperial_unit_sc: '76.png',
              imperial_unit_tc: '76.png',
              imperial_unit_en: '76.png',
              negative_image: '75.png',
              invalid_image: '74.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 117,
                y: 104,
                font_array: ["11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
                padding: false,
                h_space: 0,
                unit_sc: '76.png',
                unit_tc: '76.png',
                unit_en: '76.png',
                imperial_unit_sc: '76.png',
                imperial_unit_tc: '76.png',
                imperial_unit_en: '76.png',
                negative_image: '75.png',
                invalid_image: '74.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 199,
              am_y: 25,
              am_sc_path: '24.png',
              am_en_path: '24.png',
              pm_x: 199,
              pm_y: 25,
              pm_sc_path: '26.png',
              pm_en_path: '26.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 179,
              hour_startY: 63,
              hour_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_unit_sc: '116.png',
              hour_unit_tc: '116.png',
              hour_unit_en: '116.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 263,
              minute_startY: 63,
              minute_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sek4.png',
              // center_x: 227,
              // center_y: 227,
              // x: 126,
              // y: 232,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 126,
              pos_y: 227 - 232,
              center_x: 227,
              center_y: 227,
              src: 'sek4.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'night_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bgaod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            idle_battery_linear_scale.setAlpha(165);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 171,
              // start_y: 417,
              // color: 0xFF000000,
              // lenght: -38,
              // line_width: 20,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: True,
              // alpha: 165,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 379,
              font_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              padding: false,
              h_space: 1,
              unit_sc: '115.png',
              unit_tc: '115.png',
              unit_en: '115.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 121,
              week_en: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              week_tc: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              week_sc: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 338,
              year_startY: 150,
              year_sc_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              year_tc_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              year_en_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 287,
              month_startY: 150,
              month_sc_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              month_tc_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              month_en_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'sl.png',
              month_unit_tc: 'sl.png',
              month_unit_en: 'sl.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 236,
              day_startY: 150,
              day_sc_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              day_tc_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              day_en_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'sl.png',
              day_unit_tc: 'sl.png',
              day_unit_en: 'sl.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 199,
              am_y: 24,
              am_sc_path: '24.png',
              am_en_path: '24.png',
              pm_x: 199,
              pm_y: 25,
              pm_sc_path: '26.png',
              pm_en_path: '26.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 179,
              hour_startY: 63,
              hour_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_unit_sc: '116.png',
              hour_unit_tc: '116.png',
              hour_unit_en: '116.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 263,
              minute_startY: 63,
              minute_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'night_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 241,
              y: 196,
              w: 155,
              h: 95,
              src: 'Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 176,
              w: 154,
              h: 190,
              src: 'Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: 302,
              w: 152,
              h: 64,
              src: 'Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 166,
              y: 369,
              w: 126,
              h: 63,
              src: 'Empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 96,
              y: 102,
              w: 91,
              h: 60,
              src: 'Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 22,
              w: 62,
              h: 38,
              src: 'Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 232,
              y: 139,
              w: 178,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 64,
              w: 139,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 107,
              y: 48,
              w: 72,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 171;
                  let start_y_idle_battery = 379;
                  let lenght_ls_idle_battery = 38;
                  let line_width_ls_idle_battery = 20;
                  let color_ls_idle_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = line_width_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = lenght_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    line_width_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_y_idle_battery_draw = start_y_idle_battery_draw - line_width_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}