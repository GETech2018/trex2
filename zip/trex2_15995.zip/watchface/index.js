﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_circle_scale = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_img = ''
        let normal_temperature_max_min_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_image_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_pai_weekly_text_img = ''
        let idle_pai_weekly_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_image_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let image_top_img = ''
        let normal_cal_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'wall.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 220,
              // end_angle: 140,
              // radius: 200,
              // line_width: 20,
              // line_cap: Flat,
              // color: 0xFF607D8B,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 220,
              end_angle: 140,
              radius: 190,
              line_width: 20,
              corner_flag: 3,
              color: 0xFF607D8B,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 236,
              y: 370,
              font_array: ["pai=0.png","pai=1.png","pai=2.png","pai=3.png","pai=4.png","pai=5.png","pai=6.png","pai=7.png","pai=8.png","pai=9.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 370,
              src: 'pai=icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 323,
              font_array: ["callories=0.png","callories=1.png","callories=2.png","callories=3.png","callories=4.png","callories=5.png","callories=6.png","callories=7.png","callories=8.png","callories=9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 246,
              y: 321,
              src: 'callories=thunder.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img.setAlpha(100);

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 371,
              y: 259,
              font_array: ["battery=0.png","battery=1.png","battery=2.png","battery=3.png","battery=4.png","battery=5.png","battery=6.png","battery=7.png","battery=8.png","battery=9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 377,
              y: 282,
              image_array: ["batery=1.png","batery=10.png","batery=2.png","batery=3.png","batery=4.png","batery=5.png","batery=6.png","batery=7.png","batery=8.png","batery=9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 163,
              src: 'addicon=bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 284,
              src: 'addicon=alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 91,
              y: 122,
              image_array: ["weather-icons=_0.png","weather-icons=_1.png","weather-icons=_2.png","weather-icons=_3.png","weather-icons=_4.png","weather-icons=_5.png","weather-icons=_6.png","weather-icons=_7.png","weather-icons=_8.png","weather-icons=_9.png","weather-icons=_10.png","weather-icons=_11.png","weather-icons=_12.png","weather-icons=_13.png","weather-icons=_14.png","weather-icons=_15.png","weather-icons=_16.png","weather-icons=_17.png","weather-icons=_18.png","weather-icons=_19.png","weather-icons=_20.png","weather-icons=_21.png","weather-icons=_22.png","weather-icons=_23.png","weather-icons=_24.png","weather-icons=_25.png","weather-icons=_26.png","weather-icons=_27.png","weather-icons=_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 124,
              font_array: ["forecast=0.png","forecast=1.png","forecast=2.png","forecast=3.png","forecast=4.png","forecast=5.png","forecast=6.png","forecast=7.png","forecast=8.png","forecast=9.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'forecast=celcium.png',
              unit_tc: 'forecast=celcium.png',
              unit_en: 'forecast=celcium.png',
              imperial_unit_sc: 'forecast=faringate.png',
              imperial_unit_tc: 'forecast=faringate.png',
              imperial_unit_en: 'forecast=faringate.png',
              negative_image: 'forecast=minus.png',
              invalid_image: 'forecast=error.png',
              dot_image: 'forecast=next.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_max_min_text_img.setProperty(hmUI.prop.MORE, {
                x: 235,
                y: 124,
                font_array: ["forecast=0.png","forecast=1.png","forecast=2.png","forecast=3.png","forecast=4.png","forecast=5.png","forecast=6.png","forecast=7.png","forecast=8.png","forecast=9.png"],
                padding: false,
                h_space: 4,
                unit_sc: 'forecast=faringate.png',
                unit_tc: 'forecast=faringate.png',
                unit_en: 'forecast=faringate.png',
                imperial_unit_sc: 'forecast=celcium.png',
                imperial_unit_tc: 'forecast=celcium.png',
                imperial_unit_en: 'forecast=celcium.png',
                negative_image: 'forecast=minus.png',
                invalid_image: 'forecast=error.png',
                dot_image: 'forecast=next.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_HIGH_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 124,
              font_array: ["temperature=0.png","temperature=1.png","temperature=2.png","temperature=3.png","temperature=4.png","temperature=5.png","temperature=6.png","temperature=7.png","temperature=8.png","temperature=9.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'temperature=celcium.png',
              unit_tc: 'temperature=celcium.png',
              unit_en: 'temperature=celcium.png',
              imperial_unit_sc: 'temperature=faringate.png',
              imperial_unit_tc: 'temperature=faringate.png',
              imperial_unit_en: 'temperature=faringate.png',
              negative_image: 'temperature=minus.png',
              invalid_image: 'temperature=error.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 129,
                y: 124,
                font_array: ["temperature=0.png","temperature=1.png","temperature=2.png","temperature=3.png","temperature=4.png","temperature=5.png","temperature=6.png","temperature=7.png","temperature=8.png","temperature=9.png"],
                padding: false,
                h_space: 4,
                unit_sc: 'temperature=faringate.png',
                unit_tc: 'temperature=faringate.png',
                unit_en: 'temperature=faringate.png',
                imperial_unit_sc: 'temperature=celcium.png',
                imperial_unit_tc: 'temperature=celcium.png',
                imperial_unit_en: 'temperature=celcium.png',
                negative_image: 'temperature=minus.png',
                invalid_image: 'temperature=error.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 322,
              month_startY: 90,
              month_sc_array: ["mont=0.png","mont=1.png","mont=2.png","mont=3.png","mont=4.png","mont=5.png","mont=6.png","mont=7.png","mont=8.png","mont=9.png"],
              month_tc_array: ["mont=0.png","mont=1.png","mont=2.png","mont=3.png","mont=4.png","mont=5.png","mont=6.png","mont=7.png","mont=8.png","mont=9.png"],
              month_en_array: ["mont=0.png","mont=1.png","mont=2.png","mont=3.png","mont=4.png","mont=5.png","mont=6.png","mont=7.png","mont=8.png","mont=9.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 287,
              day_startY: 90,
              day_sc_array: ["days=0.png","days=1.png","days=2.png","days=3.png","days=4.png","days=5.png","days=6.png","days=7.png","days=8.png","days=9.png"],
              day_tc_array: ["days=0.png","days=1.png","days=2.png","days=3.png","days=4.png","days=5.png","days=6.png","days=7.png","days=8.png","days=9.png"],
              day_en_array: ["days=0.png","days=1.png","days=2.png","days=3.png","days=4.png","days=5.png","days=6.png","days=7.png","days=8.png","days=9.png"],
              day_zero: 1,
              day_space: 3,
              day_unit_sc: 'days=separator.png',
              day_unit_tc: 'days=separator.png',
              day_unit_en: 'days=separator.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 111,
              y: 90,
              week_en: ["day=1.png","day=2.png","day=3.png","day=4.png","day=5.png","day=6.png","day=7.png"],
              week_tc: ["day=1.png","day=2.png","day=3.png","day=4.png","day=5.png","day=6.png","day=7.png"],
              week_sc: ["day=1.png","day=2.png","day=3.png","day=4.png","day=5.png","day=6.png","day=7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: 42,
              src: 'label.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 227,
              // line_width: 21,
              // line_cap: Flat,
              // color: 0xFF607D8B,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 0,
              end_angle: 360,
              radius: 217,
              line_width: 21,
              corner_flag: 3,
              color: 0xFF607D8B,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 141,
              y: 323,
              font_array: ["steps=0.png","steps=1.png","steps=2.png","steps=3.png","steps=4.png","steps=5.png","steps=6.png","steps=7.png","steps=8.png","steps=9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 103,
              y: 321,
              src: 'steps=trophy.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img.setAlpha(100);

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 32,
              am_y: 227,
              am_sc_path: 'addicon=am.png',
              am_en_path: 'addicon=am.png',
              pm_x: 32,
              pm_y: 227,
              pm_sc_path: 'addicon=pm.png',
              pm_en_path: 'addicon=pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 89,
              hour_startY: 154,
              hour_array: ["hours=0.png","hours=1.png","hours=2.png","hours=3.png","hours=4.png","hours=5.png","hours=6.png","hours=7.png","hours=8.png","hours=9.png"],
              hour_zero: 1,
              hour_space: 15,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 253,
              minute_startY: 154,
              minute_array: ["minutes=0.png","minutes=1.png","minutes=2.png","minutes=3.png","minutes=4.png","minutes=5.png","minutes=6.png","minutes=7.png","minutes=8.png","minutes=9.png"],
              minute_zero: 1,
              minute_space: 15,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 375,
              second_startY: 163,
              second_array: ["seconds=0.png","seconds=1.png","seconds=2.png","seconds=3.png","seconds=4.png","seconds=5.png","seconds=6.png","seconds=7.png","seconds=8.png","seconds=9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 202,
              y: 154,
              src: 'hours=separator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'secound.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 0,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 236,
              y: 370,
              font_array: ["pai=0.png","pai=1.png","pai=2.png","pai=3.png","pai=4.png","pai=5.png","pai=6.png","pai=7.png","pai=8.png","pai=9.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img.setAlpha(150);

            idle_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 370,
              src: 'pai=icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_separator_img.setAlpha(150);

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 323,
              font_array: ["callories=0.png","callories=1.png","callories=2.png","callories=3.png","callories=4.png","callories=5.png","callories=6.png","callories=7.png","callories=8.png","callories=9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img.setAlpha(150);

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 246,
              y: 321,
              src: 'callories=thunder.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img.setAlpha(100);

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 163,
              src: 'addicon=bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 284,
              src: 'addicon=alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 322,
              month_startY: 90,
              month_sc_array: ["mont=0.png","mont=1.png","mont=2.png","mont=3.png","mont=4.png","mont=5.png","mont=6.png","mont=7.png","mont=8.png","mont=9.png"],
              month_tc_array: ["mont=0.png","mont=1.png","mont=2.png","mont=3.png","mont=4.png","mont=5.png","mont=6.png","mont=7.png","mont=8.png","mont=9.png"],
              month_en_array: ["mont=0.png","mont=1.png","mont=2.png","mont=3.png","mont=4.png","mont=5.png","mont=6.png","mont=7.png","mont=8.png","mont=9.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month.setAlpha(150);

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 287,
              day_startY: 90,
              day_sc_array: ["days=0.png","days=1.png","days=2.png","days=3.png","days=4.png","days=5.png","days=6.png","days=7.png","days=8.png","days=9.png"],
              day_tc_array: ["days=0.png","days=1.png","days=2.png","days=3.png","days=4.png","days=5.png","days=6.png","days=7.png","days=8.png","days=9.png"],
              day_en_array: ["days=0.png","days=1.png","days=2.png","days=3.png","days=4.png","days=5.png","days=6.png","days=7.png","days=8.png","days=9.png"],
              day_zero: 1,
              day_space: 3,
              day_unit_sc: 'days=separator.png',
              day_unit_tc: 'days=separator.png',
              day_unit_en: 'days=separator.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 111,
              y: 90,
              week_en: ["day=1.png","day=2.png","day=3.png","day=4.png","day=5.png","day=6.png","day=7.png"],
              week_tc: ["day=1.png","day=2.png","day=3.png","day=4.png","day=5.png","day=6.png","day=7.png"],
              week_sc: ["day=1.png","day=2.png","day=3.png","day=4.png","day=5.png","day=6.png","day=7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img.setAlpha(150);

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 113,
              y: 42,
              src: 'label.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 141,
              y: 323,
              font_array: ["steps=0.png","steps=1.png","steps=2.png","steps=3.png","steps=4.png","steps=5.png","steps=6.png","steps=7.png","steps=8.png","steps=9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img.setAlpha(150);

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 103,
              y: 321,
              src: 'steps=trophy.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img.setAlpha(100);

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 32,
              am_y: 227,
              am_sc_path: 'addicon=am.png',
              am_en_path: 'addicon=am.png',
              pm_x: 32,
              pm_y: 227,
              pm_sc_path: 'addicon=pm.png',
              pm_en_path: 'addicon=pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 89,
              hour_startY: 154,
              hour_array: ["hours=0.png","hours=1.png","hours=2.png","hours=3.png","hours=4.png","hours=5.png","hours=6.png","hours=7.png","hours=8.png","hours=9.png"],
              hour_zero: 1,
              hour_space: 15,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 253,
              minute_startY: 154,
              minute_array: ["minutes=0.png","minutes=1.png","minutes=2.png","minutes=3.png","minutes=4.png","minutes=5.png","minutes=6.png","minutes=7.png","minutes=8.png","minutes=9.png"],
              minute_zero: 1,
              minute_space: 15,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time.setAlpha(200);

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 202,
              y: 154,
              src: 'hours=separator.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'up.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 246,
              y: 321,
              w: 118,
              h: 38,
              src: 'zero.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 109,
              y: 80,
              w: 251,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'zero.png',
              normal_src: 'zero.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 91,
              y: 122,
              w: 284,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'zero.png',
              normal_src: 'zero.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 89,
              y: 164,
              w: 118,
              h: 151,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'zero.png',
              normal_src: 'zero.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 253,
              y: 164,
              w: 118,
              h: 151,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'zero.png',
              normal_src: 'zero.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 375,
              y: 164,
              w: 47,
              h: 71,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'zero.png',
              normal_src: 'zero.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 375,
              y: 246,
              w: 47,
              h: 69,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'zero.png',
              normal_src: 'zero.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 323,
              w: 142,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'zero.png',
              normal_src: 'zero.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 92,
              y: 365,
              w: 259,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'zero.png',
              normal_src: 'zero.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_pai * 100);
                  if (normal_pai_circle_scale) {
                    normal_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 220,
                      end_angle: 140,
                      radius: 190,
                      line_width: 20,
                      corner_flag: 3,
                      color: 0xFF607D8B,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 217,
                      line_width: 21,
                      corner_flag: 3,
                      color: 0xFF607D8B,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}