﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 231,
              y: 264,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 194,
              y: 264,
              src: 'Sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 283,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 24,
              y: 275,
              image_array: ["Batteria_01.png","Batteria_02.png","Batteria_03.png","Batteria_04.png","Batteria_05.png","Batteria_06.png","Batteria_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 286,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 333,
              y: 274,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 329,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 383,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 328,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Nr.Att_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 36,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 48,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              negative_image: 'Nr.Att_11.png',
              invalid_image: 'Nr.Att_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 141,
              month_startY: 136,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 147,
              y: 94,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 62,
              year_startY: 127,
              year_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              year_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              year_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              year_zero: 1,
              year_space: 3,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 327,
              day_startY: 99,
              day_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 43,
              hour_startY: 176,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 180,
              minute_startY: 176,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 315,
              second_startY: 177,
              second_array: ["Nr.Sec_01.png","Nr.Sec_02.png","Nr.Sec_03.png","Nr.Sec_04.png","Nr.Sec_05.png","Nr.Sec_06.png","Nr.Sec_07.png","Nr.Sec_08.png","Nr.Sec_09.png","Nr.Sec_10.png"],
              second_zero: 1,
              second_space: 9,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 231,
              y: 264,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 194,
              y: 264,
              src: 'Sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 283,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 24,
              y: 275,
              image_array: ["Batteria_01.png","Batteria_02.png","Batteria_03.png","Batteria_04.png","Batteria_05.png","Batteria_06.png","Batteria_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 286,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 333,
              y: 274,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 329,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 383,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 328,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Nr.Att_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 36,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 48,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 3,
              negative_image: 'Nr.Att_11.png',
              invalid_image: 'Nr.Att_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 141,
              month_startY: 136,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 147,
              y: 94,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 62,
              year_startY: 127,
              year_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              year_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              year_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              year_zero: 1,
              year_space: 3,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 327,
              day_startY: 99,
              day_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 43,
              hour_startY: 176,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 180,
              minute_startY: 176,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}