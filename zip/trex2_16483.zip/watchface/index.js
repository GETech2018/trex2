﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_city_name_text = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ];
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_step_linear_scale = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_city_name_text = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ];
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_step_linear_scale = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_heart_rate_circle_scale = ''
        let idle_analog_clock_time_pointer_second = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 150,
              y: 49,
              w: 150,
              h: 38,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFF0EA00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 373,
              font_array: ["S0035.png","S0036.png","S0037.png","S0038.png","S0039.png","S0040.png","S0041.png","S0042.png","S0043.png","S0044.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 371,
              image_array: ["bat1.png","bat2.png","bat3.png","bat4.png","bat5.png","bat6.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 286,
              y: 347,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 187,
              y: 345,
              src: 'BTH.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 233,
              y: 347,
              src: 'ALM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 324,
              y: 227,
              w: 53,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFF2E700,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 193,
              month_startY: 302,
              month_sc_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              month_tc_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              month_en_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              month_zero: 1,
              month_space: 4,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 100,
              day_startY: 302,
              day_sc_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              day_tc_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              day_en_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 257,
              y: 301,
              week_en: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              week_tc: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              week_sc: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 233,
              hour_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 208,
              minute_startY: 233,
              minute_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 317,
              second_startY: 259,
              second_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -10,
              y: 0,
              src: 'LAYER.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 86,
              // start_y: 140,
              // color: 0xFFC0C0C0,
              // lenght: 278,
              // line_width: 68,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: -131,
              // end_angle: -50,
              // radius: 208,
              // line_width: 18,
              // line_cap: Flat,
              // color: 0xFFCCB40B,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: -131,
              end_angle: -50,
              radius: 199,
              line_width: 18,
              corner_flag: 3,
              color: 0xFFCCB40B,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 88,
              font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 74,
              y: 133,
              src: 'STEP-LAYER.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 130,
              // end_angle: 49,
              // radius: 208,
              // line_width: 19,
              // line_cap: Flat,
              // color: 0xFFCAB51E,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 130,
              end_angle: 49,
              radius: 199,
              line_width: 19,
              corner_flag: 3,
              color: 0xFFCAB51E,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 11,
              second_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 150,
              y: 49,
              w: 150,
              h: 38,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFF0EA00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 373,
              font_array: ["S0035.png","S0036.png","S0037.png","S0038.png","S0039.png","S0040.png","S0041.png","S0042.png","S0043.png","S0044.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 371,
              image_array: ["bat1.png","bat2.png","bat3.png","bat4.png","bat5.png","bat6.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 286,
              y: 347,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 187,
              y: 345,
              src: 'BTH.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 233,
              y: 347,
              src: 'ALM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 324,
              y: 227,
              w: 53,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFF2E700,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 193,
              month_startY: 302,
              month_sc_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              month_tc_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              month_en_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              month_zero: 1,
              month_space: 4,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 100,
              day_startY: 302,
              day_sc_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              day_tc_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              day_en_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 257,
              y: 301,
              week_en: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              week_tc: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              week_sc: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 233,
              hour_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 208,
              minute_startY: 233,
              minute_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 317,
              second_startY: 259,
              second_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -10,
              y: 0,
              src: 'LAYER.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 86,
              // start_y: 140,
              // color: 0xFFC0C0C0,
              // lenght: 278,
              // line_width: 68,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: -131,
              // end_angle: -50,
              // radius: 208,
              // line_width: 18,
              // line_cap: Flat,
              // color: 0xFFCCB40B,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: -131,
              end_angle: -50,
              radius: 199,
              line_width: 18,
              corner_flag: 3,
              color: 0xFFCCB40B,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 88,
              font_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 74,
              y: 133,
              src: 'STEP-LAYER.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 130,
              // end_angle: 49,
              // radius: 208,
              // line_width: 19,
              // line_cap: Flat,
              // color: 0xFFCAB51E,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 130,
              end_angle: 49,
              radius: 199,
              line_width: 19,
              corner_flag: 3,
              color: 0xFFCAB51E,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 11,
              second_posY: 226,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 86;
                  let start_y_normal_step = 140;
                  let lenght_ls_normal_step = 278;
                  let line_width_ls_normal_step = 68;
                  let color_ls_normal_step = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: -131,
                      end_angle: -50,
                      radius: 199,
                      line_width: 18,
                      corner_flag: 3,
                      color: 0xFFCCB40B,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 130,
                      end_angle: 49,
                      radius: 199,
                      line_width: 19,
                      corner_flag: 3,
                      color: 0xFFCAB51E,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 86;
                  let start_y_idle_step = 140;
                  let lenght_ls_idle_step = 278;
                  let line_width_ls_idle_step = 68;
                  let color_ls_idle_step = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = lenght_ls_idle_step;
                  let line_width_ls_idle_step_draw = line_width_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    lenght_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_x_idle_step_draw = start_x_idle_step - lenght_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    color: color_ls_idle_step,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: -131,
                      end_angle: -50,
                      radius: 199,
                      line_width: 18,
                      corner_flag: 3,
                      color: 0xFFCCB40B,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                let progress_cs_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_heart_rate * 100);
                  if (idle_heart_rate_circle_scale) {
                    idle_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 130,
                      end_angle: 49,
                      radius: 199,
                      line_width: 19,
                      corner_flag: 3,
                      color: 0xFFCAB51E,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}