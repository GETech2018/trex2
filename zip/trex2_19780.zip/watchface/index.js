try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface');

        const digits = p => [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map(i => p + i + '.png');
        const week = ['w1.png', 'w2.png', 'w3.png', 'w4.png', 'w5.png', 'w6.png', 'w7.png'];

        // Widgets shared by the normal and always-on (AOD) screens, at the same spots so nothing jumps.
        function drawCommon(level, timeDigits, timeY) {
            hmUI.createWidget(hmUI.widget.IMG, { x: 171, y: 36, src: 'mascot.png', show_level: level });

            hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_startX: 67, hour_startY: timeY, hour_array: timeDigits, hour_zero: 1, hour_space: 0, hour_align: hmUI.align.LEFT,
                minute_startX: 259, minute_startY: timeY, minute_array: timeDigits, minute_zero: 1, minute_space: 0, minute_follow: 0, minute_align: hmUI.align.LEFT,
                show_level: level,
            });
            hmUI.createWidget(hmUI.widget.IMG, { x: 195, y: 141, src: 'colon.png', show_level: level });

            hmUI.createWidget(hmUI.widget.IMG_WEEK, { x: 176, y: 292, week_en: week, week_tc: week, week_sc: week, show_level: level });
            hmUI.createWidget(hmUI.widget.IMG_DATE, {
                month_startX: 228, month_startY: 292, month_en_array: digits('c'), month_sc_array: digits('c'), month_tc_array: digits('c'),
                month_zero: 1, month_space: 0, month_align: hmUI.align.LEFT, month_is_character: false,
                show_level: level,
            });
            hmUI.createWidget(hmUI.widget.IMG, { x: 256, y: 292, src: 'slash.png', show_level: level });
            hmUI.createWidget(hmUI.widget.IMG_DATE, {
                day_startX: 270, day_startY: 292, day_en_array: digits('c'), day_sc_array: digits('c'), day_tc_array: digits('c'),
                day_zero: 1, day_space: 0, day_align: hmUI.align.LEFT, day_is_character: false,
                show_level: level,
            });
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                const NORMAL = hmUI.show_level.ONLY_NORMAL;

                // Normal screen: background holds icons, labels, date pill and terminal lines.
                hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 454, h: 454, src: 'bg.png', show_level: NORMAL });
                drawCommon(NORMAL, digits('t'), 134);

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 90, y: 222, font_array: digits('n'), h_space: 0, align_h: hmUI.align.LEFT,
                    type: hmUI.data_type.HEART, show_level: NORMAL,
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 196, y: 222, font_array: digits('n'), h_space: 0, align_h: hmUI.align.LEFT,
                    type: hmUI.data_type.STEP, show_level: NORMAL,
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 330, y: 222, font_array: digits('n'), h_space: 0, align_h: hmUI.align.LEFT,
                    unit_en: 'pct.png', unit_sc: 'pct.png', unit_tc: 'pct.png',
                    type: hmUI.data_type.BATTERY, show_level: NORMAL,
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 206, y: 362,
                    image_array: ['g0.png', 'g1.png', 'g2.png', 'g3.png', 'g4.png', 'g5.png', 'g6.png', 'g7.png', 'g8.png', 'g9.png', 'g10.png'],
                    image_length: 11,
                    type: hmUI.data_type.STEP, show_level: NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: 60, y: 218, w: 110, h: 60, type: hmUI.data_type.HEART, show_level: NORMAL });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: 170, y: 218, w: 125, h: 60, type: hmUI.data_type.STEP, show_level: NORMAL });

                // Always-on screen: black, only mascot + time + date (Zepp asks for ~10% lit pixels and no seconds).
                drawCommon(hmUI.show_level.ONLY_AOD, digits('a'), 138); // thinner digits, centred on the same line
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
