﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 22;
        let normal_day_TextCircle_img_height = 43;
        let normal_timerTextUpdate = undefined;
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_day_TextCircle = new Array(2);
        let idle_day_TextCircle_ASCIIARRAY = new Array(10);
        let idle_day_TextCircle_img_width = 22;
        let idle_day_TextCircle_img_height = 43;
        let idle_timerTextUpdate = undefined;
        let idle_hour_TextCircle = new Array(2);
        let idle_hour_TextCircle_ASCIIARRAY = new Array(10);
        let idle_hour_TextCircle_img_width = 22;
        let idle_hour_TextCircle_img_height = 43;
        let idle_minute_TextCircle = new Array(2);
        let idle_minute_TextCircle_ASCIIARRAY = new Array(10);
        let idle_minute_TextCircle_img_width = 22;
        let idle_minute_TextCircle_img_height = 43;
        let idle_digital_clock_img_time_AmPm = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'base1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["20mo.png","21tu.png","21we.png","24th.png","25fr.png","26sa.png","27su.png"],
              week_tc: ["20mo.png","21tu.png","21we.png","24th.png","25fr.png","26sa.png","27su.png"],
              week_sc: ["20mo.png","21tu.png","21we.png","24th.png","25fr.png","26sa.png","27su.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["31ja.png","32fe.png","33ma.png","34ap.png","35ma.png","36ju.png","37ju.png","38au.png","391se.png","392oc.png","393no.png","394de.png"],
              month_tc_array: ["31ja.png","32fe.png","33ma.png","34ap.png","35ma.png","36ju.png","37ju.png","38au.png","391se.png","392oc.png","393no.png","394de.png"],
              month_en_array: ["31ja.png","32fe.png","33ma.png","34ap.png","35ma.png","36ju.png","37ju.png","38au.png","391se.png","392oc.png","393no.png","394de.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["digit200.png","digit201.png","digit202.png","digit203.png","digit204.png","digit205.png","digit206.png","digit207.png","digit208.png","digit209.png"],
              // radius: 201,
              // angle: -35,
              // char_space_angle: 2,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'digit200.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'digit201.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'digit202.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'digit203.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'digit204.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'digit205.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'digit206.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'digit207.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'digit208.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'digit209.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_day_TextCircle_img_width / 2,
                pos_y: 227 - 222,
                src: 'digit200.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 252,
              second_startY: 266,
              second_array: ["digit200.png","digit201.png","digit202.png","digit203.png","digit204.png","digit205.png","digit206.png","digit207.png","digit208.png","digit209.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hour.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'min.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["20mo.png","21tu.png","21we.png","24th.png","25fr.png","26sa.png","27su.png"],
              week_tc: ["20mo.png","21tu.png","21we.png","24th.png","25fr.png","26sa.png","27su.png"],
              week_sc: ["20mo.png","21tu.png","21we.png","24th.png","25fr.png","26sa.png","27su.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["31ja.png","32fe.png","33ma.png","34ap.png","35ma.png","36ju.png","37ju.png","38au.png","391se.png","392oc.png","393no.png","394de.png"],
              month_tc_array: ["31ja.png","32fe.png","33ma.png","34ap.png","35ma.png","36ju.png","37ju.png","38au.png","391se.png","392oc.png","393no.png","394de.png"],
              month_en_array: ["31ja.png","32fe.png","33ma.png","34ap.png","35ma.png","36ju.png","37ju.png","38au.png","391se.png","392oc.png","393no.png","394de.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["digit200.png","digit201.png","digit202.png","digit203.png","digit204.png","digit205.png","digit206.png","digit207.png","digit208.png","digit209.png"],
              // radius: 201,
              // angle: -35,
              // char_space_angle: 2,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextCircle_ASCIIARRAY[0] = 'digit200.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[1] = 'digit201.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[2] = 'digit202.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[3] = 'digit203.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[4] = 'digit204.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[5] = 'digit205.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[6] = 'digit206.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[7] = 'digit207.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[8] = 'digit208.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[9] = 'digit209.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - idle_day_TextCircle_img_width / 2,
                pos_y: 227 - 222,
                src: 'digit200.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["digit200.png","digit201.png","digit202.png","digit203.png","digit204.png","digit205.png","digit206.png","digit207.png","digit208.png","digit209.png"],
              // radius: 135,
              // angle: -339,
              // char_space_angle: 4,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextCircle_ASCIIARRAY[0] = 'digit200.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[1] = 'digit201.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[2] = 'digit202.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[3] = 'digit203.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[4] = 'digit204.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[5] = 'digit205.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[6] = 'digit206.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[7] = 'digit207.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[8] = 'digit208.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[9] = 'digit209.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - idle_hour_TextCircle_img_width / 2,
                pos_y: 227 - 156,
                src: 'digit200.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["digit200.png","digit201.png","digit202.png","digit203.png","digit204.png","digit205.png","digit206.png","digit207.png","digit208.png","digit209.png"],
              // radius: 135,
              // angle: -305,
              // char_space_angle: 4,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextCircle_ASCIIARRAY[0] = 'digit200.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[1] = 'digit201.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[2] = 'digit202.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[3] = 'digit203.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[4] = 'digit204.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[5] = 'digit205.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[6] = 'digit206.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[7] = 'digit207.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[8] = 'digit208.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[9] = 'digit209.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - idle_minute_TextCircle_img_width / 2,
                pos_y: 227 - 156,
                src: 'digit200.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

            };

            function text_update() {
              console.log('text_update()');

              console.log('update text circle day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_circle_string = parseInt(valueDay).toString();
              normal_day_circle_string = normal_day_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -35;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 201));
                  // alignment = CENTER_H
                  let normal_day_TextCircle_angleOffset = normal_day_TextCircle_img_angle * (normal_day_circle_string.length - 1);
                  normal_day_TextCircle_angleOffset = normal_day_TextCircle_angleOffset + 2 * (normal_day_circle_string.length - 1) / 2;
                  char_Angle -= normal_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_day_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle day_TIME');
              let idle_day_circle_string = parseInt(valueDay).toString();
              idle_day_circle_string = idle_day_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -35;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_circle_string.length > 0 && idle_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_day_TextCircle_img_angle = 0;
                  let idle_day_TextCircle_dot_img_angle = 0;
                  idle_day_TextCircle_img_angle = toDegree(Math.atan2(idle_day_TextCircle_img_width/2, 201));
                  // alignment = CENTER_H
                  let idle_day_TextCircle_angleOffset = idle_day_TextCircle_img_angle * (idle_day_circle_string.length - 1);
                  idle_day_TextCircle_angleOffset = idle_day_TextCircle_angleOffset + 2 * (idle_day_circle_string.length - 1) / 2;
                  char_Angle -= idle_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_day_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_day_TextCircle_img_width / 2);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.SRC, idle_day_TextCircle_ASCIIARRAY[charCode]);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_day_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let idle_hour_circle_string = parseInt(valueHour).toString();
              idle_hour_circle_string = idle_hour_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -339;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_circle_string.length > 0 && idle_hour_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_hour_TextCircle_img_angle = 0;
                  let idle_hour_TextCircle_dot_img_angle = 0;
                  idle_hour_TextCircle_img_angle = toDegree(Math.atan2(idle_hour_TextCircle_img_width/2, 135));
                  // alignment = CENTER_H
                  let idle_hour_TextCircle_angleOffset = idle_hour_TextCircle_img_angle * (idle_hour_circle_string.length - 1);
                  idle_hour_TextCircle_angleOffset = idle_hour_TextCircle_angleOffset + 4 * (idle_hour_circle_string.length - 1) / 2;
                  char_Angle -= idle_hour_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_hour_TextCircle_img_width / 2);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.SRC, idle_hour_TextCircle_ASCIIARRAY[charCode]);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_hour_TextCircle_img_angle + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let valueMinute = timeNaw.minute;
              let idle_minute_circle_string = parseInt(valueMinute).toString();
              idle_minute_circle_string = idle_minute_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -305;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_circle_string.length > 0 && idle_minute_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_minute_TextCircle_img_angle = 0;
                  let idle_minute_TextCircle_dot_img_angle = 0;
                  idle_minute_TextCircle_img_angle = toDegree(Math.atan2(idle_minute_TextCircle_img_width/2, 135));
                  // alignment = CENTER_H
                  let idle_minute_TextCircle_angleOffset = idle_minute_TextCircle_img_angle * (idle_minute_circle_string.length - 1);
                  idle_minute_TextCircle_angleOffset = idle_minute_TextCircle_angleOffset + 4 * (idle_minute_circle_string.length - 1) / 2;
                  char_Angle -= idle_minute_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_minute_TextCircle_img_width / 2);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.SRC, idle_minute_TextCircle_ASCIIARRAY[charCode]);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_minute_TextCircle_img_angle + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}