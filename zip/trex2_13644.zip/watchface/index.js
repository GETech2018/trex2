﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

		let colorNumber = 0;
		let pointerOn = true;
		let brightnessVal = 100;
		let brightnessValMin = 20;
		let leftNumber = 0;
		let rightNumber = 0;
		let timer_StopVibrate = null;
		let themeColors = [
			"W H I T E",
			"Y E L L O W",
			"A Q U A",
			"P U R P L E",
			"B L U E",
			"G R E E N",
			"R E D",
			"O R A N G E"
		];

		let normal_left_object_text = '';
		let normal_right_object_text = '';
		let idle_time_colon_text_font = '';
		let idle_day_period_text_font = '';
		let idle_month_period_text_font = '';

		const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);

		function click_Left() {
			switch (leftNumber) {
			case 0:
				normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_left_object_text.setProperty(hmUI.prop.TEXT, 'Calories');
				break;
			case 1:
				normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_left_object_text.setProperty(hmUI.prop.TEXT, 'PAI');
				break;
			case 2:
				normal_pai_weekly_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_left_object_text.setProperty(hmUI.prop.TEXT, 'Heart Rate');
			}
			leftNumber = leftNumber + 1;
			if (leftNumber >= 3) { leftNumber = 0; }
		}

		function click_Right() {
			switch (rightNumber) {
			case 0:
				normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_uvi_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_right_object_text.setProperty(hmUI.prop.TEXT, 'UV Index');
				break;
			case 1:
				normal_uvi_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_right_object_text.setProperty(hmUI.prop.TEXT, 'Humidity');
				break;
			case 2:
				normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_right_object_text.setProperty(hmUI.prop.TEXT, 'Temperature');
			}
			rightNumber = rightNumber + 1;
			if (rightNumber >= 3) { rightNumber = 0; }
		}

		function click_Color() {
			colorNumber = colorNumber + 1;
			if (colorNumber >= themeColors.length) { colorNumber = 0; }
			hmUI.showToast({text: themeColors[colorNumber]});
			let numPng = parseInt(colorNumber) + ".png";
			normal_image_img.setProperty(hmUI.prop.SRC, 'scale_' + numPng);
			normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 'hour_' + numPng);
			normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, 'min_' + numPng);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, 'sec_' + numPng);
		}

		function click_Dimmer() {
			brightnessVal = brightnessVal - 10;
			if (brightnessVal < brightnessValMin) { brightnessVal = 100; }
			hmUI.showToast({text: 'Brightness: ' + parseInt(brightnessVal) + '%'});
			hmSetting.setBrightness(brightnessVal);
		}

		function click_Pointer() {
			pointerOn = !pointerOn;
			normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, pointerOn);
			normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, pointerOn);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, pointerOn);
		}

		function vibro(scene = 25) {
			let stopDelay = 50;
			stopVibro();
			vibrate.stop();
			vibrate.scene = scene;
			if(scene < 23 || scene> 25) stopDelay = 1300;
			vibrate.start();
			if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
		}

		function stopVibro(){
			vibrate.stop();
			if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
		}

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_uvi_current_text_font = ''
        let normal_humidity_current_text_font = ''
        let normal_pai_weekly_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_background_bg_img = ''
        let idle_year_text_font = ''
        let idle_day_text_font = ''
        let idle_month_text_font = ''
        let idle_date_img_date_week_img = ''
        let idle_time_hour_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_minute_text_font = ''
        let idle_digital_clock_img_time_AmPm = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let Button_16 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js

			normal_left_object_text = hmUI.createWidget(hmUI.widget.TEXT, {
				x: 61,
				y: 240,
				w: 140,
				h: 30,
				text_size: 20,
				char_space: 0,
				line_space: 0,
				text: 'Heart Rate',
				color: 0xFFFF8C00,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.TOP,
				text_style: hmUI.text_style.ELLIPSIS,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			normal_right_object_text = hmUI.createWidget(hmUI.widget.TEXT, {
				x: 253,
				y: 240,
				w: 140,
				h: 30,
				text_size: 20,
				char_space: 0,
				line_space: 0,
				text: 'Temperature',
				color: 0xFFFF8C00,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.TOP,
				text_style: hmUI.text_style.ELLIPSIS,
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            // end user_script.js

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'scale_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 247,
              y: 346,
              w: 60,
              h: 34,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 171,
              y: 354,
              image_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 263,
              y: 171,
              w: 120,
              h: 96,
              text_size: 55,
              char_space: 0,
              line_space: 0,
              color: 0xFF24AAE2,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 263,
              y: 171,
              w: 120,
              h: 96,
              text_size: 55,
              char_space: 0,
              line_space: 0,
              color: 0xFF24AAE2,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 71,
              y: 171,
              w: 120,
              h: 96,
              text_size: 55,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 71,
              y: 171,
              w: 120,
              h: 96,
              text_size: 55,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 71,
              y: 171,
              w: 120,
              h: 96,
              text_size: 55,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 263,
              y: 171,
              w: 120,
              h: 96,
              text_size: 55,
              char_space: 0,
              line_space: 0,
              color: 0xFF24AAE2,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 211,
              y: 153,
              image_array: ["weather_00.png","weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'steps.png',
              center_x: 227,
              center_y: 227,
              x: 16,
              y: 165,
              start_angle: -49,
              end_angle: 49,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 139,
              y: 79,
              w: 176,
              h: 96,
              text_size: 56,
              char_space: 0,
              line_space: 0,
              color: 0xFF24AAE2,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 115,
              y: 264,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 269,
              day_startY: 264,
              day_sc_array: ["num_bd70_0.png","num_bd70_1.png","num_bd70_2.png","num_bd70_3.png","num_bd70_4.png","num_bd70_5.png","num_bd70_6.png","num_bd70_7.png","num_bd70_8.png","num_bd70_9.png"],
              day_tc_array: ["num_bd70_0.png","num_bd70_1.png","num_bd70_2.png","num_bd70_3.png","num_bd70_4.png","num_bd70_5.png","num_bd70_6.png","num_bd70_7.png","num_bd70_8.png","num_bd70_9.png"],
              day_en_array: ["num_bd70_0.png","num_bd70_1.png","num_bd70_2.png","num_bd70_3.png","num_bd70_4.png","num_bd70_5.png","num_bd70_6.png","num_bd70_7.png","num_bd70_8.png","num_bd70_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 183,
              month_startY: 264,
              month_sc_array: ["num_bd70_0.png","num_bd70_1.png","num_bd70_2.png","num_bd70_3.png","num_bd70_4.png","num_bd70_5.png","num_bd70_6.png","num_bd70_7.png","num_bd70_8.png","num_bd70_9.png"],
              month_tc_array: ["num_bd70_0.png","num_bd70_1.png","num_bd70_2.png","num_bd70_3.png","num_bd70_4.png","num_bd70_5.png","num_bd70_6.png","num_bd70_7.png","num_bd70_8.png","num_bd70_9.png"],
              month_en_array: ["num_bd70_0.png","num_bd70_1.png","num_bd70_2.png","num_bd70_3.png","num_bd70_4.png","num_bd70_5.png","num_bd70_6.png","num_bd70_7.png","num_bd70_8.png","num_bd70_9.png"],
              month_zero: 0,
              month_space: 0,
              month_unit_sc: 'bd70_period.png',
              month_unit_tc: 'bd70_period.png',
              month_unit_en: 'bd70_period.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hour_0.png',
              // center_x: 227,
              // center_y: 227,
              // x: 16,
              // y: 129,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 16,
              pos_y: 227 - 129,
              center_x: 227,
              center_y: 227,
              src: 'hour_0.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'min_0.png',
              // center_x: 227,
              // center_y: 227,
              // x: 12,
              // y: 172,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 12,
              pos_y: 227 - 172,
              center_x: 227,
              center_y: 227,
              src: 'min_0.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec_0.png',
              // center_x: 227,
              // center_y: 227,
              // x: 4,
              // y: 193,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 4,
              pos_y: 227 - 193,
              center_x: 227,
              center_y: 227,
              src: 'sec_0.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 1,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            idle_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 245,
              y: 113,
              w: 150,
              h: 70,
              text_size: 56,
              char_space: 0,
              line_space: 0,
              color: 0xFF6654A4,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 164,
              y: 113,
              w: 64,
              h: 70,
              text_size: 56,
              char_space: 0,
              line_space: 0,
              color: 0xFF6654A4,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 85,
              y: 113,
              w: 64,
              h: 70,
              text_size: 56,
              char_space: 0,
              line_space: 0,
              color: 0xFF6654A4,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 128,
              y: 50,
              week_en: ["weekday_0.png","weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png"],
              week_tc: ["weekday_0.png","weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png"],
              week_sc: ["weekday_0.png","weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 12,
              y: 150,
              w: 200,
              h: 200,
              text_size: 140,
              char_space: 0,
              line_space: 0,
              color: 0xFF24AAE2,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 242,
              y: 150,
              w: 200,
              h: 200,
              text_size: 140,
              char_space: 0,
              line_space: 0,
              color: 0xFF24AAE2,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 195,
              am_y: 340,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 195,
              pm_y: 340,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 276,
              y: 193,
              w: 100,
              h: 48,
              src: 'empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 78,
              y: 193,
              w: 100,
              h: 48,
              src: 'empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 150,
              y: 103,
              w: 150,
              h: 48,
              src: 'empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 330,
              w: 97,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                				click_Color();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 360,
              w: 128,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                				click_Color();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 390,
              w: 159,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                				click_Color();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 102,
              h: 124,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 132,
              h: 96,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 162,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 352,
              y: 330,
              w: 102,
              h: 124,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                				click_Dimmer();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 322,
              y: 358,
              w: 132,
              h: 96,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                				click_Dimmer();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 292,
              y: 388,
              w: 162,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                				click_Dimmer();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 192,
              y: 192,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                				click_Pointer();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 352,
              y: 0,
              w: 102,
              h: 124,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 322,
              y: 0,
              w: 132,
              h: 96,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 292,
              y: 0,
              w: 162,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 390,
              y: 152,
              w: 64,
              h: 150,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                				click_Right();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 152,
              w: 64,
              h: 150,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                				click_Left();
				vibro(25);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_16 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 119,
              y: 277,
              w: 219,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

			normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, true);

            // end user_script_end.js

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              if (updateHour) {
                let idle_yearStr = timeSensor.year.toString();
                idle_year_text_font.setProperty(hmUI.prop.TEXT, idle_yearStr );
              };

              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              if (updateHour) {
                let idle_monthStr = timeSensor.month.toString();
                idle_monthStr = idle_monthStr.padStart(2, '0');
                idle_month_text_font.setProperty(hmUI.prop.TEXT, idle_monthStr );
              };

              if (updateHour) {
                let idle_valueHour = hour;
                if (!timeSensor.is24Hour) {
                  idle_valueHour -= 12;
                  if (idle_valueHour < 1) idle_valueHour += 12;
                };
                let idle_hourStr = idle_valueHour.toString();
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      time_update(true, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}