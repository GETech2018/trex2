﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0

		let alt_var = 1
        let alt_all = 2
		let alt_text = ' '
		let pressure_array = read_pressure();
        let value = getPressureValue(pressure_array);
		
		let night_var = 1
        let night_all = 2
		let name_text = ' '
		let night_dig = 1
		
		let menu = 1
        let total_menu = 2
		
		let color_r = 1
        let colors_r = 8
		let namecolor_r = ' '
		
		let color_digt = 1
        let all_digt = 7
		let color_text = '0xFFFFFFFF'
		let namecolor_digt = ' '
		
		let color_bg = 7
        let totalcolors_bg = 8
		let namecolor_main = ' '
		
		let visabl_main = 1
		let totalvisabl_main = 5
		
		let xxx_clock_h = 132
		let yyy_clock_h = 323
		let xxx_clock_m = 249
		let yyy_clock_m = 323
		let xxx_clock_s = 341
		let yyy_clock_s = 324
		let xxx_clock = 218
		let yyy_clock = 315
		let xxx_day = 168
		let yyy_day = 207
		let xxx_month = 223
		let yyy_month = 207
		let xxx_day_w = 63
		let yyy_day_w = 208
		let xxx_batt = 212
		let yyy_batt = 272

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
//# барометр в мм рт. ст.


function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}



function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}
//# конец барометр в мм рт. ст.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// переключение едениц измерения давления

		

function click_ALT() {
            if(alt_var>=alt_all) {
            alt_var=1;
                }
            else {
                alt_var=alt_var+1;
            }
			if ( alt_var == 1) { 
			alt_text = "мм рт. ст."  
			value = hPa_To_mmHg(value);              // перевод в мм.рт.ст.
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
		    }			
			if ( alt_var == 2) { 
			alt_text = "гПа" 
			value = getPressureValue(pressure_array);              // перевод в гПа
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
			}
			
			hmUI.showToast({text: alt_text });
			vibro(28);
									
		}

// конец переключение едениц измерения давления

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//	возврат в дневной режим 

		function click_Day() {

		name_text = "ДНЕВНОЙ РЕЖИМ";  // "DAYTIME MODE"
		night_dig = color_digt;		
		
		 xxx_clock_h = 132
		 yyy_clock_h = 323
		 xxx_clock_m = 249
		 yyy_clock_m = 323
		 xxx_clock_s = 341
		 yyy_clock_s = 324
		 xxx_clock = 218
		 yyy_clock = 315
		 xxx_day = 168
		 yyy_day = 207
		 xxx_month = 223
		 yyy_month = 207
		 xxx_day_w = 63
		 yyy_day_w = 208
		 xxx_batt = 212
		 yyy_batt = 272

	
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: parseInt(xxx_clock_h),
              hour_startY: parseInt(yyy_clock_h),
              hour_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: parseInt(xxx_clock_m),
              minute_startY: parseInt(yyy_clock_m),
              minute_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: parseInt(xxx_clock_s),
              second_startY: parseInt(yyy_clock_s),
              second_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: xxx_clock,
              y: yyy_clock,
              src: night_dig + '_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: night_dig + '_am.png',
              am_en_path: night_dig + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: night_dig + '_pm.png',
              pm_en_path: night_dig + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	


		normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: xxx_day_w,
              y: yyy_day_w,
              week_en: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              week_tc: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              week_sc: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_date_img_date_month.setProperty(hmUI.prop.MORE, {
              month_startX: xxx_month,
              month_startY: yyy_month,
              month_sc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_tc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_en_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: xxx_day,
              day_startY: yyy_day,
              day_sc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_tc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_en_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


		normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: xxx_batt,
              y: yyy_batt,
              font_array: [night_dig + "_040.png",night_dig + "_041.png",night_dig + "_042.png",night_dig + "_043.png",night_dig + "_044.png",night_dig + "_045.png",night_dig + "_046.png",night_dig + "_047.png",night_dig + "_048.png",night_dig + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: night_dig + '_int.png',
              unit_tc: night_dig + '_int.png',
              unit_en: night_dig + '_int.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	
		normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		
			
		normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + night_dig + ".png");
		image_top_img.setProperty(hmUI.prop.VISIBLE, false);
			
			
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.VISIBLE, true);	
		
		if ( visabl_main == 1) { 		
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, true);	
		Button_7.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка давление
			};
		if ( visabl_main == 2) { 
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			};	
		if ( visabl_main == 3) { 
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			};
		if ( visabl_main == 4) { 
		normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			};
		if ( visabl_main == 5) { 
		normal_aqi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_aqi_icon_img.setProperty(hmUI.prop.VISIBLE, true);      
			};
			
		
		Button_1.setProperty(hmUI.prop.VISIBLE, true);      //   кнопка календарь
		Button_2.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка переход в ночной режим
		Button_3.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка давление, влажность, ветер ...
		Button_4.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка погодная программа
		Button_5.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка возврат в дневной режим
		Button_6.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка изменения цвета
		
		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык статистика активностей (калории)
		normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);          //   ярлык шаги 
		normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык пульса 
		normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык температуры
		normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык будильник
		normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);       //   ярлык секундомер
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык батарея		
		
		hmUI.showToast({text: name_text });
			
		vibro(28);		
				
			}
			
//	конец возврата в дневной режим 			

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
//	переход в ночной режим 			
			
		function click_Night() {		
				
		name_text = "НОЧНОЙ РЕЖИМ"   // "NIGHT MODE"
		night_dig = 'AOD'
		
		 xxx_clock_h = 64
		 yyy_clock_h = 177
		 xxx_clock_m = 214
		 yyy_clock_m = 177
		 xxx_clock_s = 354
		 yyy_clock_s = 199
		 xxx_clock = 165
		 yyy_clock = 177
		 xxx_day = 215
		 yyy_day = 64
		 xxx_month = 292
		 yyy_month = 64
		 xxx_day_w = 91
		 yyy_day_w = 64
		 xxx_batt = 184
		 yyy_batt = 311


			normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: parseInt(xxx_clock_h),
              hour_startY: parseInt(yyy_clock_h),
              hour_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: parseInt(xxx_clock_m),
              minute_startY: parseInt(yyy_clock_m),
              minute_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: parseInt(xxx_clock_s),
              second_startY: parseInt(yyy_clock_s),
              second_array: [night_dig + "_013.png",night_dig + "_014.png",night_dig + "_015.png",night_dig + "_016.png",night_dig + "_017.png",night_dig + "_018.png",night_dig + "_019.png",night_dig + "_020.png",night_dig + "_021.png",night_dig + "_022.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: xxx_clock,
              y: yyy_clock,
              src: night_dig + '_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: night_dig + '_am.png',
              am_en_path: night_dig + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: night_dig + '_pm.png',
              pm_en_path: night_dig + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	


		normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: xxx_day_w,
              y: yyy_day_w,
              week_en: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              week_tc: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              week_sc: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
		normal_date_img_date_month.setProperty(hmUI.prop.MORE, {
              month_startX: xxx_month,
              month_startY: yyy_month,
              month_sc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_tc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_en_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	
        normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: xxx_day,
              day_startY: yyy_day,
              day_sc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_tc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_en_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: xxx_batt,
              y: yyy_batt,
              font_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              padding: false,
              h_space: 3,
              unit_sc: night_dig + '_int.png',
              unit_tc: night_dig + '_int.png',
              unit_en: night_dig + '_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
		normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);	
		normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
			
		normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);	

		
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
		normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_aqi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_aqi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.VISIBLE, false);
		
		
		Button_1.setProperty(hmUI.prop.VISIBLE, false);      //   кнопка календарь
		Button_2.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка переход в ночной режим
		Button_3.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка давление, влажность, ветер ...
		Button_4.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка погодная программа
		Button_5.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка возврат в дневной режим
		Button_6.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка изменения цвета
		Button_7.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка давление
		
		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык статистика активностей (калории)
		normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);          //   ярлык шаги 
		normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык пульса 
		normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык температуры
		normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык будильник
		normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);       //   ярлык секундомер
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык батарея
		
		
		normal_background_bg_img.setProperty(hmUI.prop.SRC, night_dig + ".png");
		image_top_img.setProperty(hmUI.prop.VISIBLE, true);
		
		hmUI.showToast({text: name_text });
		vibro(28);
	
		}
		
//	конец перехода в ночной режим 		

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  изменение цвета фона

function click_BG() {
            if(color_digt>=all_digt) {
            color_digt=1;
                }
            else { 
			color_digt=color_digt+1;   
			}
			
			if ( color_digt == 1) namecolor_main = "ЦВЕТНОЙ"
			if ( color_digt == 2) namecolor_main = "БЕЛЫЙ"
			if ( color_digt == 3) namecolor_main = "ЗЕЛЁНЫЙ"
			if ( color_digt == 4) namecolor_main = "ГОЛУБОЙ"
			if ( color_digt == 5) namecolor_main = "ЖЁЛТЫЙ"
			if ( color_digt == 6) namecolor_main = "ОРАНЖЕВЫЙ"
			if ( color_digt == 7) namecolor_main = "СЕРОСИНИЙ"



		normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + parseInt(color_digt) + ".png");	
		normal_image_img.setProperty(hmUI.prop.SRC, "BG_TOP_" + parseInt(color_digt) + ".png");	
		normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.MORE, {
              second_path: 'sek_' + parseInt(color_digt) + '.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 126,
              second_posY: 236,
              fresh_frequency: 17,
              fresh_freqency: 17,
              second_cover_path: 'TOP_' + parseInt(color_digt) + '.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 302,
              y: 166,
              image_array: [parseInt(color_digt) + "_wth00.png",parseInt(color_digt) + "_wth01.png",parseInt(color_digt) + "_wth02.png",parseInt(color_digt) + "_wth03.png",parseInt(color_digt) + "_wth04.png",parseInt(color_digt) + "_wth05.png",parseInt(color_digt) + "_wth06.png",parseInt(color_digt) + "_wth07.png",parseInt(color_digt) + "_wth08.png",parseInt(color_digt) + "_wth09.png",parseInt(color_digt) + "_wth10.png",parseInt(color_digt) + "_wth11.png",parseInt(color_digt) + "_wth12.png",parseInt(color_digt) + "_wth13.png",parseInt(color_digt) + "_wth14.png",parseInt(color_digt) + "_wth15.png",parseInt(color_digt) + "_wth16.png",parseInt(color_digt) + "_wth17.png",parseInt(color_digt) + "_wth18.png",parseInt(color_digt) + "_wth19.png",parseInt(color_digt) + "_wth20.png",parseInt(color_digt) + "_wth21.png",parseInt(color_digt) + "_wth22.png",parseInt(color_digt) + "_wth23.png",parseInt(color_digt) + "_wth24.png",parseInt(color_digt) + "_wth25.png",parseInt(color_digt) + "_wth26.png",parseInt(color_digt) + "_wth27.png",parseInt(color_digt) + "_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
			
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: parseInt(color_digt) + '_am.png',
              am_en_path: parseInt(color_digt) + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: parseInt(color_digt) + '_pm.png',
              pm_en_path: parseInt(color_digt) + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
		
		normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: parseInt(color_digt) + '_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			
		
		
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: 132,
              hour_startY: 323,
              hour_array: [parseInt(color_digt) + "_001.png",parseInt(color_digt) + "_002.png",parseInt(color_digt) + "_003.png",parseInt(color_digt) + "_004.png",parseInt(color_digt) + "_005.png",parseInt(color_digt) + "_006.png",parseInt(color_digt) + "_007.png",parseInt(color_digt) + "_008.png",parseInt(color_digt) + "_009.png",parseInt(color_digt) + "_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 249,
              minute_startY: 323,
              minute_array: [parseInt(color_digt) + "_001.png",parseInt(color_digt) + "_002.png",parseInt(color_digt) + "_003.png",parseInt(color_digt) + "_004.png",parseInt(color_digt) + "_005.png",parseInt(color_digt) + "_006.png",parseInt(color_digt) + "_007.png",parseInt(color_digt) + "_008.png",parseInt(color_digt) + "_009.png",parseInt(color_digt) + "_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 341,
              second_startY: 324,
              second_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_011.png");
	
		
		normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 168,
              day_startY: 207,
              day_sc_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              day_tc_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              day_en_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_month.setProperty(hmUI.prop.MORE, {
              month_startX: 223
              month_startY: 207,
              month_sc_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              month_tc_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              month_en_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 63,
              y: 208,
              week_en: [parseInt(color_digt) + "_023.png",parseInt(color_digt) + "_024.png",parseInt(color_digt) + "_025.png",parseInt(color_digt) + "_026.png",parseInt(color_digt) + "_027.png",parseInt(color_digt) + "_028.png",parseInt(color_digt) + "_029.png"],
              week_tc: [parseInt(color_digt) + "_023.png",parseInt(color_digt) + "_024.png",parseInt(color_digt) + "_025.png",parseInt(color_digt) + "_026.png",parseInt(color_digt) + "_027.png",parseInt(color_digt) + "_028.png",parseInt(color_digt) + "_029.png"],
              week_sc: [parseInt(color_digt) + "_023.png",parseInt(color_digt) + "_024.png",parseInt(color_digt) + "_025.png",parseInt(color_digt) + "_026.png",parseInt(color_digt) + "_027.png",parseInt(color_digt) + "_028.png",parseInt(color_digt) + "_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 332,
              y: 96,
              font_array: [parseInt(color_digt) + "_030.png",parseInt(color_digt) + "_031.png",parseInt(color_digt) + "_032.png",parseInt(color_digt) + "_033.png",parseInt(color_digt) + "_034.png",parseInt(color_digt) + "_035.png",parseInt(color_digt) + "_036.png",parseInt(color_digt) + "_037.png",parseInt(color_digt) + "_038.png",parseInt(color_digt) + "_039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
			
		normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 179,
              y: 95,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 254,
              y: 47,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
				
		normal_pai_weekly_text_img.setProperty(hmUI.prop.MORE, {
              x: 229,
              y: 148,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_pai_day_text_img.setProperty(hmUI.prop.MORE, {
              x: 159,
              y: 148,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

		normal_pai_day_separator_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_minus.png");	
	
		
		
		
		normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 212,
              y: 272,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_digt) + '_int.png',
              unit_tc: parseInt(color_digt) + '_int.png',
              unit_en: parseInt(color_digt) + '_int.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
		
		
        normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 363,
              y: 179,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_digt) + '_dig.png',
              unit_tc: parseInt(color_digt) + '_dig.png',
              unit_en: parseInt(color_digt) + '_dig.png',
              imperial_unit_sc: parseInt(color_digt) + '_dig.png',
              imperial_unit_tc: parseInt(color_digt) + '_dig.png',
              imperial_unit_en: parseInt(color_digt) + '_dig.png',
              negative_image: parseInt(color_digt) + '_minus.png',
              invalid_image: parseInt(color_digt) + '_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
		
		
		normal_altimeter_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_pres.png"); 
		normal_altimeter_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 350,
              y: 239,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


		normal_aqi_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_aqi.png");
		normal_aqi_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 372,
              y: 239,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              invalid_image: parseInt(color_digt) + '_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_uvi_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_uv.png");
        normal_uvi_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 370,
              y: 239,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              invalid_image: parseInt(color_digt) + '_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 323,
              y: 233,
              image_array: [parseInt(color_digt) + "_WD_1_N.png",parseInt(color_digt) + "_WD_2_NE.png",parseInt(color_digt) + "_WD_3_E.png",parseInt(color_digt) + "_WD_4_SE.png",parseInt(color_digt) + "_WD_5_S.png",parseInt(color_digt) + "_WD_6_SW.png",parseInt(color_digt) + "_WD_7_W.png",parseInt(color_digt) + "_WD_8_NW.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_wind_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 383,
              y: 239,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_humidity_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_hum.png");
        normal_humidity_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 351,
              y: 239,
              font_array: [parseInt(color_digt) + "_040.png",parseInt(color_digt) + "_041.png",parseInt(color_digt) + "_042.png",parseInt(color_digt) + "_043.png",parseInt(color_digt) + "_044.png",parseInt(color_digt) + "_045.png",parseInt(color_digt) + "_046.png",parseInt(color_digt) + "_047.png",parseInt(color_digt) + "_048.png",parseInt(color_digt) + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_digt) + '_int.png',
              unit_tc: parseInt(color_digt) + '_int.png',
              unit_en: parseInt(color_digt) + '_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


			
			

			hmUI.showToast({text: namecolor_main });	
				
			vibro(28);
					
			}
 //  конец  изменения цвета фона	



//  переключение между покахателями давление влажность ....

function click_visabl() {
            if(visabl_main>=totalvisabl_main) {
            visabl_main=1;
                }
            else {
                visabl_main=visabl_main+1;
            }

			
			
			if ( visabl_main == 1) { 
		
		namecolor_main = "АТМОСФЕРНОЕ ДАВЛЕНИЕ"
		
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		Button_7.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка давление
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_aqi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_aqi_icon_img.setProperty(hmUI.prop.VISIBLE, false);      
	
			};
			
			if ( visabl_main == 2) { 
			
		namecolor_main = "ВЛАЖНОСТЬ ВОЗДУХА"
		
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		Button_7.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка давление
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_aqi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_aqi_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
		
			};
			
		if ( visabl_main == 3) { 
			
		namecolor_main = "СИЛА И НАПРАВЛЕНИЕ ВЕТРА"
		
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		Button_7.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка давление
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_aqi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_aqi_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
		
			};
			
		if ( visabl_main == 4) { 
			
		namecolor_main = "ИНДЕКС УЛЬТРОФИОЛЕТА"
		
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		Button_7.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка давление
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_aqi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_aqi_icon_img.setProperty(hmUI.prop.VISIBLE, false);  
		
			};	
	
		if ( visabl_main == 5) { 
			
		namecolor_main = "ИНДЕКС КАЧЕСТВА ВОЗДУХА"
		
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		Button_7.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка давление
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_aqi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_aqi_icon_img.setProperty(hmUI.prop.VISIBLE, true);  
		
			};
	
			hmUI.showToast({text: namecolor_main });
			
			vibro(28);
		}

// конец переключения между отображением пульса/калорий и давлением/влажностью




		
	
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_aqi_icon_img = ''
        let normal_aqi_text_text_img = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_pai_linear_scale = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_pai_day_separator_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_image_img = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 63,
              y: 208,
              week_en: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_tc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_sc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 223,
              month_startY: 207,
              month_sc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_tc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_en_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 168,
              day_startY: 207,
              day_sc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_tc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_en_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'databg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_battery_linear_scale.setAlpha(175);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 107,
              // start_y: 275,
              // color: 0xFF000000,
              // lenght: 104,
              // line_width: 29,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 175,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 272,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["AOD_batt_01.png","AOD_batt_02.png","AOD_batt_03.png","AOD_batt_04.png","AOD_batt_05.png","AOD_batt_06.png","AOD_batt_07.png","AOD_batt_08.png","AOD_batt_09.png","AOD_batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 302,
              y: 166,
              image_array: ["1_wth00.png","1_wth01.png","1_wth02.png","1_wth03.png","1_wth04.png","1_wth05.png","1_wth06.png","1_wth07.png","1_wth08.png","1_wth09.png","1_wth10.png","1_wth11.png","1_wth12.png","1_wth13.png","1_wth14.png","1_wth15.png","1_wth16.png","1_wth17.png","1_wth18.png","1_wth19.png","1_wth20.png","1_wth21.png","1_wth22.png","1_wth23.png","1_wth24.png","1_wth25.png","1_wth26.png","1_wth27.png","1_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 179,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_dig.png',
              unit_tc: '1_dig.png',
              unit_en: '1_dig.png',
              imperial_unit_sc: '1_dig.png',
              imperial_unit_tc: '1_dig.png',
              imperial_unit_en: '1_dig.png',
              negative_image: '1_minus.png',
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 363,
                y: 179,
                font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
                padding: false,
                h_space: 0,
                unit_sc: '1_dig.png',
                unit_tc: '1_dig.png',
                unit_en: '1_dig.png',
                imperial_unit_sc: '1_dig.png',
                imperial_unit_tc: '1_dig.png',
                imperial_unit_en: '1_dig.png',
                negative_image: '1_minus.png',
                invalid_image: '1_eror.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_aqi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1_aqi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_aqi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 372,
              y: 239,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1_uv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 370,
              y: 239,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 323,
              y: 233,
              image_array: ["1_WD_1_N.png","1_WD_2_NE.png","1_WD_3_E.png","1_WD_4_SE.png","1_WD_5_S.png","1_WD_6_SW.png","1_WD_7_W.png","1_WD_8_NW.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 383,
              y: 239,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1_hum.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 351,
              y: 239,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1_pres.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 239,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_pai_linear_scale.setAlpha(175);
            };

            // normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 49,
              // start_y: 149,
              // color: 0xFF000000,
              // lenght: 104,
              // line_width: 29,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 175,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 148,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 159,
              y: 148,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 148,
              src: '1_minus.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_heart_rate_linear_scale.setAlpha(175);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 264,
              // start_y: 97,
              // color: 0xFF000000,
              // lenght: 61,
              // line_width: 29,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 175,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 96,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_calorie_linear_scale.setAlpha(175);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 67,
              // start_y: 96,
              // color: 0xFF000000,
              // lenght: 104,
              // line_width: 29,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 175,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 95,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_step_linear_scale.setAlpha(175);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 125,
              // start_y: 48,
              // color: 0xFF000000,
              // lenght: 104,
              // line_width: 29,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 175,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 47,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '1_am.png',
              am_en_path: '1_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '1_pm.png',
              pm_en_path: '1_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 132,
              hour_startY: 323,
              hour_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 249,
              minute_startY: 323,
              minute_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 341,
              second_startY: 324,
              second_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 315,
              src: '1_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG_TOP_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sek_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 126,
              // y: 236,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'TOP_1.png',
              // cover_x: 0,
              // cover_y: 0,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sek_1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 126,
              second_posY: 236,
              fresh_frequency: 17,
              fresh_freqency: 17,
              second_cover_path: 'TOP_1.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 17,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '1_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 91,
              y: 64,
              week_en: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_tc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_sc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 292,
              month_startY: 64,
              month_sc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_tc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_en_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 215,
              day_startY: 64,
              day_sc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_tc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_en_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 311,
              font_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'AOD_int.png',
              unit_tc: 'AOD_int.png',
              unit_en: 'AOD_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["AOD_batt_01.png","AOD_batt_02.png","AOD_batt_03.png","AOD_batt_04.png","AOD_batt_05.png","AOD_batt_06.png","AOD_batt_07.png","AOD_batt_08.png","AOD_batt_09.png","AOD_batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'AOD_am.png',
              am_en_path: 'AOD_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'AOD_pm.png',
              pm_en_path: 'AOD_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 64,
              hour_startY: 177,
              hour_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 214,
              minute_startY: 177,
              minute_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 354,
              second_startY: 199,
              second_array: ["AOD_013.png","AOD_014.png","AOD_015.png","AOD_016.png","AOD_017.png","AOD_018.png","AOD_019.png","AOD_020.png","AOD_021.png","AOD_022.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 177,
              src: 'AOD_011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOD_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOD_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,
              y: 30,
              w: 254,
              h: 56,
              src: '00_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 56,
              y: 88,
              w: 196,
              h: 50,
              src: '00_empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 263,
              y: 90,
              w: 131,
              h: 59,
              src: '00_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 44,
              y: 141,
              w: 216,
              h: 54,
              src: '00_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 102,
              y: 261,
              w: 178,
              h: 55,
              src: '00_empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 358,
              y: 159,
              w: 85,
              h: 66,
              src: '00_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 338,
              y: 308,
              w: 72,
              h: 79,
              src: '00_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 260,
              w: 67,
              h: 83,
              src: '00_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 56,
              y: 198,
              w: 215,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 101,
              y: 322,
              w: 116,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 230,
              w: 101,
              h: 74,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_visabl()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 288,
              y: 159,
              w: 66,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 71,
              y: 164,
              w: 195,
              h: 125,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Day()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 226,
              y: 322,
              w: 104,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_BG()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 395,
              y: 230,
              w: 56,
              h: 74,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_ALT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let pressure_array = read_pressure();
let value = getPressureValue(pressure_array);
value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.
 
normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));

normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	
Button_5.setProperty(hmUI.prop.VISIBLE, false);	
normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
image_top_img.setProperty(hmUI.prop.VISIBLE, false);	

normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
normal_aqi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
normal_aqi_icon_img.setProperty(hmUI.prop.VISIBLE, false);




            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 211;
                  let start_y_normal_battery = 275;
                  let lenght_ls_normal_battery = -104;
                  let line_width_ls_normal_battery = 29;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_ls_normal_pai = 1 - progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_linear_scale
                  // initial parameters
                  let start_x_normal_pai = 153;
                  let start_y_normal_pai = 149;
                  let lenght_ls_normal_pai = -104;
                  let line_width_ls_normal_pai = 29;
                  let color_ls_normal_pai = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_pai_draw = start_x_normal_pai;
                  let start_y_normal_pai_draw = start_y_normal_pai;
                  lenght_ls_normal_pai = lenght_ls_normal_pai * progress_ls_normal_pai;
                  let lenght_ls_normal_pai_draw = lenght_ls_normal_pai;
                  let line_width_ls_normal_pai_draw = line_width_ls_normal_pai;
                  if (lenght_ls_normal_pai < 0){
                    lenght_ls_normal_pai_draw = -lenght_ls_normal_pai;
                    start_x_normal_pai_draw = start_x_normal_pai - lenght_ls_normal_pai_draw;
                  };
                  
                  normal_pai_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_pai_draw,
                    y: start_y_normal_pai_draw,
                    w: lenght_ls_normal_pai_draw,
                    h: line_width_ls_normal_pai_draw,
                    color: color_ls_normal_pai,
                  });
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 325;
                  let start_y_normal_heart_rate = 97;
                  let lenght_ls_normal_heart_rate = -61;
                  let line_width_ls_normal_heart_rate = 29;
                  let color_ls_normal_heart_rate = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = 1 - progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 171;
                  let start_y_normal_calorie = 96;
                  let lenght_ls_normal_calorie = -104;
                  let line_width_ls_normal_calorie = 29;
                  let color_ls_normal_calorie = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 229;
                  let start_y_normal_step = 48;
                  let lenght_ls_normal_step = -104;
                  let line_width_ls_normal_step = 29;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}