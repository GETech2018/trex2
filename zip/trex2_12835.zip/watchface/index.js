﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'base.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 179,
              font_array: ["444_(1).png","444_(2).png","444_(3).png","444_(4).png","444_(5).png","444_(6).png","444_(7).png","444_(8).png","444_(9).png","444_(91).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 121,
              y: 151,
              image_array: ["84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 164,
              week_en: ["111.png","112.png","113.png","114.png","115.png","116.png","117.png"],
              week_tc: ["111.png","112.png","113.png","114.png","115.png","116.png","117.png"],
              week_sc: ["111.png","112.png","113.png","114.png","115.png","116.png","117.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 217,
              month_startY: 161,
              month_sc_array: ["0011 (1).png","0011 (2).png","0011 (3).png","0011 (4).png","0011 (5).png","0011 (6).png","0011 (7).png","0011 (8).png","0011 (9).png","0011 (91).png"],
              month_tc_array: ["0011 (1).png","0011 (2).png","0011 (3).png","0011 (4).png","0011 (5).png","0011 (6).png","0011 (7).png","0011 (8).png","0011 (9).png","0011 (91).png"],
              month_en_array: ["0011 (1).png","0011 (2).png","0011 (3).png","0011 (4).png","0011 (5).png","0011 (6).png","0011 (7).png","0011 (8).png","0011 (9).png","0011 (91).png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 290,
              day_startY: 161,
              day_sc_array: ["0011 (1).png","0011 (2).png","0011 (3).png","0011 (4).png","0011 (5).png","0011 (6).png","0011 (7).png","0011 (8).png","0011 (9).png","0011 (91).png"],
              day_tc_array: ["0011 (1).png","0011 (2).png","0011 (3).png","0011 (4).png","0011 (5).png","0011 (6).png","0011 (7).png","0011 (8).png","0011 (9).png","0011 (91).png"],
              day_en_array: ["0011 (1).png","0011 (2).png","0011 (3).png","0011 (4).png","0011 (5).png","0011 (6).png","0011 (7).png","0011 (8).png","0011 (9).png","0011 (91).png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 104,
              hour_startY: 222,
              hour_array: ["334_(1).png","334_(2).png","334_(3).png","334_(4).png","334_(5).png","334_(6).png","334_(7).png","334_(8).png","334_(9).png","334_(91).png"],
              hour_zero: 0,
              hour_space: -3,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 203,
              minute_startY: 222,
              minute_array: ["334_(1).png","334_(2).png","334_(3).png","334_(4).png","334_(5).png","334_(6).png","334_(7).png","334_(8).png","334_(9).png","334_(91).png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 290,
              second_startY: 246,
              second_array: ["0011 (1).png","0011 (2).png","0011 (3).png","0011 (4).png","0011 (5).png","0011 (6).png","0011 (7).png","0011 (8).png","0011 (9).png","0011 (91).png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'dark_base_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 217,
              month_startY: 161,
              month_sc_array: ["634_(1).png","634_(2).png","634_(3).png","634_(4).png","634_(5).png","634_(6).png","634_(7).png","634_(8).png","634_(9).png","644_(91).png"],
              month_tc_array: ["634_(1).png","634_(2).png","634_(3).png","634_(4).png","634_(5).png","634_(6).png","634_(7).png","634_(8).png","634_(9).png","644_(91).png"],
              month_en_array: ["634_(1).png","634_(2).png","634_(3).png","634_(4).png","634_(5).png","634_(6).png","634_(7).png","634_(8).png","634_(9).png","644_(91).png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 290,
              day_startY: 161,
              day_sc_array: ["634_(1).png","634_(2).png","634_(3).png","634_(4).png","634_(5).png","634_(6).png","634_(7).png","634_(8).png","634_(9).png","644_(91).png"],
              day_tc_array: ["634_(1).png","634_(2).png","634_(3).png","634_(4).png","634_(5).png","634_(6).png","634_(7).png","634_(8).png","634_(9).png","644_(91).png"],
              day_en_array: ["634_(1).png","634_(2).png","634_(3).png","634_(4).png","634_(5).png","634_(6).png","634_(7).png","634_(8).png","634_(9).png","644_(91).png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 104,
              hour_startY: 222,
              hour_array: ["534_(1).png","534_(2).png","534_(3).png","534_(4).png","534_(5).png","534_(6).png","534_(7).png","534_(8).png","534_(9).png","534_(91).png"],
              hour_zero: 0,
              hour_space: -3,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 203,
              minute_startY: 222,
              minute_array: ["534_(1).png","534_(2).png","534_(3).png","534_(4).png","534_(5).png","534_(6).png","534_(7).png","534_(8).png","534_(9).png","534_(91).png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 290,
              second_startY: 246,
              second_array: ["634_(1).png","634_(2).png","634_(3).png","634_(4).png","634_(5).png","634_(6).png","634_(7).png","634_(8).png","634_(9).png","644_(91).png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 138,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 226,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}