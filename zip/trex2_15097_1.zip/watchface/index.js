﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let editableTimePointers = ''
        let editableTimePointers_cover_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'Ant_01.png', path: 'Back_01.png' },
                { id: 2, preview: 'Ant_02.png', path: 'Back_02.png' },
                { id: 3, preview: 'Ant_03.png', path: 'Back_03.png' },
                { id: 4, preview: 'Ant_04.png', path: 'Back_04.png' },
                { id: 5, preview: 'Ant_05.png', path: 'Back_05.png' },
                { id: 6, preview: 'Ant_06.png', path: 'Back_06.png' },
                { id: 7, preview: 'Ant_07.png', path: 'Back_07.png' },
                { id: 8, preview: 'Ant_08.png', path: 'Back_08.png' },
              ],
              count: 8,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 101,
              y: 101,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 53,
              y: 101,
              src: 'Sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 322,
              font_array: ["Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png","Nr.Giorno_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Batt.png',
              unit_tc: 'Batt.png',
              unit_en: 'Batt.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 357,
              src: 'Ico_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 244,
              y: 69,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 244,
              month_startY: 97,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 174,
              day_startY: 68,
              day_sc_array: ["Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png","Nr.Giorno_10.png"],
              day_tc_array: ["Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png","Nr.Giorno_10.png"],
              day_en_array: ["Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png","Nr.Giorno_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 267,
              am_y: 249,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 267,
              pm_y: 249,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 180,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 172,
              minute_startY: 180,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 143,
              y: 180,
              src: 'Nr.Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 101,
              y: 101,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 53,
              y: 101,
              src: 'Sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 322,
              font_array: ["Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png","Nr.Giorno_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Batt.png',
              unit_tc: 'Batt.png',
              unit_en: 'Batt.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 357,
              src: 'Ico_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 244,
              y: 69,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 244,
              month_startY: 97,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 174,
              day_startY: 68,
              day_sc_array: ["Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png","Nr.Giorno_10.png"],
              day_tc_array: ["Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png","Nr.Giorno_10.png"],
              day_en_array: ["Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png","Nr.Giorno_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 267,
              am_y: 249,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 267,
              pm_y: 249,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 180,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 172,
              minute_startY: 180,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 143,
              y: 180,
              src: 'Nr.Ore_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.ElementEditablePointers');

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  hour: {
                    centerX: 369,
                    centerY: 226,
                    posX: 57,
                    posY: 57,
                    path: 'Sec_01.png',
                  },
                  preview: 'Secb_01.png',
                },
                {
                  id: 2,
                  hour: {
                    centerX: 369,
                    centerY: 226,
                    posX: 57,
                    posY: 57,
                    path: 'Sec_02.png',
                  },
                  preview: 'Secb_02.png',
                },
                {
                  id: 3,
                  hour: {
                    centerX: 369,
                    centerY: 226,
                    posX: 57,
                    posY: 57,
                    path: 'Sec_03.png',
                  },
                  preview: 'Secb_03.png',
                },
                {
                  id: 4,
                  hour: {
                    centerX: 369,
                    centerY: 226,
                    posX: 57,
                    posY: 57,
                    path: 'Sec_04.png',
                  },
                  preview: 'Secb_04.png',
                },
                {
                  id: 5,
                  hour: {
                    centerX: 369,
                    centerY: 226,
                    posX: 57,
                    posY: 57,
                    path: 'Sec_05.png',
                  },
                  preview: 'Secb_05.png',
                },
                {
                  id: 6,
                  hour: {
                    centerX: 369,
                    centerY: 226,
                    posX: 57,
                    posY: 57,
                    path: 'Sec_06.png',
                  },
                  preview: 'Secb_06.png',
                },
                {
                  id: 7,
                  hour: {
                    centerX: 369,
                    centerY: 226,
                    posX: 57,
                    posY: 57,
                    path: 'Sec_07.png',
                  },
                  preview: 'Secb_07.png',
                },
                {
                  id: 8,
                  hour: {
                    centerX: 369,
                    centerY: 226,
                    posX: 57,
                    posY: 57,
                    path: 'Sec_08.png',
                  },
                  preview: 'Secb_08.png',
                },
              ],
              count: 8,
              default_id: 1,
              fg: '.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: '.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            editableTimePointers_cover_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 313,
              y: 170,
              src: 'Ico_02.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}