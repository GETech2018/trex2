﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 364,
              y: 102,
              src: 'Off_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 173,
              y: 105,
              src: 'Al_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 121,
              y: 24,
              image_array: ["weathera_00.png","weathera_01.png","weathera_02.png","weathera_03.png","weathera_04.png","weathera_05.png","weathera_06.png","weathera_07.png","weathera_08.png","weathera_09.png","weathera_10.png","weathera_11.png","weathera_12.png","weathera_13.png","weathera_14.png","weathera_15.png","weathera_16.png","weathera_17.png","weathera_18.png","weathera_19.png","weathera_20.png","weathera_21.png","weathera_22.png","weathera_23.png","weathera_24.png","weathera_25.png","weathera_26.png","weathera_27.png","weathera_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 32,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr.Att_13.png',
              unit_tc: 'Nr.Att_13.png',
              unit_en: 'Nr.Att_13.png',
              negative_image: 'Nr.Att_12.png',
              invalid_image: 'Nr.Att_14.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 252,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 78,
              y: 208,
              image_array: ["Indicatore_01.png","Indicatore_02.png","Indicatore_03.png","Indicatore_04.png","Indicatore_05.png","Indicatore_06.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 312,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Nr.Att_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 374,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 78,
              y: 228,
              image_array: ["Indicatore_01.png","Indicatore_02.png","Indicatore_03.png","Indicatore_04.png","Indicatore_05.png","Indicatore_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 243,
              y: 252,
              week_en: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_tc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_sc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 345,
              month_startY: 282,
              month_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              month_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              month_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 235,
              day_startY: 282,
              day_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 344,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 398,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png","Batt_08.png","Batt_09.png","Batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 37,
              hour_startY: 107,
              hour_array: ["Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png","Nr. Ore_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 213,
              minute_startY: 107,
              minute_array: ["Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png","Nr. Ore_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 107,
              src: 'Nr. Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 364,
              y: 102,
              src: 'Off_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 173,
              y: 105,
              src: 'Al_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 121,
              y: 24,
              image_array: ["weathera_00.png","weathera_01.png","weathera_02.png","weathera_03.png","weathera_04.png","weathera_05.png","weathera_06.png","weathera_07.png","weathera_08.png","weathera_09.png","weathera_10.png","weathera_11.png","weathera_12.png","weathera_13.png","weathera_14.png","weathera_15.png","weathera_16.png","weathera_17.png","weathera_18.png","weathera_19.png","weathera_20.png","weathera_21.png","weathera_22.png","weathera_23.png","weathera_24.png","weathera_25.png","weathera_26.png","weathera_27.png","weathera_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 32,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Nr.Att_13.png',
              unit_tc: 'Nr.Att_13.png',
              unit_en: 'Nr.Att_13.png',
              negative_image: 'Nr.Att_12.png',
              invalid_image: 'Nr.Att_14.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 252,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 78,
              y: 208,
              image_array: ["Indicatore_01.png","Indicatore_02.png","Indicatore_03.png","Indicatore_04.png","Indicatore_05.png","Indicatore_06.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 312,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Nr.Att_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 374,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 78,
              y: 228,
              image_array: ["Indicatore_01.png","Indicatore_02.png","Indicatore_03.png","Indicatore_04.png","Indicatore_05.png","Indicatore_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 243,
              y: 252,
              week_en: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_tc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_sc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 345,
              month_startY: 282,
              month_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              month_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              month_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 235,
              day_startY: 282,
              day_sc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_tc_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_en_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 344,
              font_array: ["Nr.Att_01.png","Nr.Att_02.png","Nr.Att_03.png","Nr.Att_04.png","Nr.Att_05.png","Nr.Att_06.png","Nr.Att_07.png","Nr.Att_08.png","Nr.Att_09.png","Nr.Att_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 398,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png","Batt_08.png","Batt_09.png","Batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 37,
              hour_startY: 107,
              hour_array: ["Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png","Nr. Ore_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 213,
              minute_startY: 107,
              minute_array: ["Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png","Nr. Ore_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 107,
              src: 'Nr. Ore_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}