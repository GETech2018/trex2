﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let idle_background_bg_img = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let timer_minute_hour_hend; // pointer sector


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '5.png',
              center_x: 342,
              center_y: 227,
              posX: 15,
              posY: 92,
              start_angle: 37,
              end_angle: 130,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '4.png',
              center_x: 102,
              center_y: 227,
              x: 15,
              y: 92,
              start_angle: 225,
              end_angle: 315,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 174,
              hour_startY: 49,
              hour_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 174,
              minute_startY: 307,
              minute_array: ["m0.png","m1.png","m2.png","m3.png","m4.png","m5.png","m6.png","m7.png","m8.png","m9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // pointer sector
            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              pos_x: 454/2-16,
              pos_y: 14-195,
              center_x: 454/2,
              center_y: 18,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              pos_x: 454/2-16,
              pos_y: 440-195,
              center_x: 454/2,
              center_y: 436,
              src: '3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // pointer sector end


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '5.png',
              center_x: 342,
              center_y: 227,
              posX: 15,
              posY: 92,
              start_angle: 37,
              end_angle: 130,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '4.png',
              center_x: 102,
              center_y: 227,
              x: 15,
              y: 92,
              start_angle: 225,
              end_angle: 315,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 174,
              hour_startY: 49,
              hour_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 174,
              minute_startY: 307,
              minute_array: ["m0.png","m1.png","m2.png","m3.png","m4.png","m5.png","m6.png","m7.png","m8.png","m9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            // pointer sector
            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              pos_x: 454/2-16,
              pos_y: 14-195,
              center_x: 454/2,
              center_y: 18,
              src: '2.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              pos_x: 454/2-16,
              pos_y: 440-195,
              center_x: 454/2,
              center_y: 436,
              src: '3.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });
            // pointer sector end

            

            // pointer sector
            let now = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                let hour = now.hour;
                let minute = now.minute;
                if (hour>11) {hour = hour - 12};
                hour = hour - 1;
                if (hour<0) {hour = 11};
                // let angle_hour = -120 - 120*hour/11 - (120/12)*minute/60;
                let angle_hour = -116 - 128*hour/11;
                let angle_min = 120*minute/60 - 60;
                if (screenType == hmSetting.screen_type.AOD) {
                  idle_analog_clock_time_pointer_minute.setProperty(hmUI.prop.ANGLE, angle_min);
                  idle_analog_clock_time_pointer_hour.setProperty(hmUI.prop.ANGLE, angle_hour);
                    
                  if (!timer_minute_hour_hend) {
                    timer_minute_hour_hend = timer.createTimer(0, 1000, (function (option) 
                    {
                      hour = now.hour;
                      minute = now.minute;
                      if (hour>11) {hour = hour - 12};
                      hour = hour - 1;
                      if (hour<0) {hour = 11};
                      // let angle_hour = -120 - 120*hour/11 - (120/12)*minute/60;
                      angle_hour = -116 - 128*hour/11;
                      angle_min = 120*minute/60 - 60

                      idle_analog_clock_time_pointer_minute.setProperty(hmUI.prop.ANGLE, angle_min);
                      idle_analog_clock_time_pointer_hour.setProperty(hmUI.prop.ANGLE, angle_hour);
                      // hmUI.showToast({text: minute.toString()});
                    })); // end timer create
                  };
                } else {
                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.ANGLE, angle_min);
                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.ANGLE, angle_hour);
                }

              }),
              pause_call: (function () {
                if (timer_minute_hour_hend) {
                  timer.stopTimer(timer_minute_hour_hend);
                  timer_minute_hour_hend = undefined;
                };
              }),
            });
            // pointer sector end


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  