﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg_dark.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 300,
              y: 144,
              src: 'i_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 64,
              y: 144,
              src: 'i_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 314,
              font_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              padding: false,
              h_space: 1,
              dot_image: 'snum_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 340,
              font_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              padding: false,
              h_space: 1,
              dot_image: 'snum_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 206,
              year_startY: 340,
              year_sc_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              year_tc_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              year_en_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              year_zero: 0,
              year_space: 1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 163,
              month_startY: 340,
              month_sc_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              month_tc_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              month_en_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              month_zero: 1,
              month_space: 1,
              month_unit_sc: 'snum_dot.png',
              month_unit_tc: 'snum_dot.png',
              month_unit_en: 'snum_dot.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 122,
              day_startY: 340,
              day_sc_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              day_tc_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              day_en_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: 'snum_dot.png',
              day_unit_tc: 'snum_dot.png',
              day_unit_en: 'snum_dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 314,
              font_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 107,
              font_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 95,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: 1,
              dot_image: 's_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 95,
              font_array: ["s_00.png","s_01.png","s_02.png","s_03.png","s_04.png","s_05.png","s_06.png","s_07.png","s_08.png","s_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 's_tmp.png',
              unit_tc: 's_tmp.png',
              unit_en: 's_tmp.png',
              negative_image: 's_minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 59,
              y: 91,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 394,
              font_array: ["num_cy_00.png","num_cy_01.png","num_cy_02.png","num_cy_03.png","num_cy_04.png","num_cy_05.png","num_cy_06.png","num_cy_07.png","num_cy_08.png","num_cy_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'num_cy_perc.png',
              unit_tc: 'num_cy_perc.png',
              unit_en: 'num_cy_perc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 19,
              font_array: ["num_yel_00.png","num_yel_01.png","num_yel_02.png","num_yel_03.png","num_yel_04.png","num_yel_05.png","num_yel_06.png","num_yel_07.png","num_yel_08.png","num_yel_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 214,
              am_y: 236,
              am_sc_path: 'i_AM.png',
              am_en_path: 'i_AM.png',
              pm_x: 214,
              pm_y: 236,
              pm_sc_path: 'i_PM.png',
              pm_en_path: 'i_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 124,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'big_sep.png',
              hour_unit_tc: 'big_sep.png',
              hour_unit_en: 'big_sep.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 215,
              second_startY: 166,
              second_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg_dark.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 314,
              font_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              padding: false,
              h_space: 1,
              dot_image: 'snum_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 340,
              font_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              padding: false,
              h_space: 1,
              dot_image: 'snum_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 206,
              year_startY: 330,
              year_sc_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              year_tc_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              year_en_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              year_zero: 0,
              year_space: 1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 163,
              month_startY: 330,
              month_sc_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              month_tc_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              month_en_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              month_zero: 1,
              month_space: 1,
              month_unit_sc: 'snum_dot.png',
              month_unit_tc: 'snum_dot.png',
              month_unit_en: 'snum_dot.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 127,
              day_startY: 330,
              day_sc_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              day_tc_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              day_en_array: ["snum_00.png","snum_01.png","snum_02.png","snum_03.png","snum_04.png","snum_05.png","snum_06.png","snum_07.png","snum_08.png","snum_09.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: 'snum_dot.png',
              day_unit_tc: 'snum_dot.png',
              day_unit_en: 'snum_dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 394,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'num_perc.png',
              unit_tc: 'num_perc.png',
              unit_en: 'num_perc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 214,
              am_y: 236,
              am_sc_path: 'i_AM.png',
              am_en_path: 'i_AM.png',
              pm_x: 214,
              pm_y: 236,
              pm_sc_path: 'i_PM.png',
              pm_en_path: 'i_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 124,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'big_sep.png',
              hour_unit_tc: 'big_sep.png',
              hour_unit_en: 'big_sep.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_aod2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 283,
              y: 309,
              w: 113,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 72,
              y: 340,
              w: 166,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 72,
              y: 303,
              w: 95,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 191,
              y: 80,
              w: 76,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 27,
              y: 80,
              w: 142,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 160,
              y: 0,
              w: 142,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}