﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

 // Alternate Elements (SETTINGS)
        
let top_element_index = 1;
let top_element_count = 4;

let bottom_element_index = 1;
let bottom_element_count = 4;

///////////////////////////// NOT EDIT BELOW /////////////////////////// 

//////////////  Alternate Elements (SCRIPTS) ////////////// 

  function click_top_bar() {
  
    top_element_index++;
    if(top_element_index > top_element_count) top_element_index = 1;
    
    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, top_element_index == 1);
    normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, top_element_index == 1);
    
    normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, top_element_index == 2);
    normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, top_element_index == 2);
    
    normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, top_element_index == 3);
    normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, top_element_index == 3);
    
    normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, top_element_index == 4);
    normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, top_element_index == 4);
  
};

  function click_bottom_bar() {
  
    bottom_element_index++;
    if(bottom_element_index > bottom_element_count) bottom_element_index = 1;
     
    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, bottom_element_index == 1);
    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, bottom_element_index == 1);
    
    normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_element_index == 2);
    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, bottom_element_index == 2);
    
    normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, bottom_element_index == 3);
    normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_element_index == 3);
    
    normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, bottom_element_index == 4);
    normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, bottom_element_index == 4);
  
};

/////////////////////////////////////////////////////////////////////////////////////////////////

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_pai_icon_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_pai_icon_img = ''
        let idle_system_disconnect_img = ''
        let idle_image_img = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '00_fg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00_top_fg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 45,
              image_array: ["11_battery_1.png","11_battery_2.png","11_battery_3.png","11_battery_4.png","11_battery_5.png","11_battery_6.png","11_battery_7.png","11_battery_8.png","11_battery_9.png","11_battery_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 45,
              y: 279,
              week_en: ["08_wd_ENG_1.png","08_wd_ENG_2.png","08_wd_ENG_3.png","08_wd_ENG_4.png","08_wd_ENG_5.png","08_wd_ENG_6.png","08_wd_ENG_7.png"],
              week_tc: ["08_wd_ENG_1.png","08_wd_ENG_2.png","08_wd_ENG_3.png","08_wd_ENG_4.png","08_wd_ENG_5.png","08_wd_ENG_6.png","08_wd_ENG_7.png"],
              week_sc: ["08_wd_ENG_1.png","08_wd_ENG_2.png","08_wd_ENG_3.png","08_wd_ENG_4.png","08_wd_ENG_5.png","08_wd_ENG_6.png","08_wd_ENG_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 158,
              day_startY: 281,
              day_sc_array: ["04_XS_00.png","04_XS_01.png","04_XS_02.png","04_XS_03.png","04_XS_04.png","04_XS_05.png","04_XS_06.png","04_XS_07.png","04_XS_08.png","04_XS_09.png"],
              day_tc_array: ["04_XS_00.png","04_XS_01.png","04_XS_02.png","04_XS_03.png","04_XS_04.png","04_XS_05.png","04_XS_06.png","04_XS_07.png","04_XS_08.png","04_XS_09.png"],
              day_en_array: ["04_XS_00.png","04_XS_01.png","04_XS_02.png","04_XS_03.png","04_XS_04.png","04_XS_05.png","04_XS_06.png","04_XS_07.png","04_XS_08.png","04_XS_09.png"],
              day_zero: 1,
              day_space: -6,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 396,
              font_array: ["03_XS_00.png","03_XS_01.png","03_XS_02.png","03_XS_03.png","03_XS_04.png","03_XS_05.png","03_XS_06.png","03_XS_07.png","03_XS_08.png","03_XS_09.png"],
              padding: false,
              h_space: -5,
              angle: -70,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 235,
              y: 294,
              src: '10_alt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 397,
              font_array: ["03_XS_00.png","03_XS_01.png","03_XS_02.png","03_XS_03.png","03_XS_04.png","03_XS_05.png","03_XS_06.png","03_XS_07.png","03_XS_08.png","03_XS_09.png"],
              padding: false,
              h_space: -5,
              angle: -70,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 293,
              src: '10_baro.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 236,
              y: 288,
              src: '10_dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 408,
              font_array: ["03_XS_00.png","03_XS_01.png","03_XS_02.png","03_XS_03.png","03_XS_04.png","03_XS_05.png","03_XS_06.png","03_XS_07.png","03_XS_08.png","03_XS_09.png"],
              padding: false,
              h_space: -5,
              angle: -70,
              dot_image: '10_dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 290,
              src: '10_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 408,
              font_array: ["03_XS_00.png","03_XS_01.png","03_XS_02.png","03_XS_03.png","03_XS_04.png","03_XS_05.png","03_XS_06.png","03_XS_07.png","03_XS_08.png","03_XS_09.png"],
              padding: false,
              h_space: -5,
              angle: -70,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 289,
              y: 130,
              src: '10_UV.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 86,
              font_array: ["03_XS_00.png","03_XS_01.png","03_XS_02.png","03_XS_03.png","03_XS_04.png","03_XS_05.png","03_XS_06.png","03_XS_07.png","03_XS_08.png","03_XS_09.png"],
              padding: false,
              h_space: -5,
              angle: -71,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 289,
              y: 130,
              src: '10_temp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 97,
              font_array: ["03_XS_00.png","03_XS_01.png","03_XS_02.png","03_XS_03.png","03_XS_04.png","03_XS_05.png","03_XS_06.png","03_XS_07.png","03_XS_08.png","03_XS_09.png"],
              padding: false,
              h_space: -5,
              angle: -71,
              unit_sc: '10_degree.png',
              unit_tc: '10_degree.png',
              unit_en: '10_degree.png',
              negative_image: '10_dash.png',
              invalid_image: '10_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 287,
              y: 134,
              src: '10_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 102,
              font_array: ["03_XS_00.png","03_XS_01.png","03_XS_02.png","03_XS_03.png","03_XS_04.png","03_XS_05.png","03_XS_06.png","03_XS_07.png","03_XS_08.png","03_XS_09.png"],
              padding: false,
              h_space: -5,
              angle: -71,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 289,
              y: 130,
              src: '10_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 95,
              font_array: ["03_XS_00.png","03_XS_01.png","03_XS_02.png","03_XS_03.png","03_XS_04.png","03_XS_05.png","03_XS_06.png","03_XS_07.png","03_XS_08.png","03_XS_09.png"],
              padding: false,
              h_space: -5,
              angle: -71,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 120,
              hour_array: ["02_hh_00.png","02_hh_01.png","02_hh_02.png","02_hh_03.png","02_hh_04.png","02_hh_05.png","02_hh_06.png","02_hh_07.png","02_hh_08.png","02_hh_09.png"],
              hour_zero: 1,
              hour_space: -21,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 242,
              minute_startY: 186,
              minute_array: ["02_mm_00.png","02_mm_01.png","02_mm_02.png","02_mm_03.png","02_mm_04.png","02_mm_05.png","02_mm_06.png","02_mm_07.png","02_mm_08.png","02_mm_09.png"],
              minute_zero: 1,
              minute_space: -12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 373,
              second_startY: 230,
              second_array: ["02_ss_00.png","02_ss_01.png","02_ss_02.png","02_ss_03.png","02_ss_04.png","02_ss_05.png","02_ss_06.png","02_ss_07.png","02_ss_08.png","02_ss_09.png"],
              second_zero: 1,
              second_space: -7,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 366,
              y: 118,
              src: '10_BT_on.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 284,
              y: 368,
              src: '10_LOCK_on.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 366,
              y: 118,
              src: '10_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 309,
              y: 301,
              src: '10_AL_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 45,
              image_array: ["11_battery_1.png","11_battery_2.png","11_battery_3.png","11_battery_4.png","11_battery_5.png","11_battery_6.png","11_battery_7.png","11_battery_8.png","11_battery_9.png","11_battery_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 120,
              hour_array: ["02_hh_00.png","02_hh_01.png","02_hh_02.png","02_hh_03.png","02_hh_04.png","02_hh_05.png","02_hh_06.png","02_hh_07.png","02_hh_08.png","02_hh_09.png"],
              hour_zero: 1,
              hour_space: -21,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 242,
              minute_startY: 186,
              minute_array: ["02_mm_00.png","02_mm_01.png","02_mm_02.png","02_mm_03.png","02_mm_04.png","02_mm_05.png","02_mm_06.png","02_mm_07.png","02_mm_08.png","02_mm_09.png"],
              minute_zero: 1,
              minute_space: -12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 373,
              second_startY: 230,
              second_array: ["02_ss_00.png","02_ss_01.png","02_ss_02.png","02_ss_03.png","02_ss_04.png","02_ss_05.png","02_ss_06.png","02_ss_07.png","02_ss_08.png","02_ss_09.png"],
              second_zero: 1,
              second_space: -7,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 366,
              y: 118,
              src: '10_BT_on.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 366,
              y: 118,
              src: '10_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '01_aod_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 278,
              w: 110,
              h: 175,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_bottom_bar()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 268,
              y: 20,
              w: 110,
              h: 160,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 25,
              press_src: '10_empty.png',
              normal_src: '10_empty.png',
              click_func: (button_widget) => {
                click_top_bar()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

////////////  Initial visibility of elements //////////// 

let cc = 0

if (cc ==0 ){

    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);

    normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);

    normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    
    normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);



    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    
    normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    
    normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    
    normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false); 
  
    cc = 1;

};

            // end user_script_end.js


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}