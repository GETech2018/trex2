﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_altimeter_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 203,
              y: 17,
              image_array: ["weather0001.png","weather0002.png","weather0003.png","weather0004.png","weather0005.png","weather0006.png","weather0007.png","weather0008.png","weather0009.png","weather0010.png","weather0011.png","weather0012.png","weather0013.png","weather0014.png","weather0015.png","weather0016.png","weather0017.png","weather0018.png","weather0019.png","weather0020.png","weather0021.png","weather0022.png","weather0023.png","weather0024.png","weather0025.png","weather0026.png","weather0027.png","weather0028.png","weather0029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 63,
              font_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              padding: false,
              h_space: 2,
              dot_image: 'POINT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 94,
              y: 70,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 63,
              font_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              padding: false,
              h_space: 2,
              dot_image: 'POINT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 329,
              y: 71,
              src: '0003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 291,
              year_startY: 119,
              year_sc_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              year_tc_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              year_en_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 229,
              month_startY: 119,
              month_sc_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              month_tc_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              month_en_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 183,
              day_startY: 119,
              day_sc_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              day_tc_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              day_en_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 221,
              y: 119,
              src: 'POINT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 85,
              y: 122,
              week_en: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              week_tc: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              week_sc: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 307,
              font_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 344,
              y: 313,
              src: 'PROCENT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 83,
              y: 306,
              image_array: ["BATT01.png","BATT02.png","BATT03.png","BATT04.png","BATT05.png","BATT06.png","BATT07.png","BATT08.png","BATT09.png","BATT10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0007.png',
              center_x: 227,
              center_y: 221,
              x: 17,
              y: 229,
              start_angle: 819,
              end_angle: 57,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 32,
              hour_startY: 183,
              hour_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 176,
              minute_startY: 183,
              minute_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 319,
              second_startY: 183,
              second_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 291,
              year_startY: 119,
              year_sc_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              year_tc_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              year_en_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 229,
              month_startY: 119,
              month_sc_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              month_tc_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              month_en_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 183,
              day_startY: 119,
              day_sc_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              day_tc_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              day_en_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 221,
              y: 119,
              src: 'POINT.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 85,
              y: 122,
              week_en: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              week_tc: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              week_sc: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 307,
              font_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 246,
              y: 313,
              src: 'PROCENT.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 32,
              hour_startY: 183,
              hour_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 177,
              minute_startY: 183,
              minute_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 320,
              second_startY: 183,
              second_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}