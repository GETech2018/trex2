﻿/*
 ** Watch_Face_Editor tool
 ** watchface js version v2.1.1
 ** Copyright © SashaCX75. All Rights Reserved
 */

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger("watchface_SashaCX75");
    //end of ignored block

    //dynamic modify start

    //dynamic modify start
    function valuesAreClose(firstValue, secondValue, tolerance = 10) {
      return Math.abs(Math.abs(firstValue) - Math.abs(secondValue)) <= tolerance;
    }

    const NORMAL_SEC = 0;
    const SEMI_SMOOTH_SEC = 1;
    const SMOOTH_SEC = 2;
    
    // meta-widget class
    // aggregates normal watchface UI widgets into single object
    class MetaWidget {
      constructor(visible = true) {
        this.visible = visible;
        this.components = new Map();
      }

      show() {
        this.visible = true;
        this.draw();
      }

      hide() {
        this.visible = false;
        this.draw();
      }

      addComponent(key, component) {
        this.components.set(key, component);
        this.draw();
      }

      draw() {
        this.components.forEach((comp) => {
          comp.setProperty(hmUI.prop.VISIBLE, this.visible);
        });
      }
    }

    // img pointer class
    class ImgPointer {
      constructor(element) {
        this._element = element;

        this._angle = 0;
        this._visible = true;
      }

      get element() {
        return _element;
      }
      set element(el) {
        this._element = el;
      }

      get angle() {
        return this._angle;
      }
      set angle(a) {
        this._angle = a;
        this._element.setProperty(hmUI.prop.ANGLE, this._angle);
      }

      show() {
        this._visible = true;
        this._element.setProperty(hmUI.prop.VISIBLE, this._visible);
      }
      hide() {
        this._visible = false;
        this._element.setProperty(hmUI.prop.VISIBLE, this._visible);
      }
      get visible() {
        return this._visible;
      }
    }

    // Analog Clock class
    class AnalonClock {
      constructor(timeSensor, secMode = SEMI_SMOOTH_SEC) {
        this.timeSensor = timeSensor;

        this.hourPointers = [];
        this.minutePointers = [];
        this.secondsPointers = [];

        this.normal_angle_hour = 0;
        this.normal_angle_minute = 0;
        this.normal_angle_second = 0;

        this.normal_timerUpdate = undefined;
        this.normal_timerUpdateSec = undefined;

        this.secondsMode = secMode;
      }
      addHourPointer(pointer) {
        this.hourPointers.push(pointer);
      }
      addMinutePointer(pointer) {
        this.minutePointers.push(pointer);
      }
      addSecondsPointer(pointer) {
        this.secondsPointers.push(pointer);
      }

      update(updateHour = false, updateMinute = false) {
        let hour = this.timeSensor.hour;
        let minute = this.timeSensor.minute;
        let second = this.timeSensor.second;

        if (updateHour) {
          let normal_hour = hour;
          let normal_fullAngle_hour = 360;
          if (normal_hour > 11) normal_hour -= 12;
          this.normal_angle_hour = 0 + (normal_fullAngle_hour * normal_hour) / 12 + ((normal_fullAngle_hour / 12) * minute) / 60;
          this.hourPointers.forEach((e) => {
            if (e) e.angle = this.normal_angle_hour;
          });
        }

        if (updateMinute) {
          let normal_fullAngle_minute = 360;
          this.normal_angle_minute = 0 + (normal_fullAngle_minute * (minute + second / 60)) / 60;
          this.minutePointers.forEach((e) => {
            if (e) e.angle = this.normal_angle_minute;
          });
        }

        let normal_fullAngle_second = 360;
        this.normal_angle_second = 0 + (normal_fullAngle_second * (second + (this.timeSensor.utc % 1000) / 1000)) / 60;
        this.secondsPointers.forEach((e) => {
          if (e) e.angle = this.normal_angle_second;
        });
      }

      start_update() {
        let screenType = hmSetting.getScreenType();

        if (screenType == hmSetting.screen_type.WATCHFACE) {
          if (!this.normal_timerUpdate) {
            let animDelay = timeSensor.utc % 1000;
            let animRepeat = 1000;
            this.normal_timerUpdate = timer.createTimer(animDelay, animRepeat, (option) => {
              this.update(false, true);
            }); // end timer
          } // end timer check
        } // end screenType

        if (screenType == hmSetting.screen_type.WATCHFACE) {
          if (!this.normal_timerUpdateSec) {
            let animDelay = 0;
            let animRepeat = 1000 / 6;
            this.normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (option) => {
              this.update(false, false);
            }); // end timer
          } // end timer check
        } // end screenType
      }

      stop_update() {
        if (this.normal_timerUpdate) {
          timer.stopTimer(this.normal_timerUpdate);
          this.normal_timerUpdate = undefined;
        }
        if (this.normal_timerUpdateSec) {
          timer.stopTimer(this.normal_timerUpdateSec);
          this.normal_timerUpdateSec = undefined;
        }
      }
    }

    let normal_background_bg_img = "";
    let normal_subdial_pointer_img = "";
    let normal_analog_clock_pro_hour_pointer_img = "";
    let normal_analog_clock_pro_minute_pointer_img = "";
    let normal_analog_clock_pro_second_pointer_img = "";

    let idle_background_bg_img = "";
    let idle_analog_clock_time_pointer_hour = "";
    let idle_analog_clock_time_pointer_minute = "";

    // date display 
    let normal_date_img_date_week_img = ''
    let normal_date_img_date_month = ''
    let normal_date_img_date_day = ''
    let normal_date_day_separator_img = ''

    let normal_temperature_current_text_img = ''
    let normal_wind_direction_image_progress_img_level = ''
    let normal_wind_text_text_img = ''
    let normal_altimeter_text_text_img = ''
    let normal_altimeter_text_separator_img = ''

    let normal_sun_high_text_img = ''
    let normal_sun_high_separator_img = ''

    let normal_sun_low_text_img = ''
    let normal_sun_low_separator_img = ''

    let normal_heart_rate_text_separator_img = ''
    let normal_heart_rate_text_text_img = ''
    let normal_distance_text_text_img = ''
    let normal_distance_text_separator_img = ''
    let normal_step_current_text_img = ''
    let normal_step_current_separator_img = ''

    // switchable widgets
    let dateWidget = new MetaWidget(false);
    let baroWidget = new MetaWidget(false);
    let tempWidget = new MetaWidget(false);
    let sunHighWidget = new MetaWidget(false);
    let sunLowWidget = new MetaWidget(false);
    let windWidget = new MetaWidget(false);
    let stepWidget = new MetaWidget(false);
    let distWidget = new MetaWidget(false);
    let heartWidget = new MetaWidget(false);
    

    let timeSensor = "";

    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start

        const deviceInfo = hmSetting.getDeviceInfo();

        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        let analonClock = new AnalonClock(timeSensor, SMOOTH_SEC);

        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
          analonClock.update(true, true);
          update_digital_display();
        });

        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "normal_bg_pixel.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_subdial_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 108,
          y: 148,
          w: 83,
          h: 83,
          pos_x: 0,
          pos_y: 0,
          center_x: 83 / 2,
          center_y: 83 / 2,
          src: "normal_sub_pointer.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // date display 
        normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 131,
          y: 302,
          week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
          week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
          week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 280,
          month_startY: 302,
          month_sc_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          month_tc_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          month_en_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          month_zero: 1,
          month_space: 3,
          month_align: hmUI.align.LEFT,
          month_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 212,
          day_startY: 302,
          day_sc_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          day_tc_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          day_en_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          day_zero: 0,
          day_space: 3,
          day_align: hmUI.align.RIGHT,
          day_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 260,
          y: 302,
          src: 'point.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        dateWidget.addComponent("normal_date_day_separator_img", normal_date_day_separator_img);
        dateWidget.addComponent("normal_date_img_date_day", normal_date_img_date_day);
        dateWidget.addComponent("normal_date_img_date_month", normal_date_img_date_month);
        dateWidget.addComponent("normal_date_img_date_week_img", normal_date_img_date_week_img);

        // baro, temp, wind
        normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 205,
          y: 302,
          font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          padding: false,
          h_space: 3,
          unit_sc: 'degree_cel.png',
          unit_tc: 'degree_cel.png',
          unit_en: 'degree_cel.png',
          negative_image: 'minus.png',
          invalid_image: 'err.png',
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        tempWidget.addComponent("normal_temperature_current_text_img", normal_temperature_current_text_img);
        
        normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 186,
          y: 302,
          font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          padding: false,
          h_space: 3,
          unit_sc: 'empty.png',
          unit_tc: 'empty.png',
          unit_en: 'empty.png',
          invalid_image: 'err.png',
          dot_image: 'colon.png',
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.SUN_RISE,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 129,
          y: 302,
          src: 'up.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        sunHighWidget.addComponent("normal_sun_high_text_img", normal_sun_high_text_img)
        sunHighWidget.addComponent("normal_sun_high_separator_img", normal_sun_high_separator_img)

        normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 186,
          y: 302,
          font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          padding: false,
          h_space: 3,
          unit_sc: 'empty.png',
          unit_tc: 'empty.png',
          unit_en: 'empty.png',
          invalid_image: 'err.png',
          dot_image: 'colon.png',
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.SUN_SET,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 129,
          y: 302,
          src: 'down.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        sunLowWidget.addComponent("normal_sun_low_text_img", normal_sun_low_text_img)
        sunLowWidget.addComponent("normal_sun_low_separator_img", normal_sun_low_separator_img)

        normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 131,
          y: 302,
          image_array: ["wind1.png","wind2.png","wind3.png","wind4.png","wind5.png","wind6.png","wind7.png","wind8.png"],
          image_length: 8,
          type: hmUI.data_type.WIND_DIRECTION,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 225,
          y: 302,
          font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          padding: false,
          h_space: 3,
          unit_sc: 'mps.png',
          unit_tc: 'mps.png',
          unit_en: 'mps.png',
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.WIND,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        windWidget.addComponent("normal_wind_direction_image_progress_img_level", normal_wind_direction_image_progress_img_level);
        windWidget.addComponent("normal_wind_text_text_img", normal_wind_text_text_img);

        normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 224,
          y: 302,
          font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          padding: false,
          h_space: 3,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.ALTIMETER,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 127,
          y: 302,
          src: 'pressure.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        baroWidget.addComponent("normal_altimeter_text_separator_img", normal_altimeter_text_separator_img);
        baroWidget.addComponent("normal_altimeter_text_text_img", normal_altimeter_text_text_img);
                
        normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 252,
          y: 302,
          font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          padding: false,
          h_space: 3,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 128,
          y: 302,
          src: 'heart.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        heartWidget.addComponent("normal_heart_rate_text_separator_img", normal_heart_rate_text_separator_img);
        heartWidget.addComponent("normal_heart_rate_text_text_img", normal_heart_rate_text_text_img);

        normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 127,
          y: 302,
          src: 'dist.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 214,
          y: 302,
          font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          padding: true,
          h_space: 3,
          dot_image: 'point.png',
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.DISTANCE,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        distWidget.addComponent("normal_distance_text_separator_img", normal_distance_text_separator_img);
        distWidget.addComponent("normal_distance_text_text_img", normal_distance_text_text_img);

        normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 128,
          y: 302,
          src: 'step.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 201,
          y: 302,
          font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
          padding: false,
          h_space: 3,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        stepWidget.addComponent("normal_step_current_separator_img", normal_step_current_separator_img);
        stepWidget.addComponent("normal_step_current_text_img", normal_step_current_text_img);

        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 26,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_hour.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 26,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_minute.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 26,
          pos_y: 227 - 227,
          center_x: 227,
          center_y: 227,
          src: "normal_second.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // idle screen
        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: "idle_bg_red.png",
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: "idle_hour_red.png",
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 26,
          hour_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: "idle_minute_red.png",
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 26,
          minute_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        // switch mode button
        let switchModeButton = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 108,
          y: 148,
          w: 83,
          h: 83,
          text: "",
          normal_src: "_empty.png",
          press_src: "_empty.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            switch_dial_mode();
          },
        });

        // switch LCD button
        let switchLcdButton = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 115,
          y: 281,
          w: 220,
          h: 83,
          text: "",
          normal_src: "_empty.png",
          press_src: "_empty.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            switch_lcd_mode();
          },
        });

        let subdialPointer = new ImgPointer(normal_subdial_pointer_img);

        let clockHourPointer = new ImgPointer(normal_analog_clock_pro_hour_pointer_img);
        let clockMinutePointer = new ImgPointer(normal_analog_clock_pro_minute_pointer_img);
        let clockSecondPointer = new ImgPointer(normal_analog_clock_pro_second_pointer_img);

        analonClock.addHourPointer(clockHourPointer);
        analonClock.addMinutePointer(clockMinutePointer);
        analonClock.addSecondsPointer(clockSecondPointer);

        const MODE_TIME = 0;
        const MODE_BARO = 1;
        const MODE_TEMP = 2;
        const MODE_SUN = 3;
        const MODE_WIND = 4;
        const MODE_STEP = 5;
        const MODE_DIST = 6;
        const MODE_HEART = 7;

        let currentMode = MODE_TIME;
        let modesAngles = [0, -34, -63, -90, -118, -150, -180, -207];

        let mode_update_timer = undefined;

        function switch_dial_mode() {
          currentMode++;
          if (currentMode >= modesAngles.length) currentMode = 0;

          let targetAngle = modesAngles[currentMode];
          let step = targetAngle == 0 ? 10 : -10;

          // start update
          if (!mode_update_timer) {
            mode_update_timer = timer.createTimer(
              0,
              20,
              (option) => {
                let targetAngle = option.targetAngle;
                let step = option.step;

                subdialPointer.angle += step;
                if (valuesAreClose(subdialPointer.angle, targetAngle, 11)) {
                  subdialPointer.angle = targetAngle;

                  timer.stopTimer(mode_update_timer);
                  mode_update_timer = undefined;
                }
              },
              {
                targetAngle: targetAngle,
                step: step,
              }
            );
          }

          update_digital_display();
        }


        function hideSun() {
          sunHighWidget.hide();
          sunLowWidget.hide();
        }

        let showSunRise = false;

        function showSun() {
          if (showSunRise) {
            sunHighWidget.hide();
            sunLowWidget.show();
          }
          else {
            sunLowWidget.hide();            
            sunHighWidget.show();
          }
        }

        function switch_lcd_mode() {
          switch (currentMode) {
            case MODE_SUN:
              showSunRise = !showSunRise;              
              break;
          }
          update_digital_display();
        }

        function update_digital_display() {
          // if (screenType != hmSetting.screen_type.WATCHFACE) return;

          switch (currentMode) {
            case MODE_TIME:
              heartWidget.hide();
              dateWidget.show();
              break;
            case MODE_BARO:
              dateWidget.hide();
              baroWidget.show();
              break;
            case MODE_TEMP:
              baroWidget.hide();
              tempWidget.show();
              break;
            case MODE_SUN:
              tempWidget.hide();
              showSun();
              break;
            case MODE_WIND:
              hideSun();
              windWidget.show();
              break;  
            case MODE_STEP:
              windWidget.hide();
              stepWidget.show();
              break;  
            case MODE_DIST:
              stepWidget.hide()
              distWidget.show();
              break;  
            case MODE_HEART:
              distWidget.hide();
              heartWidget.show();
              break;        
          }
        }

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            analonClock.update(true, true);
            analonClock.start_update();

            update_digital_display();
          },
          pause_call: function () {
            analonClock.stop_update();
          },
        });

        //dynamic modify end
      },
      onInit() {
        logger.log("index page.js on init invoke");
      },
      build() {
        this.init_view();
        logger.log("index page.js on ready invoke");
      },
      onDestroy() {
        logger.log("index page.js on destroy invoke");
      },
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  e && e.stack && e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
