﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 359,
              y: 295,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 85,
              y: 293,
              src: 'alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 359,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'sm_proc.png',
              unit_tc: 'sm_proc.png',
              unit_en: 'sm_proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 359,
              src: 'i_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 89,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: -11,
              unit_sc: 'sm_temp.png',
              unit_tc: 'sm_temp.png',
              unit_en: 'sm_temp.png',
              negative_image: 'sm_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 233,
              month_startY: 57,
              month_sc_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              month_tc_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              month_en_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              month_zero: 1,
              month_space: -11,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 178,
              day_startY: 57,
              day_sc_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              day_tc_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              day_en_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              day_zero: 1,
              day_space: -11,
              day_unit_sc: 'sm_dot.png',
              day_unit_tc: 'sm_dot.png',
              day_unit_en: 'sm_dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 219,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: -11,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 400,
              y: 219,
              src: 'i_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 219,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: -12,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 23,
              y: 219,
              src: 'i_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 121,
              hour_startY: 114,
              hour_array: ["bb_00.png","bb_01.png","bb_02.png","bb_03.png","bb_04.png","bb_05.png","bb_06.png","bb_07.png","bb_08.png","bb_09.png"],
              hour_zero: 1,
              hour_space: -12,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 121,
              minute_startY: 227,
              minute_array: ["bb_00.png","bb_01.png","bb_02.png","bb_03.png","bb_04.png","bb_05.png","bb_06.png","bb_07.png","bb_08.png","bb_09.png"],
              minute_zero: 1,
              minute_space: -12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hours.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 17,
              hour_posY: 178,
              hour_cover_path: 'hand_center.png',
              hour_cover_x: 206,
              hour_cover_y: 207,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_minutes.png',
              minute_centerX: 229,
              minute_centerY: 229,
              minute_posX: 15,
              minute_posY: 185,
              minute_cover_path: 'hand_center.png',
              minute_cover_x: 206,
              minute_cover_y: 207,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_hand.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 4,
              second_posY: 262,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 233,
              month_startY: 57,
              month_sc_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              month_tc_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              month_en_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              month_zero: 1,
              month_space: -11,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 178,
              day_startY: 57,
              day_sc_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              day_tc_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              day_en_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              day_zero: 1,
              day_space: -11,
              day_unit_sc: 'sm_dot.png',
              day_unit_tc: 'sm_dot.png',
              day_unit_en: 'sm_dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 359,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'sm_proc.png',
              unit_tc: 'sm_proc.png',
              unit_en: 'sm_proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 359,
              src: 'i_batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hours.png',
              hour_centerX: 229,
              hour_centerY: 229,
              hour_posX: 17,
              hour_posY: 178,
              hour_cover_path: 'hand_center.png',
              hour_cover_x: 206,
              hour_cover_y: 207,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_minutes.png',
              minute_centerX: 229,
              minute_centerY: 229,
              minute_posX: 15,
              minute_posY: 185,
              minute_cover_path: 'hand_center.png',
              minute_cover_x: 206,
              minute_cover_y: 207,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 210,
              w: 48,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 74,
              y: 288,
              w: 48,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 343,
              y: 213,
              w: 95,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 38,
              y: 213,
              w: 95,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 179,
              y: 88,
              w: 99,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 179,
              y: 45,
              w: 99,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}